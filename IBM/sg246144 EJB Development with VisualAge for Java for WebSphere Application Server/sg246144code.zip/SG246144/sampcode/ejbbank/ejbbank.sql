echo --- load the EJBBANK database ---

echo --- connect to EJBBANK database ---
CONNECT TO EJBBANK

DELETE FROM ITSO.TRANSRECORD
DELETE FROM ITSO.SAVINGS
DELETE FROM ITSO.CHECKING
DELETE FROM ITSO.CUSTACCT
DELETE FROM ITSO.ACCOUNT
DELETE FROM ITSO.CUSTOMER

echo --- insert into CUSTOMER tables ---
INSERT INTO ITSO.CUSTOMER                                             \
   (customerid, title, firstname, lastname, userid, password) VALUES  \
   (101, 'Mr', 'Dom',     'Faidherbe',   'cust101', 'DF'),            \
   (102, 'Mr', 'Akis',    'Laftsidis',   'cust102', 'AL'),            \
   (103, 'Mr', 'Kart',    'Ponnalagu',   'cust103', 'KP'),            \
   (105, 'Ms', 'Unknown', 'Lady',         null,      null),           \
   (106, 'Mr', 'Ueli',    'Wahli',       'cust106', 'UW') 

INSERT INTO ITSO.ADDRESS                             \
   (customerid, street, city, state, zipcode) VALUES \
   (106, 'Steinway Ave', 'Campbell', 'California', '95008')
INSERT INTO ITSO.ADDRESS (customerid) VALUES (101),(102),(103),(105)

echo --- insert into ACCOUNT tables ---
INSERT INTO ITSO.ACCOUNT                    \
   (accid, acctype, balance) VALUES         \
   ('101-1001', 'CHECKING',    80.00),      \
   ('101-1002', 'SAVINGS',    375.26),      \
   ('102-2001', 'SAVINGS',   9375.26),      \
   ('102-2002', 'CHECKING',    75.50),      \
   ('103-3001', 'SAVINGS',    100.00),      \
   ('105-5001', 'CHECKING',     0.00),      \
   ('106-6001', 'CHECKING',  1000.00),      \
   ('106-6002', 'SAVINGS',   2000.00),      \
   ('106-6003', 'SAVINGS',   3000.00)

INSERT INTO ITSO.CHECKING                    \
   (accid, overdraft) VALUES                 \
   ('101-1001',200.00), ('102-2002',200.00), \
   ('105-5001',200.00), ('106-6001',300.00)

INSERT INTO ITSO.SAVINGS                                          \
   (accid, minamount) VALUES                                      \
   ('101-1002',100.00), ('102-2001',100.00), ('103-3001',150.00), \
   ('106-6002',100.00), ('106-6003',250.00)

echo --- insert into CUSTACCT table ---
INSERT INTO ITSO.CUSTACCT               \
   (customerid, accid) VALUES           \
   (101,'101-1001'), (101,'101-1002'),  \
   (102,'102-2001'), (102,'102-2002'),  \
   (103,'103-3001'), (105,'105-5001'),  \
   (106,'106-6001'), (106,'106-6002'), (106,'106-6003'), (106,'105-5001')

echo --- insert into TRANSRECORD table ---
INSERT INTO ITSO.TRANSRECORD                                    \
   (transid,           accid,      transtype, transamt) VALUES  \
   (CURRENT TIMESTAMP, '101-1001', 'C',         80.00 )
INSERT INTO ITSO.TRANSRECORD                                    \
   (transid,           accid,      transtype, transamt) VALUES  \
   (CURRENT TIMESTAMP, '101-1002', 'D',        200.00 )
INSERT INTO ITSO.TRANSRECORD                                    \
   (transid,           accid,      transtype, transamt) VALUES  \
   (CURRENT TIMESTAMP, '106-6001', 'D',         66.66 )
INSERT INTO ITSO.TRANSRECORD                                    \
   (transid,           accid,      transtype, transamt) VALUES  \
   (CURRENT TIMESTAMP, '106-6002', 'C',         66.66 )

echo --- connect reset ---
CONNECT RESET