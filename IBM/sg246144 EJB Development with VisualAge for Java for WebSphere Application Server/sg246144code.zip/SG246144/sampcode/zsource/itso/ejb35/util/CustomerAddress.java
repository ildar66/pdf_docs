package itso.ejb35.util;

/**
 * Insert the type's description here.
 * Creation date: (3/21/2001 9:25:19 AM)
 * @author: Ueli TP
 */
public class CustomerAddress implements java.io.Serializable {
	private java.lang.String fieldCity = new String();
	private java.lang.String fieldStreet = new String();
	private java.lang.String fieldState = new String();
	private java.lang.String fieldZipcode = new String();
	private final static long serialVersionUID = -4771579797517121057L;
/**
 * CustomerAddress constructor comment.
 */
public CustomerAddress() {
	super();
}
/**
 * CustomerAddress constructor comment.
 */
public CustomerAddress(String aStreet, String aCity, String aState, String aZipcode) {
	super();
	setStreet(aStreet);
	setCity(aCity);
	setState(aState);
	setZipcode(aZipcode);
}
/**
 * Gets the city property (java.lang.String) value.
 * @return The city property value.
 * @see #setCity
 */
public java.lang.String getCity() {
	return fieldCity;
}
/**
 * Gets the state property (java.lang.String) value.
 * @return The state property value.
 * @see #setState
 */
public java.lang.String getState() {
	return fieldState;
}
/**
 * Gets the street property (java.lang.String) value.
 * @return The street property value.
 * @see #setStreet
 */
public java.lang.String getStreet() {
	return fieldStreet;
}
/**
 * Gets the zipcode property (java.lang.String) value.
 * @return The zipcode property value.
 * @see #setZipcode
 */
public java.lang.String getZipcode() {
	return fieldZipcode;
}
/**
 * Sets the city property (java.lang.String) value.
 * @param city The new value for the property.
 * @see #getCity
 */
public void setCity(java.lang.String city) {
	fieldCity = city;
}
/**
 * Sets the state property (java.lang.String) value.
 * @param state The new value for the property.
 * @see #getState
 */
public void setState(java.lang.String state) {
	fieldState = state;
}
/**
 * Sets the street property (java.lang.String) value.
 * @param street The new value for the property.
 * @see #getStreet
 */
public void setStreet(java.lang.String street) {
	fieldStreet = street;
}
/**
 * Sets the zipcode property (java.lang.String) value.
 * @param zipcode The new value for the property.
 * @see #getZipcode
 */
public void setZipcode(java.lang.String zipcode) {
	fieldZipcode = zipcode;
}
}
