package itso.ejb35.rosebank;

/**
 * This is a Home interface for the Enterprise JavaBean
 */
public interface SavingsHome extends javax.ejb.EJBHome {

/**
 * create method for a CMP entity bean
 * @return itso.ejb35.rosebank.Savings
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
itso.ejb35.rosebank.Savings create() throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * findByPrimaryKey method comment
 * @return itso.ejb35.rosebank.Savings
 * @param key itso.ejb35.rosebank.BankAccountKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.ejb35.rosebank.Savings findByPrimaryKey(itso.ejb35.rosebank.BankAccountKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
