package itso.ejb35.bmp.client;

import itso.ejb35.bmp.*;
/**
 * Insert the type's description here.
 * Creation date: (5/24/2001 10:50:41 AM)
 * @author: Ueli TP
 */
public class BmpTest {
/**
 * Starts the application.
 * @param args an array of command-line arguments
 */
public static void main(java.lang.String[] args) {
  try {
	//java.util.Properties properties = new java.util.Properties();
	//properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
	//properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY,
	//						"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
	//javax.naming.InitialContext initialContext = new javax.naming.InitialContext(properties);
	javax.naming.InitialContext initialContext = new javax.naming.InitialContext();

	Object objHome = initialContext.lookup("itso/ejb35/bmp/TransactionRecord");
	TransactionRecordHome trecHome = (TransactionRecordHome)
		javax.rmi.PortableRemoteObject.narrow(objHome,TransactionRecordHome.class);

	TransactionRecord trec1 = trecHome.create("101-1001", new java.math.BigDecimal("77.77"), "C");
	java.sql.Timestamp trec1key = trec1.getTransID();
	System.out.println("TransactionRecord created: "+ trec1key);
	TransactionRecord trec2 = trecHome.findByPrimaryKey(new TransactionRecordKey(trec1key));
	System.out.println("TransactionRecord retrieved: "+trec2.getAccID());
	trec2.setTranstype("D");
	trec1.remove();
	System.out.println("TransactionRecord removed");
  } catch(Exception ex) {
	  ex.printStackTrace();
  }
}
}
