package itso.ejb35.bank.servlet;

import itso.ejb35.bank.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.transaction.UserTransaction;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 12:56:49 PM)
 * @author: Ueli TP
 */
public class AccountMgr extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
public void performTask(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
	// Set the results page URL
	String url    = "/ejb/bankservlet/AccountMgr.jsp";
	String urlerr = "/ejb/bankservlet/AccountMgrError.html";
  try {
	// Read the input parameter from the HTML Form
	String acctnr1  = request.getParameter("Account");
	String acctnr2  = request.getParameter("Account2");
	String amountx  = request.getParameter("Amount");
	String deposit  = request.getParameter("Deposit");
	String withdraw = request.getParameter("Withdraw");
	String transfer = request.getParameter("Transfer");
	String acctid1  = request.getParameter("Acct"+acctnr1);
	String acctid2  = request.getParameter("Acct"+acctnr2);

	// variables
	java.math.BigDecimal amount = new java.math.BigDecimal(amountx);
	BankAccountAccessBean acct1 = new BankAccountAccessBean();
	BankAccountAccessBean acct2 = null;
	UserTransaction transact;
	javax.naming.InitialContext ctx = new javax.naming.InitialContext();

	// check input
	if (acctid1 == null  || (transfer != null && acctid2 == null)) {
		getServletConfig().getServletContext().getRequestDispatcher(urlerr).
			forward(request, response);
		return;
	}

	// get the accounts
	acct1.setInitKey_accID(acctid1);
	if (transfer != null) {
		acct2 = new BankAccountAccessBean();
		acct2.setInitKey_accID(acctid2);
	}

	// processing
	transact = (UserTransaction)ctx.lookup("jta/usertransaction");
	transact.begin();
	if (deposit  != null) acct1.deposit(amount);
	if (withdraw != null) acct1.withdraw(amount);
	if (transfer != null) {
		acct1.withdraw(amount);
		acct2.deposit(amount);
		acct2.commitCopyHelper();
		acct2.refreshCopyHelper();
	}
	acct1.commitCopyHelper();
	acct1.refreshCopyHelper();
	transact.commit();
	
	// Forward to the results JSP
	request.setAttribute("account1", acct1);
	if (acct2 != null) 
			request.setAttribute("account2", acct2);
	else	request.setAttribute("account2", acct1);
	getServletConfig().getServletContext().getRequestDispatcher(url).
			forward(request, response);
  }	catch (Exception ex) {
		getServletConfig().getServletContext().getRequestDispatcher(urlerr).
			forward(request, response);
  }
}
}
