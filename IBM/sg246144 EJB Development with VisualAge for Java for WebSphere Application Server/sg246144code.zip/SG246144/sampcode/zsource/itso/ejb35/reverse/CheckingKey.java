package itso.ejb35.reverse;

public class CheckingKey implements java.io.Serializable {
	public java.lang.String account_accid;
	final static long serialVersionUID = 3206093459760846163L;

/**
 * Default constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public CheckingKey() {
	super();
}
/**
 * Initialize a key from the passed values
 * @param argAccount itso.ejb35.reverse.AccountKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public CheckingKey(itso.ejb35.reverse.AccountKey argAccount) {
	privateSetAccountKey(argAccount);
}
/**
 * equals method
 * @return boolean
 * @param o java.lang.Object
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public boolean equals(Object o) {
	if (o instanceof CheckingKey) {
		CheckingKey otherKey = (CheckingKey) o;
		return ((this.account_accid.equals(otherKey.account_accid)));
	}
	else
		return false;
}
/**
 * This method was generated for supporting the association named Checking CheckingAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.AccountKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.reverse.AccountKey getAccountKey() {
	itso.ejb35.reverse.AccountKey temp = null;
	temp = new itso.ejb35.reverse.AccountKey();
	boolean account_NULLTEST = true;
	account_NULLTEST &= (account_accid == null);
	temp.accid = account_accid;
	if (account_NULLTEST) temp = null;
	return temp;
}
/**
 * hashCode method
 * @return int
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public int hashCode() {
	return (account_accid.hashCode());
}
/**
 * This method was generated for supporting the association named Checking CheckingAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param inKey itso.ejb35.reverse.AccountKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void privateSetAccountKey(itso.ejb35.reverse.AccountKey inKey) {
	boolean account_NULLTEST = (inKey == null);
	if (account_NULLTEST) account_accid = null; else account_accid = inKey.accid;
}
}
