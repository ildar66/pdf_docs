package itso.ejb35.reverse;

/**
 * This is a Home interface for the Entity Bean
 */
public interface CustacctHome extends javax.ejb.EJBHome {

/**
 * create method for a CMP entity bean
 * @return itso.ejb35.reverse.Custacct
 * @param argAccount itso.ejb35.reverse.AccountKey
 * @param argCustomer itso.ejb35.reverse.CustomerKey
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
itso.ejb35.reverse.Custacct create(itso.ejb35.reverse.AccountKey argAccount, itso.ejb35.reverse.CustomerKey argCustomer) throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * findByPrimaryKey method comment
 * @return itso.ejb35.reverse.Custacct
 * @param key itso.ejb35.reverse.CustacctKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.ejb35.reverse.Custacct findByPrimaryKey(itso.ejb35.reverse.CustacctKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Custacct CAtoAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return java.util.Enumeration
 * @param inKey itso.ejb35.reverse.AccountKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
java.util.Enumeration findCustacctByAccount(itso.ejb35.reverse.AccountKey inKey) throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Custacct CAtoCustomer Customer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return java.util.Enumeration
 * @param inKey itso.ejb35.reverse.CustomerKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
java.util.Enumeration findCustacctByCustomer(itso.ejb35.reverse.CustomerKey inKey) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
