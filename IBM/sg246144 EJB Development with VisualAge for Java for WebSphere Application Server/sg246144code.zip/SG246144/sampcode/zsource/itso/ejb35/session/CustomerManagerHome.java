package itso.ejb35.session;

/**
 * This is a Home interface for the Session Bean
 */
public interface CustomerManagerHome extends javax.ejb.EJBHome {

/**
 * create method for a session bean
 * @return itso.ejb35.session.CustomerManager
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
itso.ejb35.session.CustomerManager create() throws javax.ejb.CreateException, java.rmi.RemoteException;
}
