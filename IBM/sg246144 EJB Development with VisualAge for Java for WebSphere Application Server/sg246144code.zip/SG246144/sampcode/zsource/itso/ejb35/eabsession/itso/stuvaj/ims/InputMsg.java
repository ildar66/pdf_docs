package itso.stuvaj.ims;

import com.ibm.record.*;
import java.io.*;
import java.beans.*;
/**
 * Class: ls.conn.ims.cmd.InputMsg
 * This is a generated file.  Do not edit.
 */


public class InputMsg extends com.ibm.record.CustomRecord implements java.io.Serializable
{

	  private boolean notifyWhenContentsUpdated = false;
	  protected transient PropertyChangeSupport listeners;

	  private static InputMsg initialRecord = new InputMsg();

   public InputMsg()
	  throws RecordException
   {
	  try {
		 if (this.initialRecord == null) {
			com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
			attrs.setFloatingPointFormat(com.ibm.record.IRecordAttributes.IBMFLOATINGPOINTFORMAT);
			attrs.setEndian(com.ibm.record.IRecordAttributes.BIGENDIAN);
			attrs.setRemoteIntEndian(com.ibm.record.IRecordAttributes.BIGENDIAN);
			attrs.setCodePage("037");
			attrs.setMachine(com.ibm.ivj.eab.record.cobol.CobolRecordAttributes.MVS);
			this.setRecordAttributes(attrs);
			this.setRecordType(new CustomRecordType(ls.conn.ims.cmd.InputMsg.class,32));
			this.setRawBytes(new byte[32]);
			this.setInitialValues();
		 } else {
			this.setRecordAttributes((com.ibm.ivj.eab.record.cobol.CobolRecordAttributes)this.initialRecord.getRecordAttributes().clone());
			this.setRecordType(this.initialRecord.getRecordType());
			this.setRawBytes(new byte[32]);
			System.arraycopy(this.initialRecord.getRawBytes(),0,this.getRawBytes(),0,32);
		 }
		 this.enableNotification();
	  } catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }   
   public void addPropertyChangeListener(PropertyChangeListener x) {
	  getPropertyChange().addPropertyChangeListener( x );
   }   
   public void disableNotification()
   {
	  super.disableNotification();
	  notifyWhenContentsUpdated = false;
	  return;
   }   
   public void enableNotification()
   {
	  super.enableNotification();
	  notifyWhenContentsUpdated = true;
	  return;
   }   
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, newObj);
   }   
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }   
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }   
   public java.lang.String getIN__CMD()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,14,9,0,8,false,false,false,-7,0,"X(8)",false,true);
   }   
   public short getIN__LL()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,3,4,true,false,true,-3,0,"S9(3)",false,false);
   }   
   public java.lang.String getIN__STATIONID()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,22,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }   
   public java.lang.String getIN__TRCD()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }   
   public short getIN__ZZ()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,3,4,true,false,true,-3,0,"S9(3)",false,false);
   }   
   public static Class getMetadataClass() {
	  try {
		 return Class.forName("ls.conn.ims.cmd.InputMsgInfo");
	  } catch (ClassNotFoundException e) {
		 return null;
	  }
   }   
   protected java.beans.PropertyChangeSupport getPropertyChange() {
	  if (listeners == null) {
		 listeners = new java.beans.PropertyChangeSupport(this);
	  }
	  return listeners;
   }   
   public void notifyAllVars()
	  throws RecordConversionFailureException
   {
	  if (notifyWhenContentsUpdated && this.listeners != null) {
		 firePropertyChange("IN__LL",null,getIN__LL());
		 firePropertyChange("IN__ZZ",null,getIN__ZZ());
		 firePropertyChange("IN__TRCD",null,getIN__TRCD());
		 firePropertyChange("IN__CMD",null,getIN__CMD());
		 firePropertyChange("IN__STATIONID",null,getIN__STATIONID());
	  }
   }   
   public void removePropertyChangeListener(PropertyChangeListener x) {
	  getPropertyChange().removePropertyChangeListener( x );
   }   
   public void setBytes(byte[] contents)
   {
	  super.setBytes(contents);
	  notifyAllVars();
   }   
   public void setIN__CMD(java.lang.String aIN__CMD)
	  throws RecordConversionFailureException {
	  java.lang.String oldIN__CMD = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,14,9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,14,aIN__CMD,9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  firePropertyChange("IN__CMD",oldIN__CMD,aIN__CMD);
	  return;
   }   
   public void setIN__LL(short aIN__LL)
	  throws RecordConversionFailureException {
	  short oldIN__LL = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,3,4,true,false,true,-3,0,"S9(3)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aIN__LL,0,3,4,true,false,true,-3,0,"S9(3)",false,false);
	  firePropertyChange("IN__LL",oldIN__LL,aIN__LL);
	  return;
   }   
   public void setIN__STATIONID(java.lang.String aIN__STATIONID)
	  throws RecordConversionFailureException {
	  java.lang.String oldIN__STATIONID = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,22,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,22,aIN__STATIONID,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  firePropertyChange("IN__STATIONID",oldIN__STATIONID,aIN__STATIONID);
	  return;
   }   
   public void setIN__TRCD(java.lang.String aIN__TRCD)
	  throws RecordConversionFailureException {
	  java.lang.String oldIN__TRCD = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aIN__TRCD,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  firePropertyChange("IN__TRCD",oldIN__TRCD,aIN__TRCD);
	  return;
   }   
   public void setIN__ZZ(short aIN__ZZ)
	  throws RecordConversionFailureException {
	  short oldIN__ZZ = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,3,4,true,false,true,-3,0,"S9(3)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aIN__ZZ,0,3,4,true,false,true,-3,0,"S9(3)",false,false);
	  firePropertyChange("IN__ZZ",oldIN__ZZ,aIN__ZZ);
	  return;
   }   
   public void setInitialValues() throws
	  RecordConversionFailureException,
	  RecordConversionUnsupportedException
   {
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,14, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,22, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  return;
   }   
}
