package itso.ejb35.cmp;

import java.rmi.RemoteException;
import java.security.Identity;
import java.util.Properties;
import javax.ejb.*;
import javax.naming.*;
import itso.ejb35.cmp.*;
import itso.ejb35.bmp.*;
/**
 * This is an Entity Bean class with CMP fields
 */
public class BankAccountBean implements EntityBean {
	private javax.ejb.EntityContext entityContext = null;
	final static long serialVersionUID = 3206093459760846163L;
	public String accID;
	public java.math.BigDecimal balance;
	protected itso.ejb35.bmp.TransactionRecordHome txRecHomeBMP;
	protected itso.ejb35.cmp.TransRecordHome txRecHomeCMP;
	protected boolean txRecHome  = false;   // TxRexHome not set yet
	protected boolean runWithBMP = false;   // set to true for BMP
/**
 * This method was generated for supporting the associations.
 * @return java.util.Vector
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected java.util.Vector _getLinks() {
	java.util.Vector links = new java.util.Vector();
	return links;
}
/**
 * This method was generated for supporting the associations.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected void _initLinks() {}
/**
 * This method was generated for supporting the associations.
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.RemoveException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected void _removeLinks() throws java.rmi.RemoteException, javax.ejb.RemoveException {
	java.util.Enumeration links = _getLinks().elements();
	while (links.hasMoreElements()) {
		try {
			((com.ibm.ivj.ejb.associations.interfaces.Link) (links.nextElement())).remove();
		}
		catch (javax.ejb.FinderException e) {} //Consume Finder error since I am going away
	}
}
/**
 * Insert the method's description here.
 * Creation date: (3/22/2001 2:27:29 PM)
 * @param amount java.math.BigDecimal
 * @exception itso.ejb35.cmp.InsufficientFundException The exception description.
 */
public void deposit(java.math.BigDecimal amount) {
	System.out.println("Deposit into "+accID+" balance "+balance+" amount "+amount);
	balance = balance.add(amount);
	System.out.println(" ==> new balance "+balance);
	try {
		setTxRecHome();
		if (runWithBMP) 
			txRecHomeBMP.create(accID, amount, "D");
		else
			txRecHomeCMP.create(accID, amount, "D");
		System.out.println(" ==> transaction record created");
	}
	catch (Exception e) {
		System.out.println(" ==> transaction record failed");
		e.printStackTrace();
	}
}
/**
 * ejbActivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbActivate() throws java.rmi.RemoteException {
	_initLinks();
}
/**
 * ejbCreate method for a CMP entity bean
 * @param argAccID java.lang.String
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbCreate(java.lang.String argAccID, java.math.BigDecimal argBalance) throws javax.ejb.CreateException, java.rmi.RemoteException {
	_initLinks();
	// All CMP fields should be initialized here.
	accID = argAccID;
	balance = argBalance;
}
/**
 * ejbLoad method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbLoad() throws java.rmi.RemoteException {
	_initLinks();
}
/**
 * ejbPassivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPassivate() throws java.rmi.RemoteException {}
/**
 * ejbPostCreate method for a CMP entity bean
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPostCreate() throws java.rmi.RemoteException {}
/**
 * ejbPostCreate method for a CMP entity bean
 * @param argAccID java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPostCreate(java.lang.String argAccID) throws java.rmi.RemoteException {}
/**
 * ejbRemove method comment
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.RemoveException The exception description.
 */
public void ejbRemove() throws java.rmi.RemoteException, javax.ejb.RemoveException {
	_removeLinks();
}
/**
 * ejbStore method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbStore() throws java.rmi.RemoteException {}
/**
 * Getter method for balance
 */
public java.math.BigDecimal getBalance() {
	return balance;
}
/**
 * getEntityContext method comment
 * @return javax.ejb.EntityContext
 */
public javax.ejb.EntityContext getEntityContext() {
	return entityContext;
}
/**
 * Setter method for balance
 */
public void setBalance(java.math.BigDecimal newValue) {
	this.balance = newValue;
}
/**
 * setEntityContext method comment
 * @param ctx javax.ejb.EntityContext
 * @exception java.rmi.RemoteException The exception description.
 */
public void setEntityContext(javax.ejb.EntityContext ctx) throws java.rmi.RemoteException {
	entityContext = ctx;
}
/**
 * Insert the method's description here.
 * Creation date: (4/5/2001 10:53:01 AM)
 */
protected void setTxRecHome() {
	if (!txRecHome) {
		Properties prp = getEntityContext().getEnvironment();
		String runWith = prp.getProperty("RUN_WITH_BMP");
		if (runWith!=null && runWith.equals("YES")) runWithBMP = true;
		if (runWithBMP) setTxRecHomeBMP();
		else            setTxRecHomeCMP();
		txRecHome = true;
	}
}
/**
 * Insert the method's description here.
 * Creation date: (4/5/2001 10:53:01 AM)
 */
protected void setTxRecHomeBMP() {
	try {
		//Properties prop = new Properties();		
		//prop.put( Context.PROVIDER_URL,"iiop:///" );
		//prop.put( Context.INITIAL_CONTEXT_FACTORY, 
		//			"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
		//InitialContext ctx = new InitialContext(prop);
		InitialContext ctx = new InitialContext();
		txRecHomeBMP = (itso.ejb35.bmp.TransactionRecordHome) javax.rmi.PortableRemoteObject.narrow
			( ctx.lookup("itso/ejb35/bmp/TransactionRecord"),itso.ejb35.bmp.TransactionRecordHome.class );
	} catch ( NamingException exc ) {
		System.out.println( "Error retrieving the home of TransactionRecord" );
		exc.printStackTrace();
	}	
}
/**
 * Insert the method's description here.
 * Creation date: (4/5/2001 10:53:01 AM)
 */
protected void setTxRecHomeCMP() {
	try {
		//Properties prop = new Properties();		
		//prop.put( Context.PROVIDER_URL,"iiop:///" );
		//prop.put( Context.INITIAL_CONTEXT_FACTORY, 
		//			"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
		//InitialContext ctx = new InitialContext(prop);
		InitialContext ctx = new InitialContext();
		txRecHomeCMP = (itso.ejb35.cmp.TransRecordHome) javax.rmi.PortableRemoteObject.narrow
			( ctx.lookup("itso/ejb35/cmp/TransRecord"),itso.ejb35.cmp.TransRecordHome.class );
	} catch ( NamingException exc ) {
		System.out.println( "Error retrieving the home of TransactionRecord" );
		exc.printStackTrace();
	}	
}
/**
 * unsetEntityContext method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void unsetEntityContext() throws java.rmi.RemoteException {
	entityContext = null;
}
/**
 * Insert the method's description here.
 * Creation date: (3/22/2001 2:27:29 PM)
 * @param amount java.math.BigDecimal
 * @exception itso.ejb35.util.InsufficientFundException The exception description.
 */
public void withdraw(java.math.BigDecimal amount) throws itso.ejb35.util.InsufficientFundException {
	System.out.println("Withdraw from "+accID+" balance "+balance+" amount "+amount);
	if (balance.compareTo(amount) == -1)
		throw new itso.ejb35.util.InsufficientFundException("Not enough funds");
	else
		balance = balance.subtract(amount);
	System.out.println(" ==> new balance "+balance);
	try {
		setTxRecHome();
		if (runWithBMP) 
			txRecHomeBMP.create(accID, amount, "C");
		else
			txRecHomeCMP.create(accID, amount, "C");
		System.out.println(" ==> transaction record created");
	}
	catch (Exception e) {
		System.out.println(" ==> transaction record failed");
		e.printStackTrace();
	}
}
}
