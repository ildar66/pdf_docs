package itso.ejb35.rosebank;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface BankAccount extends javax.ejb.EJBObject {

/**
 * This method was generated for supporting the association named AccountTransactions.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aTransactions itso.ejb35.rosebank.TransRecord
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void addTransactions(itso.ejb35.rosebank.TransRecord aTransactions) throws java.rmi.RemoteException;
/**
 * Getter method for accid
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getAccid() throws java.rmi.RemoteException;
/**
 * Getter method for accType
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getAccType() throws java.rmi.RemoteException;
/**
 * Getter method for balance
 * @return java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
java.math.BigDecimal getBalance() throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named AccountToCustomer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return java.util.Enumeration
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public java.util.Enumeration getCustacct() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named AccountTransactions.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return java.util.Enumeration
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
java.util.Enumeration getTransactions() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named AccountToCustomer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aCustacct itso.ejb35.rosebank.CustAcct
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void secondaryAddCustacct(itso.ejb35.rosebank.CustAcct aCustacct) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named AccountTransactions.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aTransactions itso.ejb35.rosebank.TransRecord
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void secondaryAddTransactions(itso.ejb35.rosebank.TransRecord aTransactions) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named AccountToCustomer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aCustacct itso.ejb35.rosebank.CustAcct
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void secondaryRemoveCustacct(itso.ejb35.rosebank.CustAcct aCustacct) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named AccountTransactions.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aTransactions itso.ejb35.rosebank.TransRecord
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void secondaryRemoveTransactions(itso.ejb35.rosebank.TransRecord aTransactions) throws java.rmi.RemoteException;
/**
 * Setter method for accid
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setAccid(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * Setter method for accType
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setAccType(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * Setter method for balance
 * @param newValue java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
void setBalance(java.math.BigDecimal newValue) throws java.rmi.RemoteException;
}
