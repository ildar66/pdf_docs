package itso.ejb35.util;

import java.rmi.RemoteException;
import java.util.*;
import javax.naming.*;
/**
 * Insert the type's description here.
 * Creation date: (4/30/2001 10:52:15 AM)
 * @author: Ueli TP
 */
public class HomeHelper {
	private static java.util.ResourceBundle resGlobal = 
			ResourceBundle.getBundle("EJBhome"); 
	private static InitialContext initialContext = null;
	private static Hashtable cachedHomes = new Hashtable();

	private static Object checkInCacheFor(String className) {
		if (cachedHomes.containsKey(className)) 
			return cachedHomes.get(className);
		else
			return null;
	}
	public void flushCache() {
		cachedHomes = new Hashtable();
	}
	public static Object getHomeInterface(String className, Class aClassName) 
			throws RemoteException {
		try {
			Object cached = checkInCacheFor(className);
			if (cached != null) 
				return cached;
			InitialContext initialContext = getInitialContext();
			Object homeObject = initialContext.lookup(className);
			Object remoteObject = javax.rmi.PortableRemoteObject.narrow(
											homeObject, aClassName);
			storeInCache(className, remoteObject);
			return remoteObject;
		} catch (NamingException e) {
			throw new RemoteException("Name not found in JNDI");
		}
	}
	public static InitialContext getInitialContext() throws RemoteException {
		try {
			if (initialContext == null){
				Properties prop = new Properties();
				prop.put(Context.PROVIDER_URL, 
							resGlobal.getString("Provider_URL"));
				prop.put(Context.INITIAL_CONTEXT_FACTORY,
							resGlobal.getString("Context_Factory"));
				initialContext = new InitialContext(prop);
			}
			return initialContext;
		} catch (NamingException e) {
			throw new RemoteException("Error retrieving initial context");
		}
	}
	private static void storeInCache(String className, Object remoteObject) {
		cachedHomes.put(className, remoteObject);
	}
}
