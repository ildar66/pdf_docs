package itso.ejb35.rosebank;

public class BankAccountKey implements java.io.Serializable {
	private final static long serialVersionUID = 3206093459760846163L;
	public java.lang.String accid;
/**
 * Default constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public BankAccountKey() {
	super();
}
/**
 * Initialize a key from the passed values
 * @param argAccid java.lang.String
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public BankAccountKey(java.lang.String argAccid) {
	accid = argAccid;
}
/**
 * equals method
 * @return boolean
 * @param o java.lang.Object
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public boolean equals(java.lang.Object o) {
	if (o instanceof BankAccountKey) {
		BankAccountKey otherKey = (BankAccountKey) o;
		return ((this.accid.equals(otherKey.accid)));
	}
	else
		return false;
}
/**
 * hashCode method
 * @return int
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public int hashCode() {
	return (accid.hashCode());
}
}
