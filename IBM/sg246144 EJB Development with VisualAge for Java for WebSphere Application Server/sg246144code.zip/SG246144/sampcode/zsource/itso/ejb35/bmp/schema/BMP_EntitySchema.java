package itso.ejb35.bmp.schema;

class BMP_EntitySchema extends com.ibm.vap.common.SchemaStorageClass {
/**
 * This is a textual representation of BMP_Entity to assist documentation and comparing class versions
 * Modifying the string has no effect on the actual data which is stored internally on the class
 * If a developer wishes to share their model data with another user in another repository the class
 * should be exported taking the option to export to a repository
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
static void infoString() {
/*Logical Name: BMP_Entity
Physical Name: BMP_Entity
Schema contains 
	1 table(s)
	4 column(s)
	0 foreignKey(s)
====================================================================================================
Logical Table Name: Transrecord
Physical Table Name: Transrecord
	 qualifier: ITSO
Transrecord contains: 
	4 column(s)
	0 foreign key relationship(s) 
Transrecord has primary key:  (TransID)
----------------------------------------------------------------------------------------------------
	Column Logical Name: AccID
	Column PhysicalName: AccID
	Column Type: CHAR(8)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: TransAmt
	Column PhysicalName: TransAmt
	Column Type: DECIMAL(8, 2)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: TransID
	Column PhysicalName: TransID
	Column Type: TIMESTAMP
	Nulls Allowed: no
	Part of Primary key: yes
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: TransType
	Column PhysicalName: TransType
	Column Type: CHAR(1)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapTrimStringConverter*/}
}
