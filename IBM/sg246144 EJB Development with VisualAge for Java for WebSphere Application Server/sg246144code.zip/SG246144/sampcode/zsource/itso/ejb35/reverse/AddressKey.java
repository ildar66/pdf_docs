package itso.ejb35.reverse;

public class AddressKey implements java.io.Serializable {
	public java.lang.Integer customer_customerid;
	final static long serialVersionUID = 3206093459760846163L;

/**
 * Default constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public AddressKey() {
	super();
}
/**
 * Initialize a key from the passed values
 * @param argCustomer itso.ejb35.reverse.CustomerKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public AddressKey(itso.ejb35.reverse.CustomerKey argCustomer) {
	privateSetCustomerKey(argCustomer);
}
/**
 * equals method
 * @return boolean
 * @param o java.lang.Object
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public boolean equals(Object o) {
	if (o instanceof AddressKey) {
		AddressKey otherKey = (AddressKey) o;
		return ((this.customer_customerid.equals(otherKey.customer_customerid)));
	}
	else
		return false;
}
/**
 * This method was generated for supporting the association named Address CustAddress Customer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.CustomerKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.reverse.CustomerKey getCustomerKey() {
	itso.ejb35.reverse.CustomerKey temp = null;
	temp = new itso.ejb35.reverse.CustomerKey();
	boolean customer_NULLTEST = true;
	customer_NULLTEST &= (customer_customerid == null);
	temp.customerid = ((customer_customerid == null) ? 0 : customer_customerid.intValue());
	if (customer_NULLTEST) temp = null;
	return temp;
}
/**
 * hashCode method
 * @return int
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public int hashCode() {
	return (customer_customerid.hashCode());
}
/**
 * This method was generated for supporting the association named Address CustAddress Customer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param inKey itso.ejb35.reverse.CustomerKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void privateSetCustomerKey(itso.ejb35.reverse.CustomerKey inKey) {
	boolean customer_NULLTEST = (inKey == null);
	if (customer_NULLTEST) customer_customerid = null; else customer_customerid = (new Integer(inKey.customerid));
}
}
