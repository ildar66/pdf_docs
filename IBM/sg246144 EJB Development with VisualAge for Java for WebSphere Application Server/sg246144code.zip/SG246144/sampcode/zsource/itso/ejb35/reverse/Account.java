package itso.ejb35.reverse;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface Account extends javax.ejb.EJBObject {

/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aTransrecord itso.ejb35.reverse.Transrecord
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void addTransrecord(itso.ejb35.reverse.Transrecord aTransrecord) throws java.rmi.RemoteException;
/**
 * Getter method for acctype
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getAcctype() throws java.rmi.RemoteException;
/**
 * Getter method for balance
 * @return java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
java.math.BigDecimal getBalance() throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Checking CheckingAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.Checking
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.reverse.Checking getChecking() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Custacct CAtoAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return java.util.Enumeration
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
java.util.Enumeration getCustacct() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Savings SavingsAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.Savings
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.reverse.Savings getSavings() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return java.util.Enumeration
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
java.util.Enumeration getTransrecord() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aTransrecord itso.ejb35.reverse.Transrecord
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void removeTransrecord(itso.ejb35.reverse.Transrecord aTransrecord) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Custacct CAtoAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aCustacct itso.ejb35.reverse.Custacct
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void secondaryAddCustacct(itso.ejb35.reverse.Custacct aCustacct) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aTransrecord itso.ejb35.reverse.Transrecord
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void secondaryAddTransrecord(itso.ejb35.reverse.Transrecord aTransrecord) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Custacct CAtoAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aCustacct itso.ejb35.reverse.Custacct
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void secondaryRemoveCustacct(itso.ejb35.reverse.Custacct aCustacct) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aTransrecord itso.ejb35.reverse.Transrecord
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void secondaryRemoveTransrecord(itso.ejb35.reverse.Transrecord aTransrecord) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Checking CheckingAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aChecking itso.ejb35.reverse.Checking
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void secondarySetChecking(itso.ejb35.reverse.Checking aChecking) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Savings SavingsAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aSavings itso.ejb35.reverse.Savings
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void secondarySetSavings(itso.ejb35.reverse.Savings aSavings) throws java.rmi.RemoteException;
/**
 * Setter method for acctype
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setAcctype(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * Setter method for balance
 * @param newValue java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
void setBalance(java.math.BigDecimal newValue) throws java.rmi.RemoteException;
}
