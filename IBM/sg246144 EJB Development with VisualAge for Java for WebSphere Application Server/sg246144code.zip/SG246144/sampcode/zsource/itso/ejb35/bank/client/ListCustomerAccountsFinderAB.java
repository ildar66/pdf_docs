package itso.ejb35.bank.client;

import itso.ejb35.bank.*;
import java.util.*;
import com.ibm.ivj.ejb.runtime.AccessBeanEnumeration;
import javax.transaction.UserTransaction;
import javax.naming.InitialContext;
/**
 * Insert the type's description here.
 * Creation date: (4/17/2001 7:40:47 PM)
 * @author: Ueli TP
 */
public class ListCustomerAccountsFinderAB {
/**
 * Starts the application.
 * @param args an array of command-line arguments
 */
public static void main(java.lang.String[] args) {
	// Insert code to start the application here.
  try {
	CustomerAccessBean         cust;
	BankAccountAccessBean      acct    = new BankAccountAccessBean();
	BankAccountAccessBeanTable accttab = new BankAccountAccessBeanTable();
	TransRecordAccessBean      trec    = new TransRecordAccessBean();
	TransRecordAccessBeanTable trectab;
	InitialContext             ctx     = new InitialContext();
	UserTransaction transact = (UserTransaction)ctx.lookup("jta/usertransaction");
	
	transact.begin();
	cust = new CustomerAccessBean();
	cust.setInitKey_customerID(106);
	System.out.println("Customer "+cust.getCustomerID()+" "+cust.getName());

	accttab.setBankAccountAccessBean( acct.findAccountsForCustomer(106) );
	for (int i=0; i < accttab.numberOfRows(); i++) {
	   	acct = accttab.getBankAccountAccessBean(i);
	   	String accid = ((BankAccountKey)acct.__getKey()).accID;
		System.out.println("- Account "+accid+": "+ acct.getBalance());
			
		trectab = new TransRecordAccessBeanTable();
		trectab.setTransRecordAccessBean( new AccessBeanEnumeration(acct.getBankTransactions(), trec.getClass()) );
		for (int j=0; j < trectab.numberOfRows(); j++) {
			trec = trectab.getTransRecordAccessBean(j);
			java.sql.Timestamp treckey = ((TransRecordKey)trec.__getKey()).transID;
			System.out.println("   - Transaction: "+treckey + " " +trec .getTranstype() + " " + trec.getTransamt());
		}
	}
	System.out.println("END");
	transact.commit();
  } catch(Exception ex) {
	  ex.printStackTrace();
  }
}
}
