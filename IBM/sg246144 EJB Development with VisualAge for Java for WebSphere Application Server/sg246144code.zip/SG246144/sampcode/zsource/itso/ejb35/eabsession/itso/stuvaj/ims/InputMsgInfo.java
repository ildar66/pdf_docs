package itso.stuvaj.ims;

import com.ibm.record.*;
import java.util.Vector;
import com.ibm.ivj.eab.record.cobol.*;

/**
 * Class: ls.conn.ims.cmd.InputMsgInfo
 * This is a generated file.  Do not edit.
 */

public class InputMsgInfo extends CobolDynamicRecordType implements java.io.Serializable
{

   public InputMsgInfo() throws RecordException {

	  try {

		 int[] arraySize = null;
		 Vector v = null;

		 CobolType IN__LLFieldType = new CobolType();
		 IN__LLFieldType.setAug("COMP");
		 IN__LLFieldType.setPic("S9(3)");
		 IN__LLFieldType.setPreferredType(short.class);
		 addField(new Field(IN__LLFieldType, "IN__LL"));

		 CobolType IN__ZZFieldType = new CobolType();
		 IN__ZZFieldType.setAug("COMP");
		 IN__ZZFieldType.setPic("S9(3)");
		 IN__ZZFieldType.setPreferredType(short.class);
		 addField(new Field(IN__ZZFieldType, "IN__ZZ"));

		 CobolType IN__TRCDFieldType = new CobolType();
		 IN__TRCDFieldType.setAug("DISPLAY");
		 IN__TRCDFieldType.setPic("X(10)");
		 IN__TRCDFieldType.setPreferredType(Class.forName("java.lang.String"));
		 addField(new Field(IN__TRCDFieldType, "IN__TRCD",new CobolInitialValueObject(" ,null")));

		 CobolType IN__CMDFieldType = new CobolType();
		 IN__CMDFieldType.setAug("DISPLAY");
		 IN__CMDFieldType.setPic("X(8)");
		 IN__CMDFieldType.setPreferredType(Class.forName("java.lang.String"));
		 addField(new Field(IN__CMDFieldType, "IN__CMD",new CobolInitialValueObject(" ,null")));

		 CobolType IN__STATIONIDFieldType = new CobolType();
		 IN__STATIONIDFieldType.setAug("DISPLAY");
		 IN__STATIONIDFieldType.setPic("X(10)");
		 IN__STATIONIDFieldType.setPreferredType(Class.forName("java.lang.String"));
		 addField(new Field(IN__STATIONIDFieldType, "IN__STATIONID",new CobolInitialValueObject(" ,null")));

	  }
	  catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }   
}
