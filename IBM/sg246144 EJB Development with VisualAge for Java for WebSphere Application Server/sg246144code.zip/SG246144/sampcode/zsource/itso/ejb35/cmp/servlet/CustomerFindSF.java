package itso.ejb35.cmp.servlet;

import itso.ejb35.cmp.*;
import itso.ejb35.session.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 12:56:49 PM)
 * @author: Ueli TP
 */
public class CustomerFindSF extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
	public void performTask(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
	// URL for the results page
	String url = "/ejb/cmpservlet/CustomerFindSF.jsp"; 
	// Read the input parameters from the HTML Form.
	String id = request.getParameter("CustomerID");
	int custId = (new Integer(id)).intValue();
	try {
	// Create a CustomerManager instance
		//java.util.Properties properties = new java.util.Properties();
		//properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
		//properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY, 
		//					"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
		//javax.naming.InitialContext initialContext = new javax.naming.InitialContext(properties);
		javax.naming.InitialContext initialContext = new javax.naming.InitialContext();
		Object objHome =
						initialContext.lookup("itso/ejb35/session/CustomerManager");
		CustomerManagerHome customerMgrHome = (CustomerManagerHome)javax.rmi.
			PortableRemoteObject.narrow(objHome,CustomerManagerHome.class);
		CustomerManager customerManager = customerMgrHome.create();
	// Find the customer
		Customer customer = customerManager.findCustomer(custId);
		java.util.Hashtable ht = customerManager.getAllProperties(customer);
	// Store hashtable and call JSP
		request.setAttribute("custht", ht);
		getServletConfig().getServletContext().getRequestDispatcher(url).
															forward(request, response);
	}
	catch (Exception e) {
		System.out.println("Cannot find customer with id: " + id);
	}
	}
}
