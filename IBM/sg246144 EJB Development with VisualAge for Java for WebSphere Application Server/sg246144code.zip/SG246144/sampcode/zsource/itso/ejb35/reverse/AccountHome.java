package itso.ejb35.reverse;

/**
 * This is a Home interface for the Entity Bean
 */
public interface AccountHome extends javax.ejb.EJBHome {

/**
 * create method for a CMP entity bean
 * @return itso.ejb35.reverse.Account
 * @param argAccid java.lang.String
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
itso.ejb35.reverse.Account create(java.lang.String argAccid) throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * findByPrimaryKey method comment
 * @return itso.ejb35.reverse.Account
 * @param key itso.ejb35.reverse.AccountKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.ejb35.reverse.Account findByPrimaryKey(itso.ejb35.reverse.AccountKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
