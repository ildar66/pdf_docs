package itso.ejb35.bmp.schema;

class BMP_EntityBMP_EntityMap extends com.ibm.vap.common.MapStorageClass {
/**
 * This is a textual representation of BMP_EntityBMP_Entity to assist documentation and comparing class versions
 * Modifying the string has no effect on the actual data which is stored internally on the class
 * If a developer wishes to share their model data with another user in another repository the class
 * should be exported taking the option to export to a repository
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
static void infoString() {
/*Validation error in a VapRdbDataStoreMap('BMP_EntityBMP_Entity'), the error is: 'unknown schema: 'BMP_Entity1''
====================================================================================================
DataStore Map
Model: BMP_Entity
Schema: BMP_Entity1
Map contains 0 class maps 

====================================================================================================
*/}
}
