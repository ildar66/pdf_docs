package itso.ejb35.bank.client;

import itso.ejb35.bank.*;
import java.util.*;
import javax.rmi.*;
/**
 * Insert the type's description here.
 * Creation date: (4/17/2001 7:40:47 PM)
 * @author: Ueli TP
 */
public class ListAccountTypesAB {
/**
 * Starts the application.
 * @param args an array of command-line arguments
 */
public static void main(java.lang.String[] args) {
	// Insert code to start the application here.
  try {
	BankAccountAccessBeanTable accttab = new BankAccountAccessBeanTable();
	BankAccountAccessBean      acct    = new BankAccountAccessBean();
	CheckingAccessBeanTable    chcktab = new CheckingAccessBeanTable();
	CheckingAccessBean         chck    = new CheckingAccessBean();

	System.out.println("All Accounts:");
	accttab.setBankAccountAccessBean( acct.findAll() );
	for (int i=0; i < accttab.numberOfRows(); i++) {
		acct = accttab.getBankAccountAccessBean(i);
		String accid = ((BankAccountKey)acct.__getKey()).accID;
		System.out.println("Account  "+accid+": "+ acct.getBalance());
  	}
	System.out.println("Checking Accounts:");
	chcktab.setCheckingAccessBean( chck.findAll() );
	for (int i=0; i < chcktab.numberOfRows(); i++) {
		chck = chcktab.getCheckingAccessBean(i);
		String accid = ((BankAccountKey)chck.__getKey()).accID;
		System.out.println("Checking "+accid+": "+ chck.getBalance() +" "+ chck.getOverdraft());
  	}
	System.out.println("END");
  } catch(Exception ex) {
	  ex.printStackTrace();
  }
}
}
