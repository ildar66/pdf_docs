package itso.ejb35.reverse;

/**
 * This is a Home interface for the Entity Bean
 */
public interface SavingsHome extends javax.ejb.EJBHome {

/**
 * create method for a CMP entity bean
 * @return itso.ejb35.reverse.Savings
 * @param argAccount itso.ejb35.reverse.AccountKey
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
itso.ejb35.reverse.Savings create(itso.ejb35.reverse.AccountKey argAccount) throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * findByPrimaryKey method comment
 * @return itso.ejb35.reverse.Savings
 * @param key itso.ejb35.reverse.SavingsKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.ejb35.reverse.Savings findByPrimaryKey(itso.ejb35.reverse.SavingsKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Savings SavingsAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.Savings
 * @param inKey itso.ejb35.reverse.AccountKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.reverse.Savings findSavingsByAccount(itso.ejb35.reverse.AccountKey inKey) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
