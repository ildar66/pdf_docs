package itso.ejb35.cmp.client;

import itso.ejb35.cmp.*;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 9:43:06 AM)
 * @author: Ueli TP
 */
public class UsingFinder {
/**
 * Starts the application.
 * @param args an array of command-line arguments
 */
public static void main(java.lang.String[] args) {
  try {
	//java.util.Properties properties = new java.util.Properties();
	//properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
	//properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY,
	//						"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
	//javax.naming.InitialContext initialContext = new javax.naming.InitialContext(properties);
	javax.naming.InitialContext initialContext = new javax.naming.InitialContext();

	Object objHome = initialContext.lookup("itso/ejb35/cmp/BankAccount");
	BankAccountHome bankHome = (BankAccountHome)
		javax.rmi.PortableRemoteObject.narrow(objHome,BankAccountHome.class);
	System.out.println("Calling BankAccount finder");
	BankAccount acct;
	java.util.Enumeration enum = bankHome.findAccountsWithBalanceGreater( new java.math.BigDecimal(20.00) );
	while (enum.hasMoreElements()) {
		acct = (BankAccount)javax.rmi.PortableRemoteObject.narrow(enum.nextElement(),BankAccount.class);
		System.out.println("Account: id=" + ((BankAccountKey)acct.getPrimaryKey()).accID + " balance=" + acct.getBalance());
		acct.setBalance( acct.getBalance().add( new java.math.BigDecimal("1") ) );
	}
	System.out.println("End of list");
  } catch(Exception ex) {
	  ex.printStackTrace();
  }
}
}
