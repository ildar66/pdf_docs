package itso.ejb35.eabsession;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface IMSCommandSession extends javax.ejb.EJBObject {

/**
 * 
 * @return com.ibm.record.IByteBuffer
 * @param input itso.stuvaj.imsconn.InputMsg
 * @exception String The exception description.
 */
com.ibm.record.IByteBuffer imsTran(itso.stuvaj.imsconn.InputMsg input) throws java.rmi.RemoteException;
}
