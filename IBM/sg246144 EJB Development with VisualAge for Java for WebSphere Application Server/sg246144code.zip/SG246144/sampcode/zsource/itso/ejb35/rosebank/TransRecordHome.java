package itso.ejb35.rosebank;

/**
 * This is a Home interface for the Entity Bean
 */
public interface TransRecordHome extends javax.ejb.EJBHome {

/**
 * create method for a CMP entity bean
 * @return itso.ejb35.rosebank.TransRecord
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
itso.ejb35.rosebank.TransRecord create() throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * findByPrimaryKey method comment
 * @return itso.ejb35.rosebank.TransRecord
 * @param key itso.ejb35.rosebank.TransRecordKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.ejb35.rosebank.TransRecord findByPrimaryKey(itso.ejb35.rosebank.TransRecordKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named AccountTransactions.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return java.util.Enumeration
 * @param inKey itso.ejb35.rosebank.BankAccountKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
java.util.Enumeration findTransactionsByAccount(itso.ejb35.rosebank.BankAccountKey inKey) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
