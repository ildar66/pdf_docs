package itso.ejb35.rosebank;

import java.rmi.RemoteException;
import java.security.Identity;
import java.util.Properties;
import javax.ejb.*;
/**
 * This is an Entity Bean class with CMP fields
 */
public class SavingsBean extends itso.ejb35.rosebank.BankAccountBean {
	public java.math.BigDecimal minAmount;
	private final static long serialVersionUID = 3206093459760846163L;

/**
 * This method was generated for supporting the associations.
 * @return java.util.Vector
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected java.util.Vector _getLinks() {
	java.util.Vector links = super._getLinks();
	return links;
}
/**
 * This method was generated for supporting the associations.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected void _initLinks() {
	super._initLinks();
}
/**
 * Getter method for minAmount
 * @return java.math.BigDecimal
 */
public java.math.BigDecimal getMinAmount() {
	return minAmount;
}
/**
 * Setter method for minAmount
 * @param newValue java.math.BigDecimal
 */
public void setMinAmount(java.math.BigDecimal newValue) {
	this.minAmount = newValue;
}
}
