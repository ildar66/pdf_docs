package itso.ejb35.session;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface CustomerFinder extends javax.ejb.EJBObject {

/**
 * 
 * @return java.util.Vector
 * @param partialName java.lang.String
 * @exception String The exception description.
 */
java.util.Vector findDab(java.lang.String partialName) throws java.rmi.RemoteException;
/**
 * 
 * @return java.util.Vector
 * @param partialName java.lang.String
 * @exception String The exception description.
 */
java.util.Vector findJdbc(java.lang.String partialName) throws java.rmi.RemoteException;
/**
 * 
 * @return java.util.Vector
 * @param partialName java.lang.String
 * @exception String The exception description.
 */
java.util.Vector findStp(java.lang.String partialName) throws java.rmi.RemoteException;
}
