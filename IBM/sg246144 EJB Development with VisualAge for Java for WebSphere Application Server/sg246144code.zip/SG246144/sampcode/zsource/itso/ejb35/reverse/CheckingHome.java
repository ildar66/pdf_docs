package itso.ejb35.reverse;

/**
 * This is a Home interface for the Entity Bean
 */
public interface CheckingHome extends javax.ejb.EJBHome {

/**
 * create method for a CMP entity bean
 * @return itso.ejb35.reverse.Checking
 * @param argAccount itso.ejb35.reverse.AccountKey
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
itso.ejb35.reverse.Checking create(itso.ejb35.reverse.AccountKey argAccount) throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * findByPrimaryKey method comment
 * @return itso.ejb35.reverse.Checking
 * @param key itso.ejb35.reverse.CheckingKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.ejb35.reverse.Checking findByPrimaryKey(itso.ejb35.reverse.CheckingKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Checking CheckingAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.Checking
 * @param inKey itso.ejb35.reverse.AccountKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.reverse.Checking findCheckingByAccount(itso.ejb35.reverse.AccountKey inKey) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
