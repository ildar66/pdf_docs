package itso.ejb35.javainherit;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface AccountChecking extends javax.ejb.EJBObject {

/**
 * 
 * @return java.math.BigDecimal
 * @param balance java.math.BigDecimal
 * @exception String The exception description.
 */
java.math.BigDecimal calculateInterest(java.math.BigDecimal balance) throws java.rmi.RemoteException;
/**
 * Getter method for accType
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getAccType() throws java.rmi.RemoteException;
/**
 * Getter method for balance
 * @return java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
java.math.BigDecimal getBalance() throws java.rmi.RemoteException;
/**
 * Setter method for accType
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setAccType(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * Setter method for balance
 * @param newValue java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
void setBalance(java.math.BigDecimal newValue) throws java.rmi.RemoteException;
}
