package itso.ejb35.cmp.servlet;

import itso.ejb35.cmp.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 12:56:49 PM)
 * @author: Ueli TP
 */
public class CustomerFindProp extends HttpServlet {
	private static java.util.ResourceBundle resCustomerFind = java.util.ResourceBundle.getBundle("CustomerFind");  //$NON-NLS-1$
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
	public void performTask(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
	// Read the input parameter from the HTML Form
	String id = request.getParameter("CustomerID");//$NON-NLS-1$
	int custId = (new Integer(id)).intValue();
	// Set the results page URL
	if (resCustomerFind == null) resCustomerFind = java.util.ResourceBundle.getBundle("CustomerFind");
	String url = resCustomerFind.getString("CustomerFindJSP"); //$NON-NLS-1$
	try
	{
		// Get the initial naming context
		//java.util.Properties properties = new java.util.Properties();
		//properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");//$NON-NLS-1$
		//properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY, 
		//		resCustomerFind.getString("ContextFactory")); //$NON-NLS-1$
		//javax.naming.InitialContext initialContext = new javax.naming.InitialContext(properties);
		javax.naming.InitialContext initialContext = new javax.naming.InitialContext();

		// Obtain the EJBHome for Customer
		Object objHome = initialContext.lookup(resCustomerFind.getString("CustomerJndiName")); //$NON-NLS-1$
		CustomerHome customerHome = (CustomerHome)
			javax.rmi.PortableRemoteObject.narrow(objHome,CustomerHome.class);

		// Find the customer
		Customer customer = customerHome.findByPrimaryKey(new CustomerKey(custId));

		// Forward to the results JSP
		request.setAttribute("customer", customer);//$NON-NLS-1$
		getServletConfig().getServletContext().getRequestDispatcher(url).
			forward(request, response);
	}
	catch (Exception e)
	{
		System.out.println("Exception thrown for customer with id:" + id);//$NON-NLS-1$
		e.printStackTrace();
	}
	}
}
