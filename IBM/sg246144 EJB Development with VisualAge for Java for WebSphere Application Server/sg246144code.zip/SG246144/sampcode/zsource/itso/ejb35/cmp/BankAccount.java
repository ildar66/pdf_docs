package itso.ejb35.cmp;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface BankAccount extends javax.ejb.EJBObject {

/**
 * 
 * @return void
 * @param amount java.math.BigDecimal
 * @exception String The exception description.
 */
void deposit(java.math.BigDecimal amount) throws java.rmi.RemoteException;
/**
 * 
 * @return java.math.BigDecimal
 * @exception String The exception description.
 */
java.math.BigDecimal getBalance() throws java.rmi.RemoteException;
/**
 * 
 * @return void
 * @param newValue java.math.BigDecimal
 * @exception String The exception description.
 */
void setBalance(java.math.BigDecimal newValue) throws java.rmi.RemoteException;
/**
 * 
 * @return void
 * @param amount java.math.BigDecimal
 * @exception String The exception description.
 * @exception String The exception description.
 */
void withdraw(java.math.BigDecimal amount) throws java.rmi.RemoteException, itso.ejb35.util.InsufficientFundException;
}
