package itso.ejb35.rosebank;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface CustAcct extends javax.ejb.EJBObject {

/**
 * This method was generated for supporting the association named AccountToCustomer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.BankAccount
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.rosebank.BankAccount getAccount() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named AccountToCustomer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.BankAccountKey
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.rosebank.BankAccountKey getAccountKey() throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named CustomerToAccount.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.Customer
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.rosebank.Customer getCustomer() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named CustomerToAccount.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.CustomerKey
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.rosebank.CustomerKey getCustomerKey() throws java.rmi.RemoteException;
}
