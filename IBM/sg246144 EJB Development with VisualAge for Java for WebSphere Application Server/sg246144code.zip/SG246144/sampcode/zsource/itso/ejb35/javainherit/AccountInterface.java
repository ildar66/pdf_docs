package itso.ejb35.javainherit;

/**
 * Insert the type's description here.
 * Creation date: (4/8/2001 11:23:20 AM)
 * @author: Ueli TP
 */
import java.math.BigDecimal;
public interface AccountInterface {
/**
 * Insert the method's description here.
 * Creation date: (4/8/2001 11:29:09 AM)
 * @return java.math.BigDecimal
 * @param balance java.math.BigDecimal
 */
BigDecimal calculateInterest(BigDecimal balance);
}
