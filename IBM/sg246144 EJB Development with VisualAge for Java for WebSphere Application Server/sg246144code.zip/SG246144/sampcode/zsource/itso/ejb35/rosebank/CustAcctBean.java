package itso.ejb35.rosebank;

import java.rmi.RemoteException;
import java.security.Identity;
import java.util.Properties;
import javax.ejb.*;
/**
 * This is an Entity Bean class with CMP fields
 */
public class CustAcctBean implements EntityBean {
	private transient com.ibm.ivj.ejb.associations.interfaces.SingleLink accountLink = null;
	private transient com.ibm.ivj.ejb.associations.interfaces.SingleLink customerLink = null;
	private javax.ejb.EntityContext entityContext = null;
	private final static long serialVersionUID = 3206093459760846163L;
	public java.lang.Integer customer_customerID;
	public java.lang.String account_accid;
/**
 * This method was generated for supporting the associations.
 * @return java.util.Vector
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected java.util.Vector _getLinks() {
	java.util.Vector links = new java.util.Vector();
	links.addElement(getCustomerLink());
	links.addElement(getAccountLink());
	return links;
}
/**
 * This method was generated for supporting the associations.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected void _initLinks() {
	customerLink = null;
	accountLink = null;
}
/**
 * This method was generated for supporting the associations.
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.RemoveException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected void _removeLinks() throws java.rmi.RemoteException, javax.ejb.RemoveException {
	java.util.Enumeration links = _getLinks().elements();
	while (links.hasMoreElements()) {
		try {
			((com.ibm.ivj.ejb.associations.interfaces.Link) (links.nextElement())).remove();
		}
		catch (javax.ejb.FinderException e) {} //Consume Finder error since I am going away
	}
}
/**
 * ejbActivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbActivate() throws java.rmi.RemoteException {
	_initLinks();
}
/**
 * ejbCreate method for a CMP entity bean
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbCreate() throws javax.ejb.CreateException, java.rmi.RemoteException {
	_initLinks();
	// All CMP fields should be initialized here.
}
/**
 * ejbLoad method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbLoad() throws java.rmi.RemoteException {
	_initLinks();
}
/**
 * ejbPassivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPassivate() throws java.rmi.RemoteException {}
/**
 * ejbPostCreate method for a CMP entity bean
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPostCreate() throws java.rmi.RemoteException {}
/**
 * ejbRemove method comment
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.RemoveException The exception description.
 */
public void ejbRemove() throws java.rmi.RemoteException, javax.ejb.RemoveException {
	_removeLinks();
}
/**
 * ejbStore method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbStore() throws java.rmi.RemoteException {}
/**
 * This method was generated for supporting the association named AccountToCustomer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.BankAccount
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.rosebank.BankAccount getAccount() throws java.rmi.RemoteException, javax.ejb.FinderException {
	return (itso.ejb35.rosebank.BankAccount)this.getAccountLink().value();
}
/**
 * This method was generated for supporting the association named AccountToCustomer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.BankAccountKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.rosebank.BankAccountKey getAccountKey() {
	itso.ejb35.rosebank.BankAccountKey temp = null;
	temp = new itso.ejb35.rosebank.BankAccountKey();
	boolean account_NULLTEST = true;
	account_NULLTEST &= (account_accid == null);
	temp.accid = account_accid;
	if (account_NULLTEST) temp = null;
	return temp;
}
/**
 * This method was generated for supporting the association named AccountToCustomer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return com.ibm.ivj.ejb.associations.interfaces.SingleLink
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected com.ibm.ivj.ejb.associations.interfaces.SingleLink getAccountLink() {
	if (accountLink == null)
		accountLink = new CustAcctToAccountLink(this);
	return accountLink;
}
/**
 * This method was generated for supporting the association named CustomerToAccount.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.Customer
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.rosebank.Customer getCustomer() throws java.rmi.RemoteException, javax.ejb.FinderException {
	return (itso.ejb35.rosebank.Customer)this.getCustomerLink().value();
}
/**
 * This method was generated for supporting the association named CustomerToAccount.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.CustomerKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.rosebank.CustomerKey getCustomerKey() {
	itso.ejb35.rosebank.CustomerKey temp = null;
	temp = new itso.ejb35.rosebank.CustomerKey();
	boolean customer_NULLTEST = true;
	customer_NULLTEST &= (customer_customerID == null);
	temp.customerID = ((customer_customerID == null) ? 0 : customer_customerID.intValue());
	if (customer_NULLTEST) temp = null;
	return temp;
}
/**
 * This method was generated for supporting the association named CustomerToAccount.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return com.ibm.ivj.ejb.associations.interfaces.SingleLink
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected com.ibm.ivj.ejb.associations.interfaces.SingleLink getCustomerLink() {
	if (customerLink == null)
		customerLink = new CustAcctToCustomerLink(this);
	return customerLink;
}
/**
 * getEntityContext method comment
 * @return javax.ejb.EntityContext
 */
public javax.ejb.EntityContext getEntityContext() {
	return entityContext;
}
/**
 * This method was generated for supporting the association named AccountToCustomer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param inKey itso.ejb35.rosebank.BankAccountKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void privateSetAccountKey(itso.ejb35.rosebank.BankAccountKey inKey) {
	boolean account_NULLTEST = (inKey == null);
	if (account_NULLTEST) account_accid = null; else account_accid = inKey.accid;
}
/**
 * This method was generated for supporting the association named CustomerToAccount.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param inKey itso.ejb35.rosebank.CustomerKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void privateSetCustomerKey(itso.ejb35.rosebank.CustomerKey inKey) {
	boolean customer_NULLTEST = (inKey == null);
	if (customer_NULLTEST) customer_customerID = null; else customer_customerID = (new Integer(inKey.customerID));
}
/**
 * This method was generated for supporting the association named AccountToCustomer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param anAccount itso.ejb35.rosebank.BankAccount
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void setAccount(itso.ejb35.rosebank.BankAccount anAccount) throws java.rmi.RemoteException {
	this.getAccountLink().set(anAccount);
}
/**
 * This method was generated for supporting the association named CustomerToAccount.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aCustomer itso.ejb35.rosebank.Customer
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void setCustomer(itso.ejb35.rosebank.Customer aCustomer) throws java.rmi.RemoteException {
	this.getCustomerLink().set(aCustomer);
}
/**
 * setEntityContext method comment
 * @param ctx javax.ejb.EntityContext
 * @exception java.rmi.RemoteException The exception description.
 */
public void setEntityContext(javax.ejb.EntityContext ctx) throws java.rmi.RemoteException {
	entityContext = ctx;
}
/**
 * unsetEntityContext method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void unsetEntityContext() throws java.rmi.RemoteException {
	entityContext = null;
}
}
