package itso.ejb35.cmp;

/**
 * Insert the type's description here.
 * Creation date: (4/7/2001 3:22:21 PM)
 * @author: Ueli TP
 */
public class BankAccountBeanFinderObject extends com.ibm.vap.finders.VapEJSJDBCFinderObject implements BankAccountBeanFinderHelper {
/**
 * BankAccountBeanFinderObject constructor comment.
 */
public BankAccountBeanFinderObject() {
	super();
}
/**
 * findAccountsFor method comment.
 */
public java.sql.PreparedStatement findGoldAccounts(java.math.BigDecimal aBalance) throws Exception {
	java.sql.PreparedStatement pstmt = null;
	int mergedCount = getMergedWhereCount();
	int columnCount = 1; // number of ? in the original query
	pstmt = getMergedPreparedStatement( "T1.balance >= ?" );
	for (int i=0; i < (columnCount* mergedCount); i+=columnCount ) 
		pstmt.setBigDecimal( i+1, aBalance );
	return pstmt;
}
}
