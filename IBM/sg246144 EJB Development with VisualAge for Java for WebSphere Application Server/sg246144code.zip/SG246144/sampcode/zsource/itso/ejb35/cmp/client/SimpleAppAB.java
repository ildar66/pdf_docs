package itso.ejb35.cmp.client;

import itso.ejb35.cmp.*;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 9:43:06 AM)
 * @author: Ueli TP
 */
public class SimpleAppAB {
/**
 * Starts the application.
 * @param args an array of command-line arguments
 */
public static void main(java.lang.String[] args) {
  try {
	CustomerAccessBean cust2 = new CustomerAccessBean(202, "Mr", "Mike", "Vaughn", "MV", "MV");
	System.out.println("Customer 202 created");
	CustomerAccessBean cust1 = new CustomerAccessBean();
	cust1.setInitKey_customerID("101");
	System.out.println("Customer 101: name="+cust1.getName());
	System.out.println("Customer 202: name="+cust2.getName());
	cust2.setLastName("VaughnX");
	System.out.println("Customer 202: name="+cust2.getName());
	cust2.commitCopyHelper();
	cust2.refreshCopyHelper();
	System.out.println("Customer 202: name="+cust2.getName());
	(cust2.getEJBRef()).remove();
	System.out.println("Customer 202: deleted");
  } catch(Exception ex) {
	  ex.printStackTrace();
  }
}
}
