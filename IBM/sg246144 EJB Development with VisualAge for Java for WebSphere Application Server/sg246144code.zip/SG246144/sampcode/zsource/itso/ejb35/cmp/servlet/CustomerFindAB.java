package itso.ejb35.cmp.servlet;

import itso.ejb35.cmp.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 12:56:49 PM)
 * @author: Ueli TP
 */
public class CustomerFindAB extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
public void performTask(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
	// Read the input parameter from the HTML Form
	String id = request.getParameter("CustomerID");
	// Set the results page URL
	String url = "/ejb/cmpservlet/CustomerFindAB.jsp";

	// Instantiate the access bean and initialize it with the customerID 
	CustomerAccessBean customer = new CustomerAccessBean();      
	customer.setInitKey_customerID(id);

	// Forward to the results JSP
	request.setAttribute("customer", customer);
	getServletConfig().getServletContext().getRequestDispatcher(url).
			forward(request, response);
}
}
