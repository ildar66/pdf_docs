package itso.ejb35.bank.schema;

class Bank_EntitiesMap extends com.ibm.vap.common.MapStorageClass {
/**
 * This is a textual representation of Bank_Entities to assist documentation and comparing class versions
 * Modifying the string has no effect on the actual data which is stored internally on the class
 * If a developer wishes to share their model data with another user in another repository the class
 * should be exported taking the option to export to a repository
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
static void infoString() {
/*DataStore Map
Model: Bank_Entities
Schema: Bank_Entities
Map contains 6 class maps 

====================================================================================================
Class:	BankAccount
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: BankAccount, Table: Account
Table map contains 5 ivar maps
	Root Leaf Table Inheritance
Inheritance discriminator value: 'ACCOUNT'
	Root Table Map
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: nil in BankAccount
			Columns in Account: acctype
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'accID' in BankAccount
			Columns in Account: accid
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'balance' in BankAccount
			Columns in Account: balance
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Relationship Map  
			AccountTransactions	:	bankTransactions
			'AccountTransrecord'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Relationship Map  
			AccountToCustomer	:	custAcct
			'CAtoAccount'
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
Class:	Checking
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: Checking, Table: Checking
Table map contains 1 ivar maps
	Root Leaf Table Inheritance
Inheritance discriminator value: 'CHECKING'
	Not Root Table Map
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'overdraft' in Checking
			Columns in Checking: overdraft
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
Class:	CustAcct
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: CustAcct, Table: CustAcct
Table map contains 2 ivar maps
	Distinct Table Inheritance
	Root Table Map
----------------------------------------------------------------------------------------------------
		Relationship Map  
			AccountToCustomer	:	account
			'CAtoAccount'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Relationship Map  
			CustomerToAccount	:	customer
			'CAtoCustomer'
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
Class:	Customer
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: Customer, Table: Address
Table map contains 1 ivar maps
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: Customer, Table: Customer
Table map contains 7 ivar maps
	Distinct Table Inheritance
	Root Table Map
----------------------------------------------------------------------------------------------------
		Relationship Map  
			CustomerToAccount	:	custAcct
			'CAtoCustomer'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'customerID' in Customer
			Columns in Customer: customerID
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'firstName' in Customer
			Columns in Customer: firstName
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'lastName' in Customer
			Columns in Customer: lastName
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'password' in Customer
			Columns in Customer: password
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'title' in Customer
			Columns in Customer: title
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'userID' in Customer
			Columns in Customer: userID
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
Class:	Savings
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: Savings, Table: Savings
Table map contains 1 ivar maps
	Root Leaf Table Inheritance
Inheritance discriminator value: 'SAVINGS'
	Not Root Table Map
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'minAmount' in Savings
			Columns in Savings: minamount
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
Class:	TransRecord
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: TransRecord, Table: TransRecord
Table map contains 4 ivar maps
	Distinct Table Inheritance
	Root Table Map
----------------------------------------------------------------------------------------------------
		Relationship Map  
			AccountTransactions	:	owningAccount
			'AccountTransrecord'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'transamt' in TransRecord
			Columns in TransRecord: transamt
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'transID' in TransRecord
			Columns in TransRecord: transid
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'transtype' in TransRecord
			Columns in TransRecord: transtype
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
*/}
}
