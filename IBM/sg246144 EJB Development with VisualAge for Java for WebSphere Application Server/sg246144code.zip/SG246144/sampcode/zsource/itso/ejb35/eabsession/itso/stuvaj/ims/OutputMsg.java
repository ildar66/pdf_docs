package itso.stuvaj.ims;

import com.ibm.record.*;
import java.io.*;
import java.beans.*;
/**
 * Class: ls.conn.ims.cmd.OutputMsg
 * This is a generated file.  Do not edit.
 */


public class OutputMsg extends com.ibm.record.CustomRecord implements java.io.Serializable
{

	  private boolean notifyWhenContentsUpdated = false;
	  protected transient PropertyChangeSupport listeners;

	  private static OutputMsg initialRecord = new OutputMsg();

   public OutputMsg()
	  throws RecordException
   {
	  try {
		 if (this.initialRecord == null) {
			com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
			attrs.setFloatingPointFormat(com.ibm.record.IRecordAttributes.IBMFLOATINGPOINTFORMAT);
			attrs.setEndian(com.ibm.record.IRecordAttributes.BIGENDIAN);
			attrs.setRemoteIntEndian(com.ibm.record.IRecordAttributes.BIGENDIAN);
			attrs.setCodePage("037");
			attrs.setMachine(com.ibm.ivj.eab.record.cobol.CobolRecordAttributes.MVS);
			this.setRecordAttributes(attrs);
			this.setRecordType(new CustomRecordType(ls.conn.ims.cmd.OutputMsg.class,178));
			this.setRawBytes(new byte[178]);
			this.setInitialValues();
		 } else {
			this.setRecordAttributes((com.ibm.ivj.eab.record.cobol.CobolRecordAttributes)this.initialRecord.getRecordAttributes().clone());
			this.setRecordType(this.initialRecord.getRecordType());
			this.setRawBytes(new byte[178]);
			System.arraycopy(this.initialRecord.getRawBytes(),0,this.getRawBytes(),0,178);
		 }
		 this.enableNotification();
	  } catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }   
   public void addPropertyChangeListener(PropertyChangeListener x) {
	  getPropertyChange().addPropertyChangeListener( x );
   }   
   public void disableNotification()
   {
	  super.disableNotification();
	  notifyWhenContentsUpdated = false;
	  return;
   }   
   public void enableNotification()
   {
	  super.enableNotification();
	  notifyWhenContentsUpdated = true;
	  return;
   }   
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, newObj);
   }   
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }   
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
	  if (listeners != null)
		 listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }   
   public static Class getMetadataClass() {
	  try {
		 return Class.forName("ls.conn.ims.cmd.OutputMsgInfo");
	  } catch (ClassNotFoundException e) {
		 return null;
	  }
   }   
   public java.lang.String getOUT__CMD()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,84,9,0,8,false,false,false,-7,0,"X(8)",false,true);
   }   
   public java.lang.String getOUT__HUMIDITY()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,148,9,0,3,false,false,false,-2,0,"X(3)",false,true);
   }   
   public short getOUT__LL()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,3,4,true,false,true,-3,0,"S9(3)",false,false);
   }   
   public java.lang.String getOUT__LOCALDATE()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,166,9,0,12,false,false,false,-11,0,"X(12)",false,true);
   }   
   public java.lang.String getOUT__LOCALTIME()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,154,9,0,12,false,false,false,-11,0,"X(12)",false,true);
   }   
   public java.lang.String getOUT__MSG()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,80,false,false,false,-79,0,"X(80)",false,true);
   }   
   public java.lang.String getOUT__PLANETNAME()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,95,9,0,50,false,false,false,-49,0,"X(50)",false,true);
   }   
   public java.lang.String getOUT__STATIONID()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,92,9,0,3,false,false,false,-2,0,"X(3)",false,true);
   }   
   public java.lang.String getOUT__TEMPERATURE()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,145,9,0,3,false,false,false,-2,0,"X(3)",false,true);
   }   
   public java.lang.String getOUT__WINDSPEED()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,151,9,0,3,false,false,false,-2,0,"X(3)",false,true);
   }   
   public short getOUT__ZZ()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,3,4,true,false,true,-3,0,"S9(3)",false,false);
   }   
   protected java.beans.PropertyChangeSupport getPropertyChange() {
	  if (listeners == null) {
		 listeners = new java.beans.PropertyChangeSupport(this);
	  }
	  return listeners;
   }   
   public void notifyAllVars()
	  throws RecordConversionFailureException
   {
	  if (notifyWhenContentsUpdated && this.listeners != null) {
		 firePropertyChange("OUT__LL",null,getOUT__LL());
		 firePropertyChange("OUT__ZZ",null,getOUT__ZZ());
		 firePropertyChange("OUT__MSG",null,getOUT__MSG());
		 firePropertyChange("OUT__CMD",null,getOUT__CMD());
		 firePropertyChange("OUT__STATIONID",null,getOUT__STATIONID());
		 firePropertyChange("OUT__PLANETNAME",null,getOUT__PLANETNAME());
		 firePropertyChange("OUT__TEMPERATURE",null,getOUT__TEMPERATURE());
		 firePropertyChange("OUT__HUMIDITY",null,getOUT__HUMIDITY());
		 firePropertyChange("OUT__WINDSPEED",null,getOUT__WINDSPEED());
		 firePropertyChange("OUT__LOCALTIME",null,getOUT__LOCALTIME());
		 firePropertyChange("OUT__LOCALDATE",null,getOUT__LOCALDATE());
	  }
   }   
   public void removePropertyChangeListener(PropertyChangeListener x) {
	  getPropertyChange().removePropertyChangeListener( x );
   }   
   public void setBytes(byte[] contents)
   {
	  super.setBytes(contents);
	  notifyAllVars();
   }   
   public void setInitialValues() throws
	  RecordConversionFailureException,
	  RecordConversionUnsupportedException
   {
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("+0,null"),0,3,4,true,false,true,-3,0,"S9(3)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("+0,null"),0,3,4,true,false,true,-3,0,"S9(3)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,80,false,false,false,-79,0,"X(80)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,84, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,92, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,95, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,145, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,148, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,151, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,154, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,12,false,false,false,-11,0,"X(12)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,166, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,12,false,false,false,-11,0,"X(12)",false,true);
	  return;
   }   
   public void setOUT__CMD(java.lang.String aOUT__CMD)
	  throws RecordConversionFailureException {
	  java.lang.String oldOUT__CMD = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,84,9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,84,aOUT__CMD,9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  firePropertyChange("OUT__CMD",oldOUT__CMD,aOUT__CMD);
	  return;
   }   
   public void setOUT__HUMIDITY(java.lang.String aOUT__HUMIDITY)
	  throws RecordConversionFailureException {
	  java.lang.String oldOUT__HUMIDITY = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,148,9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,148,aOUT__HUMIDITY,9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  firePropertyChange("OUT__HUMIDITY",oldOUT__HUMIDITY,aOUT__HUMIDITY);
	  return;
   }   
   public void setOUT__LL(short aOUT__LL)
	  throws RecordConversionFailureException {
	  short oldOUT__LL = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,3,4,true,false,true,-3,0,"S9(3)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aOUT__LL,0,3,4,true,false,true,-3,0,"S9(3)",false,false);
	  firePropertyChange("OUT__LL",oldOUT__LL,aOUT__LL);
	  return;
   }   
   public void setOUT__LOCALDATE(java.lang.String aOUT__LOCALDATE)
	  throws RecordConversionFailureException {
	  java.lang.String oldOUT__LOCALDATE = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,166,9,0,12,false,false,false,-11,0,"X(12)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,166,aOUT__LOCALDATE,9,0,12,false,false,false,-11,0,"X(12)",false,true);
	  firePropertyChange("OUT__LOCALDATE",oldOUT__LOCALDATE,aOUT__LOCALDATE);
	  return;
   }   
   public void setOUT__LOCALTIME(java.lang.String aOUT__LOCALTIME)
	  throws RecordConversionFailureException {
	  java.lang.String oldOUT__LOCALTIME = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,154,9,0,12,false,false,false,-11,0,"X(12)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,154,aOUT__LOCALTIME,9,0,12,false,false,false,-11,0,"X(12)",false,true);
	  firePropertyChange("OUT__LOCALTIME",oldOUT__LOCALTIME,aOUT__LOCALTIME);
	  return;
   }   
   public void setOUT__MSG(java.lang.String aOUT__MSG)
	  throws RecordConversionFailureException {
	  java.lang.String oldOUT__MSG = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,80,false,false,false,-79,0,"X(80)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aOUT__MSG,9,0,80,false,false,false,-79,0,"X(80)",false,true);
	  firePropertyChange("OUT__MSG",oldOUT__MSG,aOUT__MSG);
	  return;
   }   
   public void setOUT__PLANETNAME(java.lang.String aOUT__PLANETNAME)
	  throws RecordConversionFailureException {
	  java.lang.String oldOUT__PLANETNAME = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,95,9,0,50,false,false,false,-49,0,"X(50)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,95,aOUT__PLANETNAME,9,0,50,false,false,false,-49,0,"X(50)",false,true);
	  firePropertyChange("OUT__PLANETNAME",oldOUT__PLANETNAME,aOUT__PLANETNAME);
	  return;
   }   
   public void setOUT__STATIONID(java.lang.String aOUT__STATIONID)
	  throws RecordConversionFailureException {
	  java.lang.String oldOUT__STATIONID = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,92,9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,92,aOUT__STATIONID,9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  firePropertyChange("OUT__STATIONID",oldOUT__STATIONID,aOUT__STATIONID);
	  return;
   }   
   public void setOUT__TEMPERATURE(java.lang.String aOUT__TEMPERATURE)
	  throws RecordConversionFailureException {
	  java.lang.String oldOUT__TEMPERATURE = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,145,9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,145,aOUT__TEMPERATURE,9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  firePropertyChange("OUT__TEMPERATURE",oldOUT__TEMPERATURE,aOUT__TEMPERATURE);
	  return;
   }   
   public void setOUT__WINDSPEED(java.lang.String aOUT__WINDSPEED)
	  throws RecordConversionFailureException {
	  java.lang.String oldOUT__WINDSPEED = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,151,9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,151,aOUT__WINDSPEED,9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  firePropertyChange("OUT__WINDSPEED",oldOUT__WINDSPEED,aOUT__WINDSPEED);
	  return;
   }   
   public void setOUT__ZZ(short aOUT__ZZ)
	  throws RecordConversionFailureException {
	  short oldOUT__ZZ = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,3,4,true,false,true,-3,0,"S9(3)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aOUT__ZZ,0,3,4,true,false,true,-3,0,"S9(3)",false,false);
	  firePropertyChange("OUT__ZZ",oldOUT__ZZ,aOUT__ZZ);
	  return;
   }   
}
