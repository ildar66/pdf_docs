package itso.ejb35.bank;

/**
 * Insert the type's description here.
 * Creation date: (4/7/2001 3:22:21 PM)
 * @author: Ueli TP
 */
public class CheckingBeanFinderObject extends BankAccountBeanFinderObject implements CheckingBeanFinderHelper {
/**
 * BankAccountBeanFinderObject constructor comment.
 */
public CheckingBeanFinderObject() {
	super();
}
}
