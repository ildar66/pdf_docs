package itso.ejb35.bank.schema;

class Bank_EntitiesSchema extends com.ibm.vap.common.SchemaStorageClass {
/**
 * This is a textual representation of Bank_Entities to assist documentation and comparing class versions
 * Modifying the string has no effect on the actual data which is stored internally on the class
 * If a developer wishes to share their model data with another user in another repository the class
 * should be exported taking the option to export to a repository
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
static void infoString() {
/*Logical Name: Bank_Entities
Physical Name: Bank_Entities
Schema contains 
	7 table(s)
	24 column(s)
	6 foreignKey(s)
====================================================================================================
Logical Table Name: Account
Physical Table Name: Account
	 qualifier: ITSO
Account contains: 
	3 column(s)
	4 foreign key relationship(s) 
Account has primary key:  (accid)
Account is pointed to by the following table(s), CustAcct , Savings , TransRecord , Checking 
----------------------------------------------------------------------------------------------------
	Column Logical Name: accid
	Column PhysicalName: accid
	Column Type: CHAR(8)
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships SavingsAccount (Account), CheckingAccount (Account), AccountTransrecord (Account), CAtoAccount (Account)
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: acctype
	Column PhysicalName: acctype
	Column Type: VARCHAR(8)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: balance
	Column PhysicalName: balance
	Column Type: DECIMAL(8, 2)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
====================================================================================================
Logical Table Name: Address
Physical Table Name: Address
	 qualifier: ITSO
Address contains: 
	5 column(s)
	1 foreign key relationship(s) 
Address has primary key:  (customerID)
Address points to the following table(s), Customer 
----------------------------------------------------------------------------------------------------
	Column Logical Name: city
	Column PhysicalName: city
	Column Type: CHAR(12)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: customerID
	Column PhysicalName: customerID
	Column Type: INTEGER
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships CustomerAddress (Customer)
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: state
	Column PhysicalName: state
	Column Type: CHAR(12)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: street
	Column PhysicalName: street
	Column Type: CHAR(20)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: zipcode
	Column PhysicalName: zipcode
	Column Type: CHAR(10)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
====================================================================================================
Logical Table Name: Checking
Physical Table Name: Checking
	 qualifier: ITSO
Checking contains: 
	2 column(s)
	1 foreign key relationship(s) 
Checking has primary key:  (accid)
Checking points to the following table(s), Account 
----------------------------------------------------------------------------------------------------
	Column Logical Name: accid
	Column PhysicalName: accid
	Column Type: CHAR(8)
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships CheckingAccount (Account)
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: overdraft
	Column PhysicalName: overdraft
	Column Type: DECIMAL(8, 2)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
====================================================================================================
Logical Table Name: CustAcct
Physical Table Name: CustAcct
	 qualifier: ITSO
CustAcct contains: 
	2 column(s)
	2 foreign key relationship(s) 
CustAcct has primary key:  (customerID accid)
CustAcct points to the following table(s), Customer , Account 
----------------------------------------------------------------------------------------------------
	Column Logical Name: accid
	Column PhysicalName: accid
	Column Type: CHAR(8)
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships CAtoAccount (Account)
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: customerID
	Column PhysicalName: customerID
	Column Type: INTEGER
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships CAtoCustomer (Customer)
	Converter Class: VapConverter
====================================================================================================
Logical Table Name: Customer
Physical Table Name: Customer
	 qualifier: ITSO
Customer contains: 
	6 column(s)
	2 foreign key relationship(s) 
Customer has primary key:  (customerID)
Customer is pointed to by the following table(s), Address , CustAcct 
----------------------------------------------------------------------------------------------------
	Column Logical Name: customerID
	Column PhysicalName: customerID
	Column Type: INTEGER
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships CustomerAddress (Customer), CAtoCustomer (Customer)
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: firstName
	Column PhysicalName: firstName
	Column Type: VARCHAR(30)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: lastName
	Column PhysicalName: lastName
	Column Type: VARCHAR(30)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: password
	Column PhysicalName: password
	Column Type: CHAR(8)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: title
	Column PhysicalName: title
	Column Type: CHAR(3)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: userID
	Column PhysicalName: userID
	Column Type: CHAR(8)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
====================================================================================================
Logical Table Name: Savings
Physical Table Name: Savings
	 qualifier: ITSO
Savings contains: 
	2 column(s)
	1 foreign key relationship(s) 
Savings has primary key:  (accid)
Savings points to the following table(s), Account 
----------------------------------------------------------------------------------------------------
	Column Logical Name: accid
	Column PhysicalName: accid
	Column Type: CHAR(8)
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships SavingsAccount (Account)
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: minamount
	Column PhysicalName: minamount
	Column Type: DECIMAL(8, 2)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
====================================================================================================
Logical Table Name: TransRecord
Physical Table Name: TransRecord
	 qualifier: ITSO
TransRecord contains: 
	4 column(s)
	1 foreign key relationship(s) 
TransRecord has primary key:  (transid)
TransRecord points to the following table(s), Account 
----------------------------------------------------------------------------------------------------
	Column Logical Name: accid
	Column PhysicalName: accid
	Column Type: CHAR(8)
	Nulls Allowed: no
	Part of Primary key: no
	Part of the following foreign key relationships AccountTransrecord (Account)
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: transamt
	Column PhysicalName: transamt
	Column Type: DECIMAL(8, 2)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: transid
	Column PhysicalName: transid
	Column Type: TIMESTAMP
	Nulls Allowed: no
	Part of Primary key: yes
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: transtype
	Column PhysicalName: transtype
	Column Type: CHAR(1)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
====================================================================================================
Logical Name: 'AccountTransrecord'
Physical Name: 'AccountTransrecord'
Parent Table Key: Account(accid) (primary key)  cardinality(1)
Member Table Key: TransRecord(accid)  cardinality[0, M)
Referential Integrity Constraint exists in database
Referential Integrity Constraint Type: no action on delete and no action on update
====================================================================================================
Logical Name: 'CAtoAccount'
Physical Name: 'CAtoAccount'
Parent Table Key: Account(accid) (primary key)  cardinality(1)
Member Table Key: CustAcct(accid) (subset of primary key)  cardinality[0, M)
Referential Integrity Constraint exists in database
Referential Integrity Constraint Type: no action on delete and no action on update
====================================================================================================
Logical Name: 'CAtoCustomer'
Physical Name: 'CAtoCustomer'
Parent Table Key: Customer(customerID) (primary key)  cardinality(1)
Member Table Key: CustAcct(customerID) (subset of primary key)  cardinality[0, M)
Referential Integrity Constraint exists in database
Referential Integrity Constraint Type: no action on delete and no action on update
====================================================================================================
Logical Name: 'CheckingAccount'
Physical Name: 'CheckingAccount'
Parent Table Key: Account(accid) (primary key)  cardinality(1)
Member Table Key: Checking(accid) (subset of primary key)  cardinality[1, 1]
Referential Integrity Constraint exists in database
Referential Integrity Constraint Type: no action on delete and no action on update
====================================================================================================
Logical Name: 'CustomerAddress'
Physical Name: 'CustomerAddress'
Parent Table Key: Customer(customerID) (primary key)  cardinality(1)
Member Table Key: Address(customerID) (subset of primary key)  cardinality[1, 1]
Referential Integrity Constraint exists in database
Referential Integrity Constraint Type: no action on delete and no action on update
====================================================================================================
Logical Name: 'SavingsAccount'
Physical Name: 'SavingsAccount'
Parent Table Key: Account(accid) (primary key)  cardinality(1)
Member Table Key: Savings(accid) (subset of primary key)  cardinality[1, 1]
Referential Integrity Constraint exists in database
Referential Integrity Constraint Type: no action on delete and no action on update*/}
}
