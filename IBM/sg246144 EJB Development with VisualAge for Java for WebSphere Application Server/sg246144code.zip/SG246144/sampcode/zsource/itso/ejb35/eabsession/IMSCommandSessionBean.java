package itso.ejb35.eabsession;


import com.ibm.record.*;
import com.ibm.ivj.eab.command.*;
import com.ibm.connector.*;
import com.ibm.connector.infrastructure.java.*;
import com.ibm.connector.infrastructure.*;

import java.util.*;
import java.beans.*;
import java.lang.reflect.*;
import java.rmi.*;
import javax.ejb.*;

// user code begin {__import_statements_1}
// user code end {__import_statements_1}

public class IMSCommandSessionBean implements javax.ejb.SessionBean, java.io.Serializable {

	// Important!
	// Fields and properties added by hand or by tools such as the Create Field
	// SmartGuide and the New Property Feature SmartGuide must be placed within the comments
	// below.  Fields and properties added outside of these comments will not be saved
	// during code regeneration.
	
	// user code begin {__declaration_1}
	// user code end {__declaration_1}
	
	transient private com.ibm.connector.ConnectionSpec connectionSpec = null;
	transient private boolean runtimeContextSet = false;
	transient CommunicationCommand comCommand = null;
	private javax.ejb.SessionContext mySessionCtx = null;
	
// Generated line, do not modify - IMSCommandSessionBean()
//Default constructor
public IMSCommandSessionBean() {
	super();
	
	// user code begin {__IMSCommandSessionBean()_1}
	// user code end {__IMSCommandSessionBean()_1}
	
}
// Generated line, do not modify - void afterInteraction()
private void afterInteraction() {

	// Remove current runtimeContext if it was set in beforeExecution() method
	
	if (this.runtimeContextSet){
	
		// Commit changes
		((com.ibm.connector.infrastructure.java.JavaCoordinator)RuntimeContext.getCurrent().getCoordinator()).commit();
		
		// Close runtime context
		JavaRuntimeContext.getCurrent().close();
		
		// Remove current runtime context
		JavaRuntimeContext.removeCurrent();
		this.runtimeContextSet = false;
		
	}
	// user code begin {__afterInteraction()_1}
	// user code end {__afterInteraction()_1}
	
}
// Generated line, do not modify - void beforeInteraction()
private void beforeInteraction() {
	
	// user code begin {__beforeInteraction()_1}
	// user code end {__beforeInteraction()_1}
	
	if (!RuntimeContext.isCurrentSet()) {
	
		// Set the field to mark that runtime context has been set up.
		this.runtimeContextSet = true;
		
		
		// Create the Runtime Context
		JavaRuntimeContext runtimeContext = new JavaRuntimeContext();
		
		
		// Set up the Connection Manager
		//runtimeContext.setConnectionManager(
		//		/* global instance of the class com.ibm.connector.connectionmanager.ConnectionManager */
		//		);
		
		// Three scenarios to set up security information
		// 1. Security information set using known values
		// 2. Security information set using retrieved from session context
		// 3. Security information set using retrieved from deployment descriptor
		
		// Some connectors may require use of specific LogonInfoItems class if they 
		// need other security information in addition to user name and password.
		// See documentation of your connector for details.
		
		// com.ibm.connector.internal.LogonInfoItems logonInfoItems = 
		//			new com.ibm.connector.internal.LogonInfoItems(runtimeContext.getLogonInfo());
		// logonInfoItems.setUser("UserID");
		// logonInfoItems.setPassword("UserPassword");
		
		
		// Set up trace level of RAS services. By default, trace and errors are logged 
		// to System.out and System.err, however JavaRASService provides methods that
		// allow to specify different output/error streams, for example files.
		// The default trace level is RAS_TRACE_OFF. Levels that can be used for trace are:
		// RAS_TRACE_OFF - no trace output is logged.
		// RAS_TRACE_ERROR_EXCEPTION - output resulting from the occurence of error or exceptio
		// 							   is logged
		// RAS_TRACE_ENTRY_EXIT - entry and exit of methods are logged
		// RAS_TRACE_INTERNAL - provides most details about object state to be logged
		
		// ((JavaRASService)runtimeContext.getRASService()).setTraceLevel(RASService.RAS_TRACE_OFF);
		
		// user code begin {__beforeInteraction()_2}
		// user code end {__beforeInteraction()_2}
		
		
		// Set current runtimeContext
		JavaRuntimeContext.setCurrent(runtimeContext);
	}
}
// Generated line, do not modify - void ejbActivate()
public void ejbActivate() throws java.rmi.RemoteException {
	initializeConnectionSpec();
	runtimeContextSet = false;
	comCommand = new CommunicationCommand();
	
	// user code begin {__ejbActivate()_1}
	// user code end {__ejbActivate()_1}
	
}
// Generated line, do not modify - void ejbCreate()
public void ejbCreate() throws javax.ejb.CreateException, java.rmi.RemoteException {
	initializeConnectionSpec();
	comCommand = new CommunicationCommand();
	
	// user code begin {__ejbCreate()_1}
	// user code end {__ejbCreate()_1}
	
}
// Generated line, do not modify - void ejbPassivate()
public void ejbPassivate() throws java.rmi.RemoteException {
	
	// user code begin {__ejbPassivate()_1}
	// user code end {__ejbPassivate()_1}
	
	connectionSpec = null;
	comCommand = null;	
}
// Generated line, do not modify - void ejbRemove()
public void ejbRemove() throws java.rmi.RemoteException {
	
	// user code begin {__ejbRemove()_1}
	// user code end {__ejbRemove()_1}
	
	comCommand = null;	
}
// Generated line, do not modify - void executeInteraction(CommunicationCommand,InteractionSpec,Object,Object)
private void executeInteraction(CommunicationCommand command, InteractionSpec is, Object in, Object out) throws java.rmi.RemoteException {
	try {
		beforeInteraction();
		
		if (is!=null)
			command.setInteractionSpec(is);
		
		if (in!=null)
			command.setInput(in);
		
		if (out!=null)
			command.setOutput(out);
		
		command.execute();
		afterInteraction();
	}
	catch (Throwable e) {
		handleException();
		java.io.ByteArrayOutputStream stream = new java.io.ByteArrayOutputStream();
		java.io.PrintWriter writer = new java.io.PrintWriter(stream);
		writer.println(e.toString());
		e.printStackTrace(writer);
		writer.flush();
		throw new java.rmi.RemoteException(stream.toString());
	}
}
// Generated line, do not modify - void executeInteraction(InteractionSpec,Object,Object)
private void executeInteraction(InteractionSpec is, Object in, Object out) throws java.rmi.RemoteException {
	executeInteraction(comCommand, is, in, out);
}
// Generated line, do not modify - void handleException()
private void handleException() {

	// Rollback changes if runtimeContext was set in beforeExecution() method
	
	if (this.runtimeContextSet){
	
		// Rollback changes
		((com.ibm.connector.infrastructure.java.JavaCoordinator)RuntimeContext.getCurrent().getCoordinator()).rollback();
		
		// Close runtime context
		JavaRuntimeContext.getCurrent().close();
		
		// Remove current runtime context
		JavaRuntimeContext.removeCurrent();
		this.runtimeContextSet = false;
		
	}
	// user code begin {__handleException()_1}
	// user code end {__handleException()_1}
	
}
/**
 * Need to cast the IByteBuffer to one of the following:
 * @return itso.stuvaj.imsconn.OutputMsg
 * @return com.ibm.connector.imstoc.DFSMsg
 */

// Generated line, do not modify - IByteBuffer imsTran(itso.stuvaj.imsconn.InputMsg)
public IByteBuffer imsTran(itso.stuvaj.imsconn.InputMsg input) throws java.rmi.RemoteException {
	
	// user code begin {__imsTran(itso.stuvaj.imsconn.InputMsg)_1}
	// user code end {__imsTran(itso.stuvaj.imsconn.InputMsg)_1}
	
	itso.stuvaj.imsconn.ReadingCommand imsTran_command = new itso.stuvaj.imsconn.ReadingCommand();
	if (imsTran_command.getConnectionSpec() == null)
		imsTran_command.setConnectionSpec(connectionSpec);
	executeInteraction(imsTran_command, null, input, null);
	
	// user code begin {__imsTran(itso.stuvaj.imsconn.InputMsg)_2}
	// user code end {__imsTran(itso.stuvaj.imsconn.InputMsg)_2}
	
	return (IByteBuffer)imsTran_command.getOutput();
}
// Generated line, do not modify - void initializeConnectionSpec()
private void initializeConnectionSpec() throws java.rmi.RemoteException {
	
	Properties environmentalProperties = mySessionCtx.getEnvironment();
	if ((environmentalProperties == null) || (environmentalProperties.isEmpty()))
		initializeDefaultConnectionSpec();
	
	Hashtable propertyDescriptors = new Hashtable();
	try {
		String classType = environmentalProperties.get("connectionspec._csClassName").toString();
		connectionSpec = (ConnectionSpec)Beans.instantiate(getClass().getClassLoader(), classType);
		BeanInfo bInfo = Introspector.getBeanInfo(connectionSpec.getClass());
		PropertyDescriptor[] descriptors = bInfo.getPropertyDescriptors();
		for (int i = 0; i<descriptors.length; i++)
			propertyDescriptors.put(descriptors[i].getName(), descriptors[i]);
	}
	catch (Exception e) {
		if (connectionSpec == null)
			initializeDefaultConnectionSpec();
		return;
	}
	
	
	Enumeration propertyNames = environmentalProperties.propertyNames();
	while (propertyNames.hasMoreElements()) {
		String propertyName = (String)propertyNames.nextElement();
		
		if (propertyName.startsWith("connectionspec.")) {
			String pType = propertyName.substring(propertyName.lastIndexOf(".") + 1);
			String propertyValue = environmentalProperties.getProperty(propertyName);
			
			PropertyDescriptor desc = (java.beans.PropertyDescriptor)propertyDescriptors.get(pType);
			if (desc != null) {
				try {
					Method setMthd = desc.getWriteMethod();
					Class argType = desc.getPropertyType();
					Object valueObject = null;
					if (argType == String.class)
						valueObject = propertyValue;
					else if ((argType == boolean.class) || (argType == Boolean.class))
						valueObject = Boolean.valueOf(propertyValue);
					else if ((argType == char.class) || (argType == Character.class))
						valueObject = new Character(propertyValue.charAt(0));
					else if ((argType == byte.class) || (argType == Byte.class))
						valueObject = Byte.valueOf(propertyValue);
					else if ((argType == double.class) || (argType == Double.class))
						valueObject = Double.valueOf(propertyValue);
					else if ((argType == float.class) || (argType == Float.class))
						valueObject = Float.valueOf(propertyValue);
					else if ((argType == int.class) || (argType == Integer.class))
						valueObject = Integer.valueOf(propertyValue);
					else if ((argType == long.class) || (argType == Long.class))
						valueObject = Long.valueOf(propertyValue);
					else if ((argType == short.class) || (argType == Short.class))
						valueObject = Short.valueOf(propertyValue);
					setMthd.invoke(connectionSpec, new Object[] {valueObject});
				}
				catch (Exception e) {
					throw new java.rmi.RemoteException(desc.getName() + " " + e.getMessage());
				}
			}
		}
	}
}
// Generated line, do not modify - void initializeDefaultConnectionSpec()
//Initialze connection spec
private void initializeDefaultConnectionSpec() {
	connectionSpec = new com.ibm.connector.imstoc.IMSConnectionSpec();
	((com.ibm.connector.imstoc.IMSConnectionSpec)connectionSpec).setHostName("MYIMS");
	((com.ibm.connector.imstoc.IMSConnectionSpec)connectionSpec).setPortNumber(9999);
	
	// user code begin {__initializeDefaultConnectionSpec()_1}
	// user code end {__initializeDefaultConnectionSpec()_1}
	
}
// Generated line, do not modify - void setSessionContext(javax.ejb.SessionContext)
public void setSessionContext(javax.ejb.SessionContext ctx) throws java.rmi.RemoteException {
	mySessionCtx = ctx;
	// user code begin {__setSessionContext(javax.ejb.SessionContext)_1}
	// user code end {__setSessionContext(javax.ejb.SessionContext)_1}
	
}
}
