package itso.ejb35.bank;

/**
 * Insert the type's description here.
 * Creation date: (4/7/2001 3:22:21 PM)
 * @author: Ueli TP
 */
public class BankAccountBeanFinderObject extends com.ibm.vap.finders.VapEJSJDBCFinderObject implements BankAccountBeanFinderHelper {
	private String cachedFindAccountsForCustomerQueryString = null;
/**
 * BankAccountBeanFinderObject constructor comment.
 */
public BankAccountBeanFinderObject() {
	super();
}
public java.sql.PreparedStatement findAccountsForCustomer(int customerID) 
										throws Exception {
	// Get the full query string and make a PreparedStatement.
	java.sql.PreparedStatement ps = getPreparedStatement( 
								getFindAccountsForCustomerQueryString() );
	// Inject the product id parameter into each merged where clause.
	for (int i = 0; i < getMergedWhereCount(); i++) {
		ps.setInt(i+1, customerID);
	}
	return ps;
}
/**
 * findAccountsFor method comment.
 */
public java.sql.PreparedStatement findGoldAccounts(java.math.BigDecimal aBalance) throws Exception {
	java.sql.PreparedStatement pstmt = null;
	int mergedCount = getMergedWhereCount();
	int columnCount = 1; // number of ? in the original query
	pstmt = getMergedPreparedStatement( "T1.balance >= ?" );
	for (int i=0; i < (columnCount* mergedCount); i+=columnCount ) 
		pstmt.setBigDecimal( i+1, aBalance );
	return pstmt;
}
protected String getFindAccountsForCustomerQueryString() {
   if (cachedFindAccountsForCustomerQueryString == null) {
   
	  // Do the WHERE first 
	  // so that the genericFindInsertPoints are correct.
	  int i;
	  int[] genericFindInsertPoints = getGenericFindInsertPoints();
	  StringBuffer sb = new StringBuffer(getGenericFindSqlString());
	  for (i = 0; i < genericFindInsertPoints.length; i++) {
		 sb.insert(genericFindInsertPoints[i], 
			"(T1.accID = T4.accID) AND (T4.CustomerID = ?)");
	  }

	  // Make sure to update every FROM clause.
	  String soFar = sb.toString();
	  int fromOffset = soFar.indexOf(" FROM ");
	  while (fromOffset != -1) {
		 sb.insert((fromOffset+5)," ITSO.CustAcct T4, ");
		 soFar = sb.toString();
		 fromOffset = soFar.indexOf(" FROM ", (fromOffset+5));										
	  }
		cachedFindAccountsForCustomerQueryString = sb.toString();
   }
   return cachedFindAccountsForCustomerQueryString;
}
}
