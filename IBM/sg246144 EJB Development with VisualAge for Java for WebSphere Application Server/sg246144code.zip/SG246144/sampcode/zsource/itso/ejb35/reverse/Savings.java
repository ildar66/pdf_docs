package itso.ejb35.reverse;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface Savings extends javax.ejb.EJBObject {

/**
 * This method was generated for supporting the association named Savings SavingsAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.Account
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.reverse.Account getAccount() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Savings SavingsAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.AccountKey
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.reverse.AccountKey getAccountKey() throws java.rmi.RemoteException;
/**
 * Getter method for minamount
 * @return java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
java.math.BigDecimal getMinamount() throws java.rmi.RemoteException;
/**
 * Setter method for minamount
 * @param newValue java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
void setMinamount(java.math.BigDecimal newValue) throws java.rmi.RemoteException;
}
