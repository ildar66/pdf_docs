package itso.ejb35.rosebank;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface TransRecord extends javax.ejb.EJBObject {

/**
 * Getter method for accid
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getAccid() throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named AccountTransactions.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.BankAccount
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.rosebank.BankAccount getAccount() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named AccountTransactions.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.BankAccountKey
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.rosebank.BankAccountKey getAccountKey() throws java.rmi.RemoteException;
/**
 * Getter method for transamt
 * @return java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
java.math.BigDecimal getTransamt() throws java.rmi.RemoteException;
/**
 * Getter method for transid
 * @return java.sql.Timestamp
 * @exception java.rmi.RemoteException The exception description.
 */
java.sql.Timestamp getTransid() throws java.rmi.RemoteException;
/**
 * Getter method for transtype
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getTranstype() throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named AccountTransactions.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param inKey itso.ejb35.rosebank.BankAccountKey
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void privateSetAccountKey(itso.ejb35.rosebank.BankAccountKey inKey) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named AccountTransactions.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param anAccount itso.ejb35.rosebank.BankAccount
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void secondarySetAccount(itso.ejb35.rosebank.BankAccount anAccount) throws java.rmi.RemoteException;
/**
 * Setter method for accid
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setAccid(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named AccountTransactions.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param anAccount itso.ejb35.rosebank.BankAccount
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void setAccount(itso.ejb35.rosebank.BankAccount anAccount) throws java.rmi.RemoteException;
/**
 * Setter method for transamt
 * @param newValue java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
void setTransamt(java.math.BigDecimal newValue) throws java.rmi.RemoteException;
/**
 * Setter method for transid
 * @param newValue java.sql.Timestamp
 * @exception java.rmi.RemoteException The exception description.
 */
void setTransid(java.sql.Timestamp newValue) throws java.rmi.RemoteException;
/**
 * Setter method for transtype
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setTranstype(java.lang.String newValue) throws java.rmi.RemoteException;
}
