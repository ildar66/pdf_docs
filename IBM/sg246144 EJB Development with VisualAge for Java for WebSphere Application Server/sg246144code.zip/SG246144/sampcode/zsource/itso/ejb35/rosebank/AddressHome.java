package itso.ejb35.rosebank;

/**
 * This is a Home interface for the Entity Bean
 */
public interface AddressHome extends javax.ejb.EJBHome {

/**
 * create method for a CMP entity bean
 * @return itso.ejb35.rosebank.Address
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
itso.ejb35.rosebank.Address create() throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named CustomerAddress.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.Address
 * @param inKey itso.ejb35.rosebank.CustomerKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.rosebank.Address findAddressByCustomer(itso.ejb35.rosebank.CustomerKey inKey) throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * findByPrimaryKey method comment
 * @return itso.ejb35.rosebank.Address
 * @param key itso.ejb35.rosebank.AddressKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.ejb35.rosebank.Address findByPrimaryKey(itso.ejb35.rosebank.AddressKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
