package itso.stuvaj.ims;

public class ReadingCommandBeanInfo extends java.beans.SimpleBeanInfo {
// Generated line, do not modify - java.beans.PropertyDescriptor dataStoreNamePropertyDescriptor()
public java.beans.PropertyDescriptor dataStoreNamePropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("dataStoreName", Class.forName(getBeanClassName()), "getDataStoreName", "setDataStoreName");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("dataStoreName");
	  aDescriptor.setDisplayName("dataStoreName");
	  aDescriptor.setShortDescription("dataStoreName");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.PropertyDescriptor DFSDATA1PropertyDescriptor()
public java.beans.PropertyDescriptor DFSDATA1PropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("DFSDATA1", Class.forName(getBeanClassName()), "getDFSDATA1", "setDFSDATA1");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("DFSDATA1");
	  aDescriptor.setDisplayName("DFSDATA1");
	  aDescriptor.setShortDescription("DFSDATA1");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.BeanInfo[] getAdditionalBeanInfo()
public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	java.lang.Class superClass;
	java.beans.BeanInfo superBeanInfo = null;

	try {
		superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	} catch (java.lang.Throwable exception) {
		return null;
	}

	try {
		superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	} catch (java.beans.IntrospectionException ie) {}
	if (superBeanInfo != null) {
		java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		ret[0] = superBeanInfo;
		return ret;
	}
	return null;
}
// Generated line, do not modify - java.lang.Class getBeanClass()
public static java.lang.Class getBeanClass() {
	return ls.conn.ims.cmd.ReadingCommand.class;
}
// Generated line, do not modify - java.lang.String getBeanClassName()
public static java.lang.String getBeanClassName() {
	return "ls.conn.ims.cmd.ReadingCommand";
}
// Generated line, do not modify - java.beans.BeanDescriptor getBeanDescriptor()
public java.beans.BeanDescriptor getBeanDescriptor() {
	java.beans.BeanDescriptor aDescriptor = null;
	try {
		aDescriptor = new java.beans.BeanDescriptor(ls.conn.ims.cmd.ReadingCommand.class);
	} catch (Throwable exception) {
	};
	return aDescriptor;
}
// Generated line, do not modify - java.beans.EventSetDescriptor[] getEventSetDescriptors()
public java.beans.EventSetDescriptor[] getEventSetDescriptors() {
	return null;
}
// Generated line, do not modify - java.beans.MethodDescriptor[] getMethodDescriptors()
public java.beans.MethodDescriptor[] getMethodDescriptors() {
	return null;
}
// Generated line, do not modify - java.beans.PropertyDescriptor[] getPropertyDescriptors()
public java.beans.PropertyDescriptor[] getPropertyDescriptors() {
	try {
		java.beans.PropertyDescriptor aDescriptorList[] = {
			inputSetAtRuntimePropertyDescriptor()
, portNumberPropertyDescriptor()
, hostNamePropertyDescriptor()
, dataStoreNamePropertyDescriptor()
, IN__STATIONIDPropertyDescriptor()
, OUT__CMDPropertyDescriptor()
, OUT__STATIONIDPropertyDescriptor()
, OUT__WINDSPEEDPropertyDescriptor()
, OUT__MSGPropertyDescriptor()
, OUT__PLANETNAMEPropertyDescriptor()
, OUT__LOCALTIMEPropertyDescriptor()
, OUT__LOCALDATEPropertyDescriptor()
, OUT__TEMPERATUREPropertyDescriptor()
, OUT__HUMIDITYPropertyDescriptor()
, DFSDATA1PropertyDescriptor()
		};
		return aDescriptorList;
	} catch (Throwable exception) {
		handleException(exception);
	};
	return null;
}
// Generated line, do not modify - void handleException(java.lang.Throwable)
private void handleException(java.lang.Throwable exception) {
}
// Generated line, do not modify - java.beans.PropertyDescriptor hostNamePropertyDescriptor()
public java.beans.PropertyDescriptor hostNamePropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("hostName", Class.forName(getBeanClassName()), "getHostName", "setHostName");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("hostName");
	  aDescriptor.setDisplayName("hostName");
	  aDescriptor.setShortDescription("hostName");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.PropertyDescriptor IN__STATIONIDPropertyDescriptor()
public java.beans.PropertyDescriptor IN__STATIONIDPropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("IN__STATIONID", Class.forName(getBeanClassName()), "getIN__STATIONID", "setIN__STATIONID");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("IN__STATIONID");
	  aDescriptor.setDisplayName("IN__STATIONID");
	  aDescriptor.setShortDescription("IN__STATIONID");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.PropertyDescriptor inputSetAtRuntimePropertyDescriptor()
public java.beans.PropertyDescriptor inputSetAtRuntimePropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("inputSetAtRuntime", Class.forName(getBeanClassName()), "getInputSetAtRuntime", "setInputSetAtRuntime");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("inputSetAtRuntime");
	  aDescriptor.setDisplayName("inputSetAtRuntime");
	  aDescriptor.setShortDescription("inputSetAtRuntime");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.PropertyDescriptor OUT__CMDPropertyDescriptor()
public java.beans.PropertyDescriptor OUT__CMDPropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__CMD", Class.forName(getBeanClassName()), "getOUT__CMD", "setOUT__CMD");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__CMD");
	  aDescriptor.setDisplayName("OUT__CMD");
	  aDescriptor.setShortDescription("OUT__CMD");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.PropertyDescriptor OUT__HUMIDITYPropertyDescriptor()
public java.beans.PropertyDescriptor OUT__HUMIDITYPropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__HUMIDITY", Class.forName(getBeanClassName()), "getOUT__HUMIDITY", "setOUT__HUMIDITY");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__HUMIDITY");
	  aDescriptor.setDisplayName("OUT__HUMIDITY");
	  aDescriptor.setShortDescription("OUT__HUMIDITY");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.PropertyDescriptor OUT__LOCALDATEPropertyDescriptor()
public java.beans.PropertyDescriptor OUT__LOCALDATEPropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__LOCALDATE", Class.forName(getBeanClassName()), "getOUT__LOCALDATE", "setOUT__LOCALDATE");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__LOCALDATE");
	  aDescriptor.setDisplayName("OUT__LOCALDATE");
	  aDescriptor.setShortDescription("OUT__LOCALDATE");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.PropertyDescriptor OUT__LOCALTIMEPropertyDescriptor()
public java.beans.PropertyDescriptor OUT__LOCALTIMEPropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__LOCALTIME", Class.forName(getBeanClassName()), "getOUT__LOCALTIME", "setOUT__LOCALTIME");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__LOCALTIME");
	  aDescriptor.setDisplayName("OUT__LOCALTIME");
	  aDescriptor.setShortDescription("OUT__LOCALTIME");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.PropertyDescriptor OUT__MSGPropertyDescriptor()
public java.beans.PropertyDescriptor OUT__MSGPropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__MSG", Class.forName(getBeanClassName()), "getOUT__MSG", "setOUT__MSG");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__MSG");
	  aDescriptor.setDisplayName("OUT__MSG");
	  aDescriptor.setShortDescription("OUT__MSG");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.PropertyDescriptor OUT__PLANETNAMEPropertyDescriptor()
public java.beans.PropertyDescriptor OUT__PLANETNAMEPropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__PLANETNAME", Class.forName(getBeanClassName()), "getOUT__PLANETNAME", "setOUT__PLANETNAME");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__PLANETNAME");
	  aDescriptor.setDisplayName("OUT__PLANETNAME");
	  aDescriptor.setShortDescription("OUT__PLANETNAME");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.PropertyDescriptor OUT__STATIONIDPropertyDescriptor()
public java.beans.PropertyDescriptor OUT__STATIONIDPropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__STATIONID", Class.forName(getBeanClassName()), "getOUT__STATIONID", "setOUT__STATIONID");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__STATIONID");
	  aDescriptor.setDisplayName("OUT__STATIONID");
	  aDescriptor.setShortDescription("OUT__STATIONID");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.PropertyDescriptor OUT__TEMPERATUREPropertyDescriptor()
public java.beans.PropertyDescriptor OUT__TEMPERATUREPropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__TEMPERATURE", Class.forName(getBeanClassName()), "getOUT__TEMPERATURE", "setOUT__TEMPERATURE");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__TEMPERATURE");
	  aDescriptor.setDisplayName("OUT__TEMPERATURE");
	  aDescriptor.setShortDescription("OUT__TEMPERATURE");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.PropertyDescriptor OUT__WINDSPEEDPropertyDescriptor()
public java.beans.PropertyDescriptor OUT__WINDSPEEDPropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__WINDSPEED", Class.forName(getBeanClassName()), "getOUT__WINDSPEED", "setOUT__WINDSPEED");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__WINDSPEED");
	  aDescriptor.setDisplayName("OUT__WINDSPEED");
	  aDescriptor.setShortDescription("OUT__WINDSPEED");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
// Generated line, do not modify - java.beans.PropertyDescriptor portNumberPropertyDescriptor()
public java.beans.PropertyDescriptor portNumberPropertyDescriptor() 
throws java.beans.IntrospectionException {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("portNumber", Class.forName(getBeanClassName()), "getPortNumber", "setPortNumber");
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }
	  aDescriptor.setBound(true);
	  aDescriptor.setName("portNumber");
	  aDescriptor.setDisplayName("portNumber");
	  aDescriptor.setShortDescription("portNumber");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
}
}
