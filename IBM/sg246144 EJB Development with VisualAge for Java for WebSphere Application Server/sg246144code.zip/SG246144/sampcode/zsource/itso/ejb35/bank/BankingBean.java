package itso.ejb35.bank;

import java.rmi.RemoteException;
import java.security.Identity;
import java.util.Properties;
import javax.ejb.*;
import java.rmi.*;
import javax.naming.*;
import java.math.BigDecimal;
/**
 * This is a Session Bean Class
 */
public class BankingBean implements SessionBean {
	private javax.ejb.SessionContext mySessionCtx = null;
	final static long serialVersionUID = 3206093459760846163L;
	private BankAccountHome bankAccHome;
public BigDecimal deposit(String anAccountID, BigDecimal anAmount) {

	// Initialize the accounts
	BankAccount anAccount = null;
	try {
		// Find the account
		anAccount = bankAccHome.findByPrimaryKey(new BankAccountKey(anAccountID));

		// Perform the deposit
		anAccount.deposit(anAmount);
		return anAccount.getBalance();

	} catch(Exception exc) {
		System.out.println("Deposit on the account failed!");
		return null;
	}
}
/**
 * ejbActivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbActivate() throws java.rmi.RemoteException {}
/**
 * ejbCreate method comment
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbCreate() throws javax.ejb.CreateException, java.rmi.RemoteException {
	InitialContext ctx = null;
	Properties prop = new Properties();
	try {
		prop.put( Context.PROVIDER_URL,"iiop://localhost:900/" );
		prop.put( Context.INITIAL_CONTEXT_FACTORY, 
					"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
		ctx = new InitialContext(prop);
		bankAccHome = (BankAccountHome) javax.rmi.PortableRemoteObject.narrow
			( ctx.lookup("itso/ejb35/bank/BankAccount"),BankAccountHome.class );
	} catch ( NamingException exc ) {
		System.out.println( "Error retrieving the home of BankAccount" );
		exc.printStackTrace();
	}	
}
/**
 * ejbPassivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPassivate() throws java.rmi.RemoteException {}
/**
 * ejbRemove method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbRemove() throws java.rmi.RemoteException {}
public BigDecimal getBalance(String anAccountID) {

	// Initialize the accounts
	BankAccount anAccount = null;
	try {
		// Find the accounts
		anAccount = bankAccHome.findByPrimaryKey(new BankAccountKey(anAccountID));
		return anAccount.getBalance();

	} catch(Exception exc) {
		exc.printStackTrace();
		System.out.println("Exception: an account could not be found!");
		return null;
	}
}
/**
 * getSessionContext method comment
 * @return javax.ejb.SessionContext
 */
public javax.ejb.SessionContext getSessionContext() {
	return mySessionCtx;
}
/**
 * setSessionContext method comment
 * @param ctx javax.ejb.SessionContext
 * @exception java.rmi.RemoteException The exception description.
 */
public void setSessionContext(javax.ejb.SessionContext ctx) throws java.rmi.RemoteException {
	mySessionCtx = ctx;
}
public void transferMoney(String fromAccountID, String toAccountID, BigDecimal anAmount)
											throws itso.ejb35.util.InsufficientFundException {

	// Initialize the two accounts
	BankAccount fromAccount = null, toAccount = null;
	try {
		// Find the two accounts
		fromAccount = bankAccHome.findByPrimaryKey(new BankAccountKey(fromAccountID));
		toAccount   = bankAccHome.findByPrimaryKey(new BankAccountKey(toAccountID));

		// Perform the money transfer
		fromAccount.withdraw(anAmount);
		toAccount.deposit(anAmount);        

	} catch(FinderException exc) {
		exc.printStackTrace();
		System.out.println("FinderException: an account could not be found!"); 
	} catch(RemoteException exc) {
		exc.printStackTrace();
		System.out.println("RemoteException: an account could not be accessed!"); 
	}
}
public BigDecimal withdraw(String anAccountID, BigDecimal anAmount) 
			throws itso.ejb35.util.InsufficientFundException {

	// Initialize the accounts
	BankAccount anAccount = null;
	try {
		// Find the accounts
		anAccount = bankAccHome.findByPrimaryKey(new BankAccountKey(anAccountID));

		// Perform the withdraw
		anAccount.withdraw(anAmount);    
		return anAccount.getBalance(); 

	} catch(Exception exc) {
		System.out.println("Withdraw on the account failed!");
		return null;
	}
}
}
