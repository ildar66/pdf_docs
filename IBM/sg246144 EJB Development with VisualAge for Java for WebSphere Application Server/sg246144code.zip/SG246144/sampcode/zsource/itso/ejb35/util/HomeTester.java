package itso.ejb35.util;

/**
 * Insert the type's description here.
 * Creation date: (4/30/2001 11:35:44 AM)
 * @author: Ueli TP
 */
import itso.ejb35.cmp.*;
public class HomeTester {
public static void main(java.lang.String[] args) {
	CustomerHome    custhome;
	BankAccountHome bankhome;
	Customer        cust;
	try {
		custhome = (CustomerHome)HomeHelper.getHomeInterface
			("itso/ejb35/cmp/Customer", CustomerHome.class);
		bankhome = (BankAccountHome)HomeHelper.getHomeInterface
			("itso/ejb35/cmp/BankAccount", BankAccountHome.class);
		cust = custhome.findByPrimaryKey(new CustomerKey(106) );
		System.out.println("Customer 106 "+cust.getName());
	}
	catch (Exception ex) {
		ex.printStackTrace();
	}
}
}
