package itso.ejb35.reverse;

/**
 * This is a Home interface for the Entity Bean
 */
public interface TransrecordHome extends javax.ejb.EJBHome {

/**
 * create method for a CMP entity bean
 * @return itso.ejb35.reverse.Transrecord
 * @param argTransid java.sql.Timestamp
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
itso.ejb35.reverse.Transrecord create(java.sql.Timestamp argTransid) throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * findByPrimaryKey method comment
 * @return itso.ejb35.reverse.Transrecord
 * @param key itso.ejb35.reverse.TransrecordKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.ejb35.reverse.Transrecord findByPrimaryKey(itso.ejb35.reverse.TransrecordKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return java.util.Enumeration
 * @param inKey itso.ejb35.reverse.AccountKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
java.util.Enumeration findTransrecordByAccount(itso.ejb35.reverse.AccountKey inKey) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
