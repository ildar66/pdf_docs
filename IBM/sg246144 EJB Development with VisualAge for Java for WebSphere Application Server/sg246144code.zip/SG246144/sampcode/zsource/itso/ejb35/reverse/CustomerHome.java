package itso.ejb35.reverse;

/**
 * This is a Home interface for the Entity Bean
 */
public interface CustomerHome extends javax.ejb.EJBHome {

/**
 * create method for a CMP entity bean
 * @return itso.ejb35.reverse.Customer
 * @param argCustomerid int
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
itso.ejb35.reverse.Customer create(int argCustomerid) throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * findByPrimaryKey method comment
 * @return itso.ejb35.reverse.Customer
 * @param key itso.ejb35.reverse.CustomerKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.ejb35.reverse.Customer findByPrimaryKey(itso.ejb35.reverse.CustomerKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
