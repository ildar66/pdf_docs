package itso.ejb35.cmp.servlet;

import itso.ejb35.cmp.*;
import itso.ejb35.session.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 12:56:49 PM)
 * @author: Ueli TP
 */
public class CustomerFindSFAB extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
public void performTask(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
	// Read the input parameter from the HTML Form
	String id = request.getParameter("CustomerID");
	int custId = (new Integer(id)).intValue();
	// Set the results page URL
	String url = "/ejb/cmpservlet/CustomerFindAB.jsp";

	// Instantiate the access bean and initialize it
	CustomerAccessBean customer = null;
	CustomerManagerAccessBean customerMgr = new CustomerManagerAccessBean();      
	try {
		customer = customerMgr.findCustomer(custId);
	} catch (Exception e) {
		System.out.println("Cannot find customer with id: "+id);
	}
	
	// Forward to the results JSP
	request.setAttribute("customer", customer);
	getServletConfig().getServletContext().getRequestDispatcher(url).
			forward(request, response);
}
}
