package itso.ejb35.session;

import itso.ejb35.cmp.*;
import java.math.BigDecimal;
import java.rmi.*;
import java.rmi.RemoteException;
import java.security.Identity;
import java.util.Properties;
import javax.ejb.*;
import javax.naming.*;
/**
 * This is a Session Bean Class
 */
public class TransferBean implements SessionBean {
	private javax.ejb.SessionContext mySessionCtx = null;
	final static long serialVersionUID = 3206093459760846163L;
	private BankAccountHome bankAccHome;
/**
 * ejbActivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbActivate() throws java.rmi.RemoteException {}
/**
 * ejbCreate method comment
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbCreate() throws javax.ejb.CreateException, java.rmi.RemoteException {
	InitialContext ctx = null;
	Properties prop = new Properties();
	try {
		//prop.put( Context.PROVIDER_URL,"iiop:///" );
		//prop.put( Context.INITIAL_CONTEXT_FACTORY, 
		//			"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
		//ctx = new InitialContext(prop);
		ctx = new InitialContext();
		bankAccHome = (BankAccountHome) javax.rmi.PortableRemoteObject.narrow
			( ctx.lookup("itso/ejb35/cmp/BankAccount"),BankAccountHome.class );
	} catch ( NamingException exc ) {
		System.out.println( "Error retrieving the home of BankAccount" );
		exc.printStackTrace();
	}	
}
/**
 * ejbPassivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPassivate() throws java.rmi.RemoteException {}
/**
 * ejbRemove method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbRemove() throws java.rmi.RemoteException {}
/**
 * getSessionContext method comment
 * @return javax.ejb.SessionContext
 */
public javax.ejb.SessionContext getSessionContext() {
	return mySessionCtx;
}
public void performTest(String accountID) {

	BankAccount account = null;
	BigDecimal balance;
	try {
		System.out.println("Session - start");
		account = bankAccHome.findByPrimaryKey(new BankAccountKey(accountID));
		System.out.println("Session - get balance");
		balance = account.getBalance();
		System.out.println("Session - balance="+balance);
		balance = balance.add( new BigDecimal(10.00) );
		System.out.println("Session - set balance");
		account.setBalance(balance);
		System.out.println("Session - get balance");
		balance = account.getBalance();
		System.out.println("Session - balance="+balance);
		balance = balance.subtract( new BigDecimal(10.00) );
		System.out.println("Session - set balance");
		account.setBalance(balance);
		System.out.println("Session - get balance");
		balance = account.getBalance();
		System.out.println("Session - balance="+balance);
		System.out.println("Session - end");
	} catch(FinderException exc) {
		exc.printStackTrace();
		System.out.println("FinderException: an account could not be found!"); 
	} catch(RemoteException exc) {
		exc.printStackTrace();
		System.out.println("RemoteException: an account could not be accessed!"); 
	}
}
/**
 * setSessionContext method comment
 * @param ctx javax.ejb.SessionContext
 * @exception java.rmi.RemoteException The exception description.
 */
public void setSessionContext(javax.ejb.SessionContext ctx) throws java.rmi.RemoteException {
	mySessionCtx = ctx;
}
public void transferMoney(String fromAccountID, String toAccountID, BigDecimal anAmount)
							throws itso.ejb35.util.InsufficientFundException {

	// Initialize the two accounts
	BankAccount fromAccount = null, toAccount = null;
	try {
		// Find the two accounts
		fromAccount = bankAccHome.findByPrimaryKey(new BankAccountKey(fromAccountID));
		toAccount   = bankAccHome.findByPrimaryKey(new BankAccountKey(toAccountID));

		// Perform the money transfer
		fromAccount.withdraw(anAmount);
		toAccount.deposit(anAmount);        

	} catch(FinderException exc) {
		exc.printStackTrace();
		System.out.println("FinderException: an account could not be found!"); 
	} catch(RemoteException exc) {
		exc.printStackTrace();
		System.out.println("RemoteException: an account could not be accessed!"); 
	}
}
}
