package itso.ejb35.util;

/**
 * Insert the type's description here.
 * Creation date: (3/22/2001 2:26:05 PM)
 * @author: Ueli TP
 */
public class InsufficientFundException extends Exception {
/**
 * InsufficientFundException constructor comment.
 */
public InsufficientFundException() {
	super();
}
/**
 * InsufficientFundException constructor comment.
 * @param s java.lang.String
 */
public InsufficientFundException(String s) {
	super(s);
}
}
