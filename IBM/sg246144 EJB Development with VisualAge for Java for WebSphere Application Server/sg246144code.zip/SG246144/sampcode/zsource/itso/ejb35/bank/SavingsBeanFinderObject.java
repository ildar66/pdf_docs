package itso.ejb35.bank;

/**
 * Insert the type's description here.
 * Creation date: (4/7/2001 3:22:21 PM)
 * @author: Ueli TP
 */
public class SavingsBeanFinderObject extends BankAccountBeanFinderObject implements SavingsBeanFinderHelper {
/**
 * BankAccountBeanFinderObject constructor comment.
 */
public SavingsBeanFinderObject() {
	super();
}
}
