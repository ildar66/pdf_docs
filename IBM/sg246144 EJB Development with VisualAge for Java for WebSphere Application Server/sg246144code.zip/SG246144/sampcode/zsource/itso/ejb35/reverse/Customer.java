package itso.ejb35.reverse;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface Customer extends javax.ejb.EJBObject {

/**
 * This method was generated for supporting the association named Custacct CAtoCustomer Customer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return java.util.Enumeration
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
java.util.Enumeration getCustacct() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * Getter method for firstname
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getFirstname() throws java.rmi.RemoteException;
/**
 * Getter method for lastname
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getLastname() throws java.rmi.RemoteException;
/**
 * Getter method for password
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getPassword() throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Address CustAddress Customer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.reverse.Address getTheAddress() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * Getter method for title
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getTitle() throws java.rmi.RemoteException;
/**
 * Getter method for userid
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getUserid() throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Custacct CAtoCustomer Customer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aCustacct itso.ejb35.reverse.Custacct
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void secondaryAddCustacct(itso.ejb35.reverse.Custacct aCustacct) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Custacct CAtoCustomer Customer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aCustacct itso.ejb35.reverse.Custacct
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void secondaryRemoveCustacct(itso.ejb35.reverse.Custacct aCustacct) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Address CustAddress Customer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void secondarySetTheAddress(itso.ejb35.reverse.Address aTheAddress) throws java.rmi.RemoteException;
/**
 * Setter method for address
 * @param newValue byte[]
 * @exception java.rmi.RemoteException The exception description.
 */
void setAddress(byte[] newValue) throws java.rmi.RemoteException;
/**
 * Setter method for firstname
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setFirstname(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * Setter method for lastname
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setLastname(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * Setter method for password
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setPassword(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * Setter method for title
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setTitle(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * Setter method for userid
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setUserid(java.lang.String newValue) throws java.rmi.RemoteException;
}
