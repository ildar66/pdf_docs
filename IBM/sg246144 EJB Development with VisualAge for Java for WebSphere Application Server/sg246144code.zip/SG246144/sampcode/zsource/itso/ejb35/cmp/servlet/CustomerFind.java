package itso.ejb35.cmp.servlet;

import itso.ejb35.cmp.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 12:56:49 PM)
 * @author: Ueli TP
 */
public class CustomerFind extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
	public void performTask(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
	// Read the input parameter from the HTML Form
	String id = request.getParameter("CustomerID");
	int custId = (new Integer(id)).intValue();
	// Set the results page URL
	String url = "/ejb/cmpservlet/CustomerFind.jsp";
	try
	{
		// Get the initial naming context
		//java.util.Properties properties = new java.util.Properties();
		//properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
		//properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY, 
		//		"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
		//javax.naming.InitialContext initialContext = new javax.naming.InitialContext(properties);
		javax.naming.InitialContext initialContext = new javax.naming.InitialContext();

		// Obtain the EJBHome for Customer
		Object objHome = initialContext.lookup("itso/ejb35/cmp/Customer");
		CustomerHome customerHome = (CustomerHome)
			javax.rmi.PortableRemoteObject.narrow(objHome,CustomerHome.class);

		// Find the customer
		Customer customer = customerHome.findByPrimaryKey(new CustomerKey(custId));

		// Forward to the results JSP
		request.setAttribute("customer", customer);
		getServletConfig().getServletContext().getRequestDispatcher(url).
			forward(request, response);
	}
	catch (Exception e)
	{
		System.out.println("Exception thrown for customer with id:" + id);
		e.printStackTrace();
	}
	}
}
