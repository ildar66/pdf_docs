package itso.ejb35.reverse;

import java.rmi.RemoteException;
import java.security.Identity;
import java.util.Properties;
import javax.ejb.*;
/**
 * This is an Entity Bean class with CMP fields
 */
public class AccountBean implements EntityBean {
	public String accid;
	public String acctype;
	public java.math.BigDecimal balance;
	private transient com.ibm.ivj.ejb.associations.interfaces.SingleLink checkingLink = null;
	private transient com.ibm.ivj.ejb.associations.interfaces.ManyLink custacctLink = null;
	private javax.ejb.EntityContext entityContext = null;
	private transient com.ibm.ivj.ejb.associations.interfaces.SingleLink savingsLink = null;
	final static long serialVersionUID = 3206093459760846163L;
	private transient com.ibm.ivj.ejb.associations.interfaces.ManyLink transrecordLink = null;

/**
 * This method was generated for supporting the associations.
 * @return java.util.Vector
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected java.util.Vector _getLinks() {
	java.util.Vector links = new java.util.Vector();
	links.addElement(getCheckingLink());
	links.addElement(getSavingsLink());
	links.addElement(getTransrecordLink());
	links.addElement(getCustacctLink());
	return links;
}
/**
 * This method was generated for supporting the associations.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected void _initLinks() {
	checkingLink = null;
	savingsLink = null;
	transrecordLink = null;
	custacctLink = null;
}
/**
 * This method was generated for supporting the associations.
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.RemoveException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected void _removeLinks() throws java.rmi.RemoteException, javax.ejb.RemoveException {
	java.util.Enumeration links = _getLinks().elements();
	while (links.hasMoreElements()) {
		try {
			((com.ibm.ivj.ejb.associations.interfaces.Link) (links.nextElement())).remove();
		}
		catch (javax.ejb.FinderException e) {} //Consume Finder error since I am going away
	}
}
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aTransrecord itso.ejb35.reverse.Transrecord
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void addTransrecord(itso.ejb35.reverse.Transrecord aTransrecord) throws java.rmi.RemoteException {
	this.getTransrecordLink().addElement(aTransrecord);
}
/**
 * ejbActivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbActivate() throws java.rmi.RemoteException {
	_initLinks();
}
/**
 * ejbCreate method for a CMP entity bean
 * @param argAccid java.lang.String
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbCreate(java.lang.String argAccid) throws javax.ejb.CreateException, java.rmi.RemoteException {
	_initLinks();
	// All CMP fields should be initialized here.
	accid = argAccid;
}
/**
 * ejbLoad method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbLoad() throws java.rmi.RemoteException {
	_initLinks();
}
/**
 * ejbPassivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPassivate() throws java.rmi.RemoteException {}
/**
 * ejbPostCreate method for a CMP entity bean
 * @param argAccid java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPostCreate(java.lang.String argAccid) throws java.rmi.RemoteException {}
/**
 * ejbRemove method comment
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.RemoveException The exception description.
 */
public void ejbRemove() throws java.rmi.RemoteException, javax.ejb.RemoveException {
	_removeLinks();
}
/**
 * ejbStore method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbStore() throws java.rmi.RemoteException {}
/**
 * Getter method for acctype
 * @return java.lang.String
 */
public java.lang.String getAcctype() {
	return acctype;
}
/**
 * Getter method for balance
 * @return java.math.BigDecimal
 */
public java.math.BigDecimal getBalance() {
	return balance;
}
/**
 * This method was generated for supporting the association named Checking CheckingAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.Checking
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.reverse.Checking getChecking() throws java.rmi.RemoteException, javax.ejb.FinderException {
	return (itso.ejb35.reverse.Checking)this.getCheckingLink().value();
}
/**
 * This method was generated for supporting the association named Checking CheckingAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return com.ibm.ivj.ejb.associations.interfaces.SingleLink
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected com.ibm.ivj.ejb.associations.interfaces.SingleLink getCheckingLink() {
	if (checkingLink == null)
		checkingLink = new AccountToCheckingLink(this);
	return checkingLink;
}
/**
 * This method was generated for supporting the association named Custacct CAtoAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return java.util.Enumeration
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public java.util.Enumeration getCustacct() throws java.rmi.RemoteException, javax.ejb.FinderException {
	return this.getCustacctLink().enumerationValue();
}
/**
 * This method was generated for supporting the association named Custacct CAtoAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return com.ibm.ivj.ejb.associations.interfaces.ManyLink
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected com.ibm.ivj.ejb.associations.interfaces.ManyLink getCustacctLink() {
	if (custacctLink == null)
		custacctLink = new AccountToCustacctLink(this);
	return custacctLink;
}
/**
 * getEntityContext method comment
 * @return javax.ejb.EntityContext
 */
public javax.ejb.EntityContext getEntityContext() {
	return entityContext;
}
/**
 * This method was generated for supporting the association named Savings SavingsAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.Savings
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.reverse.Savings getSavings() throws java.rmi.RemoteException, javax.ejb.FinderException {
	return (itso.ejb35.reverse.Savings)this.getSavingsLink().value();
}
/**
 * This method was generated for supporting the association named Savings SavingsAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return com.ibm.ivj.ejb.associations.interfaces.SingleLink
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected com.ibm.ivj.ejb.associations.interfaces.SingleLink getSavingsLink() {
	if (savingsLink == null)
		savingsLink = new AccountToSavingsLink(this);
	return savingsLink;
}
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return java.util.Enumeration
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public java.util.Enumeration getTransrecord() throws java.rmi.RemoteException, javax.ejb.FinderException {
	return this.getTransrecordLink().enumerationValue();
}
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return com.ibm.ivj.ejb.associations.interfaces.ManyLink
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected com.ibm.ivj.ejb.associations.interfaces.ManyLink getTransrecordLink() {
	if (transrecordLink == null)
		transrecordLink = new AccountToTransrecordLink(this);
	return transrecordLink;
}
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aTransrecord itso.ejb35.reverse.Transrecord
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void removeTransrecord(itso.ejb35.reverse.Transrecord aTransrecord) throws java.rmi.RemoteException {
	this.getTransrecordLink().removeElement(aTransrecord);
}
/**
 * This method was generated for supporting the association named Custacct CAtoAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aCustacct itso.ejb35.reverse.Custacct
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void secondaryAddCustacct(itso.ejb35.reverse.Custacct aCustacct) {
	this.getCustacctLink().secondaryAddElement(aCustacct);
}
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aTransrecord itso.ejb35.reverse.Transrecord
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void secondaryAddTransrecord(itso.ejb35.reverse.Transrecord aTransrecord) {
	this.getTransrecordLink().secondaryAddElement(aTransrecord);
}
/**
 * This method was generated for supporting the association named Custacct CAtoAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aCustacct itso.ejb35.reverse.Custacct
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void secondaryRemoveCustacct(itso.ejb35.reverse.Custacct aCustacct) {
	this.getCustacctLink().secondaryRemoveElement(aCustacct);
}
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aTransrecord itso.ejb35.reverse.Transrecord
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void secondaryRemoveTransrecord(itso.ejb35.reverse.Transrecord aTransrecord) {
	this.getTransrecordLink().secondaryRemoveElement(aTransrecord);
}
/**
 * This method was generated for supporting the association named Checking CheckingAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aChecking itso.ejb35.reverse.Checking
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void secondarySetChecking(itso.ejb35.reverse.Checking aChecking) throws java.rmi.RemoteException {
	this.getCheckingLink().secondarySet(aChecking);
}
/**
 * This method was generated for supporting the association named Savings SavingsAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aSavings itso.ejb35.reverse.Savings
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void secondarySetSavings(itso.ejb35.reverse.Savings aSavings) throws java.rmi.RemoteException {
	this.getSavingsLink().secondarySet(aSavings);
}
/**
 * Setter method for acctype
 * @param newValue java.lang.String
 */
public void setAcctype(java.lang.String newValue) {
	this.acctype = newValue;
}
/**
 * Setter method for balance
 * @param newValue java.math.BigDecimal
 */
public void setBalance(java.math.BigDecimal newValue) {
	this.balance = newValue;
}
/**
 * setEntityContext method comment
 * @param ctx javax.ejb.EntityContext
 * @exception java.rmi.RemoteException The exception description.
 */
public void setEntityContext(javax.ejb.EntityContext ctx) throws java.rmi.RemoteException {
	entityContext = ctx;
}
/**
 * unsetEntityContext method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void unsetEntityContext() throws java.rmi.RemoteException {
	entityContext = null;
}
}
