package itso.ejb35.rosebank;

import java.rmi.RemoteException;
import java.security.Identity;
import java.util.Properties;
import javax.ejb.*;
/**
 * This is an Entity Bean class with CMP fields
 */
public class CustomerBean implements EntityBean {
	private transient com.ibm.ivj.ejb.associations.interfaces.SingleLink addressLink = null;
	private transient com.ibm.ivj.ejb.associations.interfaces.ManyLink custacctLink = null;
	public int customerID;
	private javax.ejb.EntityContext entityContext = null;
	public String firstName;
	public String lastName;
	public String password;
	private final static long serialVersionUID = 3206093459760846163L;
	public String title;
	public String userID;

/**
 * This method was generated for supporting the associations.
 * @return java.util.Vector
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected java.util.Vector _getLinks() {
	java.util.Vector links = new java.util.Vector();
	links.addElement(getAddressLink());
	links.addElement(getCustacctLink());
	return links;
}
/**
 * This method was generated for supporting the associations.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected void _initLinks() {
	addressLink = null;
	custacctLink = null;
}
/**
 * This method was generated for supporting the associations.
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.RemoveException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected void _removeLinks() throws java.rmi.RemoteException, javax.ejb.RemoveException {
	java.util.Enumeration links = _getLinks().elements();
	while (links.hasMoreElements()) {
		try {
			((com.ibm.ivj.ejb.associations.interfaces.Link) (links.nextElement())).remove();
		}
		catch (javax.ejb.FinderException e) {} //Consume Finder error since I am going away
	}
}
/**
 * ejbActivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbActivate() throws java.rmi.RemoteException {
	_initLinks();
}
/**
 * ejbCreate method for a CMP entity bean
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbCreate() throws javax.ejb.CreateException, java.rmi.RemoteException {
	_initLinks();
	// All CMP fields should be initialized here.
}
/**
 * ejbLoad method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbLoad() throws java.rmi.RemoteException {
	_initLinks();
}
/**
 * ejbPassivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPassivate() throws java.rmi.RemoteException {}
/**
 * ejbPostCreate method for a CMP entity bean
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPostCreate() throws java.rmi.RemoteException {}
/**
 * ejbRemove method comment
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.RemoveException The exception description.
 */
public void ejbRemove() throws java.rmi.RemoteException, javax.ejb.RemoveException {
	_removeLinks();
}
/**
 * ejbStore method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbStore() throws java.rmi.RemoteException {}
/**
 * This method was generated for supporting the association named CustomerAddress.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.Address
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.rosebank.Address getAddress() throws java.rmi.RemoteException, javax.ejb.FinderException {
	return (itso.ejb35.rosebank.Address)this.getAddressLink().value();
}
/**
 * This method was generated for supporting the association named CustomerAddress.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return com.ibm.ivj.ejb.associations.interfaces.SingleLink
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected com.ibm.ivj.ejb.associations.interfaces.SingleLink getAddressLink() {
	if (addressLink == null)
		addressLink = new CustomerToAddressLink(this);
	return addressLink;
}
/**
 * This method was generated for supporting the association named CustomerToAccount.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return java.util.Enumeration
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public java.util.Enumeration getCustacct() throws java.rmi.RemoteException, javax.ejb.FinderException {
	return this.getCustacctLink().enumerationValue();
}
/**
 * This method was generated for supporting the association named CustomerToAccount.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return com.ibm.ivj.ejb.associations.interfaces.ManyLink
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected com.ibm.ivj.ejb.associations.interfaces.ManyLink getCustacctLink() {
	if (custacctLink == null)
		custacctLink = new CustomerToCustacctLink(this);
	return custacctLink;
}
/**
 * Getter method for customerID
 * @return int
 */
public int getCustomerID() {
	return customerID;
}
/**
 * getEntityContext method comment
 * @return javax.ejb.EntityContext
 */
public javax.ejb.EntityContext getEntityContext() {
	return entityContext;
}
/**
 * Getter method for firstName
 * @return java.lang.String
 */
public java.lang.String getFirstName() {
	return firstName;
}
/**
 * Getter method for lastName
 * @return java.lang.String
 */
public java.lang.String getLastName() {
	return lastName;
}
/**
 * Getter method for password
 * @return java.lang.String
 */
public java.lang.String getPassword() {
	return password;
}
/**
 * Getter method for title
 * @return java.lang.String
 */
public java.lang.String getTitle() {
	return title;
}
/**
 * Getter method for userID
 * @return java.lang.String
 */
public java.lang.String getUserID() {
	return userID;
}
/**
 * This method was generated for supporting the association named CustomerToAccount.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aCustacct itso.ejb35.rosebank.CustAcct
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void secondaryAddCustacct(itso.ejb35.rosebank.CustAcct aCustacct) {
	this.getCustacctLink().secondaryAddElement(aCustacct);
}
/**
 * This method was generated for supporting the association named CustomerToAccount.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aCustacct itso.ejb35.rosebank.CustAcct
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void secondaryRemoveCustacct(itso.ejb35.rosebank.CustAcct aCustacct) {
	this.getCustacctLink().secondaryRemoveElement(aCustacct);
}
/**
 * This method was generated for supporting the association named CustomerAddress.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param anAddress itso.ejb35.rosebank.Address
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void secondarySetAddress(itso.ejb35.rosebank.Address anAddress) throws java.rmi.RemoteException {
	this.getAddressLink().secondarySet(anAddress);
}
/**
 * This method was generated for supporting the association named CustomerAddress.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param anAddress itso.ejb35.rosebank.Address
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void setAddress(itso.ejb35.rosebank.Address anAddress) throws java.rmi.RemoteException {
	this.getAddressLink().set(anAddress);
}
/**
 * Setter method for customerID
 * @param newValue int
 */
public void setCustomerID(int newValue) {
	this.customerID = newValue;
}
/**
 * setEntityContext method comment
 * @param ctx javax.ejb.EntityContext
 * @exception java.rmi.RemoteException The exception description.
 */
public void setEntityContext(javax.ejb.EntityContext ctx) throws java.rmi.RemoteException {
	entityContext = ctx;
}
/**
 * Setter method for firstName
 * @param newValue java.lang.String
 */
public void setFirstName(java.lang.String newValue) {
	this.firstName = newValue;
}
/**
 * Setter method for lastName
 * @param newValue java.lang.String
 */
public void setLastName(java.lang.String newValue) {
	this.lastName = newValue;
}
/**
 * Setter method for password
 * @param newValue java.lang.String
 */
public void setPassword(java.lang.String newValue) {
	this.password = newValue;
}
/**
 * Setter method for title
 * @param newValue java.lang.String
 */
public void setTitle(java.lang.String newValue) {
	this.title = newValue;
}
/**
 * Setter method for userID
 * @param newValue java.lang.String
 */
public void setUserID(java.lang.String newValue) {
	this.userID = newValue;
}
/**
 * unsetEntityContext method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void unsetEntityContext() throws java.rmi.RemoteException {
	entityContext = null;
}
}
