package itso.ejb35.javainherit;

/**
 * Insert the type's description here.
 * Creation date: (4/8/2001 11:06:21 AM)
 * @author: Ueli TP
 */
import java.math.BigDecimal;
public class Account {
	private BigDecimal fieldInterestRate = new BigDecimal(0.05);
/**
 * Account constructor comment.
 */
public Account() {
	super();
}
/**
 * Perform the calculateInterest method.
 * @return java.math.BigDecimal
 * @param balance java.math.BigDecimal
 */
public BigDecimal calculateInterest(BigDecimal balance) {
	/* Perform the calculateInterest method. */
	return balance.multiply( getInterestRate() );
}
/**
 * Gets the interestRate property (java.math.BigDecimal) value.
 * @return The interestRate property value.
 * @see #setInterestRate
 */
public BigDecimal getInterestRate() {
	return fieldInterestRate;
}
/**
 * Sets the interestRate property (java.math.BigDecimal) value.
 * @param interestRate The new value for the property.
 * @see #getInterestRate
 */
public void setInterestRate(BigDecimal interestRate) {
	fieldInterestRate = interestRate;
}
}
