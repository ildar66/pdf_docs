package itso.ejb35.javainherit;

/**
 * This is a Home interface for the Entity Bean
 */
public interface AccountCheckingHome extends javax.ejb.EJBHome {

/**
 * create method for a CMP entity bean
 * @return itso.ejb35.javainherit.AccountChecking
 * @param argAccID java.lang.String
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
itso.ejb35.javainherit.AccountChecking create(java.lang.String argAccID) throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * findByPrimaryKey method comment
 * @return itso.ejb35.javainherit.AccountChecking
 * @param key itso.ejb35.javainherit.AccountCheckingKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.ejb35.javainherit.AccountChecking findByPrimaryKey(itso.ejb35.javainherit.AccountCheckingKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
