package itso.ejb35.reverse.schema;

class Bank_ReverseSchema extends com.ibm.vap.common.SchemaStorageClass {
/**
 * This is a textual representation of Bank_Reverse to assist documentation and comparing class versions
 * Modifying the string has no effect on the actual data which is stored internally on the class
 * If a developer wishes to share their model data with another user in another repository the class
 * should be exported taking the option to export to a repository
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
static void infoString() {
/*Logical Name: Bank_Reverse
Physical Name: Bank_Reverse
Schema contains 
	7 table(s)
	25 column(s)
	6 foreignKey(s)
====================================================================================================
Logical Table Name: ACCOUNT
Physical Table Name: ACCOUNT
	 qualifier: ITSO
ACCOUNT contains: 
	3 column(s)
	4 foreign key relationship(s) 
ACCOUNT has primary key:  (ACCID)
ACCOUNT is pointed to by the following table(s), CHECKING , CUSTACCT , SAVINGS , TRANSRECORD 
----------------------------------------------------------------------------------------------------
	Column Logical Name: ACCID
	Column PhysicalName: ACCID
	Column Type: CHAR(8)
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships CheckingAccount (ACCOUNT), CAtoAccount (ACCOUNT), SavingsAccount (ACCOUNT), AccountTransrecord (ACCOUNT)
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: ACCTYPE
	Column PhysicalName: ACCTYPE
	Column Type: VARCHAR(8)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: BALANCE
	Column PhysicalName: BALANCE
	Column Type: DECIMAL(8, 2)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
====================================================================================================
Logical Table Name: ADDRESS
Physical Table Name: ADDRESS
	 qualifier: ITSO
ADDRESS contains: 
	5 column(s)
	1 foreign key relationship(s) 
ADDRESS has primary key:  (CUSTOMERID)
ADDRESS points to the following table(s), CUSTOMER 
----------------------------------------------------------------------------------------------------
	Column Logical Name: CITY
	Column PhysicalName: CITY
	Column Type: CHAR(12)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: CUSTOMERID
	Column PhysicalName: CUSTOMERID
	Column Type: INTEGER
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships CustAddress (CUSTOMER)
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: STATE
	Column PhysicalName: STATE
	Column Type: CHAR(12)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: STREET
	Column PhysicalName: STREET
	Column Type: CHAR(20)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: ZIPCODE
	Column PhysicalName: ZIPCODE
	Column Type: CHAR(10)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
====================================================================================================
Logical Table Name: CHECKING
Physical Table Name: CHECKING
	 qualifier: ITSO
CHECKING contains: 
	2 column(s)
	1 foreign key relationship(s) 
CHECKING has primary key:  (ACCID)
CHECKING points to the following table(s), ACCOUNT 
----------------------------------------------------------------------------------------------------
	Column Logical Name: ACCID
	Column PhysicalName: ACCID
	Column Type: CHAR(8)
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships CheckingAccount (ACCOUNT)
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: OVERDRAFT
	Column PhysicalName: OVERDRAFT
	Column Type: DECIMAL(8, 2)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
====================================================================================================
Logical Table Name: CUSTACCT
Physical Table Name: CUSTACCT
	 qualifier: ITSO
CUSTACCT contains: 
	2 column(s)
	2 foreign key relationship(s) 
CUSTACCT has primary key:  (ACCID CUSTOMERID)
CUSTACCT points to the following table(s), CUSTOMER , ACCOUNT 
----------------------------------------------------------------------------------------------------
	Column Logical Name: ACCID
	Column PhysicalName: ACCID
	Column Type: CHAR(8)
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships CAtoAccount (ACCOUNT)
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: CUSTOMERID
	Column PhysicalName: CUSTOMERID
	Column Type: INTEGER
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships CAtoCustomer (CUSTOMER)
	Converter Class: VapConverter
====================================================================================================
Logical Table Name: CUSTOMER
Physical Table Name: CUSTOMER
	 qualifier: ITSO
CUSTOMER contains: 
	7 column(s)
	2 foreign key relationship(s) 
CUSTOMER has primary key:  (CUSTOMERID)
CUSTOMER is pointed to by the following table(s), ADDRESS , CUSTACCT 
----------------------------------------------------------------------------------------------------
	Column Logical Name: ADDRESSX
	Column PhysicalName: ADDRESS
	Column Type: BLOB(2000)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: CUSTOMERID
	Column PhysicalName: CUSTOMERID
	Column Type: INTEGER
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships CustAddress (CUSTOMER), CAtoCustomer (CUSTOMER)
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: FIRSTNAME
	Column PhysicalName: FIRSTNAME
	Column Type: VARCHAR(30)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: LASTNAME
	Column PhysicalName: LASTNAME
	Column Type: VARCHAR(30)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: PASSWORD
	Column PhysicalName: PASSWORD
	Column Type: CHAR(8)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: TITLE
	Column PhysicalName: TITLE
	Column Type: CHAR(3)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: USERID
	Column PhysicalName: USERID
	Column Type: CHAR(8)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
====================================================================================================
Logical Table Name: SAVINGS
Physical Table Name: SAVINGS
	 qualifier: ITSO
SAVINGS contains: 
	2 column(s)
	1 foreign key relationship(s) 
SAVINGS has primary key:  (ACCID)
SAVINGS points to the following table(s), ACCOUNT 
----------------------------------------------------------------------------------------------------
	Column Logical Name: ACCID
	Column PhysicalName: ACCID
	Column Type: CHAR(8)
	Nulls Allowed: no
	Part of Primary key: yes
	Part of the following foreign key relationships SavingsAccount (ACCOUNT)
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: MINAMOUNT
	Column PhysicalName: MINAMOUNT
	Column Type: DECIMAL(8, 2)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
====================================================================================================
Logical Table Name: TRANSRECORD
Physical Table Name: TRANSRECORD
	 qualifier: ITSO
TRANSRECORD contains: 
	4 column(s)
	1 foreign key relationship(s) 
TRANSRECORD has primary key:  (TRANSID)
TRANSRECORD points to the following table(s), ACCOUNT 
----------------------------------------------------------------------------------------------------
	Column Logical Name: ACCID
	Column PhysicalName: ACCID
	Column Type: CHAR(8)
	Nulls Allowed: no
	Part of Primary key: no
	Part of the following foreign key relationships AccountTransrecord (ACCOUNT)
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: TRANSAMT
	Column PhysicalName: TRANSAMT
	Column Type: DECIMAL(8, 2)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: TRANSID
	Column PhysicalName: TRANSID
	Column Type: TIMESTAMP
	Nulls Allowed: no
	Part of Primary key: yes
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: TRANSTYPE
	Column PhysicalName: TRANSTYPE
	Column Type: CHAR(1)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
====================================================================================================
Logical Name: 'AccountTransrecord'
Physical Name: 'AccountTransrecord'
Parent Table Key: ACCOUNT(ACCID) (primary key)  cardinality(1)
Member Table Key: TRANSRECORD(ACCID)  cardinality[0, M)
Referential Integrity Constraint exists in database
Referential Integrity Constraint Type: restricted on delete and no action on update
====================================================================================================
Logical Name: 'CAtoAccount'
Physical Name: 'CAtoAccount'
Parent Table Key: ACCOUNT(ACCID) (primary key)  cardinality(1)
Member Table Key: CUSTACCT(ACCID) (subset of primary key)  cardinality[0, M)
Referential Integrity Constraint exists in database
Referential Integrity Constraint Type: restricted on delete and no action on update
====================================================================================================
Logical Name: 'CAtoCustomer'
Physical Name: 'CAtoCustomer'
Parent Table Key: CUSTOMER(CUSTOMERID) (primary key)  cardinality(1)
Member Table Key: CUSTACCT(CUSTOMERID) (subset of primary key)  cardinality[0, M)
Referential Integrity Constraint exists in database
Referential Integrity Constraint Type: restricted on delete and no action on update
====================================================================================================
Logical Name: 'CheckingAccount'
Physical Name: 'CheckingAccount'
Parent Table Key: ACCOUNT(ACCID) (primary key)  cardinality(1)
Member Table Key: CHECKING(ACCID) (subset of primary key)  cardinality[1, 1]
Referential Integrity Constraint exists in database
Referential Integrity Constraint Type: restricted on delete and no action on update
====================================================================================================
Logical Name: 'CustAddress'
Physical Name: 'CustAddress'
Parent Table Key: CUSTOMER(CUSTOMERID) (primary key)  cardinality(1)
Member Table Key: ADDRESS(CUSTOMERID) (subset of primary key)  cardinality[1, 1]
Referential Integrity Constraint exists in database
Referential Integrity Constraint Type: restricted on delete and no action on update
====================================================================================================
Logical Name: 'SavingsAccount'
Physical Name: 'SavingsAccount'
Parent Table Key: ACCOUNT(ACCID) (primary key)  cardinality(1)
Member Table Key: SAVINGS(ACCID) (subset of primary key)  cardinality[1, 1]
Referential Integrity Constraint exists in database
Referential Integrity Constraint Type: restricted on delete and no action on update*/}
}
