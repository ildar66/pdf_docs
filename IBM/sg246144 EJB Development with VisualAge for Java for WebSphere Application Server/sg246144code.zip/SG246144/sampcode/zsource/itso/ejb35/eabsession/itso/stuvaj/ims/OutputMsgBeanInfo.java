package itso.stuvaj.ims;

/**
 * Class: ls.conn.ims.cmd.OutputMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.*;
import java.math.*;

public class OutputMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }   
   public static java.lang.Class getBeanClass()
   {
	  return(ls.conn.ims.cmd.OutputMsg.class);
   }   
   public static java.lang.String getBeanClassName()
   {
	  return("ls.conn.ims.cmd.OutputMsg");
   }   
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(ls.conn.ims.cmd.OutputMsg.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }   
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }   
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getOUT__CMDPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__CMD", Class.forName(getBeanClassName()), "getOUT__CMD", "setOUT__CMD" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__CMD");
	  aDescriptor.setDisplayName("OUT__CMD");
	  aDescriptor.setShortDescription("OUT__CMD");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getOUT__HUMIDITYPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__HUMIDITY", Class.forName(getBeanClassName()), "getOUT__HUMIDITY", "setOUT__HUMIDITY" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__HUMIDITY");
	  aDescriptor.setDisplayName("OUT__HUMIDITY");
	  aDescriptor.setShortDescription("OUT__HUMIDITY");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getOUT__LLPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__LL", Class.forName(getBeanClassName()), "getOUT__LL", "setOUT__LL" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__LL");
	  aDescriptor.setDisplayName("OUT__LL");
	  aDescriptor.setShortDescription("OUT__LL");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getOUT__LOCALDATEPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__LOCALDATE", Class.forName(getBeanClassName()), "getOUT__LOCALDATE", "setOUT__LOCALDATE" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__LOCALDATE");
	  aDescriptor.setDisplayName("OUT__LOCALDATE");
	  aDescriptor.setShortDescription("OUT__LOCALDATE");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getOUT__LOCALTIMEPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__LOCALTIME", Class.forName(getBeanClassName()), "getOUT__LOCALTIME", "setOUT__LOCALTIME" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__LOCALTIME");
	  aDescriptor.setDisplayName("OUT__LOCALTIME");
	  aDescriptor.setShortDescription("OUT__LOCALTIME");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getOUT__MSGPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__MSG", Class.forName(getBeanClassName()), "getOUT__MSG", "setOUT__MSG" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__MSG");
	  aDescriptor.setDisplayName("OUT__MSG");
	  aDescriptor.setShortDescription("OUT__MSG");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getOUT__PLANETNAMEPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__PLANETNAME", Class.forName(getBeanClassName()), "getOUT__PLANETNAME", "setOUT__PLANETNAME" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__PLANETNAME");
	  aDescriptor.setDisplayName("OUT__PLANETNAME");
	  aDescriptor.setShortDescription("OUT__PLANETNAME");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getOUT__STATIONIDPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__STATIONID", Class.forName(getBeanClassName()), "getOUT__STATIONID", "setOUT__STATIONID" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__STATIONID");
	  aDescriptor.setDisplayName("OUT__STATIONID");
	  aDescriptor.setShortDescription("OUT__STATIONID");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getOUT__TEMPERATUREPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__TEMPERATURE", Class.forName(getBeanClassName()), "getOUT__TEMPERATURE", "setOUT__TEMPERATURE" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__TEMPERATURE");
	  aDescriptor.setDisplayName("OUT__TEMPERATURE");
	  aDescriptor.setShortDescription("OUT__TEMPERATURE");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getOUT__WINDSPEEDPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__WINDSPEED", Class.forName(getBeanClassName()), "getOUT__WINDSPEED", "setOUT__WINDSPEED" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__WINDSPEED");
	  aDescriptor.setDisplayName("OUT__WINDSPEED");
	  aDescriptor.setShortDescription("OUT__WINDSPEED");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getOUT__ZZPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("OUT__ZZ", Class.forName(getBeanClassName()), "getOUT__ZZ", "setOUT__ZZ" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("OUT__ZZ");
	  aDescriptor.setDisplayName("OUT__ZZ");
	  aDescriptor.setShortDescription("OUT__ZZ");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getOUT__LLPropertyDescriptor()
			,getOUT__ZZPropertyDescriptor()
			,getOUT__MSGPropertyDescriptor()
			,getOUT__CMDPropertyDescriptor()
			,getOUT__STATIONIDPropertyDescriptor()
			,getOUT__PLANETNAMEPropertyDescriptor()
			,getOUT__TEMPERATUREPropertyDescriptor()
			,getOUT__HUMIDITYPropertyDescriptor()
			,getOUT__WINDSPEEDPropertyDescriptor()
			,getOUT__LOCALTIMEPropertyDescriptor()
			,getOUT__LOCALDATEPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }   
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	 // System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	 // exception.printStackTrace(System.out);
   }   
}
