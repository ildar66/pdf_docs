package itso.ejb35.session;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface Transfer extends javax.ejb.EJBObject {

/**
 * 
 * @return void
 * @param accountID java.lang.String
 * @exception String The exception description.
 */
void performTest(java.lang.String accountID) throws java.rmi.RemoteException;
/**
 * 
 * @return void
 * @param fromAccountID java.lang.String
 * @param toAccountID java.lang.String
 * @param anAmount java.math.BigDecimal
 * @exception String The exception description.
 * @exception String The exception description.
 */
void transferMoney(java.lang.String fromAccountID, java.lang.String toAccountID, java.math.BigDecimal anAmount) throws java.rmi.RemoteException, itso.ejb35.util.InsufficientFundException;
}
