package itso.ejb35.cmp.client;

import itso.ejb35.cmp.*;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 9:43:06 AM)
 * @author: Ueli TP
 */
public class UsingFinderAB {
/**
 * Starts the application.
 * @param args an array of command-line arguments
 */
public static void main(java.lang.String[] args) {
  try {
	CustomerAccessBeanTable custrows = new CustomerAccessBeanTable();
	CustomerAccessBean cust = new CustomerAccessBean();
	System.out.println("Calling Customer finder");
	custrows.setCustomerAccessBean( cust.findByLastName("%d%") );
	try {
   		for (int i=0; i < custrows.numberOfRows(); i++) {
	   		cust = custrows.getCustomerAccessBean(i);
	   		System.out.println("Customer " + cust.getCustomerID() + " " + cust.getLastName() );
   		}
	}
	catch (IndexOutOfBoundsException o) {}
	System.out.println("End of list");
  } catch(Exception ex) {
	  ex.printStackTrace();
  }
}
}
