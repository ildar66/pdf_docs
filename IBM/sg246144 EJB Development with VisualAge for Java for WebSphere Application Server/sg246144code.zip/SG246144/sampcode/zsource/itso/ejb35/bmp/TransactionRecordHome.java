package itso.ejb35.bmp;

/**
 * This is a Home interface for the Entity Bean
 */
public interface TransactionRecordHome extends javax.ejb.EJBHome {

/**
 * 
 * @return itso.ejb35.bmp.TransactionRecord
 * @param acctID java.lang.String
 * @param amnt java.math.BigDecimal
 * @param aTraccid java.lang.String
 * @exception String The exception description.
 * @exception String The exception description.
 */
itso.ejb35.bmp.TransactionRecord create(java.lang.String acctID, java.math.BigDecimal amnt, java.lang.String aTraccid) throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * 
 * @return itso.ejb35.bmp.TransactionRecord
 * @param aKey itso.ejb35.bmp.TransactionRecordKey
 * @exception String The exception description.
 * @exception String The exception description.
 * @exception String The exception description.
 */
itso.ejb35.bmp.TransactionRecord findByPrimaryKey(itso.ejb35.bmp.TransactionRecordKey aKey) throws java.rmi.RemoteException, javax.ejb.FinderException, javax.ejb.ObjectNotFoundException;
}
