package itso.ejb35.reverse;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface Custacct extends javax.ejb.EJBObject {

/**
 * This method was generated for supporting the association named Custacct CAtoAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.Account
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.reverse.Account getAccount() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Custacct CAtoAccount Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.AccountKey
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.reverse.AccountKey getAccountKey() throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Custacct CAtoCustomer Customer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.Customer
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.reverse.Customer getCustomer() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Custacct CAtoCustomer Customer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.CustomerKey
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.reverse.CustomerKey getCustomerKey() throws java.rmi.RemoteException;
}
