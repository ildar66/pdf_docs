package itso.ejb35.reverse;

public class TransrecordKey implements java.io.Serializable {
	final static long serialVersionUID = 3206093459760846163L;
	public java.sql.Timestamp transid;

/**
 * Default constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public TransrecordKey() {
	super();
}
/**
 * Initialize a key from the passed values
 * @param argTransid java.sql.Timestamp
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public TransrecordKey(java.sql.Timestamp argTransid) {
	transid = argTransid;
}
/**
 * equals method
 * @return boolean
 * @param o java.lang.Object
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public boolean equals(Object o) {
	if (o instanceof TransrecordKey) {
		TransrecordKey otherKey = (TransrecordKey) o;
		return ((this.transid.equals(otherKey.transid)));
	}
	else
		return false;
}
/**
 * hashCode method
 * @return int
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public int hashCode() {
	return (transid.hashCode());
}
}
