package itso.ejb35.bank.client;

import itso.ejb35.bank.*;
import java.util.*;
import javax.rmi.*;
/**
 * Insert the type's description here.
 * Creation date: (4/17/2001 7:40:47 PM)
 * @author: Ueli TP
 */
public class ListAccountTypes {
/**
 * Starts the application.
 * @param args an array of command-line arguments
 */
public static void main(java.lang.String[] args) {
	// Insert code to start the application here.
  try {
	BankAccountHome acctHome;
	BankAccount     acct, acct2;
	BankAccountKey  acctKey;
	Checking        acctChk;
	Savings         acctSav;
	String          acctID;
	Enumeration     eAcct;
	//Properties properties = new Properties();
	//properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
	//properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY,
	//						"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
	//javax.naming.InitialContext initialContext = new javax.naming.InitialContext(properties);
	javax.naming.InitialContext initialContext = new javax.naming.InitialContext();
	Object objHome = initialContext.lookup("itso/ejb35/bank/BankAccount");
	acctHome = (BankAccountHome)PortableRemoteObject.narrow(objHome,BankAccountHome.class);

	eAcct = acctHome.findAll();
	while (eAcct != null && eAcct.hasMoreElements()) {
		acct    = (BankAccount)PortableRemoteObject.narrow(eAcct.nextElement(),BankAccount.class);
		acctKey = (BankAccountKey)acct.getPrimaryKey();
		acctID  = acctKey.accID;
		acct2   = (BankAccount)acctHome.findByPrimaryKey(acctKey);
		if (acct2 instanceof Checking) {
			acctChk = (Checking)acct2;
			System.out.println("Checking "+acctID+": "+acct.getBalance()+" "+acctChk.getOverdraft());
		} else if (acct2 instanceof Savings) {
			acctSav = (Savings)acct2;
			System.out.println("Savings  "+acctID+": "+acct.getBalance()+" "+acctSav.getMinAmount());
		} else {
			System.out.println("Account  "+acctID+": "+acct.getBalance());
		}
	}
	System.out.println("END");
  } catch(Exception ex) {
	  ex.printStackTrace();
  }
}
}
