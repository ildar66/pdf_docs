package itso.stuvaj.ims;

import com.ibm.record.*;
import java.util.Vector;
import com.ibm.ivj.eab.record.cobol.*;

/**
 * Class: ls.conn.ims.cmd.OutputMsgInfo
 * This is a generated file.  Do not edit.
 */

public class OutputMsgInfo extends CobolDynamicRecordType implements java.io.Serializable
{

   public OutputMsgInfo() throws RecordException {

	  try {

		 int[] arraySize = null;
		 Vector v = null;

		 CobolType OUT__LLFieldType = new CobolType();
		 OUT__LLFieldType.setAug("COMP");
		 OUT__LLFieldType.setPic("S9(3)");
		 OUT__LLFieldType.setPreferredType(short.class);
		 addField(new Field(OUT__LLFieldType, "OUT__LL",new CobolInitialValueObject("+0,null")));

		 CobolType OUT__ZZFieldType = new CobolType();
		 OUT__ZZFieldType.setAug("COMP");
		 OUT__ZZFieldType.setPic("S9(3)");
		 OUT__ZZFieldType.setPreferredType(short.class);
		 addField(new Field(OUT__ZZFieldType, "OUT__ZZ",new CobolInitialValueObject("+0,null")));

		 CobolType OUT__MSGFieldType = new CobolType();
		 OUT__MSGFieldType.setAug("DISPLAY");
		 OUT__MSGFieldType.setPic("X(80)");
		 OUT__MSGFieldType.setPreferredType(Class.forName("java.lang.String"));
		 addField(new Field(OUT__MSGFieldType, "OUT__MSG",new CobolInitialValueObject(" ,null")));

		 CobolType OUT__CMDFieldType = new CobolType();
		 OUT__CMDFieldType.setAug("DISPLAY");
		 OUT__CMDFieldType.setPic("X(8)");
		 OUT__CMDFieldType.setPreferredType(Class.forName("java.lang.String"));
		 addField(new Field(OUT__CMDFieldType, "OUT__CMD",new CobolInitialValueObject(" ,null")));

		 CobolType OUT__STATIONIDFieldType = new CobolType();
		 OUT__STATIONIDFieldType.setAug("DISPLAY");
		 OUT__STATIONIDFieldType.setPic("X(3)");
		 OUT__STATIONIDFieldType.setPreferredType(Class.forName("java.lang.String"));
		 addField(new Field(OUT__STATIONIDFieldType, "OUT__STATIONID",new CobolInitialValueObject(" ,null")));

		 CobolType OUT__PLANETNAMEFieldType = new CobolType();
		 OUT__PLANETNAMEFieldType.setAug("DISPLAY");
		 OUT__PLANETNAMEFieldType.setPic("X(50)");
		 OUT__PLANETNAMEFieldType.setPreferredType(Class.forName("java.lang.String"));
		 addField(new Field(OUT__PLANETNAMEFieldType, "OUT__PLANETNAME",new CobolInitialValueObject(" ,null")));

		 CobolType OUT__TEMPERATUREFieldType = new CobolType();
		 OUT__TEMPERATUREFieldType.setAug("DISPLAY");
		 OUT__TEMPERATUREFieldType.setPic("X(3)");
		 OUT__TEMPERATUREFieldType.setPreferredType(Class.forName("java.lang.String"));
		 addField(new Field(OUT__TEMPERATUREFieldType, "OUT__TEMPERATURE",new CobolInitialValueObject(" ,null")));

		 CobolType OUT__HUMIDITYFieldType = new CobolType();
		 OUT__HUMIDITYFieldType.setAug("DISPLAY");
		 OUT__HUMIDITYFieldType.setPic("X(3)");
		 OUT__HUMIDITYFieldType.setPreferredType(Class.forName("java.lang.String"));
		 addField(new Field(OUT__HUMIDITYFieldType, "OUT__HUMIDITY",new CobolInitialValueObject(" ,null")));

		 CobolType OUT__WINDSPEEDFieldType = new CobolType();
		 OUT__WINDSPEEDFieldType.setAug("DISPLAY");
		 OUT__WINDSPEEDFieldType.setPic("X(3)");
		 OUT__WINDSPEEDFieldType.setPreferredType(Class.forName("java.lang.String"));
		 addField(new Field(OUT__WINDSPEEDFieldType, "OUT__WINDSPEED",new CobolInitialValueObject(" ,null")));

		 CobolType OUT__LOCALTIMEFieldType = new CobolType();
		 OUT__LOCALTIMEFieldType.setAug("DISPLAY");
		 OUT__LOCALTIMEFieldType.setPic("X(12)");
		 OUT__LOCALTIMEFieldType.setPreferredType(Class.forName("java.lang.String"));
		 addField(new Field(OUT__LOCALTIMEFieldType, "OUT__LOCALTIME",new CobolInitialValueObject(" ,null")));

		 CobolType OUT__LOCALDATEFieldType = new CobolType();
		 OUT__LOCALDATEFieldType.setAug("DISPLAY");
		 OUT__LOCALDATEFieldType.setPic("X(12)");
		 OUT__LOCALDATEFieldType.setPreferredType(Class.forName("java.lang.String"));
		 addField(new Field(OUT__LOCALDATEFieldType, "OUT__LOCALDATE",new CobolInitialValueObject(" ,null")));

	  }
	  catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }   
}
