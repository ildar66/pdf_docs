package itso.ejb35.cmp;

/**
 * This is a Home interface for the Entity Bean
 */
import java.util.Enumeration;
import java.math.BigDecimal;
public interface BankAccountHome extends javax.ejb.EJBHome {
/**
 * 
 * @return itso.ejb35.cmp.BankAccount
 * @param argAccID java.lang.String
 * @param argBalance java.math.BigDecimal
 * @exception String The exception description.
 * @exception String The exception description.
 */
itso.ejb35.cmp.BankAccount create(java.lang.String argAccID, java.math.BigDecimal argBalance) throws javax.ejb.CreateException, java.rmi.RemoteException;
	public Enumeration findAccountsWithBalanceBetween(BigDecimal anAmount1, BigDecimal anAmount2) throws java.rmi.RemoteException, javax.ejb.FinderException;
	public Enumeration findAccountsWithBalanceGreater(BigDecimal anAmount) 
								throws java.rmi.RemoteException, javax.ejb.FinderException;
public Enumeration findAccountsWithBalanceGreaterThan(BigDecimal anAmount) 
					throws javax.ejb.FinderException, java.rmi.RemoteException;
	public Enumeration findAll() 
								throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * findByPrimaryKey method comment
 * @return itso.ejb35.cmp.BankAccount
 * @param key itso.ejb35.cmp.BankAccountKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.ejb35.cmp.BankAccount findByPrimaryKey(itso.ejb35.cmp.BankAccountKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
	public Enumeration findGoldAccounts(java.math.BigDecimal balance) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
