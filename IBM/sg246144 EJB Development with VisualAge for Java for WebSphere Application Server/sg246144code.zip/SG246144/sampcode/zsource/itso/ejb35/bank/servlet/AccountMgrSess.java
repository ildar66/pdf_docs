package itso.ejb35.bank.servlet;

import itso.ejb35.bank.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 12:56:49 PM)
 * @author: Ueli TP
 */
public class AccountMgrSess extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
public void performTask(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
	// Set the results page URL
	String url    = "/ejb/bankservlet/AccountMgrSess.jsp";
	String urlerr = "/ejb/bankservlet/AccountMgrError.html";
  try {
	// Read the input parameter from the HTML Form
	String acctnr1  = request.getParameter("Account");
	String acctnr2  = request.getParameter("Account2");
	String amountx  = request.getParameter("Amount");
	String deposit  = request.getParameter("Deposit");
	String withdraw = request.getParameter("Withdraw");
	String transfer = request.getParameter("Transfer");
	String acctid1  = request.getParameter("Acct"+acctnr1);
	String acctid2  = request.getParameter("Acct"+acctnr2);

	// variables
	java.math.BigDecimal amount = new java.math.BigDecimal(amountx);

	// check input
	if (acctid1 == null  || (transfer != null && acctid2 == null)) {
		getServletConfig().getServletContext().getRequestDispatcher(urlerr).
			forward(request, response);
		return;
	}

	// processing
	BankingAccessBean banking = new BankingAccessBean();
	if (deposit  != null) banking.deposit(acctid1,amount);
	if (withdraw != null) banking.withdraw(acctid1,amount);
	if (transfer != null) banking.transferMoney(acctid1,acctid2,amount);
	
	// Forward to the results JSP
	request.setAttribute("banking", banking);
	getServletConfig().getServletContext().getRequestDispatcher(url).
			forward(request, response);
  }	catch (Exception ex) {
		getServletConfig().getServletContext().getRequestDispatcher(urlerr).
			forward(request, response);
  }
}
}
