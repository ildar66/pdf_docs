package itso.ejb35.reverse.schema;

class Bank_ReverseMap extends com.ibm.vap.common.MapStorageClass {
/**
 * This is a textual representation of Bank_Reverse to assist documentation and comparing class versions
 * Modifying the string has no effect on the actual data which is stored internally on the class
 * If a developer wishes to share their model data with another user in another repository the class
 * should be exported taking the option to export to a repository
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
static void infoString() {
/*DataStore Map
Model: Bank_Reverse
Schema: Bank_Reverse
Map contains 7 class maps 

====================================================================================================
Class:	Account
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: Account, Table: ACCOUNT
Table map contains 7 ivar maps
	Distinct Table Inheritance
	Root Table Map
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'accid' in Account
			Columns in ACCOUNT: ACCID
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'acctype' in Account
			Columns in ACCOUNT: ACCTYPE
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'balance' in Account
			Columns in ACCOUNT: BALANCE
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Relationship Map  
			Checking CheckingAccount Account	:	checking
			'CheckingAccount'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Relationship Map  
			Custacct CAtoAccount Account	:	custacct
			'CAtoAccount'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Relationship Map  
			Savings SavingsAccount Account	:	savings
			'SavingsAccount'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Relationship Map  
			Transrecord AccountTransrecord Account	:	transrecord
			'AccountTransrecord'
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
Class:	Address
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: Address, Table: ADDRESS
Table map contains 5 ivar maps
	Distinct Table Inheritance
	Root Table Map
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'city' in Address
			Columns in ADDRESS: CITY
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Relationship Map  
			Address CustAddress Customer	:	customer
			'CustAddress'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'state' in Address
			Columns in ADDRESS: STATE
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'street' in Address
			Columns in ADDRESS: STREET
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'zipcode' in Address
			Columns in ADDRESS: ZIPCODE
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
Class:	Checking
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: Checking, Table: CHECKING
Table map contains 2 ivar maps
	Distinct Table Inheritance
	Root Table Map
----------------------------------------------------------------------------------------------------
		Relationship Map  
			Checking CheckingAccount Account	:	account
			'CheckingAccount'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'overdraft' in Checking
			Columns in CHECKING: OVERDRAFT
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
Class:	Custacct
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: Custacct, Table: CUSTACCT
Table map contains 2 ivar maps
	Distinct Table Inheritance
	Root Table Map
----------------------------------------------------------------------------------------------------
		Relationship Map  
			Custacct CAtoAccount Account	:	account
			'CAtoAccount'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Relationship Map  
			Custacct CAtoCustomer Customer	:	customer
			'CAtoCustomer'
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
Class:	Customer
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: Customer, Table: CUSTOMER
Table map contains 9 ivar maps
	Distinct Table Inheritance
	Root Table Map
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'address' in Customer
			Columns in CUSTOMER: ADDRESSX
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Relationship Map  
			Custacct CAtoCustomer Customer	:	custacct
			'CAtoCustomer'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'customerid' in Customer
			Columns in CUSTOMER: CUSTOMERID
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'firstname' in Customer
			Columns in CUSTOMER: FIRSTNAME
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'lastname' in Customer
			Columns in CUSTOMER: LASTNAME
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'password' in Customer
			Columns in CUSTOMER: PASSWORD
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Relationship Map  
			Address CustAddress Customer	:	theAddress
			'CustAddress'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'title' in Customer
			Columns in CUSTOMER: TITLE
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'userid' in Customer
			Columns in CUSTOMER: USERID
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
Class:	Savings
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: Savings, Table: SAVINGS
Table map contains 2 ivar maps
	Distinct Table Inheritance
	Root Table Map
----------------------------------------------------------------------------------------------------
		Relationship Map  
			Savings SavingsAccount Account	:	account
			'SavingsAccount'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'minamount' in Savings
			Columns in SAVINGS: MINAMOUNT
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
Class:	Transrecord
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: Transrecord, Table: TRANSRECORD
Table map contains 4 ivar maps
	Distinct Table Inheritance
	Root Table Map
----------------------------------------------------------------------------------------------------
		Relationship Map  
			Transrecord AccountTransrecord Account	:	account
			'AccountTransrecord'
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'transamt' in Transrecord
			Columns in TRANSRECORD: TRANSAMT
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'transid' in Transrecord
			Columns in TRANSRECORD: TRANSID
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'transtype' in Transrecord
			Columns in TRANSRECORD: TRANSTYPE
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
*/}
}
