package itso.ejb35.reverse;

import java.rmi.RemoteException;
import java.security.Identity;
import java.util.Properties;
import javax.ejb.*;
/**
 * This is an Entity Bean class with CMP fields
 */
public class TransrecordBean implements EntityBean {
	public java.lang.String account_accid;
	private transient com.ibm.ivj.ejb.associations.interfaces.SingleLink accountLink = null;
	private javax.ejb.EntityContext entityContext = null;
	final static long serialVersionUID = 3206093459760846163L;
	public java.math.BigDecimal transamt;
	public java.sql.Timestamp transid;
	public String transtype;

/**
 * This method was generated for supporting the associations.
 * @return java.util.Vector
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected java.util.Vector _getLinks() {
	java.util.Vector links = new java.util.Vector();
	links.addElement(getAccountLink());
	return links;
}
/**
 * This method was generated for supporting the associations.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected void _initLinks() {
	accountLink = null;
}
/**
 * This method was generated for supporting the associations.
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.RemoveException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected void _removeLinks() throws java.rmi.RemoteException, javax.ejb.RemoveException {
	java.util.Enumeration links = _getLinks().elements();
	while (links.hasMoreElements()) {
		try {
			((com.ibm.ivj.ejb.associations.interfaces.Link) (links.nextElement())).remove();
		}
		catch (javax.ejb.FinderException e) {} //Consume Finder error since I am going away
	}
}
/**
 * ejbActivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbActivate() throws java.rmi.RemoteException {
	_initLinks();
}
/**
 * ejbCreate method for a CMP entity bean
 * @param argTransid java.sql.Timestamp
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbCreate(java.sql.Timestamp argTransid) throws javax.ejb.CreateException, java.rmi.RemoteException {
	_initLinks();
	// All CMP fields should be initialized here.
	transid = argTransid;
}
/**
 * ejbLoad method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbLoad() throws java.rmi.RemoteException {
	_initLinks();
}
/**
 * ejbPassivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPassivate() throws java.rmi.RemoteException {}
/**
 * ejbPostCreate method for a CMP entity bean
 * @param argTransid java.sql.Timestamp
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPostCreate(java.sql.Timestamp argTransid) throws java.rmi.RemoteException {}
/**
 * ejbRemove method comment
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.RemoveException The exception description.
 */
public void ejbRemove() throws java.rmi.RemoteException, javax.ejb.RemoveException {
	_removeLinks();
}
/**
 * ejbStore method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbStore() throws java.rmi.RemoteException {}
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.Account
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.reverse.Account getAccount() throws java.rmi.RemoteException, javax.ejb.FinderException {
	return (itso.ejb35.reverse.Account)this.getAccountLink().value();
}
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.AccountKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.reverse.AccountKey getAccountKey() {
	itso.ejb35.reverse.AccountKey temp = null;
	temp = new itso.ejb35.reverse.AccountKey();
	boolean account_NULLTEST = true;
	account_NULLTEST &= (account_accid == null);
	temp.accid = account_accid;
	if (account_NULLTEST) temp = null;
	return temp;
}
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return com.ibm.ivj.ejb.associations.interfaces.SingleLink
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected com.ibm.ivj.ejb.associations.interfaces.SingleLink getAccountLink() {
	if (accountLink == null)
		accountLink = new TransrecordToAccountLink(this);
	return accountLink;
}
/**
 * getEntityContext method comment
 * @return javax.ejb.EntityContext
 */
public javax.ejb.EntityContext getEntityContext() {
	return entityContext;
}
/**
 * Getter method for transamt
 * @return java.math.BigDecimal
 */
public java.math.BigDecimal getTransamt() {
	return transamt;
}
/**
 * Getter method for transtype
 * @return java.lang.String
 */
public java.lang.String getTranstype() {
	return transtype;
}
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param inKey itso.ejb35.reverse.AccountKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void privateSetAccountKey(itso.ejb35.reverse.AccountKey inKey) {
	boolean account_NULLTEST = (inKey == null);
	if (account_NULLTEST) account_accid = null; else account_accid = inKey.accid;
}
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param anAccount itso.ejb35.reverse.Account
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void secondarySetAccount(itso.ejb35.reverse.Account anAccount) throws java.rmi.RemoteException {
	this.getAccountLink().secondarySet(anAccount);
}
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param anAccount itso.ejb35.reverse.Account
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void setAccount(itso.ejb35.reverse.Account anAccount) throws java.rmi.RemoteException {
	this.getAccountLink().set(anAccount);
}
/**
 * setEntityContext method comment
 * @param ctx javax.ejb.EntityContext
 * @exception java.rmi.RemoteException The exception description.
 */
public void setEntityContext(javax.ejb.EntityContext ctx) throws java.rmi.RemoteException {
	entityContext = ctx;
}
/**
 * Setter method for transamt
 * @param newValue java.math.BigDecimal
 */
public void setTransamt(java.math.BigDecimal newValue) {
	this.transamt = newValue;
}
/**
 * Setter method for transtype
 * @param newValue java.lang.String
 */
public void setTranstype(java.lang.String newValue) {
	this.transtype = newValue;
}
/**
 * unsetEntityContext method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void unsetEntityContext() throws java.rmi.RemoteException {
	entityContext = null;
}
}
