package itso.stuvaj.ims;

/**
 * Class: ls.conn.ims.cmd.InputMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.*;
import java.math.*;

public class InputMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }   
   public static java.lang.Class getBeanClass()
   {
	  return(ls.conn.ims.cmd.InputMsg.class);
   }   
   public static java.lang.String getBeanClassName()
   {
	  return("ls.conn.ims.cmd.InputMsg");
   }   
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(ls.conn.ims.cmd.InputMsg.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }   
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getIN__CMDPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("IN__CMD", Class.forName(getBeanClassName()), "getIN__CMD", "setIN__CMD" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("IN__CMD");
	  aDescriptor.setDisplayName("IN__CMD");
	  aDescriptor.setShortDescription("IN__CMD");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getIN__LLPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("IN__LL", Class.forName(getBeanClassName()), "getIN__LL", "setIN__LL" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("IN__LL");
	  aDescriptor.setDisplayName("IN__LL");
	  aDescriptor.setShortDescription("IN__LL");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getIN__STATIONIDPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("IN__STATIONID", Class.forName(getBeanClassName()), "getIN__STATIONID", "setIN__STATIONID" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("IN__STATIONID");
	  aDescriptor.setDisplayName("IN__STATIONID");
	  aDescriptor.setShortDescription("IN__STATIONID");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getIN__TRCDPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("IN__TRCD", Class.forName(getBeanClassName()), "getIN__TRCD", "setIN__TRCD" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("IN__TRCD");
	  aDescriptor.setDisplayName("IN__TRCD");
	  aDescriptor.setShortDescription("IN__TRCD");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getIN__ZZPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("IN__ZZ", Class.forName(getBeanClassName()), "getIN__ZZ", "setIN__ZZ" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("IN__ZZ");
	  aDescriptor.setDisplayName("IN__ZZ");
	  aDescriptor.setShortDescription("IN__ZZ");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getIN__LLPropertyDescriptor()
			,getIN__ZZPropertyDescriptor()
			,getIN__TRCDPropertyDescriptor()
			,getIN__CMDPropertyDescriptor()
			,getIN__STATIONIDPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }   
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	 // System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	 // exception.printStackTrace(System.out);
   }   
}
