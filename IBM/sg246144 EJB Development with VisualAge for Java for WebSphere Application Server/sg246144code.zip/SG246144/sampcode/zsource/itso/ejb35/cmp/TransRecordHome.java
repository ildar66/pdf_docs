package itso.ejb35.cmp;

/**
 * This is a Home interface for the Entity Bean
 */
public interface TransRecordHome extends javax.ejb.EJBHome {

/**
 * 
 * @return itso.ejb35.cmp.TransRecord
 * @param anAccID java.lang.String
 * @param anAmount java.math.BigDecimal
 * @param aTranstype java.lang.String
 * @exception String The exception description.
 * @exception String The exception description.
 */
itso.ejb35.cmp.TransRecord create(java.lang.String anAccID, java.math.BigDecimal anAmount, java.lang.String aTranstype) throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * findByPrimaryKey method comment
 * @return itso.ejb35.cmp.TransRecord
 * @param key itso.ejb35.cmp.TransRecordKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.ejb35.cmp.TransRecord findByPrimaryKey(itso.ejb35.cmp.TransRecordKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
