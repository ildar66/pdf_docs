package itso.ejb35.reverse;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface Address extends javax.ejb.EJBObject {

/**
 * Getter method for city
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getCity() throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Address CustAddress Customer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.Customer
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.reverse.Customer getCustomer() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Address CustAddress Customer.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.CustomerKey
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.reverse.CustomerKey getCustomerKey() throws java.rmi.RemoteException;
/**
 * Getter method for state
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getState() throws java.rmi.RemoteException;
/**
 * Getter method for street
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getStreet() throws java.rmi.RemoteException;
/**
 * Getter method for zipcode
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getZipcode() throws java.rmi.RemoteException;
/**
 * Setter method for city
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setCity(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * Setter method for state
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setState(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * Setter method for street
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setStreet(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * Setter method for zipcode
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setZipcode(java.lang.String newValue) throws java.rmi.RemoteException;
}
