package itso.stuvaj.ims;


import com.ibm.ivj.eab.command.*;

// user code begin {__import_statements_1}
// user code end {__import_statements_1}

public class ReadingCommand extends com.ibm.ivj.eab.command.CommunicationCommand implements java.io.Serializable {

// Important!  
// Fields and properties added by hand or by tools such as the Create Field
// SmartGuide and the New Property Feature SmartGuide must be placed within the comments
// below.  Fields and properties added outside of these comments will not be saved
// during code regeneration.

// user code begin {__declarations_1}
// user code end {__declarations_1}
	private com.ibm.connector.imstoc.IMSConnectionSpec ceConnectionSpec = null;
	private com.ibm.connector.imstoc.IMSInteractionSpec ceInteractionSpec = null;
	private ls.conn.ims.cmd.InputMsg ceInput = null;
	private transient IvjEventHandler ivjEventHandler = new IvjEventHandler();
	private ls.conn.ims.cmd.OutputMsg ceOutput0 = null;
	private com.ibm.connector.imstoc.DFSMsg ceOutput1 = null;
	private com.ibm.ivj.eab.command.SelectorRecord ceSelectorHelper = null;
	private boolean fieldInputSetAtRuntime = false;
	protected transient java.beans.PropertyChangeSupport propertyChange;
	class IvjEventHandler implements java.beans.PropertyChangeListener {
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
		if (evt.getSource() == ReadingCommand.this.getselectorHelper() && (evt.getPropertyName().equals("object")))
			try{
				ReadingCommand.this.setOutput(getselectorHelper().getObject());
			} catch(Throwable exn){
				ReadingCommand.this.internalExceptionHandler(exn);
			}
			if (evt.getSource() == ReadingCommand.this && (evt.getPropertyName().equals("output")))
			try{
				getselectorHelper().setObject(ReadingCommand.this.getOutput());
			} catch(Throwable exn){
				ReadingCommand.this.internalExceptionHandler(exn);
			}
			if(evt.getSource() == ReadingCommand.this.getceConnectionSpec() && (evt.getPropertyName().equals("portNumber")))
				ReadingCommand.this.firePropertyChange("portNumber",evt.getOldValue(), evt.getNewValue());
				if(evt.getSource() == ReadingCommand.this.getceConnectionSpec() && (evt.getPropertyName().equals("hostName")))
				ReadingCommand.this.firePropertyChange("hostName",evt.getOldValue(), evt.getNewValue());
				if(evt.getSource() == ReadingCommand.this.getceInteractionSpec() && (evt.getPropertyName().equals("dataStoreName")))
				ReadingCommand.this.firePropertyChange("dataStoreName",evt.getOldValue(), evt.getNewValue());
				if(evt.getSource() == ReadingCommand.this.getceInput() && (evt.getPropertyName().equals("IN__STATIONID")))
				ReadingCommand.this.firePropertyChange("IN__STATIONID",evt.getOldValue(), evt.getNewValue());
				if(evt.getSource() == ReadingCommand.this.getceOutput0() && (evt.getPropertyName().equals("OUT__CMD")))
				ReadingCommand.this.firePropertyChange("OUT__CMD",evt.getOldValue(), evt.getNewValue());
				if(evt.getSource() == ReadingCommand.this.getceOutput0() && (evt.getPropertyName().equals("OUT__STATIONID")))
				ReadingCommand.this.firePropertyChange("OUT__STATIONID",evt.getOldValue(), evt.getNewValue());
				if(evt.getSource() == ReadingCommand.this.getceOutput0() && (evt.getPropertyName().equals("OUT__WINDSPEED")))
				ReadingCommand.this.firePropertyChange("OUT__WINDSPEED",evt.getOldValue(), evt.getNewValue());
				if(evt.getSource() == ReadingCommand.this.getceOutput0() && (evt.getPropertyName().equals("OUT__MSG")))
				ReadingCommand.this.firePropertyChange("OUT__MSG",evt.getOldValue(), evt.getNewValue());
				if(evt.getSource() == ReadingCommand.this.getceOutput0() && (evt.getPropertyName().equals("OUT__PLANETNAME")))
				ReadingCommand.this.firePropertyChange("OUT__PLANETNAME",evt.getOldValue(), evt.getNewValue());
				if(evt.getSource() == ReadingCommand.this.getceOutput0() && (evt.getPropertyName().equals("OUT__LOCALTIME")))
				ReadingCommand.this.firePropertyChange("OUT__LOCALTIME",evt.getOldValue(), evt.getNewValue());
				if(evt.getSource() == ReadingCommand.this.getceOutput0() && (evt.getPropertyName().equals("OUT__LOCALDATE")))
				ReadingCommand.this.firePropertyChange("OUT__LOCALDATE",evt.getOldValue(), evt.getNewValue());
				if(evt.getSource() == ReadingCommand.this.getceOutput0() && (evt.getPropertyName().equals("OUT__TEMPERATURE")))
				ReadingCommand.this.firePropertyChange("OUT__TEMPERATURE",evt.getOldValue(), evt.getNewValue());
				if(evt.getSource() == ReadingCommand.this.getceOutput0() && (evt.getPropertyName().equals("OUT__HUMIDITY")))
				ReadingCommand.this.firePropertyChange("OUT__HUMIDITY",evt.getOldValue(), evt.getNewValue());
				if(evt.getSource() == ReadingCommand.this.getceOutput1() && (evt.getPropertyName().equals("DFSDATA1")))
				ReadingCommand.this.firePropertyChange("DFSDATA1",evt.getOldValue(), evt.getNewValue());
		};
	};
	// Generated line, do not modify - ReadingCommand()
	public ReadingCommand(){

		super();
		try{
			// user code begin {__ReadingCommand()_1}
			// user code end {__ReadingCommand()_1}
			this.setConnectionSpec(this.getceConnectionSpec());
			this.setInteractionSpec(this.getceInteractionSpec());
			if(this.fieldInputSetAtRuntime)
			    this.getceInput();
			else
			    this.setInput(this.getceInput());
			getselectorHelper().addPropertyChangeListener(ivjEventHandler);
			this.setOutput(getselectorHelper().getObject());
			getselectorHelper().addSelectableRecord(getceOutput0());
			getselectorHelper().addSelectableRecord(getceOutput1());
			getceConnectionSpec().addPropertyChangeListener(ivjEventHandler);
			getceInteractionSpec().addPropertyChangeListener(ivjEventHandler);
			getceInput().addPropertyChangeListener(ivjEventHandler);
			getceOutput0().addPropertyChangeListener(ivjEventHandler);
			getceOutput1().addPropertyChangeListener(ivjEventHandler);
		} catch(Throwable exn){
			this.internalExceptionHandler(exn);
			// user code begin {__ReadingCommand()_2}
			// user code end {__ReadingCommand()_2}
		}
	}
	// Generated line, do not modify - void addPropertyChangeListener(java.beans.PropertyChangeListener)
	public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	    getPropertyChange().addPropertyChangeListener(listener);
	}
// Generated line, do not modify - void afterInternalExecution(CommandEvent)
public void afterInternalExecution(CommandEvent commandEvent) {
   // user code begin {__afterInternalExecution(CommandEvent)_1}
   // user code end {__afterInternalExecution(CommandEvent)_1}
	if(this.fieldInputSetAtRuntime){
		this.ceInput = null;
	}
	super.afterInternalExecution(commandEvent);
   // user code begin {__afterInternalExecution(CommandEvent)_2}
   // user code end {__afterInternalExecution(CommandEvent)_2}
}
// Generated line, do not modify - void beforeInternalExecution(CommandEvent)
public void beforeInternalExecution(CommandEvent event) {
   // user code begin {__beforeInternalExecution(CommandEvent)_1}
   // user code end {__beforeInternalExecution(CommandEvent)_1}
	if(this.fieldInputSetAtRuntime){
		if((event.getSource() == this) &&
			event.existsPropertyNamed("__ComIbmIvjEabCommand_Object")){
				try{
					ls.conn.ims.cmd.InputMsg o = (ls.conn.ims.cmd.InputMsg)event.getPropertyNamed("__ComIbmIvjEabCommand_Object");
					this.resetInput(o);
				}
				catch(ClassCastException exn1){
					throw new InvalidTriggerStateException();
				}
			}
	   // user code begin {__beforeInternalExecution(CommandEvent)_2}
	   // user code end {__beforeInternalExecution(CommandEvent)_2}
	}
	super.beforeInternalExecution(event);
   // user code begin {__beforeInternalExecution(CommandEvent)_3}
   // user code end {__beforeInternalExecution(CommandEvent)_3}
}
	// Generated line, do not modify - void firePropertyChange(String,Object,Object)
	public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
		getPropertyChange().firePropertyChange(propertyName, oldValue, newValue);
	}
// Generated line, do not modify - com.ibm.connector.imstoc.IMSConnectionSpec getceConnectionSpec()
private com.ibm.connector.imstoc.IMSConnectionSpec getceConnectionSpec() {
	if (ceConnectionSpec == null) {
		try {
			ceConnectionSpec = new com.ibm.connector.imstoc.IMSConnectionSpec();
			ceConnectionSpec.setHostName("localhost");
			ceConnectionSpec.setPortNumber(9999);
			// user code begin {__getceConnectionSpec()_1}
			// user code end {__getceConnectionSpec()_1}
		} catch (java.lang.Throwable exn) {
			this.internalExceptionHandler(exn);
			// user code begin {__getceConnectionSpec()_2}
			// user code end {__getceConnectionSpec()_2}
		}
	}
	return ceConnectionSpec;
}
// Generated line, do not modify - com.ibm.connector.imstoc.IMSConnectionSpec getCeConnectionSpec()
public com.ibm.connector.imstoc.IMSConnectionSpec getCeConnectionSpec() {
	return ceConnectionSpec;
}
// Generated line, do not modify - ls.conn.ims.cmd.InputMsg getceInput()
private ls.conn.ims.cmd.InputMsg getceInput() {
	if (ceInput == null) {
		try {
			ceInput = new ls.conn.ims.cmd.InputMsg();
			ceInput.setIN__CMD("DISPLAY ");
			ceInput.setIN__STATIONID("001       ");
			ceInput.setIN__TRCD("MYIMSTX   ");
			ceInput.setIN__LL(((short)32));
			// user code begin {__getceInput()_1}
			// user code end {__getceInput()_1}
		} catch (java.lang.Throwable exn) {
			this.internalExceptionHandler(exn);
			// user code begin {__getceInput()_2}
			// user code end {__getceInput()_2}
		}
	}
	return ceInput;
}
// Generated line, do not modify - ls.conn.ims.cmd.InputMsg getCeInput()
public ls.conn.ims.cmd.InputMsg getCeInput() {
	return this.ceInput;
}
// Generated line, do not modify - com.ibm.connector.imstoc.IMSInteractionSpec getceInteractionSpec()
private com.ibm.connector.imstoc.IMSInteractionSpec getceInteractionSpec() {
	if (ceInteractionSpec == null) {
		try {
			ceInteractionSpec = new com.ibm.connector.imstoc.IMSInteractionSpec();
			ceInteractionSpec.setDataStoreName("MYIMS");
			// user code begin {__getceInteractionSpec()_1}
			// user code end {__getceInteractionSpec()_1}
		} catch (java.lang.Throwable exn) {
			this.internalExceptionHandler(exn);
			// user code begin {__getceInteractionSpec()_2}
			// user code end {__getceInteractionSpec()_2}
		}
	}
	return ceInteractionSpec;
}
// Generated line, do not modify - com.ibm.connector.imstoc.IMSInteractionSpec getCeInteractionSpec()
public com.ibm.connector.imstoc.IMSInteractionSpec getCeInteractionSpec() {
	return ceInteractionSpec;
}
// Generated line, do not modify - ls.conn.ims.cmd.OutputMsg getceOutput0()
private ls.conn.ims.cmd.OutputMsg getceOutput0() {
	if (ceOutput0 == null) {
		try {
			ceOutput0 = new ls.conn.ims.cmd.OutputMsg();
			// user code begin {__getceOutput0()_1}
			// user code end {__getceOutput0()_1}
		} catch (java.lang.Throwable exn) {
			this.internalExceptionHandler(exn);
			// user code begin {__getceOutput0()_2}
			// user code end {__getceOutput0()_2}
		}
	}
	return ceOutput0;
}
// Generated line, do not modify - ls.conn.ims.cmd.OutputMsg getCeOutput0()
public ls.conn.ims.cmd.OutputMsg getCeOutput0() {
	return this.ceOutput0;
}
// Generated line, do not modify - com.ibm.connector.imstoc.DFSMsg getceOutput1()
private com.ibm.connector.imstoc.DFSMsg getceOutput1() {
	if (ceOutput1 == null) {
		try {
			ceOutput1 = new com.ibm.connector.imstoc.DFSMsg();
			// user code begin {__getceOutput1()_1}
			// user code end {__getceOutput1()_1}
		} catch (java.lang.Throwable exn) {
			this.internalExceptionHandler(exn);
			// user code begin {__getceOutput1()_2}
			// user code end {__getceOutput1()_2}
		}
	}
	return ceOutput1;
}
// Generated line, do not modify - com.ibm.connector.imstoc.DFSMsg getCeOutput1()
public com.ibm.connector.imstoc.DFSMsg getCeOutput1() {
	return this.ceOutput1;
}
// Generated line, do not modify - java.lang.String getDataStoreName()
public java.lang.String getDataStoreName(){ 
	return getceInteractionSpec().getDataStoreName();
}
// Generated line, do not modify - java.lang.String getDFSDATA1()
public java.lang.String getDFSDATA1(){ 
	return getceOutput1().getDFSDATA1();
}
// Generated line, do not modify - java.lang.String getHostName()
public java.lang.String getHostName(){ 
	return getceConnectionSpec().getHostName();
}
// Generated line, do not modify - java.lang.String getIN__STATIONID()
public java.lang.String getIN__STATIONID(){ 
	return getceInput().getIN__STATIONID();
}
// Generated line, do not modify - boolean getInputSetAtRuntime()
public boolean getInputSetAtRuntime() {
	return fieldInputSetAtRuntime;
}
// Generated line, do not modify - java.lang.String getOUT__CMD()
public java.lang.String getOUT__CMD(){ 
	return getceOutput0().getOUT__CMD();
}
// Generated line, do not modify - java.lang.String getOUT__HUMIDITY()
public java.lang.String getOUT__HUMIDITY(){ 
	return getceOutput0().getOUT__HUMIDITY();
}
// Generated line, do not modify - java.lang.String getOUT__LOCALDATE()
public java.lang.String getOUT__LOCALDATE(){ 
	return getceOutput0().getOUT__LOCALDATE();
}
// Generated line, do not modify - java.lang.String getOUT__LOCALTIME()
public java.lang.String getOUT__LOCALTIME(){ 
	return getceOutput0().getOUT__LOCALTIME();
}
// Generated line, do not modify - java.lang.String getOUT__MSG()
public java.lang.String getOUT__MSG(){ 
	return getceOutput0().getOUT__MSG();
}
// Generated line, do not modify - java.lang.String getOUT__PLANETNAME()
public java.lang.String getOUT__PLANETNAME(){ 
	return getceOutput0().getOUT__PLANETNAME();
}
// Generated line, do not modify - java.lang.String getOUT__STATIONID()
public java.lang.String getOUT__STATIONID(){ 
	return getceOutput0().getOUT__STATIONID();
}
// Generated line, do not modify - java.lang.String getOUT__TEMPERATURE()
public java.lang.String getOUT__TEMPERATURE(){ 
	return getceOutput0().getOUT__TEMPERATURE();
}
// Generated line, do not modify - java.lang.String getOUT__WINDSPEED()
public java.lang.String getOUT__WINDSPEED(){ 
	return getceOutput0().getOUT__WINDSPEED();
}
// Generated line, do not modify - int getPortNumber()
public int getPortNumber(){ 
	return getceConnectionSpec().getPortNumber();
}
	// Generated line, do not modify - java.beans.PropertyChangeSupport getPropertyChange()
	protected java.beans.PropertyChangeSupport getPropertyChange() {
		if (propertyChange == null) {
			propertyChange = new java.beans.PropertyChangeSupport(this);
		};
		return propertyChange;
	}
// Generated line, do not modify - com.ibm.ivj.eab.command.SelectorRecord getselectorHelper()
private com.ibm.ivj.eab.command.SelectorRecord getselectorHelper() {
	if (ceSelectorHelper == null) {
		try {
			ceSelectorHelper = new com.ibm.ivj.eab.command.SelectorRecord();
		} catch (java.lang.Throwable exn) {
			this.internalExceptionHandler(exn);
		}
	}
	return ceSelectorHelper;
}
	/**
	 * main entrypoint - runs the command when it is run as an application
	 * @param args java.lang.String[]
	 */
	// Generated line, do not modify - void main(java.lang.String[])
	public static void main(java.lang.String[] args) {
	
	   // user code begin {__main()_1}
	   // user code end {__main()_1}
	
		try {
			ReadingCommand aReadingCommand;
			aReadingCommand = new ReadingCommand();
			aReadingCommand.execute();
			System.out.println(com.ibm.ivj.eab.util.BeanDumper.toString(aReadingCommand.getOutput()));
	       // user code begin {__main()_2}
	       // user code end {__main()_2}
		} catch (Throwable exception) {
			System.err.println("Exception occurred in main() of ReadingCommand");
			exception.printStackTrace(System.out);
	       // user code begin {__main()_3}
	       // user code end {__main()_3}
		}
	}
// Generated line, do not modify - void readObject(java.io.ObjectInputStream)
private void readObject(java.io.ObjectInputStream in) throws java.io.IOException, ClassNotFoundException {
	in.defaultReadObject();
	this.propertyChange = new java.beans.PropertyChangeSupport(this);
	this.addPropertyChangeListener(this);
	this.ivjEventHandler = new IvjEventHandler();
	this.addPropertyChangeListener(ivjEventHandler);
	getceConnectionSpec().addPropertyChangeListener(ivjEventHandler);
	getceInteractionSpec().addPropertyChangeListener(ivjEventHandler);
	getceInput().addPropertyChangeListener(ivjEventHandler);
	getceOutput0().addPropertyChangeListener(ivjEventHandler);
	getceOutput1().addPropertyChangeListener(ivjEventHandler);
	getselectorHelper().addPropertyChangeListener(ivjEventHandler);
}
	// Generated line, do not modify - void removePropertyChangeListener(java.beans.PropertyChangeListener)
	public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
		getPropertyChange().removePropertyChangeListener(listener);
	}
// Generated line, do not modify - void resetInput(ls.conn.ims.cmd.InputMsg)
private void resetInput(ls.conn.ims.cmd.InputMsg newInput) {


	newInput.setIN__CMD(this.ceInput.getIN__CMD());
	newInput.setIN__STATIONID(this.ceInput.getIN__STATIONID());
	newInput.setIN__TRCD(this.ceInput.getIN__TRCD());
	newInput.setIN__LL(this.ceInput.getIN__LL());
	newInput.setIN__STATIONID(this.ceInput.getIN__STATIONID());
	this.ceInput = newInput;
}
// Generated line, do not modify - void setCeConnectionSpec(com.ibm.connector.imstoc.IMSConnectionSpec)
public void setCeConnectionSpec(com.ibm.connector.imstoc.IMSConnectionSpec aCeConnectionSpec) {
	this.ceConnectionSpec = aCeConnectionSpec;
	this.setConnectionSpec(aCeConnectionSpec);
}
// Generated line, do not modify - void setCeInput(ls.conn.ims.cmd.InputMsg)
public void setCeInput(ls.conn.ims.cmd.InputMsg aCeInput) {
	if(this.fieldInputSetAtRuntime)
		this.resetInput(aCeInput);
	else{
		this.ceInput = aCeInput;
		this.setInput(aCeInput);
	}
}
// Generated line, do not modify - void setCeInteractionSpec(com.ibm.connector.imstoc.IMSInteractionSpec)
public void setCeInteractionSpec(com.ibm.connector.imstoc.IMSInteractionSpec aCeInteractionSpec) {
	this.ceInteractionSpec = aCeInteractionSpec;
	this.setInteractionSpec(aCeInteractionSpec);
}
	// Generated line, do not modify - void setDataStoreName(java.lang.String)
	public void setDataStoreName(java.lang.String newValue){ 
	getceInteractionSpec().setDataStoreName(newValue);
}
	// Generated line, do not modify - void setDFSDATA1(java.lang.String)
	public void setDFSDATA1(java.lang.String newValue){ 
	getceOutput1().setDFSDATA1(newValue);
}
	// Generated line, do not modify - void setHostName(java.lang.String)
	public void setHostName(java.lang.String newValue){ 
	getceConnectionSpec().setHostName(newValue);
}
	// Generated line, do not modify - void setIN__STATIONID(java.lang.String)
	public void setIN__STATIONID(java.lang.String newValue){ 
	getceInput().setIN__STATIONID(newValue);
}
// Generated line, do not modify - void setInputSetAtRuntime(boolean)
public void setInputSetAtRuntime(boolean runtimeInput) {
	boolean oldValue = fieldInputSetAtRuntime;
	fieldInputSetAtRuntime = runtimeInput;
	firePropertyChange("inputSetAtRuntime", new Boolean(oldValue), new Boolean(runtimeInput));
	if(this.fieldInputSetAtRuntime)
		this.setInput(null);
}
	// Generated line, do not modify - void setOUT__CMD(java.lang.String)
	public void setOUT__CMD(java.lang.String newValue){ 
	getceOutput0().setOUT__CMD(newValue);
}
	// Generated line, do not modify - void setOUT__HUMIDITY(java.lang.String)
	public void setOUT__HUMIDITY(java.lang.String newValue){ 
	getceOutput0().setOUT__HUMIDITY(newValue);
}
	// Generated line, do not modify - void setOUT__LOCALDATE(java.lang.String)
	public void setOUT__LOCALDATE(java.lang.String newValue){ 
	getceOutput0().setOUT__LOCALDATE(newValue);
}
	// Generated line, do not modify - void setOUT__LOCALTIME(java.lang.String)
	public void setOUT__LOCALTIME(java.lang.String newValue){ 
	getceOutput0().setOUT__LOCALTIME(newValue);
}
	// Generated line, do not modify - void setOUT__MSG(java.lang.String)
	public void setOUT__MSG(java.lang.String newValue){ 
	getceOutput0().setOUT__MSG(newValue);
}
	// Generated line, do not modify - void setOUT__PLANETNAME(java.lang.String)
	public void setOUT__PLANETNAME(java.lang.String newValue){ 
	getceOutput0().setOUT__PLANETNAME(newValue);
}
	// Generated line, do not modify - void setOUT__STATIONID(java.lang.String)
	public void setOUT__STATIONID(java.lang.String newValue){ 
	getceOutput0().setOUT__STATIONID(newValue);
}
	// Generated line, do not modify - void setOUT__TEMPERATURE(java.lang.String)
	public void setOUT__TEMPERATURE(java.lang.String newValue){ 
	getceOutput0().setOUT__TEMPERATURE(newValue);
}
	// Generated line, do not modify - void setOUT__WINDSPEED(java.lang.String)
	public void setOUT__WINDSPEED(java.lang.String newValue){ 
	getceOutput0().setOUT__WINDSPEED(newValue);
}
// Generated line, do not modify - void setPortNumber(int)
public void setPortNumber(int newValue){ 
	getceConnectionSpec().setPortNumber(newValue);
}
}
