package itso.ejb35.session;

/**
 * This is a Home interface for the Session Bean
 */
public interface CustomerFinderHome extends javax.ejb.EJBHome {

/**
 * create method for a session bean
 * @return itso.ejb35.session.CustomerFinder
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
itso.ejb35.session.CustomerFinder create() throws javax.ejb.CreateException, java.rmi.RemoteException;
}
