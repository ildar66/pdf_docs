package itso.ejb35.bmp;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface TransactionRecord extends javax.ejb.EJBObject {

/**
 * 
 * @return java.lang.String
 * @exception String The exception description.
 */
java.lang.String getAccID() throws java.rmi.RemoteException;
/**
 * 
 * @return java.math.BigDecimal
 * @exception String The exception description.
 */
java.math.BigDecimal getTransamt() throws java.rmi.RemoteException;
/**
 * 
 * @return java.sql.Timestamp
 * @exception String The exception description.
 */
java.sql.Timestamp getTransID() throws java.rmi.RemoteException;
/**
 * 
 * @return java.lang.String
 * @exception String The exception description.
 */
java.lang.String getTranstype() throws java.rmi.RemoteException;
/**
 * 
 * @return void
 * @param newAccID java.lang.String
 * @exception String The exception description.
 */
void setAccID(java.lang.String newAccID) throws java.rmi.RemoteException;
/**
 * 
 * @return void
 * @param newAmount java.math.BigDecimal
 * @exception String The exception description.
 */
void setTransamt(java.math.BigDecimal newAmount) throws java.rmi.RemoteException;
/**
 * 
 * @return void
 * @param newTranstype java.lang.String
 * @exception String The exception description.
 */
void setTranstype(java.lang.String newTranstype) throws java.rmi.RemoteException;
}
