package itso.ejb35.cmp;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface TransRecord extends javax.ejb.EJBObject {

/**
 * Getter method for accID
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getAccID() throws java.rmi.RemoteException;
/**
 * Getter method for transamt
 * @return java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
java.math.BigDecimal getTransamt() throws java.rmi.RemoteException;
/**
 * Getter method for transtype
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getTranstype() throws java.rmi.RemoteException;
/**
 * Setter method for accID
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setAccID(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * Setter method for transamt
 * @param newValue java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
void setTransamt(java.math.BigDecimal newValue) throws java.rmi.RemoteException;
/**
 * Setter method for transtype
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setTranstype(java.lang.String newValue) throws java.rmi.RemoteException;
}
