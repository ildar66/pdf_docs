package itso.ejb35.cmp.client;

import itso.ejb35.cmp.*;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 9:43:06 AM)
 * @author: Ueli TP
 */
public class SimpleApp {
/**
 * Starts the application.
 * @param args an array of command-line arguments
 */
public static void main(java.lang.String[] args) {
  try {
	//java.util.Properties properties = new java.util.Properties();
	//properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
	//properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY,
	//						"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
	//javax.naming.InitialContext initialContext = new javax.naming.InitialContext(properties);
	javax.naming.InitialContext initialContext = new javax.naming.InitialContext();

	Object objHome = initialContext.lookup("itso/ejb35/cmp/Customer");
	CustomerHome customerHome = (CustomerHome)
		javax.rmi.PortableRemoteObject.narrow(objHome,CustomerHome.class);

	Customer cust2 = customerHome.create(201, "Mr", "John", "Smith", "JS", "JS");
	System.out.println("Customer 201 created");
	Customer cust1 = customerHome.findByPrimaryKey(new CustomerKey(101));
	System.out.println("Customer 101: name="+cust1.getName());
	System.out.println("Customer 201: name="+cust2.getName());
	cust2.setLastName("Keller");
	System.out.println("Customer 201: name="+cust2.getName());
	cust2.remove();
	System.out.println("Customer 201 removed");
  } catch(Exception ex) {
	  ex.printStackTrace();
  }
}
}
