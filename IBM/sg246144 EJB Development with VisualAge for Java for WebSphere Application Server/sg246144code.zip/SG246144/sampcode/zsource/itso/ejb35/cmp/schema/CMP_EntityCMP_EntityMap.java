package itso.ejb35.cmp.schema;

class CMP_EntityCMP_EntityMap extends com.ibm.vap.common.MapStorageClass {
/**
 * This is a textual representation of CMP_EntityCMP_Entity to assist documentation and comparing class versions
 * Modifying the string has no effect on the actual data which is stored internally on the class
 * If a developer wishes to share their model data with another user in another repository the class
 * should be exported taking the option to export to a repository
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
static void infoString() {
/*Validation error in a VapPersistentClassMap('TransactionRecord', 'CMP_Entity'), the error is: 'No such class: TransactionRecord  '
====================================================================================================
DataStore Map
Model: CMP_Entity
Schema: CMP_Entity
Map contains 4 class maps 

====================================================================================================
Class:	BankAccount
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: BankAccount, Table: Account
Table map contains 2 ivar maps
	Distinct Table Inheritance
	Root Table Map
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'accID' in BankAccount
			Columns in Account: accid
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'balance' in BankAccount
			Columns in Account: balance
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
Class:	Customer
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: Customer, Table: Customer
Table map contains 7 ivar maps
	Distinct Table Inheritance
	Root Table Map
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'address' in Customer
			Columns in Customer: address
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'customerID' in Customer
			Columns in Customer: customerID
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'firstName' in Customer
			Columns in Customer: firstName
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'lastName' in Customer
			Columns in Customer: lastName
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'password' in Customer
			Columns in Customer: password
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'title' in Customer
			Columns in Customer: title
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'userID' in Customer
			Columns in Customer: userID
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
Class:	TransactionRecord

----------------------------------------------------------------------------------------------------
Class:	TransRecord
----------------------------------------------------------------------------------------------------
Regular Table Map , For class: TransRecord, Table: TransRecord
Table map contains 4 ivar maps
	Distinct Table Inheritance
	Root Table Map
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'accID' in TransRecord
			Columns in TransRecord: accID
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'transamt' in TransRecord
			Columns in TransRecord: transamt
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'transID' in TransRecord
			Columns in TransRecord: transID
			Is not part of optimistic predicate  
----------------------------------------------------------------------------------------------------
		Simple Attribute Map
			Instance Variable: 'transtype' in TransRecord
			Columns in TransRecord: transtype
			Is not part of optimistic predicate  

----------------------------------------------------------------------------------------------------
*/}
}
