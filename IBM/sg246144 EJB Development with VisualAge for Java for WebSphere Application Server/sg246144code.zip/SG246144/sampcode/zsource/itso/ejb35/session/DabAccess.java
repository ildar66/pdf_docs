package itso.ejb35.session;

import com.ibm.db.*;
import com.ibm.db.base.*;
import com.ibm.ivj.db.uibeans.*;
public class DabAccess extends DatabaseAccess {
public static com.ibm.db.CallableStatementMetaData callCustStp() throws java.lang.Throwable {
  String name = "itso.ejb35.session.DabAccess.callCustStp";
  String statement = "{ CALL DB2ADMIN.CUSTOMERBYLASTNAME(:PARTIALNAME) }";

  CallableStatementMetaData aSpec = null;
  try{
    aSpec = new CallableStatementMetaData();
    aSpec.setName(name);
    aSpec.setSQL(statement);

    aSpec.addParameter("PARTIALNAME", 12, 12, 1);

    StatementMetaData result1 = new StatementMetaData();
    aSpec.setNextMetaData(result1);
    result1.setName(name + "_result1");
    result1.addColumn("CUSTOMER.CUSTOMERID", 4, 4);
    result1.addColumn("CUSTOMER.FIRSTNAME", 12, 12);
    result1.addColumn("CUSTOMER.LASTNAME", 12, 12);
    result1.addTable("DB2ADMIN.CUSTOMER");
    // user code begin {1} 
    // user code end {1}
  }
  catch(java.lang.Throwable e){
    // user code begin {2} 
    // user code end {2}
    throw e;
  }
  return aSpec;
/*V2.0
**start of SQL Assist data**
504b030414g08g08gad93992agggggggggggg0cggg6275696c64657220646174615bf39681b5b48841
343a3ada272bb12c512f27312f5d2fb8a428332fddbad82eef5ad6fd63ba4c0c0c15050c0c0c4c409522d8141af972ae6d31
7a120e53c80554288c45ddda4b61cf5fca56bbc30d2c6160333530308e37286160342c2d64a863608108b3g852d808226e8
82a64041037441136cda8db0091a963048bb381939baf87afae939870687f8fbba063945fa380687f839faba222b07b9cc32
deb884813d38323838c43104531268051b50d2d3c91753ce1022e78c4d1fd0bb2c9e21c1fe60196060308820ab6135363002
192d06520277a41e36378295026d124755eae61984432dd0660954b53086a70b8a624348acf0a2284656c16c090a4c466364
3146332056451101c6174b5e694e0e8ae196200f8204d430840d41029a18c20620011d14fb8d31ed6736c48c75a098217a9a
6133b5343001053193a111a6b8210e7103f4f4c86c01329aa5a4a83415cdc1c6580c070b639a0d16061b0dg504b070824ed
6ccf6001gg8c03gg504b010214g14g08g08gad93992a24ed6ccf6001gg8c03gg0cggggggggggg
gggggg6275696c6465722064617461504b0506gggg01g01g3aggg9a01gggg
**end of SQL Assist data**/
}
public static com.ibm.db.DatabaseConnection conn() throws java.lang.Throwable, com.ibm.db.DataException {
  com.ibm.db.DatabaseConnection connection = null;
  try{ 
    connection = new com.ibm.db.DatabaseConnection();
    connection.setConnectionAlias("itso.ejb35.session.DabAccess.conn");
    connection.setInitialContextFactory("com.ibm.ejs.ns.jndi.CNInitialContextFactory");
    connection.setJndiDataSource("jdbc/EJBBANK");
    connection.setUserID("");
    connection.setPromptUID(false);
    connection.setAutoCommit(false);
    connection.setPassword("", true);
  }
  catch(com.ibm.db.DataException e){throw e;}
  catch(java.lang.Throwable e){throw e;}
  return connection;
}
public static com.ibm.db.DatabaseConnection connx() throws java.lang.Throwable, com.ibm.db.DataException {
  com.ibm.db.DatabaseConnection connection = null;
  try{ 
    connection = new com.ibm.db.DatabaseConnection();
    connection.setConnectionAlias("itso.ejb35.session.DabAccess.connx");
    connection.setDriverName("COM.ibm.db2.jdbc.app.DB2Driver");
    connection.setDataSourceName("jdbc:db2:ejbbank");
    connection.setUserID("db2admin");
    connection.setPromptUID(false);
    connection.setAutoCommit(false);
    connection.setPassword("acedg0574g0864623261646d696e", true);
  }
  catch(com.ibm.db.DataException e){throw e;}
  catch(java.lang.Throwable e){throw e;}
  return connection;
}
public static com.ibm.db.StatementMetaData selectByLastname() throws java.lang.Throwable {
  String name = "itso.ejb35.session.DabAccess.selectByLastname";
  String statement = "SELECT ITSO.CUSTOMER.CUSTOMERID, ITSO.CUSTOMER.FIRSTNAME, ITSO.CUSTOMER.LASTNAME FROM ITSO.CUSTOMER WHERE ( ( ITSO.CUSTOMER.LASTNAME like '%'||:PARTIALNAME||'%' ) )";

  StatementMetaData aSpec = null;
  try{
    aSpec = new com.ibm.db.StatementMetaData();
    aSpec.setName(name);
    aSpec.setSQL(statement);
    aSpec.addTable("ITSO.CUSTOMER");
    aSpec.addColumn("CUSTOMER.CUSTOMERID", 4,4);
    aSpec.addColumn("CUSTOMER.FIRSTNAME", 12,12);
    aSpec.addColumn("CUSTOMER.LASTNAME", 12,12);
    aSpec.addParameter("PARTIALNAME", 12, 12);
    // user code begin {1} 
    // user code end {1}
  }
  catch(java.lang.Throwable e){
    // user code begin {2} 
    // user code end {2}
    throw e;
  }
  return aSpec;
/*V2.0
**start of SQL Assist data**
504b030414g08g08gfd84992agggggggggggg0cggg6275696c64657220646174615bf39681b5b48841
243ada272bb12c512f27312f5d2fb8a428332fdddac897736d8bd193702606868a0206060629a042612cead65e0a7bfe52b6
da1da68ea98481d9c8c0b08481d1b0b490a18e810922c66a6c60146f54c220e61912ecafe71c1a1ce2efeb1aa4e7e3181ce2
e7e8eb8aa114688038aa5237cf201c6a0d4a182450d5c2189e2ec88ad98d0c2ce20d40cad1dc6668600c12e5453104458591
812548056b5a624e712a9a8c29d8447334510226325b82c3c818598cd10c885551444c4b1858f24a7372500cb70405254880
0343d81024c08d216cg12e043b1df18d37e66430323f4b0018a81d419a0f9ce0ce43b2623746113903007d648358244144b
4951692a5aa498432285c72ac03128c4d3d1075d2fb305c80d183a813e330625292643230c6143ecc2a0883201g504b0708
9218dc2b3001ggf602gg504b010214g14g08g08gfd84992a9218dc2b3001ggf602gg0cggggggggg
gggggggg6275696c6465722064617461504b0506gggg01g01g3aggg6a01gggg
**end of SQL Assist data**/
}
}
