package itso.ejb35.reverse;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface Transrecord extends javax.ejb.EJBObject {

/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.Account
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.reverse.Account getAccount() throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.reverse.AccountKey
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
itso.ejb35.reverse.AccountKey getAccountKey() throws java.rmi.RemoteException;
/**
 * Getter method for transamt
 * @return java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
java.math.BigDecimal getTransamt() throws java.rmi.RemoteException;
/**
 * Getter method for transtype
 * @return java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
java.lang.String getTranstype() throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param inKey itso.ejb35.reverse.AccountKey
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void privateSetAccountKey(itso.ejb35.reverse.AccountKey inKey) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param anAccount itso.ejb35.reverse.Account
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void secondarySetAccount(itso.ejb35.reverse.Account anAccount) throws java.rmi.RemoteException;
/**
 * This method was generated for supporting the association named Transrecord AccountTransrecord Account.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param anAccount itso.ejb35.reverse.Account
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
void setAccount(itso.ejb35.reverse.Account anAccount) throws java.rmi.RemoteException;
/**
 * Setter method for transamt
 * @param newValue java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
void setTransamt(java.math.BigDecimal newValue) throws java.rmi.RemoteException;
/**
 * Setter method for transtype
 * @param newValue java.lang.String
 * @exception java.rmi.RemoteException The exception description.
 */
void setTranstype(java.lang.String newValue) throws java.rmi.RemoteException;
}
