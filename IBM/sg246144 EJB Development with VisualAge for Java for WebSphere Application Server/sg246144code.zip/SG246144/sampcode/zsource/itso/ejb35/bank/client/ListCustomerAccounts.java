package itso.ejb35.bank.client;

import itso.ejb35.bank.*;
import java.util.*;
import javax.rmi.*;
import javax.transaction.UserTransaction;
import javax.naming.InitialContext;
/**
 * Insert the type's description here.
 * Creation date: (4/17/2001 7:40:47 PM)
 * @author: Ueli TP
 */
public class ListCustomerAccounts {
/**
 * Starts the application.
 * @param args an array of command-line arguments
 */
public static void main(java.lang.String[] args) {
	// Insert code to start the application here.
  try {
	CustomerHome custHome;
	Customer     cust;
	CustAcct     ca;
	BankAccount  acct;
	Checking     acctChk;
	Savings      acctSav;
	TransRecord  trec;
	Enumeration  eCustAcct, eAcct;
	InitialContext ctx = new InitialContext();
	UserTransaction transact;
	
	int custKey = 106;   // example
	
	if (args.length > 0 ) custKey = (new Integer(args[0])).intValue(); 
	//Properties properties = new Properties();
	//properties.put(javax.naming.Context.PROVIDER_URL, "iiop:///");
	//properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY,
	//						"com.ibm.ejs.ns.jndi.CNInitialContextFactory");
	//InitialContext initialContext = new InitialContext(properties);
	InitialContext initialContext = new InitialContext();
	Object objHome = initialContext.lookup("itso/ejb35/bank/Customer");
	custHome = (CustomerHome)PortableRemoteObject.narrow(objHome,CustomerHome.class);

	transact = (UserTransaction)ctx.lookup("jta/usertransaction");
	transact.begin();

	cust = custHome.findByPrimaryKey( new CustomerKey(custKey) );
	System.out.println("Customer "+cust.getCustomerID()+" "+cust.getName());
	eCustAcct = cust.getCustAcct();
	while (eCustAcct != null && eCustAcct.hasMoreElements()) {
		ca = (CustAcct)PortableRemoteObject.narrow( eCustAcct.nextElement() ,CustAcct.class);
		acct = ca.getAccount();
		String accid = ((BankAccountKey)acct.getPrimaryKey()).accID;
		if (acct instanceof Checking) {
			System.out.println("- Checking "+accid+": "+ acct.getBalance()); 
		} else if (acct instanceof Savings) {
			System.out.println("- Savings "+accid+": "+ acct.getBalance()); 
		} else {
			System.out.println("- Account "+accid+": "+ acct.getBalance()); 
		}
		try { eAcct = acct.getBankTransactions(); }
		catch (Exception e) {eAcct = null; }
		while (eAcct != null && eAcct.hasMoreElements()) {
			trec = (TransRecord)PortableRemoteObject.narrow( eAcct.nextElement(),TransRecord.class);
			java.sql.Timestamp treckey = ((TransRecordKey)trec.getPrimaryKey()).transID;
			System.out.println("  - Transaction: "+treckey + " " +trec .getTranstype() + " " + trec.getTransamt());
		}
	}
	System.out.println("END");
	transact.commit();
  } catch(Exception ex) {
	  ex.printStackTrace();
  }
}
}
