package itso.ejb35.rosebank;

import java.rmi.RemoteException;
import java.security.Identity;
import java.util.Properties;
import javax.ejb.*;
/**
 * This is an Entity Bean class with CMP fields
 */
public class AddressBean implements EntityBean {
	public String city;
	public int customerID;
	private transient com.ibm.ivj.ejb.associations.interfaces.SingleLink customerLink = null;
	private javax.ejb.EntityContext entityContext = null;
	private final static long serialVersionUID = 3206093459760846163L;
	public String state;
	public String street;
	public String zipcode;
	public java.lang.Integer customer_customerID;
/**
 * This method was generated for supporting the associations.
 * @return java.util.Vector
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected java.util.Vector _getLinks() {
	java.util.Vector links = new java.util.Vector();
	links.addElement(getCustomerLink());
	return links;
}
/**
 * This method was generated for supporting the associations.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected void _initLinks() {
	customerLink = null;
}
/**
 * This method was generated for supporting the associations.
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.RemoveException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected void _removeLinks() throws java.rmi.RemoteException, javax.ejb.RemoveException {
	java.util.Enumeration links = _getLinks().elements();
	while (links.hasMoreElements()) {
		try {
			((com.ibm.ivj.ejb.associations.interfaces.Link) (links.nextElement())).remove();
		}
		catch (javax.ejb.FinderException e) {} //Consume Finder error since I am going away
	}
}
/**
 * ejbActivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbActivate() throws java.rmi.RemoteException {
	_initLinks();
}
/**
 * ejbCreate method for a CMP entity bean
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbCreate() throws javax.ejb.CreateException, java.rmi.RemoteException {
	_initLinks();
	// All CMP fields should be initialized here.
}
/**
 * ejbLoad method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbLoad() throws java.rmi.RemoteException {
	_initLinks();
}
/**
 * ejbPassivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPassivate() throws java.rmi.RemoteException {}
/**
 * ejbPostCreate method for a CMP entity bean
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPostCreate() throws java.rmi.RemoteException {}
/**
 * ejbRemove method comment
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.RemoveException The exception description.
 */
public void ejbRemove() throws java.rmi.RemoteException, javax.ejb.RemoveException {
	_removeLinks();
}
/**
 * ejbStore method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbStore() throws java.rmi.RemoteException {}
/**
 * Getter method for city
 * @return java.lang.String
 */
public java.lang.String getCity() {
	return city;
}
/**
 * This method was generated for supporting the association named CustomerAddress.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.Customer
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.rosebank.Customer getCustomer() throws java.rmi.RemoteException, javax.ejb.FinderException {
	return (itso.ejb35.rosebank.Customer)this.getCustomerLink().value();
}
/**
 * Getter method for customerID
 * @return int
 */
public int getCustomerID() {
	return customerID;
}
/**
 * This method was generated for supporting the association named CustomerAddress.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return itso.ejb35.rosebank.CustomerKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public itso.ejb35.rosebank.CustomerKey getCustomerKey() {
	itso.ejb35.rosebank.CustomerKey temp = null;
	temp = new itso.ejb35.rosebank.CustomerKey();
	boolean customer_NULLTEST = true;
	customer_NULLTEST &= (customer_customerID == null);
	temp.customerID = ((customer_customerID == null) ? 0 : customer_customerID.intValue());
	if (customer_NULLTEST) temp = null;
	return temp;
}
/**
 * This method was generated for supporting the association named CustomerAddress.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @return com.ibm.ivj.ejb.associations.interfaces.SingleLink
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
protected com.ibm.ivj.ejb.associations.interfaces.SingleLink getCustomerLink() {
	if (customerLink == null)
		customerLink = new AddressToCustomerLink(this);
	return customerLink;
}
/**
 * getEntityContext method comment
 * @return javax.ejb.EntityContext
 */
public javax.ejb.EntityContext getEntityContext() {
	return entityContext;
}
/**
 * Getter method for state
 * @return java.lang.String
 */
public java.lang.String getState() {
	return state;
}
/**
 * Getter method for street
 * @return java.lang.String
 */
public java.lang.String getStreet() {
	return street;
}
/**
 * Getter method for zipcode
 * @return java.lang.String
 */
public java.lang.String getZipcode() {
	return zipcode;
}
/**
 * This method was generated for supporting the association named CustomerAddress.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param inKey itso.ejb35.rosebank.CustomerKey
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void privateSetCustomerKey(itso.ejb35.rosebank.CustomerKey inKey) {
	boolean customer_NULLTEST = (inKey == null);
	if (customer_NULLTEST) customer_customerID = null; else customer_customerID = (new Integer(inKey.customerID));
}
/**
 * This method was generated for supporting the association named CustomerAddress.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aCustomer itso.ejb35.rosebank.Customer
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void secondarySetCustomer(itso.ejb35.rosebank.Customer aCustomer) throws java.rmi.RemoteException {
	this.getCustomerLink().secondarySet(aCustomer);
}
/**
 * Setter method for city
 * @param newValue java.lang.String
 */
public void setCity(java.lang.String newValue) {
	this.city = newValue;
}
/**
 * This method was generated for supporting the association named CustomerAddress.  
 * 	It will be deleted/edited when the association is deleted/edited.
 * @param aCustomer itso.ejb35.rosebank.Customer
 * @exception java.rmi.RemoteException The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void setCustomer(itso.ejb35.rosebank.Customer aCustomer) throws java.rmi.RemoteException {
	this.getCustomerLink().set(aCustomer);
}
/**
 * Setter method for customerID
 * @param newValue int
 */
public void setCustomerID(int newValue) {
	this.customerID = newValue;
}
/**
 * setEntityContext method comment
 * @param ctx javax.ejb.EntityContext
 * @exception java.rmi.RemoteException The exception description.
 */
public void setEntityContext(javax.ejb.EntityContext ctx) throws java.rmi.RemoteException {
	entityContext = ctx;
}
/**
 * Setter method for state
 * @param newValue java.lang.String
 */
public void setState(java.lang.String newValue) {
	this.state = newValue;
}
/**
 * Setter method for street
 * @param newValue java.lang.String
 */
public void setStreet(java.lang.String newValue) {
	this.street = newValue;
}
/**
 * Setter method for zipcode
 * @param newValue java.lang.String
 */
public void setZipcode(java.lang.String newValue) {
	this.zipcode = newValue;
}
/**
 * unsetEntityContext method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void unsetEntityContext() throws java.rmi.RemoteException {
	entityContext = null;
}
}
