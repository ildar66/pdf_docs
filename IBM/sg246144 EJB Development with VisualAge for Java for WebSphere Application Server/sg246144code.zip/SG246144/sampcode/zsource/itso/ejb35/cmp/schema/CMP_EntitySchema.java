package itso.ejb35.cmp.schema;

class CMP_EntitySchema extends com.ibm.vap.common.SchemaStorageClass {
/**
 * This is a textual representation of CMP_Entity to assist documentation and comparing class versions
 * Modifying the string has no effect on the actual data which is stored internally on the class
 * If a developer wishes to share their model data with another user in another repository the class
 * should be exported taking the option to export to a repository
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
static void infoString() {
/*Logical Name: CMP_Entity
Physical Name: CMP_Entity
Schema contains 
	3 table(s)
	13 column(s)
	0 foreignKey(s)
====================================================================================================
Logical Table Name: Account
Physical Table Name: Account
	 qualifier: ITSO
Account contains: 
	2 column(s)
	0 foreign key relationship(s) 
Account has primary key:  (accid)
----------------------------------------------------------------------------------------------------
	Column Logical Name: accid
	Column PhysicalName: accid
	Column Type: CHAR(8)
	Nulls Allowed: no
	Part of Primary key: yes
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: balance
	Column PhysicalName: balance
	Column Type: DECIMAL(8, 2)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
====================================================================================================
Logical Table Name: Customer
Physical Table Name: Customer
	 qualifier: ITSO
Customer contains: 
	7 column(s)
	0 foreign key relationship(s) 
Customer has primary key:  (customerID)
----------------------------------------------------------------------------------------------------
	Column Logical Name: address
	Column PhysicalName: address
	Column Type: BLOB(2000)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapBinaryStreamToSerializableObjectConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: customerID
	Column PhysicalName: customerID
	Column Type: INTEGER
	Nulls Allowed: no
	Part of Primary key: yes
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: firstName
	Column PhysicalName: firstName
	Column Type: VARCHAR(30)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: lastName
	Column PhysicalName: lastName
	Column Type: VARCHAR(30)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: password
	Column PhysicalName: password
	Column Type: CHAR(8)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: title
	Column PhysicalName: title
	Column Type: CHAR(3)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: userID
	Column PhysicalName: userID
	Column Type: CHAR(8)
	Nulls Allowed: yes
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
====================================================================================================
Logical Table Name: TransRecord
Physical Table Name: TransRecord
	 qualifier: ITSO
TransRecord contains: 
	4 column(s)
	0 foreign key relationship(s) 
TransRecord has primary key:  (transID)
----------------------------------------------------------------------------------------------------
	Column Logical Name: accID
	Column PhysicalName: accID
	Column Type: CHAR(8)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapTrimStringConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: transamt
	Column PhysicalName: transamt
	Column Type: DECIMAL(8, 2)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: transID
	Column PhysicalName: transID
	Column Type: TIMESTAMP
	Nulls Allowed: no
	Part of Primary key: yes
	Converter Class: VapConverter
----------------------------------------------------------------------------------------------------
	Column Logical Name: transtype
	Column PhysicalName: transtype
	Column Type: CHAR(1)
	Nulls Allowed: no
	Part of Primary key: no
	Converter Class: VapTrimStringConverter*/}
}
