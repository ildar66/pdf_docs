package itso.ejb35.session;

import java.rmi.*;
import java.rmi.RemoteException;
import java.security.Identity;
import java.util.Properties;
import javax.ejb.*;
import javax.naming.*;
import javax.rmi.*;
import java.util.*;
import itso.ejb35.cmp.*;
/**
 * This is a Session Bean Class
 */
public class CustomerManagerBean implements SessionBean {
	private javax.ejb.SessionContext mySessionCtx = null;
	final static long serialVersionUID = 3206093459760846163L;
	private CustomerHome customerHome;
public Customer createCustomer(int id, String title, String firstName, 
							   String lastName, String userid, String password) {
	Customer customer = null;
	try {
		customer = getCustomerHome().create(id, title, firstName, lastName, userid, password);
	} catch (Exception e) {
		System.out.println("Cannot create a new EJB for customer" + id);
	}
	return customer;
}
/**
 * ejbActivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbActivate() throws java.rmi.RemoteException {}
/**
 * ejbCreate method comment
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbCreate() throws javax.ejb.CreateException, java.rmi.RemoteException {}
/**
 * ejbPassivate method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbPassivate() throws java.rmi.RemoteException {}
/**
 * ejbRemove method comment
 * @exception java.rmi.RemoteException The exception description.
 */
public void ejbRemove() throws java.rmi.RemoteException {}
public Customer findCustomer(int id) {
	Customer customer = null;
	try {
		customer = getCustomerHome().findByPrimaryKey(new CustomerKey(id));
		} catch (Exception e) {
		System.out.println("Cannot find the customer: " + id);
	}
	return customer;
}
public Hashtable getAllProperties(Customer customer) throws RemoteException{
	Hashtable ht = new Hashtable();
	ht.put("customerID", new Integer(customer.getCustomerID()));
	ht.put("title",      customer.getTitle());
	ht.put("firstName",  customer.getFirstName());
	ht.put("lastName",   customer.getLastName());
	ht.put("userID",     customer.getUserID());
	ht.put("password",   customer.getPassword());
	return ht;
}
private itso.ejb35.cmp.CustomerHome getCustomerHome()  {
	if (customerHome == null) {
		try {
			// Get initial context 
			Properties prp = getSessionContext().getEnvironment();					
			String sProviderURL= prp.getProperty("provider_URL"); 
			String sNameService= "com.ibm.ejs.ns.jndi.CNInitialContextFactory";
			Hashtable htEnv = new Hashtable();
			htEnv.put(javax.naming.Context.PROVIDER_URL, sProviderURL);
			htEnv.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY, sNameService);
			InitialContext ctx = new InitialContext(htEnv);
			//InitialContext ctx = new InitialContext();
			// Get EJBHome for Customer
			Object objHome = ctx.lookup(prp.getProperty("customer_JNDI")); 
			customerHome = (CustomerHome) PortableRemoteObject.narrow(objHome,
																	CustomerHome.class);
		} catch (Exception e) {
			System.out.println("Cannot retrieve the EJBHome for Customer");
		}
	}
	return customerHome;
}
/**
 * getSessionContext method comment
 * @return javax.ejb.SessionContext
 */
public javax.ejb.SessionContext getSessionContext() {
	return mySessionCtx;
}
public void setAllProperties(Customer customer, Hashtable ht) 
					throws RemoteException {
	String localTitle     = (String) ht.get("title");
	String localFirstName = (String) ht.get("firstName");
	String localLastName  = (String) ht.get("lastName");
	String localPassword  = (String) ht.get("password");
	String localUserID    = (String) ht.get("userID");
	// Set the property, only if parameter not null
	if ( localTitle     != null ) customer.setTitle(localTitle);
	if ( localFirstName != null ) customer.setFirstName(localFirstName);
	if ( localLastName  != null ) customer.setLastName(localTitle);
	if ( localUserID    != null ) customer.setUserID(localUserID);
	if ( localPassword  != null ) customer.setPassword(localPassword);
}
/**
 * setSessionContext method comment
 * @param ctx javax.ejb.SessionContext
 * @exception java.rmi.RemoteException The exception description.
 */
public void setSessionContext(javax.ejb.SessionContext ctx) throws java.rmi.RemoteException {
	mySessionCtx = ctx;
}
}
