package itso.ejb35.bank.servlet;

import itso.ejb35.bank.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 12:56:49 PM)
 * @author: Ueli TP
 */
public class CustAccountsSess extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
public void performTask(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
	// Set the results page URL
	String url    = "/ejb/bankservlet/CustAccountsSess.jsp";
	String urlerr = "/ejb/bankservlet/CustAccountsError.html";

  try {
	// Read the input parameter from the HTML Form
	String id = request.getParameter("CustomerID");
	int custId = (new Integer(id)).intValue();

	// variables
	CustomerAccessBean         customer = new CustomerAccessBean(); 
	BankAccountAccessBean      acct     = new BankAccountAccessBean();
	BankAccountAccessBeanTable accounts = new BankAccountAccessBeanTable();

	// get the customer and bank accounts
	customer.setInitKey_customerID(custId);
	String custName = customer.getName();
	accounts.setBankAccountAccessBean( acct.findAccountsForCustomer(custId) ); 

	// Forward to the result JSP
	request.setAttribute("customer", customer);
	request.setAttribute("accounts", accounts);
	getServletConfig().getServletContext().getRequestDispatcher(url).
			forward(request, response);
  } catch (Exception e) {
		getServletConfig().getServletContext().getRequestDispatcher(urlerr).
			forward(request, response);
  }
}
}
