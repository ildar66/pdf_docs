/**
 * JDBC Stored Procedure DB2ADMIN.CustomerByLastname
 */
import java.sql.*;                   // JDBC classes

public class CustomerByLastname
{
    public static void customerByLastname ( String partialName,
                                            ResultSet[] rs ) throws SQLException, Exception
    {
        // Get connection to the database
        Connection con = DriverManager.getConnection("jdbc:default:connection");
        PreparedStatement stmt = null;
        String sql;

        sql = "SELECT"
            + "    ITSO.CUSTOMER.CUSTOMERID AS CUSTOMERID,"
            + "    ITSO.CUSTOMER.FIRSTNAME AS FIRSTNAME,"
            + "    ITSO.CUSTOMER.LASTNAME AS LASTNAME"
            + " FROM"
            + "    ITSO.CUSTOMER"
            + " WHERE"
            + "    ("
            + "      ( ITSO.CUSTOMER.LASTNAME like '%' CONCAT  ?  CONCAT '%' )"
            + "    )";
        stmt = con.prepareStatement( sql );
        stmt.setString( 1, partialName );
        rs[0] = stmt.executeQuery();
        if (con != null) con.close();
    }
}
