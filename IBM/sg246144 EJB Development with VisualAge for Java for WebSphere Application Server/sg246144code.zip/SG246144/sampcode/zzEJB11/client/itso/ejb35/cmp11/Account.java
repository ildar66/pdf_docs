package itso.ejb35.cmp11;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface Account extends javax.ejb.EJBObject {

/**
 * 
 * @return java.lang.String
 * @exception String The exception description.
 */
java.lang.String getAccType() throws java.rmi.RemoteException;
/**
 * Getter method for balance
 * @return java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
java.math.BigDecimal getBalance() throws java.rmi.RemoteException;
/**
 * 
 * @return void
 * @param newValue java.lang.String
 * @exception String The exception description.
 */
void setAccType(java.lang.String newValue) throws java.rmi.RemoteException;
/**
 * Setter method for balance
 * @param newValue java.math.BigDecimal
 * @exception java.rmi.RemoteException The exception description.
 */
void setBalance(java.math.BigDecimal newValue) throws java.rmi.RemoteException;
}
