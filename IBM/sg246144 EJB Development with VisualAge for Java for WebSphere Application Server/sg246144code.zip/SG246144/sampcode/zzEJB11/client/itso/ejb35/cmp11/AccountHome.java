package itso.ejb35.cmp11;

/**
 * This is a Home interface for the Entity Bean
 */
public interface AccountHome extends javax.ejb.EJBHome {

/**
 * create method for a CMP entity bean
 * @return itso.ejb35.cmp11.Account
 * @param argAccID java.lang.String
 * @exception javax.ejb.CreateException The exception description.
 * @exception java.rmi.RemoteException The exception description.
 */
itso.ejb35.cmp11.Account create(java.lang.String argAccID) throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * 
 * @return itso.ejb35.cmp11.Account
 * @param argAccID java.lang.String
 * @param argBalance java.math.BigDecimal
 * @param argAccType java.lang.String
 * @exception String The exception description.
 * @exception String The exception description.
 */
itso.ejb35.cmp11.Account create(java.lang.String argAccID, java.math.BigDecimal argBalance, java.lang.String argAccType) throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * findByPrimaryKey method comment
 * @return itso.ejb35.cmp11.Account
 * @param key itso.ejb35.cmp11.AccountKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.ejb35.cmp11.Account findByPrimaryKey(itso.ejb35.cmp11.AccountKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
