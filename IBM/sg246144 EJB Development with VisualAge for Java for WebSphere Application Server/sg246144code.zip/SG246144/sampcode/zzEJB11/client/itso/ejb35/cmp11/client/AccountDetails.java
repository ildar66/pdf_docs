package itso.ejb35.cmp11.client;

import itso.ejb35.cmp11.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.math.BigDecimal;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 12:56:49 PM)
 * @author: Ueli TP
 */
public class AccountDetails extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		performTask(request, response); 	
	}
	public void performTask(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
	// Read the input parameter from the HTML Form
	String id = request.getParameter("accountID");
	// Set the results page URL
	String url = "/ejb/cmp11/AccountDetails.jsp";
	try
	{
		// Get the initial naming context
		javax.naming.InitialContext initialContext = new javax.naming.InitialContext();

		// Obtain the EJBHome for Account
		Object objHome = initialContext.lookup("itso/ejb35/cmp11/Account");
		AccountHome accountHome = (AccountHome)
			javax.rmi.PortableRemoteObject.narrow(objHome,AccountHome.class);

		// Find the account
		Account account = accountHome.findByPrimaryKey(new AccountKey(id));

		// Forward to the results JSP
		request.setAttribute("account", account);
		getServletConfig().getServletContext().getRequestDispatcher(url).
			forward(request, response);
	}
	catch (Exception e)
	{
		System.out.println("Exception thrown for account with id:" + id);
		e.printStackTrace();
	}
	}
}
