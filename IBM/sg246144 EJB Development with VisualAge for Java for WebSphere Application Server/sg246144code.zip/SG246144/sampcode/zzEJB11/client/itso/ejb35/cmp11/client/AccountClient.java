package itso.ejb35.cmp11.client;

import itso.ejb35.cmp11.*;
import java.math.BigDecimal;
/**
 * Insert the type's description here.
 * Creation date: (4/10/2001 9:43:06 AM)
 * @author: Ueli TP
 */
public class AccountClient {
/**
 * Starts the application.
 * @param args an array of command-line arguments
 */
public static void main(java.lang.String[] args) {
  try {
	javax.naming.InitialContext initialContext = new javax.naming.InitialContext();

	Object objHome = initialContext.lookup("itso/ejb35/cmp11/Account");
	AccountHome accountHome = (AccountHome)
		javax.rmi.PortableRemoteObject.narrow(objHome,AccountHome.class);

	Account acc1 = accountHome.create("111-1111", new BigDecimal("111.11"),"Checking");
	System.out.println("Account 111-1111 created: balance="+acc1.getBalance()+" Type="+acc1.getAccType());
	Account acc2 = accountHome.findByPrimaryKey(new AccountKey("101-1001"));
	System.out.println("Account 101-1001: balance="+acc2.getBalance()+" Type="+acc2.getAccType());
	acc1.setBalance(new BigDecimal("222.22"));
	System.out.println("Account 111-1111 changed: balance="+acc1.getBalance()+" Type="+acc1.getAccType());
	acc1.remove();
	System.out.println("Account 111-1111 removed");
  } catch(Exception ex) {
	  ex.printStackTrace();
  }
}
}
