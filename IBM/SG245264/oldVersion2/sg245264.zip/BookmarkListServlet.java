package itso.bookmark.servlet;

/**
 * This type was created in VisualAge.
 */
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import itso.bookmark.Bookmark;

public class BookmarkListServlet extends javax.servlet.http.HttpServlet {
	private String SerializedBookmarkFileName = "C:\\TEMP\\BOOKMARK.SER";
	private Vector fieldBookmarkList = new Vector();
	private String ServletURL = null;
/**
 * BookmarkListServlet constructor comment.
 */
public BookmarkListServlet() {
	super();
}
/**
 * Perform the addEntry method.
 * @param title java.lang.String
 * @param url java.lang.String
 */
public  synchronized void addEntry(String title, String url) {
	getBookmarkList().addElement( new Bookmark(title, url));
	return;
}
/**
 * Perform the addEntry method.
 * @param title java.lang.String
 * @param url java.lang.String
 */
public  synchronized void deleteEntry(String title) {
	Enumeration e = getBookmarkList().elements();
	Bookmark b = null;
	while( e.hasMoreElements()){
		b = (Bookmark)e.nextElement();
		if( b.getTitle().equals( title)){
			getBookmarkList().removeElement(b);
			return;
		}
	}	
	return;
}
public void destroy()
{
	saveList();
}
protected void doGet(HttpServletRequest req,
				  HttpServletResponse resp) throws ServletException, IOException
{
	sendList( req, resp);
}
protected void doPost(HttpServletRequest req,
				  HttpServletResponse resp) throws ServletException, IOException
{
	boolean sendTheList = true;
	String action = req.getParameter("action");
	String title = req.getParameter("title");
	String url = req.getParameter("url");
	if( action.equals("add")){
		addEntry( title, url);
	}
	else if( action.equals("delete")){
		deleteEntry( title);
	}
	else if( action.equals("save")){
		saveList();
	}	
	else{
		sendTheList = false;
		log("Bad request");
	}
	if( sendTheList){
		sendList( req, resp);
	}
}
/**
 * Gets the bookmarkList property (java.util.Vector) value.
 * @return The bookmarkList property value.
 * @see #setBookmarkList
 */
public Vector getBookmarkList() {
	return fieldBookmarkList;
}
public void init(ServletConfig config) throws ServletException
{
	try{
   		FileInputStream fIn = new FileInputStream( SerializedBookmarkFileName);
   		ObjectInputStream in = new ObjectInputStream( fIn);
   		setBookmarkList((Vector)in.readObject());
	}
	catch( FileNotFoundException e){
   		setBookmarkList( new Vector());
	}
	catch( Exception e){
   		log( "Error initializing servlet: " + e);
		throw new UnavailableException( this, "Error initializing servlet: " + e);
	}
}
public synchronized void saveList()
{
	try{
   		FileOutputStream fOut = new FileOutputStream( SerializedBookmarkFileName);
   		ObjectOutputStream out = new ObjectOutputStream( fOut);
   		out.writeObject( getBookmarkList());
	}
	catch( IOException e){
		log("Error saving list: " + e);
	}
}
private void sendList( HttpServletRequest req, HttpServletResponse resp)
{
	PrintWriter pOut = null;
	ServletURL = req.getScheme() + "://" + req.getServerName() + ":" + 
		req.getServerPort() + req.getServletPath();
	try{
		resp.setContentType( "text/html");
/*
		pOut = resp.getWriter();
		The Domino Go Webserver does not support the getWriter method
*/
		pOut = new PrintWriter( resp.getOutputStream());
		pOut.println("<TITLE>BookmarkList Application</TITLE>");
		pOut.println("<H1>BookmarkList Application</H1>");
		pOut.println("<H2>Bookmarks:</H2>");
		pOut.println("<TABLE>");
		for( int i = 0; i < getBookmarkList().size(); i++){
			String Url = ((Bookmark)getBookmarkList().elementAt(i)).getUrl();
			String Title = ((Bookmark)getBookmarkList().elementAt(i)).getTitle();
			pOut.println("<TR>");
			pOut.println("<TD VALIGN=TOP>");
			pOut.println("<A HREF=" + Url + ">" + Title + "</a>");
			pOut.println("<TD>");			
			pOut.println("<FORM ACTION=" + ServletURL + " METHOD=POST>");
			pOut.println("<INPUT TYPE=HIDDEN NAME=action VALUE=delete>");
			pOut.println("<INPUT TYPE=HIDDEN NAME=title VALUE=\"" + Title + "\">");			
			pOut.println("<INPUT TYPE=SUBMIT NAME=DeleteButton VALUE=Delete>");
			pOut.println("</FORM>");
			pOut.println("</TR>");
		}
		pOut.println("</TABLE>");					
		pOut.println("<HR>");
		pOut.println("<FORM ACTION=" + ServletURL + " METHOD=POST>");
		pOut.println("<INPUT TYPE=HIDDEN NAME=action VALUE=add>");
		pOut.println("<b>Title:</b>");
		pOut.println("<INPUT TYPE=TEXT NAME=title SIZE=30>");
		pOut.println("<b>URL:</b>");
		pOut.println("<INPUT TYPE=TEXT NAME=url SIZE=30 VALUE=http://>");
		pOut.println("<INPUT TYPE=SUBMIT NAME=AddButton VALUE=Add>");
		pOut.println("</FORM>");
		pOut.println("<HR>");		
		pOut.println("<FORM ACTION=" + ServletURL + " METHOD=POST>");
		pOut.println("<INPUT TYPE=HIDDEN NAME=action VALUE=save>");
		pOut.println("<INPUT TYPE=SUBMIT NAME=SaveButton VALUE=Save>");
		pOut.println("</FORM>");
		resp.setStatus( HttpServletResponse.SC_OK);
		pOut.close();
	}
	catch( IOException e)
	{
		pOut.close();
		log("Error writing to browser: " + e);
	}
}
/**
 * Sets the bookmarkList property (java.util.Vector) value.
 * @param bookmarkList The new value for the property.
 * @see #getBookmarkList
 */
public void setBookmarkList(Vector bookmarkList) {
	fieldBookmarkList = bookmarkList;
}
}