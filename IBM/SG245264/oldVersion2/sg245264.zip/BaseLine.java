package baseline;

/**
 * This type was created in VisualAge.
 */
import com.ibm.ivj.util.base.*; 
public class BaseLine extends com.sun.java.swing.JFrame implements java.awt.event.ActionListener, java.awt.event.WindowListener, java.beans.PropertyChangeListener {
	private com.sun.java.swing.JButton ivjApplyButton1 = null;
	private com.sun.java.swing.JButton ivjCancelButton1 = null;
	private com.sun.java.swing.JOptionPane ivjErrorPanel = null;
	private com.sun.java.swing.JLabel ivjJLabel11 = null;
	private com.sun.java.swing.JTextField ivjVersionTextField1 = null;
	private com.sun.java.swing.JPanel ivjMainPanel = null;
	private System ivjSystemVariable = null;
	private com.sun.java.swing.JLabel ivjStatusLabel = null;
	Workspace ws = null;
	Project programElement = null;
	String errorString = "You must select one project before starting the baseline tool";
	private com.sun.java.swing.JLabel ivjElementNameLabel = null;
	private com.sun.java.swing.JLabel ivjElementTypeLabel = null;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public BaseLine() {
	super();
	initialize();
}
/**
 * BaseLine constructor comment.
 * @param title java.lang.String
 */
public BaseLine(String title) {
	super(title);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getCancelButton1()) ) {
		connEtoM3(e);
	}
	if ((e.getSource() == getApplyButton1()) ) {
		connEtoC2(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * Comment
 */
public boolean checkVersion( String versionName) {
	try{
		ProjectEdition[] allEditions = ((Project)programElement).getAllEditions();
		for (int p = 0; p < allEditions.length; p++){
			if( allEditions[p].isVersion()){
				if( allEditions[p].getVersionName().equals( versionName)){
					return false;
				}
			}
		}
	}	
	catch( IvjException e){
		getStatusLabel().setText( "Error checking for existing version.");
	}
	return true;
}
/**
 * connEtoC1:  (ErrorPanel.propertyChange.propertyChange(java.beans.PropertyChangeEvent) --> BaseLine.errorPanel_PropertyChange(Lcom.sun.java.swing.JOptionPane;)V)
 * @param arg1 java.beans.PropertyChangeEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.beans.PropertyChangeEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.errorPanelEvent((com.sun.java.swing.JOptionPane)getErrorPanel().getMessage());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (ApplyButton1.action.actionPerformed(java.awt.event.ActionEvent) --> BaseLine.makeVersion()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.makeVersion(getVersionTextField1().getText());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM2:  (BaseLine.window.windowClosed(java.awt.event.WindowEvent) --> SystemVariable.exit(I)V)
 * @param arg1 java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM2(java.awt.event.WindowEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		System.exit(0);
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM3:  (CancelButton1.action.actionPerformed(java.awt.event.ActionEvent) --> BaseLine.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Comment
 */
public void errorPanelEvent(com.sun.java.swing.JOptionPane pane) {
	if( pane.getValue() != com.sun.java.swing.JOptionPane.UNINITIALIZED_VALUE){
		dispose();
	}
}
/**
 * Return the ApplyButton1 property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getApplyButton1() {
	if (ivjApplyButton1 == null) {
		try {
			ivjApplyButton1 = new com.sun.java.swing.JButton();
			ivjApplyButton1.setName("ApplyButton1");
			ivjApplyButton1.setText("Apply");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjApplyButton1;
}
/**
 * 
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private static void getBuilderData() {
/*V1.1
**start of data**
	D0CB838494G88G88G46E0B5A5GGGGGGGGGGGG8CGGGE2F5E9ECE4E5F2A0E4E1F4E164BB8BD0D4D7165646ECC84A5910DAA62B0915189DA61BCD180D99F5C2D612A1719362A762A79193B40CB209F1B44144CCB125898F0186A2AAAAAAC9C80211A42804G12890B28C0B7820A0002CAECF625219F5D8DCDF75B7D1A0FF156BD67FEDE3FEEDE53511D295A2A6D6254FB771CF36FB9775CF34FBD775E071073791434642DB902101CA6305F774902D05EAA88BD839BD6F0DC46D4FD0A20789DG
	58A5EC362442B397E846A4FDCA36A09E4900F2911473BF50276C0777BDC25F1135E761450F1CC820BDFE577B7DE34BB9FF0A4BC9A765B947326039832084F06DG1327227C1547F299FE984ABB58BBC272D660FD82F99E3B1A2B4047B13ED4206582C4901E44E33EBC43001FG908A10C9B45B3E3B025123CBFFAEF4FC7031E6BB4AD15463107AEBAA2310BD85A1A18D0D10A2E8B250C6D52D7D26935D8617E83558444A4ADAF8EB02B7E1622FD11745D7B3882FA0F4C139E09A629A1D587FD8A8EF82481A46F5FA
	7E0BAAA6F342240740E01F785549BC0D6AB2E11AC7278E7DBB69D466E7D5DC6602E9DC66ABA7D1E66AF4FDCA9EC079F40E3F4D0278A6A89B812ECF673A3C7E9557A55C7E10507919FFDDC226D39D4227FBF419FE7A1D740F48D82F2A47315884345C997A14A200D6G87C0B040A74447A61DBA8C4F1AEEC9EB9F98305BEA9C0EDA2B51F956EE942D70DED9899406BBAF76581DC6C120FE747255A295FDB8BCB2435B0790E85FAE89FC6CF541778BA1D219A6CD25EFB9BB3E50C430B622E7F87A167B9B345BC2B206
	890047FABB513F89FEA541F77E46033F7EA462DB889E4B6301A6BC496DBC7EC72ECB7B0F41C2DC5B91CD3A1AAE3FAA51C4BEC9F508F952238B35714AC634F1EAB84CDB008A00D6G87C0F0B837711AD3C783593851A609CE1B415A666EF6981CD22D5BE2B50ACEE66B03D57EEC9D96BE5A4EBBE4FBB4D7E33FA34329BDB2E53C1E60E395F8EA27B86227D8CE84DA67D360B704FFB371534827A87FF6391D8F7B909F2F4053F66EA47CD84E78F7FD0A84C0ED25BD03360A037296001C196013GCDG66195CD64575
	5F7EC4FFECD5580956FD23FE9FBC45E149E9E83439A4032DC73CE8F0DA8C5DD651A5B01E04FA34E937D73D7748BC6981997522CDF49AA40B5D862D9B86C4989497657920FE9772B8C5C2ED378C08A0E040A170F6B58DFB60E9B538248B8E23C192BD9C143E23816DBAE83888ADC283B8E7E7222DB6109895846F21B3391D7A1A9037854AB9915CAE7F56309B1EE740C9C4EBE5254E5203EA981CA3FCBEAEF56641339078F5G0FGE4BF8DB185A06F99FDCA78B35C675F6A60BEBFAE6FBEA1626787D5FDFE7A4C9C
	0D6337543702FE6B71F9AAEB8D11B5957051G89G59117A149200D6GC7A4DFEBAEB89D0AB6D187FF71026B0D3A224EA406C478674FFE5ABF0D4A163CE46F74430B0031BA0D796BB6C59B7E78B38350C073234A98573569CBD59B0735FD21890EE4FD0D740DABBB1BF18EC581BE9EA075D96E87EFB664537901EB9D1F91ADCEF0E65168718A4A7BFAA376DB9C94ED12CEF408B6A33C3818BFEEE84C744C15DE3B6C476F92BC46A0ADB833CB467F29F19745C39B4A194769492711EE10A427255BAD09ED22A4D9EC
	A6CF7D4C53280B4BAB3C39589C28A4EBE69E74317CD96EBB6D5559706C003295E0BCG7A882599888DF9A783C482444975DEBF5961E3E72C6FBBCE63D5F0054C5FBAD4E85E3E15B4CAC61A9FDEFF3E13B2068FD19949FD398A5F4CE43E79A94067B2CFB661911E835BG34828C83CC8108FA0E5B63EECB170F1F6FD03467CF878EDCDEA0BEAA6BD1D5D9694258F306836A337DA770D1FFEABA635F375B4E287B768FE754FD7B4A1931FD57F4C64DF7A94DF68663F20F5DE69349641349824DD35FEAC71DADB60BF4
	49E2B409D21B651A886B67AC747BD4A77AFD820CD56AAC9E1F078E7258D1D8F72FD032E12FEAFE1455F0D453B90B7A29E316A7F6D01D6CCD98BBC42BB8GC6515A5DB609625DE4DDE1F8D78A411DBC06F55BC6DC12B84097CBBAFEFB0487C574737CC21ED6978DD9ECC67BD0B1FDE82DF617E8AC6CB38C9A0A8DC3D2B1990B62CB04D6076F07723F7966C43EF753C56230C5AAECBCF471D0A9155172F5A7112145555ADA6B16A43B2D3448C0ECD9CC9F2D2233576E9C98AD2B06109532E4C50D96178334AB84B9E5
	D44E9F132F90B990B22DA3FFADB18306FE11AD68A82A1C59ADDB8AA1327E06521AC8AD2B41E6AAEE833735190E017CA20353D4CA6AB036F6188327AC2255D8DAA4416B216F28FEBBC6FEC6742BF3BA6D10C6C1C6D164F05A9D22D39A511A21C931583BC8D56C968DB6D7F12B97C5CDCDD1EE15D08B1BFA6C8345AE372D1834628267B1951FEEF150A44BA6226225658277390C6F43186D7E4FE867B12BC2A5486EDC8613F82874BB3ADEB734601C8B0639988A90B10B2F579B1B104E73B636D0EB6DD6AB8D97C04B
	1D0D3160E3D70EE2FEAF1BC5776629C02374EFC614742E59143EC32E7FC3G7A6DDE74A90C3EDEEEDFF3CDC997667856AF3B26D63FEA8E2FBF4DEFFDEA1FD32DE81FD6401B810667F07B9CBE3BC7E11FA63B3D5F6DE8A7C1085277B663DA6F922F3AC58890C8B8A30E301CBC2FF9378F6D22416A76647A854D3826D895ED5218BC5500F80753B2G2992A6B36CFC63DC15726CE2826A89FD88076782GDA776CD798C339BBD11F7D76DB0C5DE78D9662B2D65917DF5C76A1BCBDCE434FD17E25DAA9A71E49491E2B
	CFA9184B6DF907C9E94F2A3914478A4F0839C85FEE6174F1D01E4868A45FF99E69277A7298BD75F91AD765BDCF73240E6715FC197D1CAF9C4A51G890C3FA40A7205C5A15FBF5AB8DF83143B22A89F4A9C4778DADFC03EFABB67CB0C22B9C9B66073812A810A657676BAB85F6497E88EB77D855A1EB0CF59DE2C4CD7BD0F66B69D73A83FF99EED6F7ABC647B44494FDD3E15F1E58437B4D5909626705C7CEC36726CC93863DB557595A1126931EC1EEFEEFE4FB9ECF79360D367F3BFFE30D96947B5AE173D47C236
	0A4C971BDB14EBAF4BD3DA50BFFAADCE976C7F0D62301C2734202E3817E4E86637EF6E7BC2983DB72EB3DAA43BD3BEC8684120C24F224E39D0A659774F6779456A4B4AF3AEE96BA71AEDFE7A5FBA1F659773BD7D9FBE7DCEBA552535DE6DCC43DB97AD4D8334F2F2F451A28E313EBCF66478CF2D5FEE5742563C812631CFCB3C1F91A3FC6C274E67737446F071CFE85F37C15A1E659AEFEF2DBC3ECD2D6AB95579D6BCDF6D17E35245D60D007BFC9A0728AE0B4BB007A6E71523D71B4A4A5327702801493E136C05
	B0E74EDF404F893FA667B29DD0F6G84AD60FD7C2F3C315B25C107367BDAF5867323A9F23B9A9D369B836584000C053C5DC5E985E3366BD99EE95B4F18383D72218DFA86D4CE4E00502FBAG97AC371D34F59FEFDBCEE1AAABE9124867E8F89E775135ABC30460B9F9FEFDB4EAA1754D358BBDBE5A5535A11D6AE0A767D3C42F97A1EEG50387CF29F46081BCCE659D8AE59C366B14BE2293E874ED6B3FD4689778BB9BF96E8F62A681BB1142789FE111D573E6851B756FDCFFA82G55392C1F6BACAC5227D4AC62
	6B4119D265FA60D8C4773E139771BECD6AAF03674D27185CC79F5E0F314813B773333C88DB96731B29A0EB2D2C4FF21D1ABE7951FC1CAB3E4A07E72014155AAF7DC3257DA2CB3FD335DF70EDF91A72E8EA374EE80F7DF4F78727F7GD0FD9DF6EE3FC700A7AE1A5BE7399D67A9E6F2D47F2A9BCA7DF397D37D9B96F37EA4420FD9B355B1698A5731F35103C248C31F2A6AC8680B29EE6397AB6E87A292532DGD447938EEE53E5401335044B7C2583E3627FAA599578F8165420BF5CFC364B47BD6DAA37238E743B
	AE6BE83D4A6DC84BA1D7B1D631EC181F7117A9575835FD1F79DDE327AF21B60ADA623B460E3463BC0B87FC62929E0323DBF11F4E5758739038216338DDE56B663D67D0A708452CFC5FB914CBE231404FA8AE3AFC4F523316FA4EFB72956F65705E30141F493EFA817D25934A43G41G0FGC4AD653A9DB89F700C3FEEF80CB37EE7C7463ACF710535CB79790E6D5A4D545BA2570BA4F78A594B544F3A8AFC70954B78DD407DE4ADEADAC64F7C91A8BE142ED18ABC7523EFCE72F540883428E5DCFEFC352F5EC5AF
	F9E4D63FB4DAAFAA67AE32E6353F64FB77F39F41DFFF49776EA7CB476FFEC201167FB217BF4BB4165DA63FBCDABE2DD7E93999FBFB6AB55CF4BD6AF79517506F2602BE8BG628136G64AD67FE57FF3EA8105F71339766F0D49FF7DFA0FD2A16FB5B00563BADE03DAE1FFA349F7F5001F97CB050C2G42G22G5683E44468D30AE2F8FF1EBCFFACD0FFD8D2C8D7B12D6F499B5333227F567AF7AAE03D26986FFAB45E1AB3730531F2A6FA88C473253FAB653918B1067B63F3B6DF3913FD64286B9BBD2ADE31CFB9
	5C279D2A430EBA2EC3F48C0FF1E917F10CB2D6C0FE88D0855081F09DE0A2C0448ABEC699EDEA393B5A980DCE5CBD7786D47FC17B2D0D53780075E2D7280D537BA587479CA779480C5949F50367361BD6F0BB5D2EC7BB953D826B83C09740F500A9G91GF12FF0BB695BEA8359C93EE684FF66674FAA4622FD56B9EE4DC74E0F2A676BA3092F28555BB6669D3FFFF99F852C177D2ADA0C18550936AE84DA452B5C060B5B70CE002F792DF60BCD9278FA7F5F6D385732BBADA60B0D63EEA3389EBB70BB799D6BG59
	87B7C01BE6G0A3B4F0D3889D08E15F1B38791978565D89937026092211C9FAB5F67DF70FF77306E027A5DC34285753B07BFDE987BDE6D038B7E6EA628FEB1E46F2B835D3AE2394E37DF63B8C946ADA77B4AA0A807493812635C8611B26E7193A46F02F2E2AC0FCD8F1D946431FDD471FEF454BD58DF93280C263F298C5A674DE4EF1C3A92F21C155C8ECBEB39EDAAD6F2BB846BF05EF7C2D98288868885188D908730C5661BC278700C8C4F53F2D651732FF2F83683C82BB85FEE1DA300FE58B6FFC7D91D8AD901
	7A962C6011946FD4F6E9C0594A7BC174DD0C01B897473ACBD74AD046DDEFFB3FE262368DD94567D475A57FF32A7E127A1CBAFBC9FDCE35DD9AFBCE69AF791BD31F12FE3EA16D95D46E741A7114061F6D0675E5B21EBA49FE36CCEEFBE2077FFEBC58215E0FDFF620DDDDF63733C77455B52CA3D726F99606C6C99CC0F5A84F8CD2DF02CD19B82A2F9124BE25792BBF27431FBDE8DF6D7D4A3E9E15FD680ED235B89F3E0A7A5A02D523FD145A7705FDBB497838DC220BA48ABA03E4E0327EE4D34852164932765429
	490AE3B2B6294822FD5BF9597FF86C3B2CBE9EF9177D0F47414B01472368327F71B8FAB970F8D4DD9EFBBCFEE55F46EC545A6B348F3416B19B8D5F98EB5D4DF84D1F0D6E567B37513DFAF59BCD567B3751AF7401ED942677EF23E97A40B60A50238D3AADC60B135D24D15B7C68D07ACF29EC335A2B5EB6ABE53222BAF13FB8AC4BDEC04AA3824F976DDDF847E4F29A9CE6CB0FCBA73AFA1C9607E487E5A73E0631EC3C8BF54D0377AAGAB4084051DE99BCF8C216CDE4874E0985B9CE20FA045E15DA75C7C9EA88E
	6AEC824881FCB9C0FB9CBFC7FB7CA8BE2D06EE453D5212C12C63FBE7CF791BFBF16D69B674741B1CF6374DD8BFCAF32AF742A04A0EGB931GD93FD353DB2C59A10FC31D4D4812AFFA3772B649BB9A41D84B13B9EEB249BBD6EC950405DB392EEFD5E1ACB50A3D8637D5A2272CAD8E76099D766BF7648E6AB85F0B94C1195A267EB8374DD4404D860887C8DD8DFB13557CACEA6E892CA3D9A4F28624DB0D5FBFE763AB133D3BC6C3ECB7E2F7035E312B315DC3B54AF33FA040CD85183D1A4BDDD74B65962C01359F
	2083E098E0629AAE37A0974F9414F77B947FECAE7A3457178C32AED7BE42BE1EEE4201ACE57C1BBF42F9BE6A2EDE2EB3659B3C7B2C23F78E6DA38E1154E6FEDE25206134D0502A8E233F35C986496DA2E8F607BB37DD597770B5744CB3FE8DBF534DB82CC6CF14694DE6B5FAD6BC27CFAED4236747F35BEEB4F15B16832E81408C908470C8BC4F3B9EA0FB63A8A847483824D21EAF444B3843F51C2F7C779CF7F79D672B7660EEF0DC706F7978BD6842B92DB80EA6B329744FB09FDE47BACF39707E63G03CC86B8
	D6F1500695F870FD426B3C3D3F38315F0306EE13255755893E6EF0DFAB7DF3B114A87D1F5C02406FB6BEB1723B0D2A89A1C24862BC3F5FF68BEF5079D8700667EC343A7A29943AAFDDCE76AFD82F9368A1EF10B35BC1257DD1F60DC077FA147E3D971D2CB149CA3A450B1EB92A7E7DDEF41CFB67981D76ED5DBE39EF6FCF910A6E717FDDFFAC6F53DA7A0CBF951696BCBDB81D5AEB5B904A110F2D64D8D6D6CE47674BA19C1FD286FCFCF08FD9816D995F2463B27ECDBEBE49A33B9463B3E8F0161563604873AC7F
	B866B4AAC763747E8716A07C18D8F2956B9A5BDADB5A6A2E34B4DF51B6418B6BF728C9F95E9D7342817F675DEF3273EE76B46F89CB2363B9F01C0F27300E0F677D47FD47F30D57F89CB961BB1EDFFB517F73046FF8A6EDD5526FBE61BB1E873D46F37FE5E53F2AE79D507033DD5FFED52C237D512D737DBF0D52AEDC0FBC77FD06A12932325EE9B1569ACCCDA4B2537E2756727E8F2F637713E53598E727C2B98AA0EE9D3F433E53AD7B59318704751D6A7703E10F16E99219BE39FF706895F51A7F2FC636164BEC
	7F833779892D2F4D27F95954217535395EEB8E7D33565766A3DE74E5DADF1BBF46686C9EAE401DAE0D67D47F775B793AB9817427381307B9EE360C3B5D4CF1DBE45C52C20EABDF4FF17B4D5C9E56755C9EF5E6DFFB4C7032471059579EC73CFC6CDF4D3E76586EC5FF556CEB0F632CFDBAB7EB6A78BD9CDD5F671BF094E72F473A7B4AF4AA3E2854B50DBD91C2218E42DE564770751E3B8A5A760796CF5B8F570D55F6321F368FB2DA5686CF5B2C3D9B01F4D56A1B3B4123AB490B946D517F8DDB6E9A874F3F6F6D
	05BFF3D04F2460F113A66D8B6A2E4D88CA51EA02FA3499C1DBEBB5C15D3AFC21DCABE47468EA4BF43519795DF5C37B2F6AF4A5BD75A32E211C727C6E7A2121215D5DA5BD27768FDDED93B45D3567F66D2D5518FBF4DFDEA800F63A4B702789B2103933AF88047522BC7E0B5DC06ED8A4BE0695D046B5F37686BA5FE83CFEDAD22E27A902A7E6673F856B69DB1E3C134E6F4F37AB63CE56679FEB76886AF1E7822B9B411E8D4DE16C7E70EB72EDF482600537A12F86A882288668FC1B1FB9DC90713E344651FBDE24
	1B1533861B41C4B22A4ACAC0B78EC0C9197233FDD62C7BE66FF2E83FBEBE40631659BCC918706927FE3FEB98FE1B76E7A2FB66650625611376EDC6BF76AD8AE871G998910E3811483B4A5703ECD96593D90FE72D2A3C9069EB37972C83E943208C39EB4EECA28DFE9077249A2143C0B7C32FD5EF7493F7F9F6FFE6CC07DFE4A90777B2E846A776B9314FE7F9F434ABCC56977299B75A90E0D9E3F27639AE345789B8C78300D72D933F8C440DC28EF7497CC00641FGD0AC797A11792873782D5DB7AE9D401ED259
	07FA3F74A79BBC68B4ACCBAD5DFD307BEEB718643911D9FB33F2697D6D43E42DDF305177DE79F1020F5968FB2FDCD14B6F15630156708E3F1BF94706E3928665A800B800C4005CF739BD6F6CAD91825C49345B9DCD6220E8D59C9D523E6D555E5A5D2F7922DA3D72F7D94CFA575FDD336E30DA3DCE466F70DB6FAE33DA3D710CFF225FFAB105EA754298FF245FFAF92A7246024F49D888827ABB7F51B57887BC66E271F20D03474BCD5FCD92C26D859A3E3E7A36370C69D630491367E574AFCE27ED2E9894D4E5A6
	1C24745D5730C4635FD752B8417BB78E901164A7888FBFBCEFDEC2826451C91BB763F38A7CC2C31187FF14BFA949431FC4FE42CD7F280F1BA57E8DCEA774ABE4934FFF456BFCFD4CE97819107A40C7FE5711854C9E6B59B3647B30B45A4FD725EAF87EA5D1905E5FA288098C12BE207A0F8244EF71400DC42AA70D03021B47415C776839D579FB4AEF3F777D78BF3CDCDDE89CD5948E5207208F7AA09830940388FD482BD024CA9E94C4C44466A17EE1C19F7A2074C513B559581BECFE5A123411C6EACAA2C1DA4D
	26DA22ADAD0628C95AE897D3D8E2C8DAA212C9F6B6BB3B131938B35DEC331BDD4F39FFBB7BB359A6D8878E3B734D39774E3DF34FB9771EFB6EC5BDB8835892108DD489749450812017015E8172FCA2E3AD35E178E582AA7CD7E3E357D7EF2889EDC54518D86E2424861A25990D62B851107E41ABD1E76C8F43FE0AE20CDB1C9B7BC0C8603FC6319F07F41DFA7899F6A30AF3D74D30D44352ECADC1597933BF223D794F2862E5F57DBB0DED515730689B851A830AG259BC45D5E0E72985E92B6F9BA342A0A4926A8
	6B05183BEF7625D8797D2E2F45304E4B26ED1BEB183F406BE2D8E75BDC27A0435E24FE7E38369A3199AB475F0B214C68EA18422C7FBC37D1C1F27DDE74777F7BE2F2625D9036208A5A797586F1FE42C2F289FEBDA079C835A0C97FA509FC198C6CC98A99B85E48E460FCA3138156066F6A78DF7A741929664FBE50B1AD6E915394DD5B244ED196A24974EB8D0691F0DD7B2C637FAFD38FFE7DF5610116416A5FE4387771D633747AC317D9FA6D2F475CFEAF5F97267BBE546C3C70A90EB78A7F6161F961BF3CA931
	459141D7A53103A3B21EC0E25591417731445AB441C7BC82BBCA6762C138DF12581CDF70699EB136295B42B964C1382F87728275FD3A689B861AG1A830AG25019E872A812A852A83BA8264816AEE0239C21350C57BAC1C7F380DAD391306AA24384262AEF84C21DDE86F2FB4ED3F9E4D52250B52155B6F496A7D900D551D01B21600AA009E835AAF6BB13BB9C4CA598B3AFBC28D85959DFA8157DB676E76125CA56CB353A393F7059E29053CBDB27F2FD3A84F9BDA480E48FE74ED8A5796A2AAAACB01FDC77940
	BAB978FEC821ED36D694830FA889AAA10EDFCBE1D94B77EC558A2AF15CCB44701FD3E847C20A2D307B49D4976D67348ABC6DEFA92C83FC9443620B5CDAD255791AF8413315FB3794AB461E05536EF23616AEEFCB92E99A7B8EB6G97A39816CA53981CF058D2E5BBD424FBA5963002A69AC953E0FD20AD393BB1F46F0E53316F3DAF697E3DDFCC0A6FBD5A8C3283444603BF62A763FE1B4679F2FEA09FA96D8722FBAD1A8BFDCCEFF46772BEB4A2722EE9AE161F56027C8B732EAD4A7B73D3393C7B35F27E26D2F9
	8B5F582B0E3C199F2E531F6F078B1E4E1595730B326ADD6A51C5F23E2D8F0187C95403F8F3E5317EF3E44B3D1F9E5DAA5FCFBDDB2547BC1FED950FF9FC1952E31E9399671807E127B2783E2B2097EFCB3EB3923BA331AFE91E08AD64690C2FB2A7B9FEB3CFEF1C4F60FBEDD06C3618FBBB30BB9C3B14C1D903AAC75099456389B278DD421A4E657F9A65413129AD5BE31C3E23362EB85EFBD2E2785E5DDE7C0E4F5079C6EBEB2BA4467BF0166ABA45886932AD9F4D629A9A6A2FD9F59D065470097822AEFB7EC496
	5F4B52B6F95BBD19AD5C0B49706AAC16E9DA333FCFCD9BE034D50B47616E5847464F0D58E53AD7F629176AF71C0E49CFB5B69F776337DF943E7820D7682037D094B96F197E9C6FDE3F602D84DE77F9748CAE3B70F9F4D55EF9DBFD637DA54FA3C12A7572F30E78EFF026061F79F26222331E2485469EAD77E3732B7D4EF44310E63CCCBAE6732F8E527D42403B84E43788DB7C4840B9D24A56C37F39EE6A260C799C22ED3A87529DA2823BC0313DAD2C5D98F640AF7896A5763C5F4947E5E890F5D7DC9576FBE210
	493D2A9A12E7FA907B7CB20C6C192ED33E41BA70F1BDD5858C9FC87664F0218A383D52A3D7614354FCC4BAECF2DCECB336C9A70BAA30C9878DBB306264345C54952042FEB8F1F94C777E533EB6529EA01DCC7985C8BBEA30G69208AAEC0FC207C126BA47FBAE97DC3B2C41C9D07AAEA388895CF08CDFAF84042904E164760BE98B7518BA86E3B589A55E51B1C1D46D32D066C08BA1460E9F002FE2928BCFA5D87CA36C7C5FF2F3C606C6FF333832E6B317B0FF1FF6D31427DC7E7691C5783F89F790B773D556877
	445D9F7A671A226B362247A60D907AC627F0ECA77B46C08C7337848FFF48E34A683CBB6AC8736FGD0CB878889FF18D19E9CGGDCD0GGD0CB818294G94G88G88G46E0B5A589FF18D19E9CGGDCD0GG8CGGGGGGGGGGGGGGGGGE2F5E9ECE4E5F2A0E4E1F4E1D0CB8586GGGG81G81GBAGGGD89CGGGG
**end of data**/
}
/**
 * Return the CancelButton1 property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getCancelButton1() {
	if (ivjCancelButton1 == null) {
		try {
			ivjCancelButton1 = new com.sun.java.swing.JButton();
			ivjCancelButton1.setName("CancelButton1");
			ivjCancelButton1.setText("Cancel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjCancelButton1;
}
/**
 * Return the ElementNameLabel1 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getElementNameLabel() {
	if (ivjElementNameLabel == null) {
		try {
			ivjElementNameLabel = new com.sun.java.swing.JLabel();
			ivjElementNameLabel.setName("ElementNameLabel");
			ivjElementNameLabel.setText("JLabel3");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjElementNameLabel;
}
/**
 * Return the ElementTypeLabel1 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getElementTypeLabel() {
	if (ivjElementTypeLabel == null) {
		try {
			ivjElementTypeLabel = new com.sun.java.swing.JLabel();
			ivjElementTypeLabel.setName("ElementTypeLabel");
			ivjElementTypeLabel.setText("Project Name:");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjElementTypeLabel;
}
/**
 * Return the ErrorPanel property value.
 * @return com.sun.java.swing.JOptionPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JOptionPane getErrorPanel() {
	if (ivjErrorPanel == null) {
		try {
			ivjErrorPanel = new com.sun.java.swing.JOptionPane();
			ivjErrorPanel.setName("ErrorPanel");
			ivjErrorPanel.setBounds(30, 277, 262, 90);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjErrorPanel;
}
/**
 * Return the JLabel11 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabel11() {
	if (ivjJLabel11 == null) {
		try {
			ivjJLabel11 = new com.sun.java.swing.JLabel();
			ivjJLabel11.setName("JLabel11");
			ivjJLabel11.setText("Version Name:");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabel11;
}
/**
 * Return the mainPanel property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getMainPanel() {
	java.awt.GridBagConstraints constraintsApplyButton1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsCancelButton1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsJLabel11 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsVersionTextField1 = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsElementTypeLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsElementNameLabel = new java.awt.GridBagConstraints();
	java.awt.GridBagConstraints constraintsStatusLabel = new java.awt.GridBagConstraints();
	if (ivjMainPanel == null) {
		try {
			ivjMainPanel = new com.sun.java.swing.JPanel();
			ivjMainPanel.setName("MainPanel");
			ivjMainPanel.setLayout(new java.awt.GridBagLayout());
			ivjMainPanel.setBounds(213, 173, 188, 89);

			constraintsApplyButton1.gridx = 0; constraintsApplyButton1.gridy = 2;
			constraintsApplyButton1.gridwidth = 1; constraintsApplyButton1.gridheight = 1;
			constraintsApplyButton1.anchor = java.awt.GridBagConstraints.WEST;
			constraintsApplyButton1.weightx = 0.0;
			constraintsApplyButton1.weighty = 0.0;
			constraintsApplyButton1.insets = new java.awt.Insets(10, 10, 0, 40);
			getMainPanel().add(getApplyButton1(), constraintsApplyButton1);

			constraintsCancelButton1.gridx = 1; constraintsCancelButton1.gridy = 2;
			constraintsCancelButton1.gridwidth = 1; constraintsCancelButton1.gridheight = 1;
			constraintsCancelButton1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsCancelButton1.weightx = 0.0;
			constraintsCancelButton1.weighty = 0.0;
			constraintsCancelButton1.insets = new java.awt.Insets(10, 0, 0, 0);
			getMainPanel().add(getCancelButton1(), constraintsCancelButton1);

			constraintsJLabel11.gridx = 0; constraintsJLabel11.gridy = 1;
			constraintsJLabel11.gridwidth = 1; constraintsJLabel11.gridheight = 1;
			constraintsJLabel11.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsJLabel11.anchor = java.awt.GridBagConstraints.WEST;
			constraintsJLabel11.weightx = 0.0;
			constraintsJLabel11.weighty = 0.0;
			constraintsJLabel11.insets = new java.awt.Insets(0, 10, 0, 0);
			getMainPanel().add(getJLabel11(), constraintsJLabel11);

			constraintsVersionTextField1.gridx = 1; constraintsVersionTextField1.gridy = 1;
			constraintsVersionTextField1.gridwidth = 2; constraintsVersionTextField1.gridheight = 1;
			constraintsVersionTextField1.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsVersionTextField1.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsVersionTextField1.weightx = 1.0;
			constraintsVersionTextField1.weighty = 0.0;
			constraintsVersionTextField1.insets = new java.awt.Insets(0, 0, 0, 10);
			getMainPanel().add(getVersionTextField1(), constraintsVersionTextField1);

			constraintsElementTypeLabel.gridx = 0; constraintsElementTypeLabel.gridy = 0;
			constraintsElementTypeLabel.gridwidth = 1; constraintsElementTypeLabel.gridheight = 1;
			constraintsElementTypeLabel.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsElementTypeLabel.anchor = java.awt.GridBagConstraints.WEST;
			constraintsElementTypeLabel.weightx = 0.0;
			constraintsElementTypeLabel.weighty = 0.0;
			constraintsElementTypeLabel.insets = new java.awt.Insets(0, 10, 0, 0);
			getMainPanel().add(getElementTypeLabel(), constraintsElementTypeLabel);

			constraintsElementNameLabel.gridx = 1; constraintsElementNameLabel.gridy = 0;
			constraintsElementNameLabel.gridwidth = 1; constraintsElementNameLabel.gridheight = 1;
			constraintsElementNameLabel.anchor = java.awt.GridBagConstraints.CENTER;
			constraintsElementNameLabel.weightx = 0.0;
			constraintsElementNameLabel.weighty = 0.0;
			getMainPanel().add(getElementNameLabel(), constraintsElementNameLabel);

			constraintsStatusLabel.gridx = 0; constraintsStatusLabel.gridy = 3;
			constraintsStatusLabel.gridwidth = 2; constraintsStatusLabel.gridheight = 1;
			constraintsStatusLabel.fill = java.awt.GridBagConstraints.HORIZONTAL;
			constraintsStatusLabel.anchor = java.awt.GridBagConstraints.WEST;
			constraintsStatusLabel.weightx = 0.0;
			constraintsStatusLabel.weighty = 0.0;
			getMainPanel().add(getStatusLabel(), constraintsStatusLabel);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjMainPanel;
}
/**
 * Return the StatusLabel property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getStatusLabel() {
	if (ivjStatusLabel == null) {
		try {
			ivjStatusLabel = new com.sun.java.swing.JLabel();
			ivjStatusLabel.setName("StatusLabel");
			ivjStatusLabel.setText("Enter the version name.");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjStatusLabel;
}
/**
 * Return the SystemVariable property value.
 * @return java.lang.System
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private System getSystemVariable() {
	// user code begin {1}
	// user code end
	return ivjSystemVariable;
}
/**
 * Return the VersionTextField1 property value.
 * @return com.sun.java.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JTextField getVersionTextField1() {
	if (ivjVersionTextField1 == null) {
		try {
			ivjVersionTextField1 = new com.sun.java.swing.JTextField();
			ivjVersionTextField1.setName("VersionTextField1");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjVersionTextField1;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
public void init( String[] args)
{
	boolean error = false;

	if( args.length != 2){
		error = true;
	}
	else if( !error && args[0].charAt(0) != '-'){
		error = true;
	}		
	else if(  !error && (ws = ToolEnv.connectToWorkspace()) == null){
		error = true;
		errorString = "Error accessing VisualAge workspace";
	}
	
	if( !error && args[0].charAt(1) == 'P'){
		programElement = ws.loadedProjectNamed( args[1]);
	}
	else if(!error){
		error = true;
	}

	if(!error && programElement == null){
		error = true;
		errorString = "Invalid project";				
	}

	if( error){
		getErrorPanel().setMessage( errorString);
		setContentPane( getErrorPanel());
	}
	else{
		getElementNameLabel().setText(programElement.getName());		
		setContentPane( getMainPanel());		
	}
	show();
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	this.addWindowListener(this);
	getCancelButton1().addActionListener(this);
	getApplyButton1().addActionListener(this);
	getErrorPanel().addPropertyChangeListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	setName("BaseLine");
	setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
	setSize(383, 113);
	setTitle("BaseLine");
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	BaseLine aBaseLine = new BaseLine();
	aBaseLine.init(args);
}
/**
 * Comment
 */
public void makeVersion( String versionName) {
	if( !checkVersion( versionName)){
		getStatusLabel().setText("Version already exists.");
		return;
	}
	else{
		getStatusLabel().setText("");		
	}
	try{
		Project project = (Project)programElement;			
		if( programElement.isVersion()){
			project.createNewEdition();
		}
		Package[] packages = project.getPackages();
		for (int p = 0; p < packages.length; p++)
		{
			Package pkg = packages[p];
			if( pkg.isVersion()){
				pkg.createNewEdition();
			}
			Type[] types = pkg.getTypes();
			for (int t = 0; t < types.length; t++)
			{
				Type type = types[t];
				if( type.isVersion()){
					type.createNewEdition();
				}
				type.createVersion(versionName, true);
			}
			pkg.createVersion(versionName);
 			}
		project.createVersion(versionName);
	}
	catch( IvjException e){
		getStatusLabel().setText( "Error creating new version.");
	}
}
/**
 * Method to handle events for the PropertyChangeListener interface.
 * @param evt java.beans.PropertyChangeEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void propertyChange(java.beans.PropertyChangeEvent evt) {
	// user code begin {1}
	// user code end
	if ((evt.getSource() == getErrorPanel()) ) {
		connEtoC1(evt);
	}
	// user code begin {2}
	// user code end
}
/**
 * Set the SystemVariable to a new value.
 * @param newValue java.lang.System
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void setSystemVariable(System newValue) {
	if (ivjSystemVariable != newValue) {
		try {
			ivjSystemVariable = newValue;
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowActivated(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowClosed(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == this) ) {
		connEtoM2(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowClosing(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowDeactivated(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowDeiconified(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowIconified(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
/**
 * Method to handle events for the WindowListener interface.
 * @param e java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void windowOpened(java.awt.event.WindowEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}
}