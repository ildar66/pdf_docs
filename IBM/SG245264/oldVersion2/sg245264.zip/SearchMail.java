package itso.notes;

import lotus.notes.*;
/**
 * This type was created in VisualAge.
 */
public class SearchMail extends DebugAgentBase {
/**
 * SearchMail constructor comment.
 */
public SearchMail() {
	super();
}
public void NotesMain()
{
	try{
		Session session = getSession();
		AgentContext ac = session.getAgentContext();
		Database db = ac.getCurrentDatabase();
		Document doc = ac.getDocumentContext();
		if( doc != null){
			String subject = doc.getItemValueString("Subject");
			if( subject != null){
				DocumentCollection dc = db.FTSearch("FIELD Subject contains " + subject);
				if( dc.getCount() > 0){
					Newsletter nl = session.createNewsletter(dc);
					nl.setSubjectItemName("Subject");
					Document nlDoc = nl.formatMsgWithDoclinks( null);
					nlDoc.appendItemValue( "Form", "Memo");
					nlDoc.appendItemValue( "Subject", "Documents with subject: "
							+ subject);
					nlDoc.send(false, session.getUserName());
				}
			}		
		}
		else{
			System.err.println("Error: No document context");
		}
	}
	catch( NotesException e)
	{
		System.err.println("Error, Notes Exception: " + e);
	}
}
}