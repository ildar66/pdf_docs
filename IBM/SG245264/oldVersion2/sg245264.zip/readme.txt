Programming with VisualAge for Java Version 2       updated: November 23, 1999
=============================================
Welcome to Java programming with VisualAge for Java!

This directory contains SG245264.zip which contains all the examples in the book:
	BaseLine.java
	BookmarkListController.java
	BookmarkListServlet.java
	SearchMail.java
	VAJV2Book.dat
	buildbank.txt
	KeypadDeclaration.txt
	ExerciseModel.txt
	frflag.gif
	itflag.gif
	usflag.gif
	databeans
		BUILDBookmarks.BAT
		COMP.DEL
		makebookmarks.sql


To load the completed examples into VisualAge, unzip the file SG245264.zip, import the
repository file: VAJV2Book.dat and then add the project "Programming VAJ V2" to your workspace.

If any changes are made to the book they will be found here.

The products required for the examples are not on this ftp server.

Have fun!

Comments:  Send to redbook@us.ibm.com