package itso.bookmark.databeans;

import com.sun.java.swing.*;
import java.util.*;
import itso.bookmark.Bookmark;
/** 
 * This type was created in VisualAge.
 */
public class BookmarkListController extends Object {
	private DefaultListModel fieldBookmarkList = new DefaultListModel();
/**
 * Perform the addEntry method.
 * @param title java.lang.String
 * @param url java.lang.String
 */
public void addEntry(String title, String url) {
	getBookmarkList().addElement( new Bookmark(title, url));
	return;
}
/**
 * Perform the addEntry method.
 * @param title java.lang.String
 * @param url java.lang.String
 */
public void deleteEntry(String title) {
	Enumeration e = getBookmarkList().elements();
	Bookmark b = null;
	while( e.hasMoreElements()){
		b = (Bookmark)e.nextElement();
		if( b.getTitle().equals( title)){
			getBookmarkList().removeElement(b);
			return;
		}
	}	
	return;
}
/**
 * Gets the bookmarkList property (com.sun.java.swing.DefaultListModel) value.
 * @return The bookmarkList property value.
 */
public DefaultListModel getBookmarkList() {
	return fieldBookmarkList;
}
/*
	Fill the list
*/	
public void init( JApplet applet){
	StringTokenizer st = new StringTokenizer( applet.getParameter("Data"), ";");
	while (st.hasMoreTokens()) {
			Bookmark b = new Bookmark( st.nextToken(), st.nextToken());
			getBookmarkList().addElement( b);
	}
	
	return;
}
}