/*
 * File Name: CodeReviewSample.java
 */

package itso.bank.test;


public class CodeReviewSample {

	/**
	 * This method is used to demonstrate the capabilities of the
	 * Rule based Code Review Tool, this method contains code
	 * violating one of the J2SE Best Practices - Null Pointer
	 * Category Rules that is set up by default in IBM
	 * Rational Applicatin Developer. Based on the input provided
	 * by the tool the method above is fixed.
	 * @param dummy
	 * @return
	 */
	public Object[] verifyCodeReview(boolean dummy){
		Object[] dummyValues = { new Object(), new Object() };
		if ( dummy ){
			return dummyValues;
		} else {
			// This line violates the J2SE Best practice
			return null;
		}
	}

	/**
	 * This method is used to demonstrate the capabilities of the
	 * Rule based Code Review Tool, the verifyCodeReview method
	 * violates one of the J2SE Best Practices - Null Pointer
	 * Category Rules that is set up by default in IBM
	 * Rational Applicatin Developer. Based on the input provided
	 * by the tool the method above is fixed.
	 * @param dummy
	 * @return
	 */
	public Object[] verifyCodeReviewFixed(boolean dummy){
		Object[] dummyValues = { new Object(), new Object() };
		if ( dummy ){
			return dummyValues;
		} else {
			return new Object[0];
		}
	}

	public String verifyCompilationErrors(boolean dummy){
		//comment the following line to view compilation error
		return null;
	}

}
