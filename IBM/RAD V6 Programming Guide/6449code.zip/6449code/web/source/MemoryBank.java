package itso.bank.facade;

import itso.bank.exception.ApplicationException;
import itso.bank.exception.InsufficientFundsException;
import itso.bank.exception.UnknownAccountException;
import itso.bank.exception.UnknownCustomerException;
import itso.bank.model.Account;
import itso.bank.model.Credit;
import itso.bank.model.Customer;
import itso.bank.model.Debit;
import itso.bank.model.Transaction;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;

/**
 * An in-memory based Bank facade.
 * 
 * @see itso.bank.facade.Bank
 */
public class MemoryBank extends Bank {
	
	private java.util.Map customers;
	private java.util.Map accounts;
	private java.util.Map customerAccounts;
	private java.util.Map transactions;
	
	/**
	 * Create the in-memory bank, initialized with the default data.
	 */
	protected MemoryBank() {
		// create the maps
		customers = new HashMap();
		accounts = new HashMap();
		customerAccounts = new HashMap();
		transactions = new HashMap();
		
		// seed with data
		addCustomer("111-11-1111", "MR", "John", "Ganci");
		addCustomer("222-22-2222", "MR", "Richard", "Raszka");
		addCustomer("333-33-3333", "MR", "Fabio", "Ferraz");
		addCustomer("444-44-4444", "MR", "Neil", "Weightman");
		addCustomer("555-55-5555", "MR", "Kiriya", "Keat");
		addCustomer("666-66-6666", "MR", "Hari", "Kanangi");
		addCustomer("777-77-7777", "MR", "Juha", "Nevalainen");
		addCustomer("999-99-9999", "Sir", "Nicolai", "Nielsen");

		addAccount("111-11-1111", "001-999000777", 123456789);
		addAccount("111-11-1111", "001-999000888", 654321);
		addAccount("111-11-1111", "001-999000999", 9876);
		addAccount("222-22-2222", "002-999000777", 6548423);
		addAccount("222-22-2222", "002-999000888", 8796);
		addAccount("222-22-2222", "002-999000999", 65465);
		addAccount("333-33-3333", "003-999000777", 987652);
		addAccount("333-33-3333", "003-999000888", 56879);
		addAccount("333-33-3333", "003-999000999", 2156);
		addAccount("444-44-4444", "004-999000777", 98765);
		addAccount("444-44-4444", "004-999000888", 145645646);
		addAccount("444-44-4444", "004-999000999", 2315646);
		addAccount("555-55-5555", "005-999000777", 6589);
		addAccount("555-55-5555", "005-999000888", 7221341);
		addAccount("555-55-5555", "005-999000999", 89755);
		addAccount("666-66-6666", "006-999000777", 50000);
		addAccount("666-66-6666", "006-999000888", 10000);
		addAccount("666-66-6666", "006-999000999", 1000000);
		addAccount("777-77-7777", "007-999000777", 250000000);
		addAccount("777-77-7777", "007-999000888", 100000000);
		addAccount("777-77-7777", "007-999000999", 123);
		addAccount("999-99-9999", "009-999000999", 65860042);
	}

	/**
	 * @see Bank#getCustomer(String)
	 */
	public Customer getCustomer(String customerNumber)
			throws UnknownCustomerException {
		
		Customer customer = (Customer)customers.get(customerNumber);
		
		if (customer == null) {
			// not found
			throw new UnknownCustomerException(customerNumber);
		}
		
		return customer;
	}

	/**
	 * @see itso.bank.facade.Bank#updateCustomer(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public void updateCustomer(String ssn, String title, String firstName, String lastName) throws UnknownCustomerException, ApplicationException {
		
		Customer customer = getCustomer(ssn);
		
		customer.setTitle(title);
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
	}
	
	/**
	 * @see Bank#getAccounts(String)
	 */
	public Account[] getAccounts(String customerNumber) 
			throws UnknownCustomerException {
		
		if (!customers.containsKey(customerNumber)) {
			// no such customer
			throw new UnknownCustomerException(customerNumber);
		}
		
		Collection accounts = (Collection)customerAccounts.get(customerNumber);
		
		if (accounts == null) {
			// no accounts - return empty array
			return new Account[0];
		}
		else {
			// copy to array of Account objects and cast
			return (Account[])accounts.toArray(new Account[0]);
		}
	}
	
	/**
	 * @see Bank#getAccount(String)
	 */
	public Account getAccount(String accountNumber) 
			throws UnknownAccountException {

		Account account = (Account)accounts.get(accountNumber);
		
		if (account == null) {
			// not found
			throw new UnknownAccountException(accountNumber);
		}
		
		return account;
	}
	
	/**
	 * @see Bank#getTransactions(String)
	 */
	public Transaction[] getTransactions(String accountId)
			throws UnknownAccountException {
		
		if (accounts.containsKey(accountId)) {
		
			Collection accountTransactions = (Collection)transactions.get(accountId);
			
			if (accountTransactions == null) {
				// no transactions - return empty array
				return new Transaction[0];
			}
			else {
				// copy to array of Transaction objects and cast
				return (Transaction[])accountTransactions.toArray(new Transaction[0]);
			}
		}
		else {
			throw new UnknownAccountException(accountId);
		}
	}
	
	/**
	 * @see Bank#deposit(String, int)
	 */
	public void deposit(String accountId, int amount) 
			throws UnknownAccountException, ApplicationException {
		
		Account account = getAccount(accountId);
		
		Transaction transaction = addCreditTransaction(accountId, amount);
		
		account.setBalance(account.getBalance()+transaction.getSignedAmount());
	}
	
	/**
	 * @see Bank#withdraw(String, int)
	 */
	public void withdraw(String accountId, int amount) 
			throws UnknownAccountException, InsufficientFundsException, ApplicationException {
		Account account = getAccount(accountId);

		if (account.getBalance() > amount) {
			
			Transaction transaction = addDebitTransaction(accountId, amount);
			
			account.setBalance(account.getBalance()+transaction.getSignedAmount());
		}
		else {
			// would result in overdraft
			throw new InsufficientFundsException(accountId, amount);
		}
	}
	
	/**
	 * @see Bank#transfer(String, String, int)
	 */
	public void transfer(String debitAccountNumber, String creditAccountNumber, int amount) 
			throws UnknownAccountException, InsufficientFundsException, ApplicationException {
		Account debitAccount = getAccount(debitAccountNumber);
		Account creditAccount = getAccount(creditAccountNumber);
		
		if (debitAccount.getBalance() > amount) {
			
			Transaction credit = addCreditTransaction(creditAccountNumber, amount);
			Transaction debit = addDebitTransaction(debitAccountNumber, amount);
			
			debitAccount.setBalance(debitAccount.getBalance()+credit.getSignedAmount());
			creditAccount.setBalance(creditAccount.getBalance()+debit.getSignedAmount());
		}
		else {
			// would result in overdraft
			throw new InsufficientFundsException(debitAccountNumber, amount);
		}
	}
	
	/**
	 * Add a Debit transaction for the specified account's transaction log.
	 *  
	 * @param accountId The account to add a record for.
	 * @param amount The amount debited from the account.
	 * @return The added transaction.
	 * @throws UnknownAccountException If the specified account could not be found.
	 */
	private Transaction addDebitTransaction(String accountId, int amount) throws UnknownAccountException {
		Transaction transaction = new Debit();
		transaction.setAccountNumber(accountId);
		transaction.setAmount(amount);
		transaction.setTimestamp(new Date());
		
		addTransactionToLog(transaction);
		
		return transaction;
	}

	/**
	 * Adds a Credit transaction for the specified account's transaction log.
	 *  
	 * @param accountId The account to add a record for.
	 * @param amount The amount credited to the account.
	 * @return The added transaction.
	 * @throws UnknownAccountException If the specified account could not be found.
	 */
	private Transaction addCreditTransaction(String accountId, int amount) throws UnknownAccountException {
		Transaction transaction = new Credit();
		transaction.setAccountNumber(accountId);
		transaction.setAmount(amount);
		transaction.setTimestamp(new Date());
		
		addTransactionToLog(transaction);
		
		return transaction;
	}
	
	/**
	 * Add the specified transaction to the account's transaction log.
	 *  
	 * @param transaction The transaction to add (the account number is 
	 *        stored in the Transaction obejct).
	 * @throws UnknownAccountException If the specified account could not be found.
	 */
	private void addTransactionToLog(Transaction transaction) throws UnknownAccountException {
		if (accounts.containsKey(transaction.getAccountNumber())) {
				
			Collection accountTransactions = (Collection)transactions.get(transaction.getAccountNumber());
				
			if (accountTransactions == null) {
				// no transactions create new list
				accountTransactions = new LinkedList();
				transactions.put(transaction.getAccountNumber(), accountTransactions);
			}
			accountTransactions.add(transaction);
		}
		else {
			throw new UnknownAccountException(transaction.getAccountNumber());
		}
	}

	/**
	 * Add a customer record with the given information to the customer database.
	 * This method is used by the constructor to seed the in-memory database.
	 * 
	 * @param ssn The customer number (SSN) of the new customer.
	 * @param title The salutation for the new customer
	 * @param firstName The new customer's first name.
	 * @param lastName The new customer's last name.
	 * 
	 * @see Customer
	 * @see #Bank(Bank)
	 */
	private void addCustomer(String ssn, String title, String firstName, String lastName) {
		Customer customer = new Customer();
		customer.setSsn(ssn);
		customer.setTitle(title);
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		
		customers.put(ssn, customer);
	}
	
	/**
	 * Add a new account with the given information to the account database.
	 * This method is used by the constructor to seed the in-memory database.
	 * 
	 * @param ssn The customer number (SSN) of the customer owning the account.
	 * @param accountNumber The number of the new account.
	 * @param balance The initial balance, in cents.
	 * 
	 * @see Account
	 * @see #Bank(Bank)
	 */
	private void addAccount(String ssn, String accountNumber, int balance) {
		Account account = new Account();
		account.setAccountNumber(accountNumber);
		account.setBalance(balance);
		
		Collection customerAccountsColl = (Collection)customerAccounts.get(ssn);
		
		if (customerAccountsColl == null) {
			customerAccountsColl = new LinkedList();
			customerAccounts.put(ssn, customerAccountsColl);
		}
		
		customerAccountsColl.add(account);
		accounts.put(accountNumber, account);
	}
}
