package itso.bank.facade;

import itso.bank.exception.ApplicationException;
import itso.bank.exception.InsufficientFundsException;
import itso.bank.exception.UnknownAccountException;
import itso.bank.exception.UnknownCustomerException;
import itso.bank.model.Account;
import itso.bank.model.Customer;
import itso.bank.model.Transaction;


/**
 * The facade for the ITSO bank. 
 * 
 * The class is a singleton, controlled through the static method <code>getBank</code>.
 * 
 * The class is used as follows (this example retrieves an Account object
 * for a given account number):
 * 
 * <pre>
 * 		Bank bank = Bank.getBank();
 * 		Account account = bank.getAccount(accountNumber);
 * </pre>
 * 
 * @see Bank#getBank()
 */
public abstract class Bank
{
	/**
	 *  The Bank singleton
	 */
	private static Bank singleton = null;
	
	/**
	 * Create a singleton. The method will ensure that only
	 * one Bank object is created.
	 * 
	 * @throws ApplicationException If an application-level non-business related
	 *         exception occurred.
	 * 
	 * @see Bank#Bank()
	 */
	public static Bank getBank() throws ApplicationException {
		if (singleton == null) {
			// no singleton has been created yet - create one
			singleton = new MemoryBank();
		}
		
		return singleton;
	}
	
	/**
	 * Retrieve a Customer object for a given customer number (SSN).
	 * 
	 * @param customerNumber The customer number (SSN) to look up.
	 * @return A Customer instance, representing that customer.
	 * @throws UnknownCustomerException If the specified customer
	 *         does not exist.
	 * @throws ApplicationException If an application-level non-business related
	 *         exception occurred.
	 * 
	 * @see Customer
	 */
	public abstract Customer getCustomer(String customerNumber)
			throws UnknownCustomerException, ApplicationException;
	
	/**
	 * Retrieve an array of the accounts for a given customer 
	 * number (SSN).
	 * 
	 * @param customerNumber The customer number (SSN) to look up.
	 * @return An array of Account instances, each representing an
	 *         account that the customer owns within the bank.
	 * @throws UnknownCustomerException If the specified customer
	 *         does not exist.
	 * @throws ApplicationException If an application-level non-business related
	 *         exception occurred.
	 * 
	 * @see Account
	 */
	public abstract Account[] getAccounts(String customerNumber) 
			throws UnknownCustomerException, ApplicationException;
	
	/**
	 * Retrieve an Account object for a given account number.
	 * 
	 * @param accountNumber The account number to look up.
	 * @return An Account instance, representing the given 
	 *         account number.
	 * @throws UnknownAccountException If the account does not
	 *         exist.
	 * @throws ApplicationException If an application-level non-business related
	 *         exception occurred.
	 * 
	 * @see Account
	 */
	public abstract Account getAccount(String accountNumber) 
			throws UnknownAccountException, ApplicationException;
	
	/**
	 * Retrieve an array of transaction records for the given account.
	 * 
	 * @param accountId The account number to retrieve the transaction
	 *        log for.
	 * @return An array of instances of the Transaction class, each
	 *         representing a movement on the account. If the account has
	 *         had no transaction, an empty array (an array of length zero)
	 *         is returned.
	 * @throws UnknownAccountException If the specified account does not exist.
	 * @throws ApplicationException If an application-level non-business related
	 *         exception occurred.
	 * 
	 * @see Transaction
	 */
	public abstract Transaction[] getTransactions(String accountId)
			throws UnknownAccountException, ApplicationException;
	
	
	/**
	 * Update the customer data for the specified customer. The specified SSN 
	 * must match an existing customer.
	 * 
	 * @param ssn 
	 * @param title
	 * @param firstName
	 * @param lastName
	 * @throws UnknownCustomerException If either of the accounts do not exist.
	 * @throws ApplicationException If an application-level non-business related
	 *         exception occurred.
	 */
	public abstract void updateCustomer(String ssn, String title, 
			String firstName, String lastName) 
			throws UnknownCustomerException, ApplicationException;
	
	/**
	 * Deposit (credit) the specified amount of cents to 
	 * the specified account.
	 * 
	 * After a successful transaction, the transaction log for
	 * the account will be updated.
	 * 
	 * @param accountId The account number to deposit into.
	 * @param amount The amount to deposit, in cents.
	 * @throws UnknownAccountException If the account does not exist.
	 * @throws ApplicationException If an application-level non-business related
	 *         exception occurred.
	 */
	public abstract void deposit(String accountId, int amount) 
			throws UnknownAccountException, ApplicationException;
	
	/**
	 * Withdraw (debit) the specified amount of cents from 
	 * the specified account.
	 * 
	 * After a successful transaction, the transaction log for
	 * the account will be updated.
	 * 
	 * @param accountId The account number to withdraw from.
	 * @param amount The amount to withdraw, in cents.
	 * @throws UnknownAccountException If the account does not exist.
	 * @throws InsufficientFundsException If the amount exceeds the
	 *         current balance of the account.
	 * @throws ApplicationException If an application-level non-business related
	 *         exception occurred.
	 */
	public abstract void withdraw(String accountId, int amount) 
			throws UnknownAccountException, InsufficientFundsException, ApplicationException;
	
	/**
	 * Transfer the specified amount of cents from one account to
	 * another. The accounts do not need to be owned by the same customer.
	 * 
	 * After a successful transaction, the transaction log for
	 * both accounts will be updated.
	 * 
	 * @param debitAccountNumber The account number to withdraw (debit) from.
	 * @param creditAccountNumber The account number to deposit (credit) to.
	 * @param amount The amount to transfer, in cents.
	 * @throws UnknownAccountException If either of the accounts do not exist.
	 * @throws InsufficientFundsException If the amount exceeds the
	 *         current balance of the debit account.
	 * @throws ApplicationException If an application-level non-business related
	 *         exception occurred.
	 */
	public abstract void transfer(String debitAccountNumber, String creditAccountNumber, 
			int amount) 
			throws UnknownAccountException, InsufficientFundsException, ApplicationException;
}
