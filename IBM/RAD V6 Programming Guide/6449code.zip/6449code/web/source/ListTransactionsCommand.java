package com.ibm.bankbasic.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.bankbasic.facade.Bank;
import com.ibm.bankbasic.model.Account;
import com.ibm.bankbasic.model.TransRecord;

/**
 * List transactions command. Will retrieve the account history and forward
 * to a JSP that can show this information to the user.
 * 
 * Parameters:
 * <dl>
 * <dt>accountId</dt><dd>The account to show the transaction history for</dd>
 * </dl>
 */
public class ListTransactionsCommand
		implements Command
{
	/**
	 * Retrieve the transactions for the account.
	 * 
	 * @see com.ibm.bankbasic.command.Command#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public void execute(HttpServletRequest req, HttpServletResponse resp)
			throws Exception
	{
		// Parameters
		String accountId = req.getParameter("accountId");
		
		// Control logic
		Bank bank = Bank.getBank();
		
		// Response
		Account account = bank.getAccount(accountId);
		TransRecord[] transactions = bank.getTransactions(accountId);

		req.setAttribute("account", account);
		req.setAttribute("transactions", transactions);
	}
	
	/**
	 * @see com.ibm.bankbasic.command.Command#getForwardView()
	 */
	public String getForwardView() {
		return "listTransactions.jsp";
	}
}