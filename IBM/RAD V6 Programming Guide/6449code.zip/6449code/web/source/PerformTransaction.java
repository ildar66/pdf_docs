package com.ibm.bankbasic.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.bankbasic.command.*;

/**
 * Servlet to perform a transaction on an account. Will call one of the commands
 * implementing the Command interface.
 *
 * Parameters. In addition to the parameter required by the called command, the
 *             following parameter must be specified:
 * <dl>
 * <dt>transaction</dt>
 * <dd>The transaction to perform. Must be one of: <tt>deposit</tt>, <tt>withdraw/tt>,
 *     <tt>transfer</tt>, <tt>list</tt>.</dd>
 * </dl>
 * 
 * Output (request parameters): None apart from the ones set by the called command. 
 * 
 * Forwards to: 
 * <dl>
 * <dt><see called command></dt>
 * <dd>If no error occurs.</dd>
 * 
 * <dt>showException.jsp</dt>
 * <dd>If an error occurs.</dd>
 * </dl>
 * 
 * @see com.ibm.bankbasic.command.Command
 * @see com.ibm.bankbasic.command.DepositCommand
 * @see com.ibm.bankbasic.command.WithdrawCommand
 * @see com.ibm.bankbasic.command.TransferCommand
 * @see com.ibm.bankbasic.command.ListTransactionsCommand
 */
public class PerformTransaction
		extends HttpServlet
		implements Servlet
{
	private Map commands;
	
	public PerformTransaction()
	{
		commands = new HashMap();
		
		commands.put("deposit", new DepositCommand());
		commands.put("withdraw", new WithdrawCommand());
		commands.put("transfer", new TransferCommand());
		commands.put("list", new ListTransactionsCommand());
	}
	
	/**
	 * HTTP GET service method. Calls performTask to service requests.
	 * 
	 * @see performTask(HttpServletRequest req, HttpServletResponse resp)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest req,
	 *      HttpServletResponse resp)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		performTask(req, resp);
	}

	/**
	 * HTTP POST service method. Calls performTask to service requests.
	 * 
	 * @see performTask(HttpServletRequest req, HttpServletResponse resp)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest req,
	 *      HttpServletResponse resp)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		performTask(req, resp);
	}

	/**
	 * This method does the actual servlet processing.
	 * 
	 * @see #doGet(HttpServletRequest, HttpServletResponse)
	 * @see #doPost(HttpServletRequest, HttpServletResponse)
	 */
	private void performTask(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		String transaction = null;
		
		try
		{
			// Get input parameter and keep it on the HTTP session
			transaction = req.getParameter("transaction");
			
			Command command = (Command)commands.get(transaction);
			if (command != null)
			{
				command.execute(req, resp);
				
				String forwardView = command.getForwardView();
				
				if (forwardView != null)
				{
					// Call the presentation renderer
					ServletContext ctx = getServletContext();
					RequestDispatcher disp = ctx.getRequestDispatcher(forwardView);
					disp.forward(req, resp);
				}
			}
			else
			{
				// set up error information and forward to the error page
				req.setAttribute("message", "Unknown transaction: "+transaction);
				req.setAttribute("forward", "index.html");
				ServletContext ctx = getServletContext();
				RequestDispatcher disp = ctx.getRequestDispatcher("showException.jsp");
				disp.forward(req, resp);
			}
		}
		catch (Exception e)
		{
			// set up error information and forward to the error page
			req.setAttribute("message", e.getMessage());
			req.setAttribute("forward", "index.html");
			ServletContext ctx = getServletContext();
			RequestDispatcher disp = ctx.getRequestDispatcher("showException.jsp");
			disp.forward(req, resp);
		}
	}
}