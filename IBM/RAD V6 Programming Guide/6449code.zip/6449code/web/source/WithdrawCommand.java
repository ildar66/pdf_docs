package com.ibm.bankbasic.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.bankbasic.facade.Bank;
import com.ibm.bankbasic.model.Account;

/**
 * Withdrawal command. Will perform a withdrawal of the specified amount
 * from the specified account.
 * 
 * Parameters:
 * <dl>
 * <dt>amount</dt><dd>The amount cents to withdraw</dd>
 * <dt>accountId</dt><dd>The account number to withdraw from</dd>
 * </dl>
 */
public class WithdrawCommand
		implements Command
{

	/**
	 * Do the actual withdrawal.
	 * 
	 * @see com.ibm.bankbasic.command.Command#execute(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public void execute(HttpServletRequest req, HttpServletResponse resp)
			throws Exception
	{
		// Parameters
		String accountId = req.getParameter("accountId");
		String strAmount = req.getParameter("amount");
		int iAmount = Integer.parseInt(strAmount);

		// Control logic
		Bank bank = Bank.getBank();
		bank.withdraw(accountId, iAmount);
		
		// Response
		Account account = bank.getAccount(accountId);
		req.setAttribute("account", account);
	}

	/**
	 * @see com.ibm.bankbasic.command.Command#getForwardView()
	 */
	public String getForwardView() {
		return "accountDetails.jsp";
	}
}