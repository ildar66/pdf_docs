package itso.bank.client.control;

import itso.bank.client.ui.AccountTableModel;
import itso.bank.client.ui.BankDesktop;
import itso.bank.model.Account;
import itso.bank.model.Customer;
import itso.bank.exception.UnknownCustomerException;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.ibm.etools.service.locator.ServiceLocatorManager;
import java.rmi.RemoteException;
import itso.bank.facade.ejb.BankHome;
import itso.bank.facade.ejb.Bank;
/**
 * Controller class for the Bank Desktop application
 */
public class BankDesktopController implements ActionListener {

	/** The user interface */
	private BankDesktop desktop = null;

	/** The table model for showing account overview */
	private AccountTableModel accountTableModel = null;

	private final static String STATIC_BankHome_REF_NAME = "ejb/Bank";
	private final static Class STATIC_BankHome_CLASS = BankHome.class;
	/**
	 * Constructor for the BankDesktopController class.
	 * Creates and shows the user interface, as implemented by the
	 * BankDesktop class.
	 * 
	 * @see itso.bank.client.ui.BankDesktop
	 */
	public BankDesktopController() {

		desktop = new BankDesktop();

		desktop.getBtnSearch().addActionListener(this);

		desktop.setVisible(true);
	}

	/**
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		// we know that we are only listening to action events from
		// the search button, so...

		String ssn = desktop.getTfSSN().getText();

		Bank aBank = createBank();
		
		try {
			// look up the customer
			Customer customer = aBank.getCustomer(ssn);
			// look up the accounts
			Account[] accounts = aBank.getAccounts(ssn);
			
			// update the user interface
			desktop.getTfTitle().setText(customer.getTitle());
			desktop.getTfFirstName().setText(customer.getFirstName());
			desktop.getTfLastName().setText(customer.getLastName());
			setAccounts(accounts);
		}
		catch (UnknownCustomerException x) {
			// unknown customer. Report this using the output fields...
			desktop.getTfTitle().setText("(not found)");
			desktop.getTfFirstName().setText("(not found)");
			desktop.getTfLastName().setText("(not found)");
			setAccounts(new Account[0]);
		}
		catch (RemoteException x) {
			// unexpected RMI exception. Print it to the console and report it...
			x.printStackTrace();
			desktop.getTfTitle().setText("(internal error)");
			desktop.getTfFirstName().setText("(internal error)");
			desktop.getTfLastName().setText("(internal error)");
			setAccounts(new Account[0]);
		}
	}

	/**
	 * Updates the account overview by refresing the specialized account
	 * table model.
	 * 
	 * @param accounts an array of accounts to populate the table with.
	 * 
	 * @see itso.bank.client.ui.AccountTableModel
	 */
	private void setAccounts(Account[] accounts) {
		if (accountTableModel == null) {
			// instantiate the model and associate it with the JTable, if it
			// hasn't been created yet.
			accountTableModel = new AccountTableModel();
			desktop.getTblAccounts().setModel(accountTableModel);
		}
		
		// update the JTable
		accountTableModel.setAccounts(accounts);
	}

	/**
	 * Main method for running the ITSO Bank J2EE application client.
	 * 
	 * @param args command-line parameters. No parameters necessary.
	 */
	public static void main(String[] args) {

		// make a new controller and magic will happen...!
		BankDesktopController controller = new BankDesktopController();
	}

	protected Bank createBank() {
		BankHome aBankHome = (BankHome) ServiceLocatorManager.getRemoteHome(
				STATIC_BankHome_REF_NAME, STATIC_BankHome_CLASS);
		try {
			if (aBankHome != null)
				return aBankHome.create();
		} catch (javax.ejb.CreateException ce) {
			// TODO Auto-generated catch block
			ce.printStackTrace();
		} catch (RemoteException re) {
			// TODO Auto-generated catch block
			re.printStackTrace();
		}
		return null;
	}
}
