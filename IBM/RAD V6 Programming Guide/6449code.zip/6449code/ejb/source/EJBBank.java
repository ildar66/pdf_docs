package itso.bank.facade;

import com.ibm.etools.service.locator.ServiceLocatorManager;
import itso.bank.exception.ApplicationException;
import itso.bank.exception.InsufficientFundsException;
import itso.bank.exception.UnknownAccountException;
import itso.bank.exception.UnknownCustomerException;
import itso.bank.facade.ejb.BankHome;
import itso.bank.model.Account;
import itso.bank.model.Customer;
import itso.bank.model.Transaction;

import java.rmi.RemoteException;

/**
 * An EJB-based Bank facade.
 * 
 * @see itso.bank.facade.Bank
 */
public class EJBBank extends Bank {
	
	private itso.bank.facade.ejb.Bank bankEJB = null;
	
	private final static String STATIC_BankHome_REF_NAME = "ejb/Bank";
	private final static Class STATIC_BankHome_CLASS = BankHome.class;
	
	/**
	 * @see itso.bank.facade.Bank#getAccount(String)
	 */
	public Account getAccount(String accountNumber)
			throws UnknownAccountException, ApplicationException {
		try {
			return getBankEJB().getAccount(accountNumber);
		} catch (RemoteException e) {
			throw new ApplicationException("Unable to retrieve account: "+accountNumber, e);
		}
	}
	
	/**
	 * @see itso.bank.facade.Bank#getAccounts(String)
	 */
	public Account[] getAccounts(String customerNumber)
			throws UnknownCustomerException, ApplicationException {
		try {
			return getBankEJB().getAccounts(customerNumber);
		} catch (RemoteException e) {
			throw new ApplicationException("Unable to retrieve accounts for: "+customerNumber, e);
		}
	}
	
	/**
	 * @see itso.bank.facade.Bank#getCustomer(String)
	 */
	public Customer getCustomer(String customerNumber)
			throws UnknownCustomerException, ApplicationException {
		try {
			return getBankEJB().getCustomer(customerNumber);
		} catch (RemoteException e) {
			throw new ApplicationException("Unable to retrieve accounts for: "+customerNumber, e);
		}
	}
	
	/**
	 * @see itso.bank.facade.Bank#getTransactions(String)
	 */
	public Transaction[] getTransactions(String accountId)
			throws UnknownAccountException, ApplicationException {
		try {
			return getBankEJB().getTransactions(accountId);
		} catch (RemoteException e) {
			throw new ApplicationException("Unable to retrieve transactions for: "+accountId, e);
		}
	}
	
	/**
	 * @see itso.bank.facade.Bank#deposit(java.lang.String, int)
	 */
	public void deposit(String accountId, int amount) throws UnknownAccountException, ApplicationException {
		try {
			getBankEJB().deposit(accountId, amount);
		} catch (RemoteException e) {
			throw new ApplicationException("Unable to deposit "+amount+" to "+accountId, e);
		}
	}

	/**
	 * @see itso.bank.facade.Bank#withdraw(java.lang.String, int)
	 */
	public void withdraw(String accountId, int amount) throws UnknownAccountException, InsufficientFundsException, ApplicationException {
		try {
			getBankEJB().withdraw(accountId, amount);
		} catch (RemoteException e) {
			throw new ApplicationException("Unable to withdraw "+amount+" from "+accountId, e);
		}
	}

	/**
	 * @see itso.bank.facade.Bank#transfer(java.lang.String, java.lang.String, int)
	 */
	public void transfer(String debitAccountNumber, String creditAccountNumber, int amount) throws UnknownAccountException, InsufficientFundsException, ApplicationException {
		try {
			getBankEJB().transfer(debitAccountNumber, creditAccountNumber, amount);
		} catch (RemoteException e) {
			throw new ApplicationException("Unable to transfer "+amount+" from "+debitAccountNumber+" to "+creditAccountNumber, e);
		}
	}

	/**
	 * @see itso.bank.facade.Bank#updateCustomer(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public void updateCustomer(String ssn, String title, String firstName, String lastName) throws UnknownCustomerException, ApplicationException {
		
		try {
			getBankEJB().updateCustomer(ssn, title, firstName, lastName);
		} catch (RemoteException e) {
			throw new ApplicationException("Unable to udpate customer "+ssn, e);
		}
	}

	/**
	 * @return A reference to the remote interface for the Bank EJB.
	 * @throws ApplicationException If the EJb could not be instantiated.
	 */
	private itso.bank.facade.ejb.Bank getBankEJB() throws ApplicationException {
		if (bankEJB == null) {
			BankHome aBankHome = (BankHome) ServiceLocatorManager.getRemoteHome(
					STATIC_BankHome_REF_NAME, STATIC_BankHome_CLASS);
			try {
				if (aBankHome != null)
					bankEJB = aBankHome.create();
			} catch (javax.ejb.CreateException ce) {
				throw new ApplicationException("Unable to create EJB: "+STATIC_BankHome_REF_NAME, ce);
			} catch (RemoteException re) {
				throw new ApplicationException("Unable to create EJB: "+STATIC_BankHome_REF_NAME, re);
			}
		}
		return bankEJB;
	}
}
