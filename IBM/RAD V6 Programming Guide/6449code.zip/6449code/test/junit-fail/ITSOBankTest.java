package itso.bank.test.junit;

import itso.bank.exception.InvalidAccountException;
import itso.bank.exception.InvalidCustomerException;
import itso.bank.exception.InvalidTransactionException;
import itso.bank.facade.Bank;
import itso.bank.facade.ITSOBank;
import itso.bank.model.Account;
import itso.bank.model.Customer;
import itso.bank.model.TransactionType;

import java.math.BigDecimal;

import junit.framework.TestCase;

public class ITSOBankTest extends TestCase {
	Bank bank;
	Customer customer1;
	Account account11, account12;

	public static void main(String[] args) {
		junit.textui.TestRunner.run(ITSOBankTest.class);
	}

	protected void setUp() throws Exception {
		super.setUp();

		bank = new ITSOBank();
		try {
			customer1 = new Customer("111-11-1111","Jane","Doe");
			bank.addCustomer(customer1);
			System.out.println ( "Successfully Added customer1. "+customer1);
			account11 = new Account("11",new BigDecimal(10000.00D));
			bank.addAccount(customer1,account11);
			account12 = new Account("12",new BigDecimal(11234.23));
			bank.addAccount(customer1,account12);
			System.out.println("Successfully Added 2 Accounts to Customer1... ");
			System.out.println(customer1);
			
		}catch(InvalidCustomerException e){
			e.printStackTrace();
		}
	}

	public void testProcessTransaction(){
		try {
			BigDecimal balanceBefore = new BigDecimal(account11.getBalance().toString());
			BigDecimal debitAmount = new BigDecimal(2399.99D);
			
			bank.processTransaction(customer1,account11,debitAmount,TransactionType.CREDIT);
			
			assertEquals(account11.getBalance(), balanceBefore.subtract(debitAmount));
			
		}catch(InvalidCustomerException e){
			e.printStackTrace();
			fail("InvalidCustomerException. Message: " + e.getMessage());
		}catch(InvalidAccountException e){
			e.printStackTrace();
			fail("InvalidAccountException. Message: " + e.getMessage());
		}catch(InvalidTransactionException e){
			e.printStackTrace();
			fail("InvalidTransactionException. Message: " + e.getMessage());
		}
	}
	
	public void testInvalidProcessTransaction(){
		try {
			BigDecimal balanceBefore = new BigDecimal(account11.getBalance().toString());
			BigDecimal debitAmount = new BigDecimal(12399.99D);
			
			bank.processTransaction(new Customer("374-594-3994", "a", "b"),account11,debitAmount,TransactionType.DEBIT);
			
			fail("Transaction should not be processed. Negative balance");
		}catch(InvalidCustomerException e){
			e.printStackTrace();
			fail("InvalidCustomerException. Message: " + e.getMessage());
		}catch(InvalidAccountException e){
			e.printStackTrace();
			fail("InvalidAccountException. Message: " + e.getMessage());
		}catch(InvalidTransactionException e){
			assertTrue(true);
		}
	}

}
