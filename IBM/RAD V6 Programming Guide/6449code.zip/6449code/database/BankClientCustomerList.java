package itso.bank.client;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BankClientCustomerList {
	static String dbtab = "CUSTOMER";
	
	public static void main(String[] args) {
		System.out.println("************************************************************ ");
		System.out.println("Customer Listing for the ITSO Bank:");

		Connection con = null;
		con = connect();

		Statement stmt = null;
		ResultSet rs = null;
		String select = "SELECT * FROM ITSO." + dbtab;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(select);
			while (rs.next()) {
				String firstName = rs.getString("firstName");
				String lastName = rs.getString("lastName");
				System.out.println(firstName + " " + lastName);
			}
			System.out.println("End of Listing");
			System.out.println("************************************************************ ");
		} catch (Exception e) {
			System.err.println("Exception: " + e.getMessage());
		} finally {
			try {
				if (rs   != null) rs.close();
				if (stmt != null) stmt.close();
				if (con  != null) con.close();
			} catch (SQLException e) {}
		}	
	}
	
	protected static Connection connect() {
		Connection con = null;
		try {
			Class.forName("com.ibm.db2j.jdbc.DB2jDriver");
			con = DriverManager.getConnection("jdbc:db2j:C:\\databases\\BANK");
		} catch (Exception e) {
			System.err.println("Exception: " + e.getMessage());
		}
		return con;
	}
}
