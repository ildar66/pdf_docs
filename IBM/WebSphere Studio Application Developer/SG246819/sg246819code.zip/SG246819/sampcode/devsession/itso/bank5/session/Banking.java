package itso.bank5.session;
import java.math.BigDecimal;
import javax.ejb.FinderException;
import itso.bank5.exception.InsufficientFundException;
/**
 * Remote interface for Enterprise Bean: Banking
 */
public interface Banking extends javax.ejb.EJBObject {
	/**
	 * balance
	 */
	public BigDecimal getBalance(String accountID)
		throws FinderException, java.rmi.RemoteException;
	/**
	 * deposit
	 */
	public BigDecimal deposit(String accountID, BigDecimal amount)
		throws FinderException, java.rmi.RemoteException;
	/**
	 * withdraw
	 */
	public BigDecimal withdraw(String accountID, BigDecimal amount)
		throws FinderException, InsufficientFundException, java.rmi.RemoteException;
	/**
	 * transfer
	 */
	public BigDecimal transfer(
		String accountID1,
		String accountID2,
		BigDecimal amount)
		throws FinderException, InsufficientFundException, java.rmi.RemoteException;
	/**
	 * getTransrecords for account
	 */
	public java.util.Vector getTransrecords(String accountID)
		throws FinderException, java.rmi.RemoteException;
	/**
	 * getCustomers for account
	 */
	public java.util.Vector getCustomers(String accountID)
		throws FinderException, java.rmi.RemoteException;
	/**
	 * list accounts and transaction records for a customer
	 */
	public java.util.Vector listAccountsOfCustomer(int customerID)
		throws FinderException, java.rmi.RemoteException;
	/**
	 * getAccountInfo for account
	 */
	public String[] getAccountInfo(String accountID)
		throws FinderException, java.rmi.RemoteException;
	/**
	 * addCustAcct and removeCustAcct: add/remove account for a customer
	 */
	public void addCustAcct(int custid, String accid)
		throws java.rmi.RemoteException;
	public void removeCustAcct(int custid, String accid)
		throws java.rmi.RemoteException;
	/**
	 * addAcctCust and removeAcctCust: add/remove customer for an account
	 */
	public void addAcctCust(int custid, String accid)
		throws java.rmi.RemoteException;
	public void removeAcctCust(int custid, String accid)
		throws java.rmi.RemoteException;
}
