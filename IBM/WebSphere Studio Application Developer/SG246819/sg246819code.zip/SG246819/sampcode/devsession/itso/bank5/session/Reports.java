package itso.bank5.session;
import javax.ejb.FinderException;
import java.util.Vector;
import itso.bank5.sessionexception.ReportInconsistentException;

/**
 * Remote interface for Enterprise Bean: Reports
 */
public interface Reports extends javax.ejb.EJBObject {
	/**
	 * list all accounts and transaction records 
	 */
	public java.util.Vector listAllAccounts()
		throws FinderException, java.rmi.RemoteException;
	/**
	 * list gold accounts
	 */
	public java.util.Vector listGoldAccounts()
		throws FinderException, java.rmi.RemoteException, ReportInconsistentException;
	/**
	 * list transfer accounts 
	 */
	public java.util.Vector listTransferAccounts()
		throws FinderException, java.rmi.RemoteException, ReportInconsistentException;
	/**
	 * list largest accounts of a customer
	 */
	public String[] listLargestAccount()
		throws FinderException, java.rmi.RemoteException, ReportInconsistentException;
	/**
	 * list gold customers
	 */
	public java.util.Vector listGoldCustomers()
		throws FinderException, java.rmi.RemoteException, ReportInconsistentException;

	/**
	 * list all customer names
	 */
	public java.util.Vector listCustomerNames()
		throws FinderException, java.rmi.RemoteException;
	/**
	 * list customers with high interest
	 */
	public java.util.Vector listHighInterest()
		throws FinderException, java.rmi.RemoteException, ReportInconsistentException;
	/**
	 * set current customer
	 */
	public void setCurrentCustomer(int customerID)
		throws java.rmi.RemoteException;
	/**
	 * set current account
	 */
	public void setCurrentAccount(String accountID)
		throws java.rmi.RemoteException;
	/**
	 * set current interest
	 */
	public void setCurrentInterest(int interest)
		throws java.rmi.RemoteException;
	/**
	 * set current balance
	 */
	public void setCurrentBalance(java.math.BigDecimal balance)
		throws java.rmi.RemoteException;
	/**
	 * get customer list
	 */
	public Vector getCustomerList() throws java.rmi.RemoteException;
}
