package itso.bank5.session;
/**
 * Home interface for Enterprise Bean: Banking
 */
public interface BankingHome extends javax.ejb.EJBHome {
	/**
	 * Creates a default instance of Session Bean: Banking
	 */
	public itso.bank5.session.Banking create()
		throws javax.ejb.CreateException, java.rmi.RemoteException;
}
