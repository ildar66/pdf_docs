package itso.bank5.session;

import itso.bank5.cmp.*;                    // CMP entity beans
import itso.bank5.exception.*;              // Exception for withdraw failure
import javax.ejb.*;                         // EJB exceptions
import javax.naming.*;                      // JNDI access
import java.math.BigDecimal;                // Business logic parameters
import java.util.*;                         // Vector, Collection
import itso.bank5.utility.HomeFactory;      // Home factory

/**
 * Bean implementation class for Enterprise Bean: Banking
 */
public class BankingBean implements javax.ejb.SessionBean {
	
	// home fields
	private AccountLocalHome     accountHome  = null;
	private TransRecordLocalHome trecordHome  = null;
	private CustomerLocalHome    customerHome = null;
		
	private javax.ejb.SessionContext mySessionCtx; 
	/**
	 * getSessionContext
	 */
	public javax.ejb.SessionContext getSessionContext() {
		return mySessionCtx;
	}
	/**
	 * setSessionContext
	 */
	public void setSessionContext(javax.ejb.SessionContext ctx) {
		mySessionCtx = ctx;
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbCreate
	 */
	public void ejbCreate() throws javax.ejb.CreateException {
		getHomes();
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() {
	}


// get homes

	/**
	 * getHomes
	 */
	protected void getHomes() {
		try {
			// InitialContext initCtx = new InitialContext();
			// accountHome  = (AccountLocalHome)    initCtx.lookup("java:comp/env/ejb/Account");
			// trecordHome  = (TransRecordLocalHome)initCtx.lookup("java:comp/env/ejb/TransRecord");
			// customerHome = (CustomerLocalHome)   initCtx.lookup("java:comp/env/ejb/Customer");
			accountHome  = (AccountLocalHome)    HomeFactory.singleton().getHome("ejb/Account");
			trecordHome  = (TransRecordLocalHome)HomeFactory.singleton().getHome("ejb/TransRecord");
			customerHome = (CustomerLocalHome)   HomeFactory.singleton().getHome("ejb/Customer");
		} catch (NamingException ex) {
			ex.printStackTrace();
			throw new EJBException("Error looking up homes: "+ex.getMessage());
		}
	}
	

// business methods

	/**
	 * balance
	 */
	public BigDecimal getBalance(String accountID) throws FinderException {
		try {
			AccountLocal account = accountHome.findByPrimaryKey(accountID);
			return account.getBalance();
		} catch (FinderException ex) {
			throw new FinderException("Account "+accountID+" not found");
		} catch (EJBException ex) {
			throw new EJBException("Account getBalance failed for "+accountID);
		}
	}
	
	/**
	 * deposit
	 */
	public BigDecimal deposit(String accountID, BigDecimal amount) throws FinderException {
		try {
			AccountLocal account = accountHome.findByPrimaryKey(accountID);
			TransRecordLocal tr = trecordHome.create("C", amount, account);
			return account.deposit(amount);
		} catch (FinderException ex) {
			throw new FinderException("Account "+accountID+" not found");
		} catch (CreateException ex) {
			throw new EJBException("Account "+accountID+" create Transrecord failed");
		} catch (EJBException ex) {
			throw new EJBException("Account deposit failed for "+accountID);
		}
	}

	/**
	 * withdraw
	 */
	public BigDecimal withdraw(String accountID, BigDecimal amount) throws FinderException, InsufficientFundException {
		try {
			AccountLocal account = accountHome.findByPrimaryKey(accountID);
			BigDecimal result = account.withdraw(amount);
			TransRecordLocal tr = trecordHome.create("D", amount, account);
			return result;
		} catch (InsufficientFundException ex) {
			getSessionContext().setRollbackOnly();
			throw new InsufficientFundException("Account "+accountID+": not enough funds");
		} catch (FinderException ex) {
			throw new FinderException("Account "+accountID+" not found");
		} catch (CreateException ex) {
			throw new EJBException("Account "+accountID+" create Transrecord failed");
		} catch (EJBException ex) {
			throw new EJBException("Account withdraw failed for "+accountID);
		}
	}
	
	/**
	 * transfer
	 */
	public BigDecimal transfer(String accountID1, String accountID2, BigDecimal amount) throws FinderException, InsufficientFundException {
		AccountLocal account1 = null;
		AccountLocal account2 = null;
		try {
			account1 = accountHome.findByPrimaryKey(accountID1);
		} catch (FinderException ex) {
			throw new FinderException("Account "+accountID1+" not found");
		}
		try {
			account2 = accountHome.findByPrimaryKey(accountID2);
		} catch (FinderException ex) {
			throw new FinderException("Account "+accountID2+" not found");
		}
		try {	
			account1.withdraw(amount);
			account2.deposit(amount);
			TransRecordLocal tr1 = trecordHome.create("D", amount, account1);
			TransRecordLocal tr2 = trecordHome.create("C", amount, account2);
			return account1.getBalance();
		} catch (InsufficientFundException ex) {
			getSessionContext().setRollbackOnly();
			throw new InsufficientFundException("Account "+accountID1+": not enough funds");
		} catch (CreateException ex) {
			throw new EJBException("Account transfer create Transrecord failed");
		} catch (EJBException ex) {
			throw new EJBException("Account transfer failed for "+accountID1+"/"+accountID2);
		}
	}

	/**
	 * getTransrecords for account
	 */
	public java.util.Vector getTransrecords(String accountID) throws FinderException {
		try {
			Vector result = new Vector();
			AccountLocal account = accountHome.findByPrimaryKey(accountID);
			Collection coll = account.getTransrecords();
			Iterator collit = coll.iterator();
			while ( collit.hasNext() ) {
				TransRecordLocal tr = (TransRecordLocal)collit.next();
				result.addElement ( ((java.sql.Timestamp)tr.getPrimaryKey()).toString()+" "+tr.getTransType()+" "+tr.getTransAmount().toString() );
			} 
			return result;			
		} catch (FinderException ex) {
			throw new FinderException("Account "+accountID+" not found");
		}
	}

	/**
	 * getCustomers for account
	 */
	public java.util.Vector getCustomers(String accountID) throws FinderException {
		try {
			Vector result = new Vector();
			AccountLocal account = accountHome.findByPrimaryKey(accountID);
			Collection coll = account.getCustomers();
			Iterator collit = coll.iterator();
			while ( collit.hasNext() ) {
				CustomerLocal cust = (CustomerLocal)collit.next();
				result.addElement ( ((CustomerKey)cust.getPrimaryKey()).getCustomerID()+" "+cust.getName() );
			} 
			return result;			
		} catch (FinderException ex) {
			throw new FinderException("Account "+accountID+" not found");
		}
	}

	/**
	 * list accounts and transaction records for a customer
	 */
	public java.util.Vector listAccountsOfCustomer(int customerID) throws FinderException {
		try {
			Vector result = new Vector();
			CustomerLocal cust = customerHome.findByPrimaryKey(new CustomerKey(customerID) );
			result.addElement( new String[] { "C", String.valueOf(customerID), cust.getName(), "", "" } );
			Collection coll1 = cust.getAccounts();
			if (coll1 == null) {
				result.addElement( new String[] { "A", "No accounts", "", "", "" } );
				return result;
			}
			Iterator collit1 = coll1.iterator();
			while ( collit1.hasNext() ) {
				AccountLocal account = (AccountLocal)collit1.next();
				if (account instanceof CheckingLocal) {
					CheckingLocal checking = (CheckingLocal)account;
					result.addElement ( new String[] { "A", account.getAccountType(), (String)account.getPrimaryKey(), account.getBalance().toString(), "Overdraft: "+checking.getOverdraft().toString() } );
				} else if (account instanceof SavingsLocal) {
					SavingsLocal savings = (SavingsLocal)account;
					result.addElement ( new String[] { "A", account.getAccountType(), (String)account.getPrimaryKey(), account.getBalance().toString(), "MinAmount: "+savings.getMinAmount().toString() } );
				} else {
					result.addElement ( new String[] { "A", account.getAccountType(), (String)account.getPrimaryKey(), account.getBalance().toString(), "" } );
				}
				Collection coll2 = account.getTransrecords();
				if (coll2 != null) {
					Iterator collit2 = coll2.iterator();
					while ( collit2.hasNext() ) {
						TransRecordLocal tr = (TransRecordLocal)collit2.next();
						if ( tr.getTransType().equals("C") ) 
							result.addElement( new String[] {"T", "Credit", ((java.sql.Timestamp)tr.getPrimaryKey()).toString(), tr.getTransAmount().toString(), "" } );
						else
							result.addElement( new String[] {"T", "Debit",  ((java.sql.Timestamp)tr.getPrimaryKey()).toString(), tr.getTransAmount().toString(), "" } );
					}
				}
			}
			return result;	
		} catch (FinderException ex) {
			throw new FinderException("Customer "+customerID+" not found");
		}
	}
	
	/**
	 * getAccountInfo for account
	 */
	public String[] getAccountInfo(String accountID) throws FinderException {
		try {
			String[] result = new String[4];
			AccountLocal account = accountHome.findByPrimaryKey(accountID);
 			result[0] = accountID;
 			result[1] = account.getAccountType();
 			result[2] = account.getBalance().toString();
 			result[3] = String.valueOf(account.getInterest());
			return result;			
		} catch (FinderException ex) {
			throw new FinderException("Account "+accountID+" not found");
		}
	}

	/**
	 * addCustAcct and removeCustAcct: add/remove account for a customer
	 */
	public void addCustAcct(int custid, String accid) {
		try {
			CustomerLocal cust = customerHome.findByPrimaryKey( new CustomerKey(custid) );
			AccountLocal  acct = accountHome. findByPrimaryKey( accid );
			cust.addAccount(acct);
		} catch (Exception e) { e.printStackTrace(); }
	}
	public void removeCustAcct(int custid, String accid) {
		try {
			CustomerLocal cust = customerHome.findByPrimaryKey( new CustomerKey(custid) );
			AccountLocal  acct = accountHome. findByPrimaryKey( accid );
			cust.removeAccount(acct);
		} catch (Exception e) { e.printStackTrace(); }
	}

	/**
	 * addAcctCust and removeAcctCust: add/remove customer for an account
	 */
	public void addAcctCust(int custid, String accid) {
		try {
			CustomerLocal cust = customerHome.findByPrimaryKey( new CustomerKey(custid) );
			AccountLocal  acct = accountHome. findByPrimaryKey( accid );
			acct.addCustomer(cust);
		} catch (Exception e) { e.printStackTrace(); }
	}
	public void removeAcctCust(int custid, String accid) {
		try {
			CustomerLocal cust = customerHome.findByPrimaryKey( new CustomerKey(custid) );
			AccountLocal  acct = accountHome. findByPrimaryKey( accid );
			acct.removeCustomer(cust);
		} catch (Exception e) { e.printStackTrace(); }
	}
		
}
