package itso.bank5.session;

import itso.bank5.cmp.*;
import itso.bank5.exception.*;
import java.rmi.*;
import javax.rmi.*;
import javax.ejb.*;
import javax.naming.*;
import java.math.BigDecimal;
import java.util.*;
import itso.bank5.utility.HomeFactory;
import itso.bank5.sessionexception.ReportInconsistentException;

/**
 * Bean implementation class for Enterprise Bean: Reports
 */
public class ReportsBean implements javax.ejb.SessionBean {
	
	// home fields
	private transient AccountLocalHome     accountHome    = null;
	private transient CustomerLocalHome    customerHome   = null;
	private transient CustomerHome         custRemoteHome = null;

	// stateful fields
	private Vector  customerList   = null;
	private String  currentAccount = null;
	private int     currentCustomer = 0;
	private int     currentInterest = 0;
	private BigDecimal currentBalance = new BigDecimal(0.00);
	
	private javax.ejb.SessionContext mySessionCtx;

	/**
	 * getSessionContext
	 */
	public javax.ejb.SessionContext getSessionContext() {
		return mySessionCtx;
	}
	/**
	 * setSessionContext
	 */
	public void setSessionContext(javax.ejb.SessionContext ctx) {
		mySessionCtx = ctx;
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
		getHomes();
	}
	/**
	 * ejbCreate
	 */
	public void ejbCreate() throws javax.ejb.CreateException {
		getHomes();
	}
	public void ejbCreateByAccount(int customerID, String accountID) throws javax.ejb.CreateException {
		getHomes();
		setCurrentCustomer(customerID);
		setCurrentAccount(accountID);
	}

	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
		accountHome    = null;
		customerHome   = null;
		custRemoteHome = null;
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() {
	}
	
// get homes

	/**
	 * getHomes
	 */
	protected void getHomes() {
		try {
			// InitialContext initCtx = new InitialContext();
			// accountHome    = (AccountLocalHome) initCtx.lookup("java:comp/env/ejb/Account");
			// customerHome   = (CustomerLocalHome)initCtx.lookup("java:comp/env/ejb/Customer");
			// custRemoteHome = (CustomerHome)     initCtx.lookup("java:comp/env/ejb/CustomerRemote");
			accountHome    = (AccountLocalHome) HomeFactory.singleton().getHome("ejb/Account");
			customerHome   = (CustomerLocalHome)HomeFactory.singleton().getHome("ejb/Customer");
			custRemoteHome = (CustomerHome)     HomeFactory.singleton().getHome("ejb/CustomerRemote");
		} catch (NamingException ex) {
			ex.printStackTrace();
			throw new EJBException("Error looking up homes: "+ex.getMessage());
		}
	}
	

// business methods

	/**
	 * list all customer names
	 */
	public java.util.Vector listCustomerNames() throws FinderException {
		try {
			customerList = customerHome.getAllCustomers();
			return customerList;
		} catch (FinderException ex) {
			throw new FinderException("List customer names find error "+ex.getMessage());
		}
	}

	
	/**
	 * get customer list
	 */
	public Vector getCustomerList() {
		return customerList;
	}
	
	/**
	 * set current customer
	 */
	public void setCurrentCustomer(int customerID) {
		currentCustomer = customerID;
	}

	/**
	 * set current account
	 */
	public void setCurrentAccount(String accountID) {
		currentAccount = accountID;
	}

	/**
	 * set current balance
	 */
	public void setCurrentBalance(java.math.BigDecimal balance) {
		currentBalance = balance;
	}

	/**
	 * set current interest
	 */
	public void setCurrentInterest(int interest) {
		currentInterest = interest;
	}

	/**
	 * list all accounts and transaction records 
	 */
	public java.util.Vector listAllAccounts() throws FinderException {
		try {
			Vector result = new Vector();
			Collection coll1 = accountHome.findAllAccounts();
			if (coll1 == null) {
				result.addElement( new String[] { "A", "No accounts", "", "", "" } );
				return result;
			}
			Iterator collit1 = coll1.iterator();
			while ( collit1.hasNext() ) {
				AccountLocal account = (AccountLocal)collit1.next();
				if (account instanceof CheckingLocal) {
					CheckingLocal checking = (CheckingLocal)account;
					result.addElement ( new String[] { "A", account.getAccountType(), (String)account.getPrimaryKey(), account.getBalance().toString(), "Overdraft: "+checking.getOverdraft().toString() } );	
				} else if (account instanceof SavingsLocal) {
					SavingsLocal savings = (SavingsLocal)account;
					result.addElement ( new String[] { "A", account.getAccountType(), (String)account.getPrimaryKey(), account.getBalance().toString(), "MinAmount: "+savings.getMinAmount().toString() } );	
				} else {
					result.addElement ( new String[] { "A", account.getAccountType(), (String)account.getPrimaryKey(), account.getBalance().toString(), "" } );				
				}
				Collection coll2 = account.getTransrecords();
				if (coll2 != null) {
					Iterator collit2 = coll2.iterator();
					while ( collit2.hasNext() ) {
						TransRecordLocal tr = (TransRecordLocal)collit2.next();
						if ( tr.getTransType().equals("C") ) 
					  		result.addElement( new String[] {"T", "Credit", ((java.sql.Timestamp)tr.getPrimaryKey()).toString(), tr.getTransAmount().toString(), "" } );
						else
					  		result.addElement( new String[] {"T", "Debit",  ((java.sql.Timestamp)tr.getPrimaryKey()).toString(), tr.getTransAmount().toString(), "" } );
					}
				}
			}
			return result;	
		} catch (FinderException ex) {
			throw new FinderException("All accounts error "+ex.getMessage());
		}
	}

	/**
	 * list gold accounts
	 */
	public java.util.Vector listGoldAccounts() throws FinderException, ReportInconsistentException {
		if (currentBalance.equals(new BigDecimal(0.00))) throw new ReportInconsistentException("Balance not set");
		try {
			Vector result = new Vector();
			Collection coll1 = accountHome.findGoldAccounts(currentBalance);
			if (coll1 == null) {
				result.addElement( new String[] { "No gold accounts", "", "" } );
				return result;
			}
			Iterator collit1 = coll1.iterator();
			while ( collit1.hasNext() ) {
				AccountLocal account = (AccountLocal)collit1.next();
				if (account instanceof CheckingLocal) {
					CheckingLocal checking = (CheckingLocal)account;
					result.addElement ( new String[] { "Checking", (String)account.getPrimaryKey(), account.getBalance().toString() } );	
				} else if (account instanceof SavingsLocal) {
					SavingsLocal savings = (SavingsLocal)account;
					result.addElement ( new String[] { "Savings",  (String)account.getPrimaryKey(), account.getBalance().toString() } );	
				} else {
					result.addElement ( new String[] { "Account",  (String)account.getPrimaryKey(), account.getBalance().toString() } );				
				}
			}
			return result;	
		} catch (FinderException ex) {
			throw new FinderException("Gold accounts find error "+ex.getMessage());
		}
	}

	/**
	 * list transfer accounts 
	 */
	public java.util.Vector listTransferAccounts() throws FinderException, ReportInconsistentException {
		if (currentCustomer == 0)   throw new ReportInconsistentException("Customer ID not set");
		if (currentAccount == null) throw new ReportInconsistentException("AccountID not set");
		try {
			Vector result = new Vector();
			Collection coll1 = accountHome.findTransferAccounts(currentCustomer, currentAccount);
			if (coll1 == null) {
				result.addElement( new String[] { "No transfer accounts", "", "" } );
				return result;
			}
			Iterator collit1 = coll1.iterator();
			while ( collit1.hasNext() ) {
				AccountLocal account = (AccountLocal)collit1.next();
				result.addElement ( new String[] { (String)account.getPrimaryKey(), account.getAccountType(), account.getBalance().toString() } );	
			}
			return result;	
		} catch (FinderException ex) {
			throw new FinderException("Transfer accounts find error "+ex.getMessage());
		}
	}
	
	/**
	 * list largest account of a customer
	 */
	public String[] listLargestAccount() throws FinderException, ReportInconsistentException {
		if (currentCustomer == 0) throw new ReportInconsistentException("Customer ID not set");
		try {
			AccountLocal account = accountHome.findLargestAccount(currentCustomer);
			if (account == null) {
				return new String[] { "No largest account", "", "" };
			} else {
				return new String[] { (String)account.getPrimaryKey(), account.getAccountType(), account.getBalance().toString() };	
			}
		} catch (FinderException ex) {
			throw new FinderException("Largest account find error "+ex.getMessage());
		}
	}

	/**
	 * list gold customers
	 */
	public java.util.Vector listGoldCustomers() throws FinderException, ReportInconsistentException {
		if (currentBalance.equals(new BigDecimal(0.00))) throw new ReportInconsistentException("Balance not set");
		try {
			Vector result = new Vector();
			Collection coll1 = customerHome.findGoldCustomers(currentBalance);
			if (coll1 == null) {
				result.addElement( new String[] { "No gold customers", "" } );
				return result;
			}
			Iterator collit1 = coll1.iterator();
			while ( collit1.hasNext() ) {
				CustomerLocal cust = (CustomerLocal)collit1.next();
				result.addElement ( new String[] { String.valueOf( ((CustomerKey)cust.getPrimaryKey()).getCustomerID() ), cust.getName() } );	
			}
			return result;	
		} catch (FinderException ex) {
			throw new FinderException("Gold customers find error "+ex.getMessage());
		}
	}

	/**
	 * list customers with high interest
	 */
	public java.util.Vector listHighInterest() throws FinderException, ReportInconsistentException {
		if (currentInterest == 0) throw new ReportInconsistentException("Interest not set");
		try {
			Vector result = new Vector();
			Collection coll1 = custRemoteHome.findHighInterest(currentInterest);
			if (coll1 == null) {
				result.addElement( new String[] { "No high interest customers", "", "", "" } );
				return result;
			}
			Iterator collit1 = coll1.iterator();
			while ( collit1.hasNext() ) {
				Customer custRemote  = (Customer)collit1.next();
				CustomerLocal cust   = customerHome.findByPrimaryKey( (CustomerKey)custRemote.getPrimaryKey() );
				Collection coll2 = cust.getAccounts();
				if (coll2 != null) {
					Iterator collit2 = coll2.iterator();
					while ( collit2.hasNext() ) {
						AccountLocal acct = (AccountLocal)collit2.next();
						if ( acct.getInterest() > currentInterest ) 
					  		result.addElement( new String[] {String.valueOf( ((CustomerKey)cust.getPrimaryKey()).getCustomerID() ), cust.getName(), (String)acct.getPrimaryKey(), String.valueOf( acct.getInterest() ) } );
					}
				}
			}
			return result;	
		} catch (FinderException ex) {
			throw new FinderException("High interest customers find error "+ex.getMessage());
		} catch (java.rmi.RemoteException ex) {
			throw new FinderException("High interest customers remote error "+ex.getMessage());
		}
	}

}
