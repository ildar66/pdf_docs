package itso.bank5.session;
/**
 * Home interface for Enterprise Bean: Reports
 */
public interface ReportsHome extends javax.ejb.EJBHome {
	/**
	 * Creates a default instance of Session Bean: Reports
	 */
	public itso.bank5.session.Reports create()
		throws javax.ejb.CreateException, java.rmi.RemoteException;
	public itso.bank5.session.Reports createByAccount(int customerID, String accountID)
		throws javax.ejb.CreateException, java.rmi.RemoteException;
}
