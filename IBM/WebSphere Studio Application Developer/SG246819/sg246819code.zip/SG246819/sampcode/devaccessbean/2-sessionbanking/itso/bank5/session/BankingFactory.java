package itso.bank5.session;
import javax.ejb.*;
import java.rmi.RemoteException;
import javax.naming.NamingException;
import com.ibm.etools.ejb.client.runtime.*;
/**
 * BankingFactory
 * @generated
 */
public class BankingFactory extends AbstractEJBFactory {
	/**
	 * BankingFactory
	 * @generated
	 */
	public BankingFactory() {
		super();
	}
	/**
	 * _acquireBankingHome
	 * @generated
	 */
	protected itso.bank5.session.BankingHome _acquireBankingHome()
		throws java.rmi.RemoteException {
		return (itso.bank5.session.BankingHome) _acquireEJBHome();
	}
	/**
	 * acquireBankingHome
	 * @generated
	 */
	public itso.bank5.session.BankingHome acquireBankingHome()
		throws javax.naming.NamingException {
		return (itso.bank5.session.BankingHome) acquireEJBHome();
	}
	/**
	 * getDefaultJNDIName
	 * @generated
	 */
	public String getDefaultJNDIName() {
		return "ejb/itsobank/Banking";
	}
	/**
	 * getHomeInterface
	 * @generated
	 */
	protected Class getHomeInterface() {
		return itso.bank5.session.BankingHome.class;
	}
	/**
	 * resetBankingHome
	 * @generated
	 */
	public void resetBankingHome() {
		resetEJBHome();
	}
	/**
	 * setBankingHome
	 * @generated
	 */
	public void setBankingHome(itso.bank5.session.BankingHome home) {
		setEJBHome(home);
	}
	/**
	 * create
	 * @generated
	 */
	public itso.bank5.session.Banking create()
		throws CreateException, RemoteException {
		return _acquireBankingHome().create();
	}
}
