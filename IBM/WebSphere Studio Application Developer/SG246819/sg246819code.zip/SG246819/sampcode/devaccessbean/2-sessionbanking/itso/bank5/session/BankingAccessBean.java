package itso.bank5.session;
import javax.ejb.*;
import javax.rmi.*;
import com.ibm.ivj.ejb.runtime.*;
/**
 * BankingAccessBean
 * @generated
 */
public class BankingAccessBean extends AbstractSessionAccessBean {
	/**
	 * @generated
	 */
	private Banking __ejbRef;
	/**
	 * BankingAccessBean
	 * @generated
	 */
	public BankingAccessBean() {
		super();
	}
	/**
	 * BankingAccessBean
	 * @generated
	 */
	public BankingAccessBean(javax.ejb.EJBObject o)
		throws java.rmi.RemoteException {
		super(o);
	}
	/**
	 * defaultJNDIName
	 * @generated
	 */
	public String defaultJNDIName() {
		return "ejb/itsobank/Banking";
	}
	/**
	 * ejbHome
	 * @generated
	 */
	private itso.bank5.session.BankingHome ejbHome()
		throws java.rmi.RemoteException, javax.naming.NamingException {
		return (itso.bank5.session.BankingHome) PortableRemoteObject.narrow(
			getHome(),
			itso.bank5.session.BankingHome.class);
	}
	/**
	 * ejbRef
	 * @generated
	 */
	private itso.bank5.session.Banking ejbRef()
		throws java.rmi.RemoteException {
		if (ejbRef == null)
			return null;
		if (__ejbRef == null)
			__ejbRef =
				(itso.bank5.session.Banking) PortableRemoteObject.narrow(
					ejbRef,
					itso.bank5.session.Banking.class);

		return __ejbRef;
	}
	/**
	 * instantiateEJB
	 * @generated
	 */
	protected void instantiateEJB()
		throws
			javax.naming.NamingException,
			javax.ejb.CreateException,
			java.rmi.RemoteException {
		if (ejbRef() != null)
			return;

		ejbRef = ejbHome().create();
	}
	/**
	 * withdraw
	 * @generated
	 */
	public java.math.BigDecimal withdraw(
		java.lang.String accountID,
		java.math.BigDecimal amount)
		throws
			javax.naming.NamingException,
			javax.ejb.FinderException,
			javax.ejb.CreateException,
			itso.bank5.exception.InsufficientFundException,
			java.rmi.RemoteException {
		instantiateEJB();
		return ejbRef().withdraw(accountID, amount);
	}
	/**
	 * getTransrecords
	 * @generated
	 */
	public java.util.Vector getTransrecords(java.lang.String accountID)
		throws
			javax.naming.NamingException,
			javax.ejb.FinderException,
			javax.ejb.CreateException,
			java.rmi.RemoteException {
		instantiateEJB();
		return ejbRef().getTransrecords(accountID);
	}
	/**
	 * listAccountsOfCustomer
	 * @generated
	 */
	public java.util.Vector listAccountsOfCustomer(int customerID)
		throws
			javax.naming.NamingException,
			javax.ejb.FinderException,
			javax.ejb.CreateException,
			java.rmi.RemoteException {
		instantiateEJB();
		return ejbRef().listAccountsOfCustomer(customerID);
	}
	/**
	 * deposit
	 * @generated
	 */
	public java.math.BigDecimal deposit(
		java.lang.String accountID,
		java.math.BigDecimal amount)
		throws
			javax.naming.NamingException,
			javax.ejb.FinderException,
			javax.ejb.CreateException,
			java.rmi.RemoteException {
		instantiateEJB();
		return ejbRef().deposit(accountID, amount);
	}
	/**
	 * getCustomers
	 * @generated
	 */
	public java.util.Vector getCustomers(java.lang.String accountID)
		throws
			javax.naming.NamingException,
			javax.ejb.FinderException,
			javax.ejb.CreateException,
			java.rmi.RemoteException {
		instantiateEJB();
		return ejbRef().getCustomers(accountID);
	}
	/**
	 * transfer
	 * @generated
	 */
	public java.math.BigDecimal transfer(
		java.lang.String accountID1,
		java.lang.String accountID2,
		java.math.BigDecimal amount)
		throws
			javax.naming.NamingException,
			javax.ejb.FinderException,
			javax.ejb.CreateException,
			itso.bank5.exception.InsufficientFundException,
			java.rmi.RemoteException {
		instantiateEJB();
		return ejbRef().transfer(accountID1, accountID2, amount);
	}
	/**
	 * getBalance
	 * @generated
	 */
	public java.math.BigDecimal getBalance(java.lang.String accountID)
		throws
			javax.naming.NamingException,
			javax.ejb.FinderException,
			javax.ejb.CreateException,
			java.rmi.RemoteException {
		instantiateEJB();
		return ejbRef().getBalance(accountID);
	}
}
