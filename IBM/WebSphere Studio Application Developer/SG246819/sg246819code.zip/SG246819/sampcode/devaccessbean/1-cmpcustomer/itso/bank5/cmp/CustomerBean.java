package itso.bank5.cmp;
/**
 * Bean implementation class for Enterprise Bean: Customer
 */
public abstract class CustomerBean implements javax.ejb.EntityBean, itso.bank5.access.CustomerData.Store {

	private javax.ejb.EntityContext myEntityCtx;
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		myEntityCtx = ctx;
	}
	/**
	 * getEntityContext
	 */
	public javax.ejb.EntityContext getEntityContext() {
		return myEntityCtx;
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		myEntityCtx = null;
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbCreate
	 */
	public itso.bank5.cmp.CustomerKey ejbCreate(int customerID)
		throws javax.ejb.CreateException {
		setCustomerID(customerID);
		setFirstName("");
		setLastName("");
		setTitle("");
		setUserID("");
		setPassword("");
		setAddress(null);
		return null;
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(int customerID)
		throws javax.ejb.CreateException {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
	}
	/**
	 * Get accessor for persistent attribute: customerID
	 */
	public abstract int getCustomerID();
	/**
	 * Set accessor for persistent attribute: customerID
	 */
	public abstract void setCustomerID(int newCustomerID);
	/**
	 * Get accessor for persistent attribute: firstName
	 */
	public abstract java.lang.String getFirstName();
	/**
	 * Set accessor for persistent attribute: firstName
	 */
	public abstract void setFirstName(java.lang.String newFirstName);
	/**
	 * Get accessor for persistent attribute: lastName
	 */
	public abstract java.lang.String getLastName();
	/**
	 * Set accessor for persistent attribute: lastName
	 */
	public abstract void setLastName(java.lang.String newLastName);
	/**
	 * Get accessor for persistent attribute: title
	 */
	public abstract java.lang.String getTitle();
	/**
	 * Set accessor for persistent attribute: title
	 */
	public abstract void setTitle(java.lang.String newTitle);
	/**
	 * Get accessor for persistent attribute: userID
	 */
	public abstract java.lang.String getUserID();
	/**
	 * Set accessor for persistent attribute: userID
	 */
	public abstract void setUserID(java.lang.String newUserID);
	/**
	 * Get accessor for persistent attribute: password
	 */
	public abstract java.lang.String getPassword();
	/**
	 * Set accessor for persistent attribute: password
	 */
	public abstract void setPassword(java.lang.String newPassword);
	/**
	 * Get accessor for persistent attribute: address
	 */
	public abstract itso.bank5.beans.Address getAddress();
	/**
	 * Set accessor for persistent attribute: address
	 */
	public abstract void setAddress(itso.bank5.beans.Address newAddress);

	/**
	 * retrieve full name
	 */
	public String getName() {
		return new StringBuffer( getTitle() ).append(" ")
						.append( getFirstName() ).append(" ")
						.append( getLastName() ).toString();
	}
	/**
	 * This method was generated for supporting the relationship role named accounts.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract java.util.Collection getAccounts();
	/**
	 * This method was generated for supporting the relationship role named accounts.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract void setAccounts(java.util.Collection anAccounts);

	public void addAccount(AccountLocal anAccount) {
		getAccounts().add(anAccount);
	}
	public void removeAccount(AccountLocal anAccount) {
		getAccounts().remove(anAccount);
	}
	public String[] getAccountNumbers() {
		java.util.Collection accounts = getAccounts();
		if ( accounts.size() == 0 ) return null;
		String[] result = new String[ accounts.size() ];
		java.util.Iterator it = accounts.iterator();
		for (int i=0; it.hasNext(); i++ ) {
			AccountLocal account = (AccountLocal)it.next();
			result[i] = (String)account.getPrimaryKey();
		}
		return result;
	}
	
	// select methods
	public abstract java.util.Set ejbSelectAllCustomerNames() throws javax.ejb.FinderException;
	
	public abstract java.util.Collection ejbSelectNumberOfAccounts(
		java.lang.String name)
		throws javax.ejb.FinderException;
	// home method
	/**
	 * returns an Vector with array of strings: customerlastname, accountIDs
	 */
	public java.util.Vector ejbHomeGetAllCustomers() throws javax.ejb.FinderException {
		Object[] objects = ejbSelectAllCustomerNames().toArray();
		java.util.Vector names = new java.util.Vector();
		for (int i=0; i < objects.length; i++) {
			String custname = (String)objects[i];
			Object[] accounts = ejbSelectNumberOfAccounts(custname).toArray();
			String[] data = new String[ accounts.length +1 ];
			data[0] = custname;
			for (int j=0; j < accounts.length; j++) {
				data[j+1] = (String)accounts[j];
			}
			names.addElement(data);
			System.out.println("Customer: " + custname + " Accounts: " + accounts.length);
		}
		return names;
	}
	/**
	 * getCustomerData
	 */
	public itso.bank5.access.CustomerData getCustomerData() {
		return new itso.bank5.access.CustomerData(this);
	}
	/**
	 * setCustomerData
	 */
	public void setCustomerData(itso.bank5.access.CustomerData data)
		throws com.ibm.etools.ejb.client.runtime.FieldChangedException {
		data.copyTo(this);
		if (!data.getIstitleDirty()) {
			if (this.getTitle() != null && data.getTitle() != null) {
				if (!this.getTitle().equals(data.getTitle())) {
					throw new com
						.ibm
						.etools
						.ejb
						.client
						.runtime
						.FieldChangedException();
				}
			} else if (!(this.getTitle() == null && data.getTitle() == null)) {
				throw new com
					.ibm
					.etools
					.ejb
					.client
					.runtime
					.FieldChangedException();
			}
		}
		if (!data.getIsaddressDirty()) {
			if (this.getAddress() != null && data.getAddress() != null) {
				if (!this.getAddress().equals(data.getAddress())) {
					throw new com
						.ibm
						.etools
						.ejb
						.client
						.runtime
						.FieldChangedException();
				}
			} else if (
				!(this.getAddress() == null && data.getAddress() == null)) {
				throw new com
					.ibm
					.etools
					.ejb
					.client
					.runtime
					.FieldChangedException();
			}
		}
		if (!data.getIsfirstNameDirty()) {
			if (this.getFirstName() != null && data.getFirstName() != null) {
				if (!this.getFirstName().equals(data.getFirstName())) {
					throw new com
						.ibm
						.etools
						.ejb
						.client
						.runtime
						.FieldChangedException();
				}
			} else if (
				!(this.getFirstName() == null
					&& data.getFirstName() == null)) {
				throw new com
					.ibm
					.etools
					.ejb
					.client
					.runtime
					.FieldChangedException();
			}
		}
		if (!data.getIspasswordDirty()) {
			if (this.getPassword() != null && data.getPassword() != null) {
				if (!this.getPassword().equals(data.getPassword())) {
					throw new com
						.ibm
						.etools
						.ejb
						.client
						.runtime
						.FieldChangedException();
				}
			} else if (
				!(this.getPassword() == null && data.getPassword() == null)) {
				throw new com
					.ibm
					.etools
					.ejb
					.client
					.runtime
					.FieldChangedException();
			}
		}
		if (!data.getIslastNameDirty()) {
			if (this.getLastName() != null && data.getLastName() != null) {
				if (!this.getLastName().equals(data.getLastName())) {
					throw new com
						.ibm
						.etools
						.ejb
						.client
						.runtime
						.FieldChangedException();
				}
			} else if (
				!(this.getLastName() == null && data.getLastName() == null)) {
				throw new com
					.ibm
					.etools
					.ejb
					.client
					.runtime
					.FieldChangedException();
			}
		}
		if (!data.getIsuserIDDirty()) {
			if (this.getUserID() != null && data.getUserID() != null) {
				if (!this.getUserID().equals(data.getUserID())) {
					throw new com
						.ibm
						.etools
						.ejb
						.client
						.runtime
						.FieldChangedException();
				}
			} else if (
				!(this.getUserID() == null && data.getUserID() == null)) {
				throw new com
					.ibm
					.etools
					.ejb
					.client
					.runtime
					.FieldChangedException();
			}
		}
	}
	/**
	 * syncCustomerData
	 */
	public itso.bank5.access.CustomerData syncCustomerData(
		itso.bank5.access.CustomerData data) {
		data.copyTo(this);
		return this.getCustomerData();
	}
	/**
	 * getPrimaryKey
	 */
	public Object getPrimaryKey() {
		return getEntityContext().getPrimaryKey();
	}
}
