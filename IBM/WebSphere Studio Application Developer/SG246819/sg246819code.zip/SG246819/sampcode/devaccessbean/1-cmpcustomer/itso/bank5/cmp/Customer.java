package itso.bank5.cmp;
/**
 * Remote interface for Enterprise Bean: Customer
 */
public interface Customer extends javax.ejb.EJBObject {
	/**
	 * Get accessor for persistent attribute: firstName
	 */
	public java.lang.String getFirstName() throws java.rmi.RemoteException;
	/**
	 * Set accessor for persistent attribute: firstName
	 */
	public void setFirstName(java.lang.String newFirstName)
		throws java.rmi.RemoteException;
	/**
	 * Get accessor for persistent attribute: lastName
	 */
	public java.lang.String getLastName() throws java.rmi.RemoteException;
	/**
	 * Set accessor for persistent attribute: lastName
	 */
	public void setLastName(java.lang.String newLastName)
		throws java.rmi.RemoteException;
	/**
	 * Get accessor for persistent attribute: title
	 */
	public java.lang.String getTitle() throws java.rmi.RemoteException;
	/**
	 * Set accessor for persistent attribute: title
	 */
	public void setTitle(java.lang.String newTitle)
		throws java.rmi.RemoteException;
	/**
	 * Get accessor for persistent attribute: userID
	 */
	public java.lang.String getUserID() throws java.rmi.RemoteException;
	/**
	 * Set accessor for persistent attribute: userID
	 */
	public void setUserID(java.lang.String newUserID)
		throws java.rmi.RemoteException;
	/**
	 * Get accessor for persistent attribute: password
	 */
	public java.lang.String getPassword() throws java.rmi.RemoteException;
	/**
	 * Set accessor for persistent attribute: password
	 */
	public void setPassword(java.lang.String newPassword)
		throws java.rmi.RemoteException;
	/**
	 * Get accessor for persistent attribute: address
	 */
	public itso.bank5.beans.Address getAddress()
		throws java.rmi.RemoteException;
	/**
	 * Set accessor for persistent attribute: address
	 */
	public void setAddress(itso.bank5.beans.Address newAddress)
		throws java.rmi.RemoteException;
	// business methods
	public String[] getAccountNumbers() throws java.rmi.RemoteException;

	/**
	 * retrieve full name
	 */
	public String getName() throws java.rmi.RemoteException;
	/**
	 * getCustomerData
	 */
	public itso.bank5.access.CustomerData getCustomerData()
		throws java.rmi.RemoteException;
	/**
	 * setCustomerData
	 */
	public void setCustomerData(itso.bank5.access.CustomerData data)
		throws
			java.rmi.RemoteException,
			com.ibm.etools.ejb.client.runtime.FieldChangedException;
	/**
	 * syncCustomerData
	 */
	public itso.bank5.access.CustomerData syncCustomerData(
		itso.bank5.access.CustomerData data)
		throws java.rmi.RemoteException;
}
