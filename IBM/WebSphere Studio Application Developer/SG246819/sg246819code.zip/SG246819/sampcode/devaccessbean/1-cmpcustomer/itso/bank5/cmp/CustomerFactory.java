package itso.bank5.cmp;
import javax.ejb.*;
import java.rmi.RemoteException;
import javax.naming.NamingException;
import com.ibm.etools.ejb.client.runtime.*;
/**
 * CustomerFactory
 * @generated
 */
public class CustomerFactory extends AbstractEJBFactory {
	/**
	 * CustomerFactory
	 * @generated
	 */
	public CustomerFactory() {
		super();
	}
	/**
	 * _acquireCustomerHome
	 * @generated
	 */
	protected itso.bank5.cmp.CustomerHome _acquireCustomerHome()
		throws java.rmi.RemoteException {
		return (itso.bank5.cmp.CustomerHome) _acquireEJBHome();
	}
	/**
	 * acquireCustomerHome
	 * @generated
	 */
	public itso.bank5.cmp.CustomerHome acquireCustomerHome()
		throws javax.naming.NamingException {
		return (itso.bank5.cmp.CustomerHome) acquireEJBHome();
	}
	/**
	 * getDefaultJNDIName
	 * @generated
	 */
	public String getDefaultJNDIName() {
		return "ejb/itsobank/Customer";
	}
	/**
	 * getHomeInterface
	 * @generated
	 */
	protected Class getHomeInterface() {
		return itso.bank5.cmp.CustomerHome.class;
	}
	/**
	 * resetCustomerHome
	 * @generated
	 */
	public void resetCustomerHome() {
		resetEJBHome();
	}
	/**
	 * setCustomerHome
	 * @generated
	 */
	public void setCustomerHome(itso.bank5.cmp.CustomerHome home) {
		setEJBHome(home);
	}
	/**
	 * create
	 * @generated
	 */
	public itso.bank5.cmp.Customer create(int customerID)
		throws CreateException, RemoteException {
		return _acquireCustomerHome().create(customerID);
	}
	/**
	 * findHighInterest
	 * @generated
	 */
	public java.util.Collection findHighInterest(int interest)
		throws FinderException, RemoteException {
		return _acquireCustomerHome().findHighInterest(interest);
	}
	/**
	 * findByPrimaryKey
	 * @generated
	 */
	public itso.bank5.cmp.Customer findByPrimaryKey(
		itso.bank5.cmp.CustomerKey primaryKey)
		throws FinderException, RemoteException {
		return _acquireCustomerHome().findByPrimaryKey(primaryKey);
	}
}
