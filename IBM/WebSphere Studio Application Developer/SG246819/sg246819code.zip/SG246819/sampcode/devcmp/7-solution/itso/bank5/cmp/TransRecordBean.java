package itso.bank5.cmp;
/**
 * Bean implementation class for Enterprise Bean: TransRecord
 */
public abstract class TransRecordBean implements javax.ejb.EntityBean {
	private javax.ejb.EntityContext myEntityCtx;
	
	// random number generator for timestamp
	private java.util.Random random = new java.util.Random();
	
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		myEntityCtx = ctx;
	}
	/**
	 * getEntityContext
	 */
	public javax.ejb.EntityContext getEntityContext() {
		return myEntityCtx;
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		myEntityCtx = null;
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbCreate
	 */
	public java.sql.Timestamp ejbCreate(String type, java.math.BigDecimal amount, AccountLocal anAccount) 
						throws javax.ejb.CreateException {
		java.sql.Timestamp ts = new java.sql.Timestamp(System.currentTimeMillis());
		ts.setNanos( ts.getNanos() + random.nextInt(999999) );
		setTransID(ts);
		setTransType(type);
		setTransAmount(amount);
		return null;
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(String type, java.math.BigDecimal amount, AccountLocal anAccount)
		throws javax.ejb.CreateException {
		setTheAccount(anAccount);
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
	}
	/**
	 * Get accessor for persistent attribute: transID
	 */
	public abstract java.sql.Timestamp getTransID();
	/**
	 * Set accessor for persistent attribute: transID
	 */
	public abstract void setTransID(java.sql.Timestamp newTransID);
	/**
	 * Get accessor for persistent attribute: transType
	 */
	public abstract java.lang.String getTransType();
	/**
	 * Set accessor for persistent attribute: transType
	 */
	public abstract void setTransType(java.lang.String newTransType);
	/**
	 * Get accessor for persistent attribute: transAmount
	 */
	public abstract java.math.BigDecimal getTransAmount();
	/**
	 * Set accessor for persistent attribute: transAmount
	 */
	public abstract void setTransAmount(java.math.BigDecimal newTransAmount);
	/**
	 * ejbCreate
	 */
	public java.sql.Timestamp ejbCreate(java.sql.Timestamp transID)
		throws javax.ejb.CreateException {
		setTransID(transID);
		return null;
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(java.sql.Timestamp transID)
		throws javax.ejb.CreateException {
	}
	/**
	 * This method was generated for supporting the relationship role named theAccount.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract itso.bank5.cmp.AccountLocal getTheAccount();
	/**
	 * This method was generated for supporting the relationship role named theAccount.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract void setTheAccount(itso.bank5.cmp.AccountLocal aTheAccount);
}
