package itso.bank5.cmp;
/**
 * Home interface for Enterprise Bean: Customer
 */
public interface CustomerHome extends javax.ejb.EJBHome {
	/**
	 * Creates an instance from a key for Entity Bean: Customer
	 */
	public itso.bank5.cmp.Customer create(int customerID)
		throws javax.ejb.CreateException, java.rmi.RemoteException;
	/**
	 * Finds an instance using a key for Entity Bean: Customer
	 */
	public itso.bank5.cmp.Customer findByPrimaryKey(
		itso.bank5.cmp.CustomerKey primaryKey)
		throws javax.ejb.FinderException, java.rmi.RemoteException;
		
	// finder method
	public java.util.Collection findHighInterest(int interest)
		throws javax.ejb.FinderException, java.rmi.RemoteException;
}
