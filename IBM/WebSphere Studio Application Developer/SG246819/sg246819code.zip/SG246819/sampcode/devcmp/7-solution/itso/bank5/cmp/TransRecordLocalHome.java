package itso.bank5.cmp;
import itso.bank5.cmp.AccountLocal;
/**
 * Local Home interface for Enterprise Bean: TransRecord
 */
public interface TransRecordLocalHome extends javax.ejb.EJBLocalHome {
	/**
	 * Finds an instance using a key for Entity Bean: TransRecord
	 */
	public itso.bank5.cmp.TransRecordLocal findByPrimaryKey(
		java.sql.Timestamp primaryKey)
		throws javax.ejb.FinderException;
	/**
	 * Creates an instance from a key for Entity Bean: TransRecord
	 */
	public itso.bank5.cmp.TransRecordLocal create(java.sql.Timestamp transID)
		throws javax.ejb.CreateException;
	/**
	 * ejbCreate
	 */
	public itso.bank5.cmp.TransRecordLocal create(
		String type,
		java.math.BigDecimal amount,
		AccountLocal anAccount)
		throws javax.ejb.CreateException;
}
