package itso.bank5.cmp;
/**
 * Local Home interface for Enterprise Bean: Account
 */
public interface AccountLocalHome extends javax.ejb.EJBLocalHome {
	/**
	 * Creates an instance from a key for Entity Bean: Account
	 */
	public itso.bank5.cmp.AccountLocal create(java.lang.String accountID)
		throws javax.ejb.CreateException;
	/**
	 * Finds an instance using a key for Entity Bean: Account
	 */
	public itso.bank5.cmp.AccountLocal findByPrimaryKey(
		java.lang.String primaryKey)
		throws javax.ejb.FinderException;
	/**
	 * ejbCreate with parameters
	 */
	public itso.bank5.cmp.AccountLocal create(
		java.lang.String accountID,
		java.math.BigDecimal balance,
		int interest)
		throws javax.ejb.CreateException;
		
	// finder methods generated	
	public java.util.Collection findGoldAccounts(java.math.BigDecimal balance) throws javax.ejb.FinderException;
	public java.util.Collection findAllAccounts()
		throws javax.ejb.FinderException;
	public java.util.Collection findTransferAccounts(int customerID, java.lang.String accountID) throws javax.ejb.FinderException;
	public itso.bank5.cmp.AccountLocal findLargestAccount(int customerID) throws javax.ejb.FinderException;
}
