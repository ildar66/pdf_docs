package itso.bank5.cmp;
import itso.bank5.cmp.AccountLocal;
/**
 * Local interface for Enterprise Bean: Customer
 */
public interface CustomerLocal extends javax.ejb.EJBLocalObject {
	/**
	 * Get accessor for persistent attribute: firstName
	 */
	public java.lang.String getFirstName();
	/**
	 * Set accessor for persistent attribute: firstName
	 */
	public void setFirstName(java.lang.String newFirstName);
	/**
	 * Get accessor for persistent attribute: lastName
	 */
	public java.lang.String getLastName();
	/**
	 * Set accessor for persistent attribute: lastName
	 */
	public void setLastName(java.lang.String newLastName);
	/**
	 * Get accessor for persistent attribute: title
	 */
	public java.lang.String getTitle();
	/**
	 * Set accessor for persistent attribute: title
	 */
	public void setTitle(java.lang.String newTitle);
	/**
	 * Get accessor for persistent attribute: userID
	 */
	public java.lang.String getUserID();
	/**
	 * Set accessor for persistent attribute: userID
	 */
	public void setUserID(java.lang.String newUserID);
	/**
	 * Get accessor for persistent attribute: password
	 */
	public java.lang.String getPassword();
	/**
	 * Set accessor for persistent attribute: password
	 */
	public void setPassword(java.lang.String newPassword);
	/**
	 * Get accessor for persistent attribute: address
	 */
	public itso.bank5.beans.Address getAddress();
	/**
	 * Set accessor for persistent attribute: address
	 */
	public void setAddress(itso.bank5.beans.Address newAddress);

	/**
	 * retrieve full name
	 */
	public String getName();
	/**
	 * This method was generated for supporting the relationship role named accounts.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public java.util.Collection getAccounts();
	/**
	 * This method was generated for supporting the relationship role named accounts.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	// public void setAccounts(java.util.Collection anAccounts);
	
	public void addAccount(AccountLocal anAccount);
	public void removeAccount(AccountLocal anAccount);
}
