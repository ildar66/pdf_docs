package itso.bank5.cmp;
/**
 * Bean implementation class for Enterprise Bean: Account
 */
public abstract class AccountBean implements javax.ejb.EntityBean {
	private javax.ejb.EntityContext myEntityCtx;
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		myEntityCtx = ctx;
	}
	/**
	 * getEntityContext
	 */
	public javax.ejb.EntityContext getEntityContext() {
		return myEntityCtx;
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		myEntityCtx = null;
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbCreate
	 */
	public java.lang.String ejbCreate(java.lang.String accountID)
		throws javax.ejb.CreateException {
		setAccountID(accountID);
		setBalance( new java.math.BigDecimal(0.00) );
		setInterest(0);
		setAccountType("ACCOUNT");
		return null;
	}
	/**
	 * ejbCreate with parameters
	 */
	public java.lang.String ejbCreate(java.lang.String accountID, java.math.BigDecimal balance, int interest)
		throws javax.ejb.CreateException {
		setAccountID(accountID);
		setBalance(balance);
		setInterest(interest);
		setAccountType("ACCOUNT");
		return null;
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(java.lang.String accountID)
		throws javax.ejb.CreateException {
	}
	/**
	 * ejbPostCreate with parameters
	 */
	public void ejbPostCreate(java.lang.String accountID, java.math.BigDecimal balance, int interest)
		throws javax.ejb.CreateException {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
	}
	/**
	 * Get accessor for persistent attribute: accountID
	 */
	public abstract java.lang.String getAccountID();
	/**
	 * Set accessor for persistent attribute: accountID
	 */
	public abstract void setAccountID(java.lang.String newAccountID);
	/**
	 * Get accessor for persistent attribute: balance
	 */
	public abstract java.math.BigDecimal getBalance();
	/**
	 * Set accessor for persistent attribute: balance
	 */
	public abstract void setBalance(java.math.BigDecimal newBalance);
	/**
	 * Get accessor for persistent attribute: interest
	 */
	public abstract int getInterest();
	/**
	 * Set accessor for persistent attribute: interest
	 */
	public abstract void setInterest(int newInterest);
	/**
	 * Get accessor for persistent attribute: accountType
	 */
	public abstract java.lang.String getAccountType();
	/**
	 * Set accessor for persistent attribute: accountType
	 */
	public abstract void setAccountType(java.lang.String newAccountType);

	/**
	 * deposit funds
	 */
	public java.math.BigDecimal deposit(java.math.BigDecimal amount) {
		setBalance( getBalance().add(amount) );
		return getBalance();
	}
	
	/**
	 * withdraw funds
	 */
	public java.math.BigDecimal withdraw(java.math.BigDecimal amount) throws itso.bank5.exception.InsufficientFundException {
		if ( getBalance().compareTo(amount) == -1) 
			throw new itso.bank5.exception.InsufficientFundException("Not enough funds");
		else
			setBalance( getBalance().subtract(amount) );
		return getBalance();
	}
	
	/**
	 * This method was generated for supporting the relationship role named transrecords.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract java.util.Collection getTransrecords();
	/**
	 * This method was generated for supporting the relationship role named transrecords.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract void setTransrecords(java.util.Collection aTransrecords);
	/**
	 * This method was generated for supporting the relationship role named customers.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract java.util.Collection getCustomers();
	/**
	 * This method was generated for supporting the relationship role named customers.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract void setCustomers(java.util.Collection aCustomers);
	
	public void addCustomer(CustomerLocal aCustomer) {
		getCustomers().add(aCustomer);
	}
	public void removeCustomer(CustomerLocal aCustomer) {
		getCustomers().remove(aCustomer);
	}
}
