package itso.bank5.cmp;
/**
 * Local interface for Enterprise Bean: Savings
 */
public interface SavingsLocal extends itso.bank5.cmp.AccountLocal {
	/**
	 * Get accessor for persistent attribute: minAmount
	 */
	public java.math.BigDecimal getMinAmount();
	/**
	 * Set accessor for persistent attribute: minAmount
	 */
	public void setMinAmount(java.math.BigDecimal newMinAmount);
}
