package itso.bank5.cmp;
/**
 * Local Home interface for Enterprise Bean: Checking
 */
public interface CheckingLocalHome extends javax.ejb.EJBLocalHome {
	/**
	 * Finds an instance using a key for Entity Bean: Checking
	 */
	public itso.bank5.cmp.CheckingLocal findByPrimaryKey(
		java.lang.String primaryKey)
		throws javax.ejb.FinderException;
	/**
	 * ejbCreate with parameters
	 */
	public itso.bank5.cmp.CheckingLocal create(
		java.lang.String accountID,
		java.math.BigDecimal balance,
		int interest,
		java.math.BigDecimal overdraft)
		throws javax.ejb.CreateException;
}
