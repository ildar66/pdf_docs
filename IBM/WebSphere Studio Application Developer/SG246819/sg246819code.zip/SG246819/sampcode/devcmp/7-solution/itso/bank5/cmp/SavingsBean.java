package itso.bank5.cmp;
/**
 * Bean implementation class for Enterprise Bean: Savings
 */
public abstract class SavingsBean extends itso.bank5.cmp.AccountBean {
	/**
	 * Get accessor for persistent attribute: minAmount
	 */
	public abstract java.math.BigDecimal getMinAmount();
	/**
	 * Set accessor for persistent attribute: minAmount
	 */
	public abstract void setMinAmount(java.math.BigDecimal newMinAmount);
	
	/**
	 * ejbCreate with parameters
	 */
	public java.lang.String ejbCreate(java.lang.String accountID, java.math.BigDecimal balance, int interest, java.math.BigDecimal minAmount)
		throws javax.ejb.CreateException {
		super.ejbCreate(accountID, balance, interest);
		setAccountType("SAVINGS");
		setMinAmount(minAmount);
		return null;
	}
	/**
	 * ejbPostCreate with parameters
	 */
	public void ejbPostCreate(java.lang.String accountID, java.math.BigDecimal balance, int interest, java.math.BigDecimal minAmount)
		throws javax.ejb.CreateException {
	}

	/**
	 * withdraw funds
	 */
	public java.math.BigDecimal withdraw(java.math.BigDecimal amount) throws itso.bank5.exception.InsufficientFundException {
		if ( getBalance().subtract( getMinAmount() ).compareTo(amount) == -1) 
			throw new itso.bank5.exception.InsufficientFundException("Savings: Not enough funds - minAmount");
		else
			setBalance( getBalance().subtract(amount) );
		return getBalance();
	}
}
