package itso.bank5.cmp;
/**
 * Bean implementation class for Enterprise Bean: Checking
 */
public abstract class CheckingBean extends itso.bank5.cmp.AccountBean {
	/**
	 * Get accessor for persistent attribute: overdraft
	 */
	public abstract java.math.BigDecimal getOverdraft();
	/**
	 * Set accessor for persistent attribute: overdraft
	 */
	public abstract void setOverdraft(java.math.BigDecimal newOverdraft);
	
	/**
	 * ejbCreate with parameters
	 */
	public java.lang.String ejbCreate(java.lang.String accountID, java.math.BigDecimal balance, int interest, java.math.BigDecimal overdraft)
		throws javax.ejb.CreateException {
		super.ejbCreate(accountID, balance, interest);
		setAccountType("CHECKING");
		setOverdraft(overdraft);
		return null;
	}
	/**
	 * ejbPostCreate with parameters
	 */
	public void ejbPostCreate(java.lang.String accountID, java.math.BigDecimal balance, int interest, java.math.BigDecimal overdraft)
		throws javax.ejb.CreateException {
	}

	/**
	 * withdraw funds
	 */
	public java.math.BigDecimal withdraw(java.math.BigDecimal amount) throws itso.bank5.exception.InsufficientFundException {
		if ( getBalance().add( getOverdraft() ).compareTo(amount) == -1) 
			throw new itso.bank5.exception.InsufficientFundException("Checking: Not enough funds - overdraft");
		else
			setBalance( getBalance().subtract(amount) );
		return getBalance();
	}
}
