package itso.bank5.cmp;
/**
 * Local Home interface for Enterprise Bean: Customer
 */
public interface CustomerLocalHome extends javax.ejb.EJBLocalHome {
	/**
	 * Creates an instance from a key for Entity Bean: Customer
	 */
	public itso.bank5.cmp.CustomerLocal create(int customerID)
		throws javax.ejb.CreateException;
	/**
	 * Finds an instance using a key for Entity Bean: Customer
	 */
	public itso.bank5.cmp.CustomerLocal findByPrimaryKey(
		itso.bank5.cmp.CustomerKey primaryKey)
		throws javax.ejb.FinderException;
		
	// finder method
	public java.util.Collection findGoldCustomers(java.math.BigDecimal balance)
		throws javax.ejb.FinderException;
		
	// home method
	/**
	 * returns an Vector with array of strings: customerlastname, accountIDs
	 */
	public java.util.Vector getAllCustomers()
		throws javax.ejb.FinderException;
}
