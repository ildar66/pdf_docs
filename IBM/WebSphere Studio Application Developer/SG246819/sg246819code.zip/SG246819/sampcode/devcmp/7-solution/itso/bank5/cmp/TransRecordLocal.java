package itso.bank5.cmp;
/**
 * Local interface for Enterprise Bean: TransRecord
 */
public interface TransRecordLocal extends javax.ejb.EJBLocalObject {
	/**
	 * Get accessor for persistent attribute: transType
	 */
	public java.lang.String getTransType();
	/**
	 * Set accessor for persistent attribute: transType
	 */
	public void setTransType(java.lang.String newTransType);
	/**
	 * Get accessor for persistent attribute: transAmount
	 */
	public java.math.BigDecimal getTransAmount();
	/**
	 * Set accessor for persistent attribute: transAmount
	 */
	public void setTransAmount(java.math.BigDecimal newTransAmount);
	/**
	 * This method was generated for supporting the relationship role named theAccount.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public itso.bank5.cmp.AccountLocal getTheAccount();
	/**
	 * This method was generated for supporting the relationship role named theAccount.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	// public void setTheAccount(itso.bank5.cmp.AccountLocal aTheAccount);
}
