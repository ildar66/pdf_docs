package itso.bank5.cmp;
/**
 * Local Home interface for Enterprise Bean: Savings
 */
public interface SavingsLocalHome extends javax.ejb.EJBLocalHome {
	/**
	 * Finds an instance using a key for Entity Bean: Savings
	 */
	public itso.bank5.cmp.SavingsLocal findByPrimaryKey(
		java.lang.String primaryKey)
		throws javax.ejb.FinderException;

	/**
	 * ejbCreate with parameters
	 */
	public itso.bank5.cmp.SavingsLocal create(
		java.lang.String accountID,
		java.math.BigDecimal balance,
		int interest,
		java.math.BigDecimal minAmount)
		throws javax.ejb.CreateException;
}
