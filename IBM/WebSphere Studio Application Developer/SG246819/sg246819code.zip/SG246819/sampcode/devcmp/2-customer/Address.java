package itso.bank5.beans;

import java.io.Serializable;

/**
 * @author UELI
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class Address implements Serializable {
	private String street;
	private String city;
	private String state;
	private String zipcode;
	/**
	 * Constructor
	 **/
	public Address(String aStreet, String aCity, String aState, String aZipcode) {
		street  = aStreet;
		city    = aCity;
		state   = aState;
		zipcode = aZipcode;
	}
	/**
	 * Returns the city.
	 * @return String
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Returns the state.
	 * @return String
	 */
	public String getState() {
		return state;
	}

	/**
	 * Returns the street.
	 * @return String
	 */
	public String getStreet() {
		return street;
	}

	/**
	 * Returns the zipcode.
	 * @return String
	 */
	public String getZipcode() {
		return zipcode;
	}

	/**
	 * Sets the city.
	 * @param city The city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Sets the state.
	 * @param state The state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Sets the street.
	 * @param street The street to set
	 */
	public void setStreet(String street) {
		this.street = street;
	}

	/**
	 * Sets the zipcode.
	 * @param zipcode The zipcode to set
	 */
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

}
