package itso.bank5.utility;

import java.io.Serializable;
import java.math.BigDecimal;

public class TransferDataObject implements Serializable {
	// data variables
	private String fromAccount = null; // the account from which money is transferred
	private String toAccount   = null; // the account into which transferred money goes
	private BigDecimal amount  = null; // the amount to be transferred
	
	//constructor
	public TransferDataObject(String from, String to, BigDecimal amt) {
		fromAccount = from;
		toAccount = to;
		amount = amt;
	}

	public BigDecimal getAmount() {
		return amount;
	}
	public String getFromAccount() {
		return fromAccount;
	}
	public String getToAccount() {
		return toAccount;
	}

}
