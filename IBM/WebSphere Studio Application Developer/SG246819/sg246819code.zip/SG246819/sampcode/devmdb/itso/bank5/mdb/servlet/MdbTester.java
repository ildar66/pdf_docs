package itso.bank5.mdb.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import javax.jms.*;
import itso.bank5.utility.*;
import java.math.BigDecimal;
import javax.naming.*;

/**
 * @version 	1.0
 * @author
 */
public class MdbTester extends HttpServlet {

	private static final String QUEUECONNECTIONFACTORY = "jms/ItsoMdbConnectionFactoryRef";
	private static final String SENDQUEUE              = "jms/ItsoMdbQueueRef";
	private static final String RESPONSEQUEUE          = "jms/ItsoResponseQueueRef";
	
	private InitialContext initialContext = null;

	/**
	* @see javax.servlet.http.HttpServlet#void (javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	*/
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
									throws ServletException, IOException {
			
		String fromAccount = "101-1002";
		String toAccount   = "101-1001";
		BigDecimal amount  = new BigDecimal(10.00);
		
		String messageID = null;
		String selector  = null;
		boolean verbose = true;
		QueueSession session = null;
		QueueConnection connection = null;
		PrintWriter out = resp.getWriter();
		
		try {
			out.println("<html><body><h1>MDB Tester</h1>");
			// Attempt to retrieve ConnectionFactory and Queues from the JNDI namespace
			if (verbose) System.out.println("Tester: Retrieving a QueueConnectionFactory from JNDI");
			//QueueConnectionFactory qcf = (QueueConnectionFactory)HomeFactory.singleton().getJMS(QUEUECONNECTIONFACTORY); 
			QueueConnectionFactory qcf = (QueueConnectionFactory)getJMS(QUEUECONNECTIONFACTORY); 
			if (qcf == null) System.out.println("Tester: Failed to retrieve a QueueConnectionFactory from JNDI");

			if (verbose) System.out.println("Tester: Retrieving Queues from JNDI");
			//Queue outQueue = (Queue)HomeFactory.singleton().getJMS(SENDQUEUE);
			//Queue inQueue  = (Queue)HomeFactory.singleton().getJMS(RESPONSEQUEUE);
			Queue outQueue = (Queue)getJMS(SENDQUEUE);
			Queue inQueue  = (Queue)getJMS(RESPONSEQUEUE);
			out.println("Got factory and queues");
			
			// Create a QueueConnection from the QueueConnectionFactory
			connection = qcf.createQueueConnection();

			// IMPORTANT: Receive calls will be blocked if the connection is
			// not explicitly started, so make sure its started.
			connection.start();

			// Create a QueueSession from the connection.
			// Not transacted, and acknowledge received messages
			boolean transacted = false;
			session = connection.createQueueSession( transacted, Session.AUTO_ACKNOWLEDGE);

			// Use the session to create a QueueSender, passing in the Queue as parameter
			QueueSender queueSender = session.createSender(outQueue);

			// assemble our parameters
			TransferDataObject transferMsg = new TransferDataObject(fromAccount, toAccount, amount);
			out.println("<br>Prepare msg "+fromAccount+"/"+toAccount+"/"+amount);
			
			// use the session to create our objectmessage
			ObjectMessage outMessage = session.createObjectMessage(transferMsg);

			// tell the MDB what business method we want it to call, set correlation ID
			outMessage.setStringProperty("BUSINESSMETHOD", "transfer");
			selector = "CORR:TF"+ (new java.util.Random()).nextInt(999999);
			outMessage.setJMSCorrelationID(selector);
			out.println("<br>Sending message to "+outQueue.getQueueName());

			// send the message
			if (verbose) System.out.println("Tester: Sending the message to " + outQueue.getQueueName());
			queueSender.send(outMessage);

			// get message id 
			messageID = outMessage.getJMSMessageID();
			out.println("<br>Sent message "+messageID+"/"+selector);

			// Message sent, let's read the response message using the correlation ID
			if (verbose) System.out.println("Tester: Receiving message from " + inQueue.getQueueName());
			selector = "JMSCorrelationID = '" + selector + "'";
			QueueReceiver queueReceiver = session.createReceiver(inQueue, selector);

			// Use the QueueReceiver to retrieve the message, blocking for a maximum of 5000ms. 
			// The receive call returns when the message arrives, or after X ms
			if (verbose) System.out.println("Tester: Waiting for  message");
			out.println("<br>Waiting for response from "+inQueue.getQueueName());
			
			Message inMessage = queueReceiver.receive(15000);

			// Check to see if the receive call has actually returned a message.
			if (inMessage == null) {
				System.out.println("Tester: The attempt to read the message failed");
				out.println("<br>Failed to retrieve message");
				throw new JMSException("Failed to retrieve message.");
			}

			if (inMessage instanceof TextMessage) {
				// Extract the message content with getText()
				String replyString = ((TextMessage) inMessage).getText();
				if (verbose) System.out.println("Tester: Reply = '" + replyString + "'");
				out.println("<br>Reply: "+replyString);
				
			} else {
				// Report that the incoming message was not of the expected type, and throw an exception
				System.out.println("Tester: Reply message was not a TextMessage");
				out.println("<br>Reply message was not a TextMessage");
				throw new JMSException("Tester: Retrieved the wrong type of message");
			}

			// Call the close() method on all of the objects.
			queueReceiver.close();
			queueSender.close();
			session.close();
			session = null;
			connection.close();
			connection = null;

			System.out.println("Tester: Done");
		} catch (JMSException e) {
			System.out.println("Tester: JMS failed with " + e);
			out.println("<br>JMS failed with " + e);
			Exception le = e.getLinkedException();
			if (le != null) System.out.println("linked exception " + le);
		} catch (Exception exc) {
			System.out.println("Tester: Unexpected error " + exc);
			out.println("<br>Unexpected error " + exc);
		} finally {
			//  Ensure JMS objects are closed
			try {
				if (session != null) session.close();
				if (connection != null) connection.close();
			} catch (JMSException e) {
				System.out.println("Tester: Unexpected error, failed with " + e);
			}
			out.println("<br>MDB Tester done</body></html>");
		}
	}

	private Object getJMS(String jmsRef) throws NamingException {
		if (initialContext == null) initialContext = new InitialContext();
		Object nsObject =
				initialContext.lookup(
					new StringBuffer("java:comp/env/")
						.append(jmsRef)
						.toString());
		System.out.println("class=" + nsObject.getClass());
		return nsObject;
	}
	
}
