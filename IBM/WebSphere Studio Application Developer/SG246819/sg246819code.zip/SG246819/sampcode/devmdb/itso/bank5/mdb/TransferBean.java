package itso.bank5.mdb;

import javax.jms.*;
import itso.bank5.session.*;
import itso.bank5.utility.*;
import java.math.BigDecimal;

/**
 * Bean implementation class for Enterprise Bean: Transfer
 */
public class TransferBean implements javax.ejb.MessageDrivenBean, javax.jms.MessageListener {
		
	private javax.ejb.MessageDrivenContext fMessageDrivenCtx;
	
	private static final String QUEUECONNECTIONFACTORY = "jms/ItsoMdbConnectionFactoryRef";
	private static final String RESPONSEQUEUE          = "jms/ItsoResponseQueueRef";

	private BankingHome            bankingHome = null;
	private QueueConnectionFactory qcf         = null;
	private Queue                  sendQueue   = null;
	
	/**
	 * getMessageDrivenContext
	 */
	public javax.ejb.MessageDrivenContext getMessageDrivenContext() {
		return fMessageDrivenCtx;
	}
	/**
	 * setMessageDrivenContext
	 */
	public void setMessageDrivenContext(javax.ejb.MessageDrivenContext ctx) {
		fMessageDrivenCtx = ctx;
	}
	/**
	 * ejbCreate
	 */
	public void ejbCreate() {
		initialize();
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() {
	}

	/**
	 * onMessage
	 */
	public void onMessage(javax.jms.Message msg) {
		String messageID = null;
		String selector  = null;
		System.out.println("MDB onMessage");
	
		try {
			messageID = msg.getJMSMessageID();
			selector  = msg.getJMSCorrelationID();
			ObjectMessage objectMessage = (ObjectMessage)msg;
			// JMS property for business method
			String businessMethod = msg.getStringProperty("BUSINESSMETHOD");
			if ( businessMethod.equalsIgnoreCase("transfer") ) {
				System.out.println("MDB got a transfer message: "+messageID +"/"+ selector);
				TransferDataObject transferMsg = (TransferDataObject)objectMessage.getObject();
				String fromAccount = transferMsg.getFromAccount();
				String toAccount   = transferMsg.getToAccount();
				BigDecimal amount  = transferMsg.getAmount();
				System.out.println("MDB got parms: "+ fromAccount+"/"+toAccount+"/"+amount);
				Banking bank = bankingHome.create();
				System.out.println("MDB got session bean");
				BigDecimal balance = bank.transfer( fromAccount, toAccount, amount );
				//BigDecimal balance = new BigDecimal(99.00);
				System.out.println("MDB did the transfer: " + balance);
				String response = "Transfer OK: " + amount + " from/to " + fromAccount + "/" + toAccount + " Balance=" + balance;
				sendResponseMessage(selector, response);
			} else {
				System.out.println("MDB got a wrong message: "+businessMethod);
			}
		} catch (Exception e) {
			System.out.println("MDB exception: " + e.getMessage());
			e.printStackTrace();
			if ( messageID != null ) {
				sendResponseMessage(selector, "ERROR: " + e.getMessage());
			}
		}
	}
			
	private void sendResponseMessage(String corrid, String text) {
		System.out.println("MDB response " + corrid +": " + text);
		QueueConnection qc      = null;
		QueueSession    session = null;
		QueueSender     sender  = null;

		try {
			// Create a connection
			qc = qcf.createQueueConnection();
			qc.start();

			// Create a session.
			session = qc.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);

			// Create a QueueSender
			System.out.println("MDB creating queue sender");
			sender = session.createSender(sendQueue);

			// Create a message to send to the queue...
			TextMessage message = session.createTextMessage(text);

			// Set CorrelationID from the input message and send
			System.out.println("MDB sending message to queue");
			message.setJMSCorrelationID(corrid);
			sender.send(message);

			// Close the connection (close calls will cascade to other objects)
			sender.close();
			session.close();
			qc.close();
			qc = null;

			System.out.println("MDB Send done");
		} catch (JMSException e) {
			System.out.println("MDB JMSException - send message failed with " + e);
			Exception le = e.getLinkedException();
			if (le != null)
				System.out.println("MDB linked exception " + le);
		} catch (Exception e) {
			System.out.println("MDB exception: " + e);
		} finally {
			// Ensure that the Connection always gets closed
			if (qc != null) {
				try { qc.close(); } catch (JMSException e) {}
			}
		}
	} 		
			
	private void initialize() {
		try {
			System.out.println("MDB initialize");
			bankingHome = (BankingHome)HomeFactory.singleton().getHome("ejb/Banking");
			System.out.println("MDB found session bean home");
			qcf = (QueueConnectionFactory)HomeFactory.singleton().getJMS(QUEUECONNECTIONFACTORY);
			System.out.println("MDB found QueueConnectionFactory");
			sendQueue = (Queue)HomeFactory.singleton().getJMS(RESPONSEQUEUE);
			System.out.println("MDB found ResponseQueue");
		} catch (javax.naming.NamingException e) {
			System.out.println("MDB initialization failed: " + e.getMessage());
			e.printStackTrace();
		}
	}

}
