package itso.bank5.composer;
/**
 * Local Home interface for Enterprise Bean: CustomerComposer
 */
public interface CustomerComposerLocalHome extends javax.ejb.EJBLocalHome {
	/**
	 * Creates an instance from a key for Entity Bean: CustomerComposer
	 */
	public itso.bank5.composer.CustomerComposerLocal create(int customerid)
		throws javax.ejb.CreateException;
	/**
	 * Finds an instance using a key for Entity Bean: CustomerComposer
	 */
	public itso.bank5.composer.CustomerComposerLocal findByPrimaryKey(
		itso.bank5.composer.CustomerComposerKey primaryKey)
		throws javax.ejb.FinderException;
}
