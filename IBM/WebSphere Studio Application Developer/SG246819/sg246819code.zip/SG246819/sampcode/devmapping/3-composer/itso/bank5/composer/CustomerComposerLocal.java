package itso.bank5.composer;
/**
 * Local interface for Enterprise Bean: CustomerComposer
 */
public interface CustomerComposerLocal extends javax.ejb.EJBLocalObject {
	/**
	 * Get accessor for persistent attribute: title
	 */
	public java.lang.String getTitle();
	/**
	 * Set accessor for persistent attribute: title
	 */
	public void setTitle(java.lang.String newTitle);
	/**
	 * Get accessor for persistent attribute: firstName
	 */
	public java.lang.String getFirstName();
	/**
	 * Set accessor for persistent attribute: firstName
	 */
	public void setFirstName(java.lang.String newFirstName);
	/**
	 * Get accessor for persistent attribute: lastName
	 */
	public java.lang.String getLastName();
	/**
	 * Set accessor for persistent attribute: lastName
	 */
	public void setLastName(java.lang.String newLastName);
	/**
	 * Get accessor for persistent attribute: address
	 */
	public itso.bank5.beans.Address getAddress();
	/**
	 * Set accessor for persistent attribute: address
	 */
	public void setAddress(itso.bank5.beans.Address newAddress);
}
