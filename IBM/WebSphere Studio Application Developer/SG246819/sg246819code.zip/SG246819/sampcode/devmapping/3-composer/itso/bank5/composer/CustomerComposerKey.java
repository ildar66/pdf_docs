package itso.bank5.composer;
/**
 * Key class for Entity Bean: CustomerComposer
 */
public class CustomerComposerKey implements java.io.Serializable {
	static final long serialVersionUID = 3206093459760846163L;
	/**
	 * Implementation field for persistent attribute: customerid
	 */
	public int customerid;
	/**
	 * Creates an empty key for Entity Bean: CustomerComposer
	 */
	public CustomerComposerKey() {
	}
	/**
	 * Creates a key for Entity Bean: CustomerComposer
	 */
	public CustomerComposerKey(int customerid) {
		this.customerid = customerid;
	}
	/**
	 * Returns true if both keys are equal.
	 */
	public boolean equals(java.lang.Object otherKey) {
		if (otherKey instanceof itso.bank5.composer.CustomerComposerKey) {
			itso.bank5.composer.CustomerComposerKey o =
				(itso.bank5.composer.CustomerComposerKey) otherKey;
			return ((this.customerid == o.customerid));
		}
		return false;
	}
	/**
	 * Returns the hash code for the key.
	 */
	public int hashCode() {
		return ((new java.lang.Integer(customerid).hashCode()));
	}
	/**
	 * Get accessor for persistent attribute: customerid
	 */
	public int getCustomerid() {
		return customerid;
	}
	/**
	 * Set accessor for persistent attribute: customerid
	 */
	public void setCustomerid(int newCustomerid) {
		customerid = newCustomerid;
	}
}
