package itso.bank5.composer;
/**
 * Bean implementation class for Enterprise Bean: CustomerComposer
 */
public abstract class CustomerComposerBean implements javax.ejb.EntityBean {
	private javax.ejb.EntityContext myEntityCtx;
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		myEntityCtx = ctx;
	}
	/**
	 * getEntityContext
	 */
	public javax.ejb.EntityContext getEntityContext() {
		return myEntityCtx;
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		myEntityCtx = null;
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbCreate
	 */
	public itso.bank5.composer.CustomerComposerKey ejbCreate(int customerid)
		throws javax.ejb.CreateException {
		setCustomerid(customerid);
		return null;
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(int customerid)
		throws javax.ejb.CreateException {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
	}
	/**
	 * Get accessor for persistent attribute: customerid
	 */
	public abstract int getCustomerid();
	/**
	 * Set accessor for persistent attribute: customerid
	 */
	public abstract void setCustomerid(int newCustomerid);
	/**
	 * Get accessor for persistent attribute: title
	 */
	public abstract java.lang.String getTitle();
	/**
	 * Set accessor for persistent attribute: title
	 */
	public abstract void setTitle(java.lang.String newTitle);
	/**
	 * Get accessor for persistent attribute: firstName
	 */
	public abstract java.lang.String getFirstName();
	/**
	 * Set accessor for persistent attribute: firstName
	 */
	public abstract void setFirstName(java.lang.String newFirstName);
	/**
	 * Get accessor for persistent attribute: lastName
	 */
	public abstract java.lang.String getLastName();
	/**
	 * Set accessor for persistent attribute: lastName
	 */
	public abstract void setLastName(java.lang.String newLastName);
	/**
	 * Get accessor for persistent attribute: address
	 */
	public abstract itso.bank5.beans.Address getAddress();
	/**
	 * Set accessor for persistent attribute: address
	 */
	public abstract void setAddress(itso.bank5.beans.Address newAddress);
}
