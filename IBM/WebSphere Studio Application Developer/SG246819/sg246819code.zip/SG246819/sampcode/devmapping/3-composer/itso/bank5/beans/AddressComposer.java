package itso.bank5.beans;



/**
 * AddressComposer
 * @generated
 */
public class AddressComposer
	extends com.ibm.vap.composers.VapAttributeComposer {
	static AddressComposer singleton = null;
	/**
	 * Return the target class name. This should return the name of the class for the instance instanciated 
	 * as a result of the objectFrom: message sent to the composer. 
	 */
	public static String getTargetClassName() {
		return "itso.bank5.beans.Address";
	}
	/**
	 * Answer the appropriate collection of objects that are to go TO a datastore fields. 
	 * Note that this is an object to object collection conversion. The conversion to persistent 
	 * format (strings in the case of SQL) occurs elsewhere. The default is to do nothing. 
	 */
	public Object[] dataFrom (Object anObject) {
		Object[] anArray = new Object[] {null, null, null, null};
		if (anObject != null) {
			Address address = (Address) anObject;
			anArray[0] = address.getZipcode();
			anArray[1] = address.getState();
			anArray[2] = address.getCity();
			anArray[3] = address.getStreet();
		}
		return anArray;
	}
	/** 
	 * Answer the list of attribute names for my target class. 
	 * @return java.lang.String[] 
	 */
	public static String[] getAttributeNames() {
		String[] attributes = { "zipcode", "state", "city", "street" };
		return attributes;
	}
	/** 
	 * Return the data elements class name. This should return the name of the class for the data element 
	 * passed as a parameter to the objectFrom: message sent to the composer. 
	 */
	public static String[] getSourceDatatype() {
		String[] types =
			{
				"java.lang.String",
				"java.lang.String",
				"java.lang.String",
				"java.lang.String" };
		return types;
	}
	/** 
	 * Use the collection of data values to instantiate an Object. The default 
	 * does nothing but return the collection. 
	 */
	public Object objectFrom (Object[] anArray) {
		String name, street, city, state, zipcode;
		zipcode = (String) anArray[0];
		state   = (String) anArray[1];
		city    = (String) anArray[2];
		street  = (String) anArray[3];
		return new Address(street, city, state, zipcode);
	}
	/** 
	 * Set the singleton variable to null. 
	 * This is required by each subclass. 
	 */
	public static void reset() {
		singleton = null;
	}
	/** 
	 * Singleton method to return instance of the composer 
	 */
	public static AddressComposer singleton() {
		if (singleton == null)
			singleton = new AddressComposer();
		return singleton;
	}
}
