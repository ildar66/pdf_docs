package itso.bank5.bottom;
/**
 * Local interface for Enterprise Bean: Account
 */
public interface AccountLocal extends javax.ejb.EJBLocalObject {
	/**
	 * Get accessor for persistent attribute: balance
	 */
	public java.math.BigDecimal getBalance();
	/**
	 * Set accessor for persistent attribute: balance
	 */
	public void setBalance(java.math.BigDecimal newBalance);
	/**
	 * Get accessor for persistent attribute: interest
	 */
	public java.lang.Integer getInterest();
	/**
	 * Set accessor for persistent attribute: interest
	 */
	public void setInterest(java.lang.Integer newInterest);
	/**
	 * Get accessor for persistent attribute: acctype
	 */
	public java.lang.String getAcctype();
	/**
	 * Set accessor for persistent attribute: acctype
	 */
	public void setAcctype(java.lang.String newAcctype);
	/**
	 * This method was generated for supporting the relationship role named transrecords.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public java.util.Collection getTransrecords();
	/**
	 * This method was generated for supporting the relationship role named transrecords.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public void setTransrecords(java.util.Collection aTransrecords);
	/**
	 * This method was generated for supporting the relationship role named customers.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public java.util.Collection getCustomers();
	/**
	 * This method was generated for supporting the relationship role named customers.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public void setCustomers(java.util.Collection aCustomers);
}
