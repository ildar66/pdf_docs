package itso.bank5.bottom;
/**
 * Key class for Entity Bean: Account
 */
public class AccountKey implements java.io.Serializable {
	static final long serialVersionUID = 3206093459760846163L;
	/**
	 * Implementation field for persistent attribute: accid
	 */
	public java.lang.String accid;
	/**
	 * Creates an empty key for Entity Bean: Account
	 */
	public AccountKey() {
	}
	/**
	 * Creates a key for Entity Bean: Account
	 */
	public AccountKey(java.lang.String accid) {
		this.accid = accid;
	}
	/**
	 * Returns true if both keys are equal.
	 */
	public boolean equals(java.lang.Object otherKey) {
		if (otherKey instanceof itso.bank5.bottom.AccountKey) {
			itso.bank5.bottom.AccountKey o =
				(itso.bank5.bottom.AccountKey) otherKey;
			return ((this.accid.equals(o.accid)));
		}
		return false;
	}
	/**
	 * Returns the hash code for the key.
	 */
	public int hashCode() {
		return (accid.hashCode());
	}
	/**
	 * Get accessor for persistent attribute: accid
	 */
	public java.lang.String getAccid() {
		return accid;
	}
	/**
	 * Set accessor for persistent attribute: accid
	 */
	public void setAccid(java.lang.String newAccid) {
		accid = newAccid;
	}
}
