package itso.bank5.bottom;
/**
 * Bean implementation class for Enterprise Bean: Customer
 */
public abstract class CustomerBean implements javax.ejb.EntityBean {
	private javax.ejb.EntityContext myEntityCtx;
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		myEntityCtx = ctx;
	}
	/**
	 * getEntityContext
	 */
	public javax.ejb.EntityContext getEntityContext() {
		return myEntityCtx;
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		myEntityCtx = null;
	}
	/**
	 * ejbCreate
	 */
	public itso.bank5.bottom.CustomerKey ejbCreate(
		java.lang.Integer customerid)
		throws javax.ejb.CreateException {
		setCustomerid(customerid);
		return null;
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(java.lang.Integer customerid)
		throws javax.ejb.CreateException {
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
	}
	/**
	 * ejbCreate method for a CMP entity bean.
	 */
	public itso.bank5.bottom.CustomerKey ejbCreate(
		java.lang.Integer customerid,
		java.lang.String title,
		java.lang.String firstname,
		java.lang.String lastname)
		throws javax.ejb.CreateException {
		setCustomerid(customerid);
		setTitle(title);
		setFirstname(firstname);
		setLastname(lastname);
		return null;
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(
		java.lang.Integer customerid,
		java.lang.String title,
		java.lang.String firstname,
		java.lang.String lastname)
		throws javax.ejb.CreateException {
	}
	/**
	 * Get accessor for persistent attribute: customerid
	 */
	public abstract java.lang.Integer getCustomerid();
	/**
	 * Set accessor for persistent attribute: customerid
	 */
	public abstract void setCustomerid(java.lang.Integer newCustomerid);
	/**
	 * Get accessor for persistent attribute: title
	 */
	public abstract java.lang.String getTitle();
	/**
	 * Set accessor for persistent attribute: title
	 */
	public abstract void setTitle(java.lang.String newTitle);
	/**
	 * Get accessor for persistent attribute: firstname
	 */
	public abstract java.lang.String getFirstname();
	/**
	 * Set accessor for persistent attribute: firstname
	 */
	public abstract void setFirstname(java.lang.String newFirstname);
	/**
	 * Get accessor for persistent attribute: lastname
	 */
	public abstract java.lang.String getLastname();
	/**
	 * Set accessor for persistent attribute: lastname
	 */
	public abstract void setLastname(java.lang.String newLastname);
	/**
	 * Get accessor for persistent attribute: userid
	 */
	public abstract java.lang.String getUserid();
	/**
	 * Set accessor for persistent attribute: userid
	 */
	public abstract void setUserid(java.lang.String newUserid);
	/**
	 * Get accessor for persistent attribute: password
	 */
	public abstract java.lang.String getPassword();
	/**
	 * Set accessor for persistent attribute: password
	 */
	public abstract void setPassword(java.lang.String newPassword);
	/**
	 * This method was generated for supporting the relationship role named accounts.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract java.util.Collection getAccounts();
	/**
	 * This method was generated for supporting the relationship role named accounts.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract void setAccounts(java.util.Collection anAccounts);
	/**
	 * Get accessor for persistent attribute: street
	 */
	public abstract java.lang.String getStreet();
	/**
	 * Set accessor for persistent attribute: street
	 */
	public abstract void setStreet(java.lang.String newStreet);
	/**
	 * Get accessor for persistent attribute: city
	 */
	public abstract java.lang.String getCity();
	/**
	 * Set accessor for persistent attribute: city
	 */
	public abstract void setCity(java.lang.String newCity);
	/**
	 * Get accessor for persistent attribute: state
	 */
	public abstract java.lang.String getState();
	/**
	 * Set accessor for persistent attribute: state
	 */
	public abstract void setState(java.lang.String newState);
	/**
	 * Get accessor for persistent attribute: zipcode
	 */
	public abstract java.lang.String getZipcode();
	/**
	 * Set accessor for persistent attribute: zipcode
	 */
	public abstract void setZipcode(java.lang.String newZipcode);
}
