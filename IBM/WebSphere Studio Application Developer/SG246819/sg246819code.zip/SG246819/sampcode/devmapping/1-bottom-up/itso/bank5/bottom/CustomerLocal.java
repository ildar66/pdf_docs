package itso.bank5.bottom;
/**
 * Local interface for Enterprise Bean: Customer
 */
public interface CustomerLocal extends javax.ejb.EJBLocalObject {
	/**
	 * Get accessor for persistent attribute: title
	 */
	public java.lang.String getTitle();
	/**
	 * Set accessor for persistent attribute: title
	 */
	public void setTitle(java.lang.String newTitle);
	/**
	 * Get accessor for persistent attribute: firstname
	 */
	public java.lang.String getFirstname();
	/**
	 * Set accessor for persistent attribute: firstname
	 */
	public void setFirstname(java.lang.String newFirstname);
	/**
	 * Get accessor for persistent attribute: lastname
	 */
	public java.lang.String getLastname();
	/**
	 * Set accessor for persistent attribute: lastname
	 */
	public void setLastname(java.lang.String newLastname);
	/**
	 * Get accessor for persistent attribute: userid
	 */
	public java.lang.String getUserid();
	/**
	 * Set accessor for persistent attribute: userid
	 */
	public void setUserid(java.lang.String newUserid);
	/**
	 * Get accessor for persistent attribute: password
	 */
	public java.lang.String getPassword();
	/**
	 * Set accessor for persistent attribute: password
	 */
	public void setPassword(java.lang.String newPassword);
	/**
	 * This method was generated for supporting the relationship role named accounts.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public java.util.Collection getAccounts();
	/**
	 * This method was generated for supporting the relationship role named accounts.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public void setAccounts(java.util.Collection anAccounts);
	/**
	 * Get accessor for persistent attribute: street
	 */
	public java.lang.String getStreet();
	/**
	 * Set accessor for persistent attribute: street
	 */
	public void setStreet(java.lang.String newStreet);
	/**
	 * Get accessor for persistent attribute: city
	 */
	public java.lang.String getCity();
	/**
	 * Set accessor for persistent attribute: city
	 */
	public void setCity(java.lang.String newCity);
	/**
	 * Get accessor for persistent attribute: state
	 */
	public java.lang.String getState();
	/**
	 * Set accessor for persistent attribute: state
	 */
	public void setState(java.lang.String newState);
	/**
	 * Get accessor for persistent attribute: zipcode
	 */
	public java.lang.String getZipcode();
	/**
	 * Set accessor for persistent attribute: zipcode
	 */
	public void setZipcode(java.lang.String newZipcode);
}
