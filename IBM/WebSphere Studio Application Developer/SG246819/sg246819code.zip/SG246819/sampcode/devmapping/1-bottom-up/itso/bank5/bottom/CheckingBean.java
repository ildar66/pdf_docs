package itso.bank5.bottom;
/**
 * Bean implementation class for Enterprise Bean: Checking
 */
public abstract class CheckingBean extends itso.bank5.bottom.AccountBean {


	/**
	 * ejbCreate
	 */
	public itso.bank5.bottom.AccountKey ejbCreate(
		java.lang.String checkingaccount_accid,
		java.math.BigDecimal overdraft)
		throws javax.ejb.CreateException {
		setOverdraft(overdraft);
		return null;
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(
		java.lang.String checkingaccount_accid,
		java.math.BigDecimal overdraft)
		throws javax.ejb.CreateException {
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
	}
	/**
	 * ejbCreate method for a CMP entity bean.
	 */
	public itso.bank5.bottom.AccountKey ejbCreate(
		itso.bank5.bottom.AccountLocal argCheckingaccount,
		java.math.BigDecimal overdraft)
		throws javax.ejb.CreateException {
		setOverdraft(overdraft);
		itso.bank5.bottom.AccountKey argCheckingaccountPK =
			(itso.bank5.bottom.AccountKey) argCheckingaccount.getPrimaryKey();
		return null;
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(
		itso.bank5.bottom.AccountLocal argCheckingaccount,
		java.math.BigDecimal overdraft)
		throws javax.ejb.CreateException {
	}
	/**
	 * Get accessor for persistent attribute: overdraft
	 */
	public abstract java.math.BigDecimal getOverdraft();
	/**
	 * Set accessor for persistent attribute: overdraft
	 */
	public abstract void setOverdraft(java.math.BigDecimal newOverdraft);
}
