package itso.bank5.bottom;
/**
 * Local interface for Enterprise Bean: Savings
 */
public interface SavingsLocal extends itso.bank5.bottom.AccountLocal {


	/**
	 * Get accessor for persistent attribute: minamount
	 */
	public java.math.BigDecimal getMinamount();
	/**
	 * Set accessor for persistent attribute: minamount
	 */
	public void setMinamount(java.math.BigDecimal newMinamount);
}
