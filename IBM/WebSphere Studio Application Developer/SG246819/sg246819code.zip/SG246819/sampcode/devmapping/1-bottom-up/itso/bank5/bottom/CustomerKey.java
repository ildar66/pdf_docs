package itso.bank5.bottom;
/**
 * Key class for Entity Bean: Customer
 */
public class CustomerKey implements java.io.Serializable {
	static final long serialVersionUID = 3206093459760846163L;
	/**
	 * Implementation field for persistent attribute: customerid
	 */
	public java.lang.Integer customerid;
	/**
	 * Creates an empty key for Entity Bean: Customer
	 */
	public CustomerKey() {
	}
	/**
	 * Creates a key for Entity Bean: Customer
	 */
	public CustomerKey(java.lang.Integer customerid) {
		this.customerid = customerid;
	}
	/**
	 * Returns true if both keys are equal.
	 */
	public boolean equals(java.lang.Object otherKey) {
		if (otherKey instanceof itso.bank5.bottom.CustomerKey) {
			itso.bank5.bottom.CustomerKey o =
				(itso.bank5.bottom.CustomerKey) otherKey;
			return ((this.customerid.equals(o.customerid)));
		}
		return false;
	}
	/**
	 * Returns the hash code for the key.
	 */
	public int hashCode() {
		return (customerid.hashCode());
	}
	/**
	 * Get accessor for persistent attribute: customerid
	 */
	public java.lang.Integer getCustomerid() {
		return customerid;
	}
	/**
	 * Set accessor for persistent attribute: customerid
	 */
	public void setCustomerid(java.lang.Integer newCustomerid) {
		customerid = newCustomerid;
	}
}
