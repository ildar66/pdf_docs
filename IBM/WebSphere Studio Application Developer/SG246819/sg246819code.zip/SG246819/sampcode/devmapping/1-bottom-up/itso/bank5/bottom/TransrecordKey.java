package itso.bank5.bottom;
/**
 * Key class for Entity Bean: Transrecord
 */
public class TransrecordKey implements java.io.Serializable {
	static final long serialVersionUID = 3206093459760846163L;
	/**
	 * Implementation field for persistent attribute: transid
	 */
	public java.sql.Timestamp transid;
	/**
	 * Creates an empty key for Entity Bean: Transrecord
	 */
	public TransrecordKey() {
	}
	/**
	 * Creates a key for Entity Bean: Transrecord
	 */
	public TransrecordKey(java.sql.Timestamp transid) {
		this.transid = transid;
	}
	/**
	 * Returns true if both keys are equal.
	 */
	public boolean equals(java.lang.Object otherKey) {
		if (otherKey instanceof itso.bank5.bottom.TransrecordKey) {
			itso.bank5.bottom.TransrecordKey o =
				(itso.bank5.bottom.TransrecordKey) otherKey;
			return ((this.transid.equals(o.transid)));
		}
		return false;
	}
	/**
	 * Returns the hash code for the key.
	 */
	public int hashCode() {
		return (transid.hashCode());
	}
	/**
	 * Get accessor for persistent attribute: transid
	 */
	public java.sql.Timestamp getTransid() {
		return transid;
	}
	/**
	 * Set accessor for persistent attribute: transid
	 */
	public void setTransid(java.sql.Timestamp newTransid) {
		transid = newTransid;
	}
}
