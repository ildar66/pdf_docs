package itso.bank5.bottom;
/**
 * Local interface for Enterprise Bean: Checking
 */
public interface CheckingLocal extends itso.bank5.bottom.AccountLocal {


	/**
	 * Get accessor for persistent attribute: overdraft
	 */
	public java.math.BigDecimal getOverdraft();
	/**
	 * Set accessor for persistent attribute: overdraft
	 */
	public void setOverdraft(java.math.BigDecimal newOverdraft);
}
