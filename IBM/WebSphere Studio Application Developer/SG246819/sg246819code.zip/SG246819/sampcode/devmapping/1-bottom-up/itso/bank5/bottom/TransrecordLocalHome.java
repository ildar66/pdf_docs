package itso.bank5.bottom;
/**
 * Local Home interface for Enterprise Bean: Transrecord
 */
public interface TransrecordLocalHome extends javax.ejb.EJBLocalHome {
	/**
	 * Creates an instance from a key for Entity Bean: Transrecord
	 */
	public itso.bank5.bottom.TransrecordLocal create(
		java.sql.Timestamp transid)
		throws javax.ejb.CreateException;
	/**
	 * Finds an instance using a key for Entity Bean: Transrecord
	 */
	public itso.bank5.bottom.TransrecordLocal findByPrimaryKey(
		itso.bank5.bottom.TransrecordKey primaryKey)
		throws javax.ejb.FinderException;
	/**
	 * Creates an instance from a key for Entity Bean: Transrecord
	 */
	public itso.bank5.bottom.TransrecordLocal create(
		java.sql.Timestamp transid,
		java.lang.String transtype,
		java.math.BigDecimal transamt)
		throws javax.ejb.CreateException;
}
