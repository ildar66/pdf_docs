package itso.bank5.bottom;
/**
 * Local Home interface for Enterprise Bean: Account
 */
public interface AccountLocalHome extends javax.ejb.EJBLocalHome {
	/**
	 * Creates an instance from a key for Entity Bean: Account
	 */
	public itso.bank5.bottom.AccountLocal create(java.lang.String accid)
		throws javax.ejb.CreateException;
	/**
	 * Finds an instance using a key for Entity Bean: Account
	 */
	public itso.bank5.bottom.AccountLocal findByPrimaryKey(
		itso.bank5.bottom.AccountKey primaryKey)
		throws javax.ejb.FinderException;
	/**
	 * Creates an instance from a key for Entity Bean: Account
	 */
	public itso.bank5.bottom.AccountLocal create(
		java.lang.String accid,
		java.math.BigDecimal balance,
		java.lang.Integer interest,
		java.lang.String acctype)
		throws javax.ejb.CreateException;
}
