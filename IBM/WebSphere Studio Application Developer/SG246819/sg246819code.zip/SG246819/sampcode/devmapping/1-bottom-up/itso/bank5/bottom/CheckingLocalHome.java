package itso.bank5.bottom;
/**
 * Local Home interface for Enterprise Bean: Checking
 */
public interface CheckingLocalHome extends javax.ejb.EJBLocalHome {
	/**
	 * Creates an instance from a key for Entity Bean: Checking
	 */
	public itso.bank5.bottom.CheckingLocal create(java.lang.String accid)
		throws javax.ejb.CreateException;
	/**
	 * Finds an instance using a key for Entity Bean: Checking
	 */
	public itso.bank5.bottom.CheckingLocal findByPrimaryKey(
		itso.bank5.bottom.AccountKey primaryKey)
		throws javax.ejb.FinderException;
	/**
	 * Creates an instance from a key for Entity Bean: Checking
	 */
	public itso.bank5.bottom.CheckingLocal create(
		itso.bank5.bottom.AccountLocal argCheckingaccount,
		java.math.BigDecimal overdraft)
		throws javax.ejb.CreateException;
}
