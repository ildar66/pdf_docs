package itso.bank5.bottom;
/**
 * Bean implementation class for Enterprise Bean: Savings
 */
public abstract class SavingsBean extends itso.bank5.bottom.AccountBean {


	/**
	 * ejbCreate
	 */
	public itso.bank5.bottom.AccountKey ejbCreate(
		java.lang.String savingsaccount_accid,
		java.math.BigDecimal minamount)
		throws javax.ejb.CreateException {
		setMinamount(minamount);
		return null;
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(
		java.lang.String savingsaccount_accid,
		java.math.BigDecimal minamount)
		throws javax.ejb.CreateException {
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
	}
	/**
	 * ejbCreate method for a CMP entity bean.
	 */
	public itso.bank5.bottom.AccountKey ejbCreate(
		itso.bank5.bottom.AccountLocal argSavingsaccount,
		java.math.BigDecimal minamount)
		throws javax.ejb.CreateException {
		setMinamount(minamount);
		itso.bank5.bottom.AccountKey argSavingsaccountPK =
			(itso.bank5.bottom.AccountKey) argSavingsaccount.getPrimaryKey();
		return null;
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(
		itso.bank5.bottom.AccountLocal argSavingsaccount,
		java.math.BigDecimal minamount)
		throws javax.ejb.CreateException {
	}
	/**
	 * Get accessor for persistent attribute: minamount
	 */
	public abstract java.math.BigDecimal getMinamount();
	/**
	 * Set accessor for persistent attribute: minamount
	 */
	public abstract void setMinamount(java.math.BigDecimal newMinamount);
}
