package itso.bank5.bottom;
/**
 * Local Home interface for Enterprise Bean: Savings
 */
public interface SavingsLocalHome extends javax.ejb.EJBLocalHome {
	/**
	 * Creates an instance from a key for Entity Bean: Savings
	 */
	public itso.bank5.bottom.SavingsLocal create(java.lang.String accid)
		throws javax.ejb.CreateException;
	/**
	 * Finds an instance using a key for Entity Bean: Savings
	 */
	public itso.bank5.bottom.SavingsLocal findByPrimaryKey(
		itso.bank5.bottom.AccountKey primaryKey)
		throws javax.ejb.FinderException;
	/**
	 * Creates an instance from a key for Entity Bean: Savings
	 */
	public itso.bank5.bottom.SavingsLocal create(
		itso.bank5.bottom.AccountLocal argSavingsaccount,
		java.math.BigDecimal minamount)
		throws javax.ejb.CreateException;
}
