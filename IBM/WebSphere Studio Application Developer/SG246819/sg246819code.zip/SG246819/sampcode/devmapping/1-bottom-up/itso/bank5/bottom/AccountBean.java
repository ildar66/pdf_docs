package itso.bank5.bottom;
/**
 * Bean implementation class for Enterprise Bean: Account
 */
public abstract class AccountBean implements javax.ejb.EntityBean {
	private javax.ejb.EntityContext myEntityCtx;
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		myEntityCtx = ctx;
	}
	/**
	 * getEntityContext
	 */
	public javax.ejb.EntityContext getEntityContext() {
		return myEntityCtx;
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		myEntityCtx = null;
	}
	/**
	 * ejbCreate
	 */
	public itso.bank5.bottom.AccountKey ejbCreate(java.lang.String accid)
		throws javax.ejb.CreateException {
		setAccid(accid);
		return null;
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(java.lang.String accid)
		throws javax.ejb.CreateException {
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
	}
	/**
	 * ejbCreate method for a CMP entity bean.
	 */
	public itso.bank5.bottom.AccountKey ejbCreate(
		java.lang.String accid,
		java.math.BigDecimal balance,
		java.lang.Integer interest,
		java.lang.String acctype)
		throws javax.ejb.CreateException {
		setAccid(accid);
		setBalance(balance);
		setInterest(interest);
		setAcctype(acctype);
		return null;
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(
		java.lang.String accid,
		java.math.BigDecimal balance,
		java.lang.Integer interest,
		java.lang.String acctype)
		throws javax.ejb.CreateException {
	}
	/**
	 * Get accessor for persistent attribute: accid
	 */
	public abstract java.lang.String getAccid();
	/**
	 * Set accessor for persistent attribute: accid
	 */
	public abstract void setAccid(java.lang.String newAccid);
	/**
	 * Get accessor for persistent attribute: balance
	 */
	public abstract java.math.BigDecimal getBalance();
	/**
	 * Set accessor for persistent attribute: balance
	 */
	public abstract void setBalance(java.math.BigDecimal newBalance);
	/**
	 * Get accessor for persistent attribute: interest
	 */
	public abstract java.lang.Integer getInterest();
	/**
	 * Set accessor for persistent attribute: interest
	 */
	public abstract void setInterest(java.lang.Integer newInterest);
	/**
	 * Get accessor for persistent attribute: acctype
	 */
	public abstract java.lang.String getAcctype();
	/**
	 * Set accessor for persistent attribute: acctype
	 */
	public abstract void setAcctype(java.lang.String newAcctype);
	/**
	 * This method was generated for supporting the relationship role named transrecords.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract java.util.Collection getTransrecords();
	/**
	 * This method was generated for supporting the relationship role named transrecords.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract void setTransrecords(java.util.Collection aTransrecords);
	/**
	 * This method was generated for supporting the relationship role named customers.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract java.util.Collection getCustomers();
	/**
	 * This method was generated for supporting the relationship role named customers.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract void setCustomers(java.util.Collection aCustomers);
}
