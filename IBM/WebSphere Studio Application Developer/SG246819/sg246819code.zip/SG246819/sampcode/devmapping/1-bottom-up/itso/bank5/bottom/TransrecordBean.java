package itso.bank5.bottom;
/**
 * Bean implementation class for Enterprise Bean: Transrecord
 */
public abstract class TransrecordBean implements javax.ejb.EntityBean {
	private javax.ejb.EntityContext myEntityCtx;
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		myEntityCtx = ctx;
	}
	/**
	 * getEntityContext
	 */
	public javax.ejb.EntityContext getEntityContext() {
		return myEntityCtx;
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		myEntityCtx = null;
	}
	/**
	 * ejbCreate
	 */
	public itso.bank5.bottom.TransrecordKey ejbCreate(
		java.sql.Timestamp transid)
		throws javax.ejb.CreateException {
		setTransid(transid);
		return null;
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(java.sql.Timestamp transid)
		throws javax.ejb.CreateException {
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
	}
	/**
	 * ejbCreate method for a CMP entity bean.
	 */
	public itso.bank5.bottom.TransrecordKey ejbCreate(
		java.sql.Timestamp transid,
		java.lang.String transtype,
		java.math.BigDecimal transamt)
		throws javax.ejb.CreateException {
		setTransid(transid);
		setTranstype(transtype);
		setTransamt(transamt);
		return null;
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(
		java.sql.Timestamp transid,
		java.lang.String transtype,
		java.math.BigDecimal transamt)
		throws javax.ejb.CreateException {
	}
	/**
	 * Get accessor for persistent attribute: transid
	 */
	public abstract java.sql.Timestamp getTransid();
	/**
	 * Set accessor for persistent attribute: transid
	 */
	public abstract void setTransid(java.sql.Timestamp newTransid);
	/**
	 * Get accessor for persistent attribute: transtype
	 */
	public abstract java.lang.String getTranstype();
	/**
	 * Set accessor for persistent attribute: transtype
	 */
	public abstract void setTranstype(java.lang.String newTranstype);
	/**
	 * Get accessor for persistent attribute: transamt
	 */
	public abstract java.math.BigDecimal getTransamt();
	/**
	 * Set accessor for persistent attribute: transamt
	 */
	public abstract void setTransamt(java.math.BigDecimal newTransamt);
	/**
	 * This method was generated for supporting the relationship role named theAccount.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract itso.bank5.bottom.AccountLocal getTheAccount();
	/**
	 * This method was generated for supporting the relationship role named theAccount.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public abstract void setTheAccount(
		itso.bank5.bottom.AccountLocal aTheAccount);
}
