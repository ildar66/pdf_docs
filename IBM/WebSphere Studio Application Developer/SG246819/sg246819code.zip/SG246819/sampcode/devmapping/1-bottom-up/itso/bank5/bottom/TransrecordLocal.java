package itso.bank5.bottom;
/**
 * Local interface for Enterprise Bean: Transrecord
 */
public interface TransrecordLocal extends javax.ejb.EJBLocalObject {
	/**
	 * Get accessor for persistent attribute: transtype
	 */
	public java.lang.String getTranstype();
	/**
	 * Set accessor for persistent attribute: transtype
	 */
	public void setTranstype(java.lang.String newTranstype);
	/**
	 * Get accessor for persistent attribute: transamt
	 */
	public java.math.BigDecimal getTransamt();
	/**
	 * Set accessor for persistent attribute: transamt
	 */
	public void setTransamt(java.math.BigDecimal newTransamt);
	/**
	 * This method was generated for supporting the relationship role named theAccount.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public itso.bank5.bottom.AccountLocal getTheAccount();
	/**
	 * This method was generated for supporting the relationship role named theAccount.
	 * It will be deleted/edited when the relationship is deleted/edited.
	 */
	public void setTheAccount(itso.bank5.bottom.AccountLocal aTheAccount);
}
