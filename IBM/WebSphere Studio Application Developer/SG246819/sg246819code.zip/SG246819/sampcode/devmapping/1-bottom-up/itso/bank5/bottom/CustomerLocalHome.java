package itso.bank5.bottom;
/**
 * Local Home interface for Enterprise Bean: Customer
 */
public interface CustomerLocalHome extends javax.ejb.EJBLocalHome {
	/**
	 * Creates an instance from a key for Entity Bean: Customer
	 */
	public itso.bank5.bottom.CustomerLocal create(java.lang.Integer customerid)
		throws javax.ejb.CreateException;
	/**
	 * Finds an instance using a key for Entity Bean: Customer
	 */
	public itso.bank5.bottom.CustomerLocal findByPrimaryKey(
		itso.bank5.bottom.CustomerKey primaryKey)
		throws javax.ejb.FinderException;
	/**
	 * Creates an instance from a key for Entity Bean: Customer
	 */
	public itso.bank5.bottom.CustomerLocal create(
		java.lang.Integer customerid,
		java.lang.String title,
		java.lang.String firstname,
		java.lang.String lastname)
		throws javax.ejb.CreateException;
}
