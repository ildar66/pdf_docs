package itso.bank5.bmp.persister;

import itso.bank5.bmp.CustomerInfoBmpBean;
import itso.bank5.bmp.CustomerInfoKey;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 * This is a helper class for handling the JDBC jobs for the BMP CustomerInfoBmp
 */
public class CustomerInfoBmpPersister {

	// sql datasource cached
	private DataSource ds = null;

	// environment variable key and value - must exist in bean environment 
	final String DB_DATASOURCE_KEY = "bmp/dbdatasource";

	// SQL statements
	final String SELECT_SQL = "SELECT T1.CUSTOMERID, T1.INFOID, T1.DESCRIPTION, T1.DATA FROM ITSO.CUSTOMERINFO T1 WHERE T1.CUSTOMERID = ? AND T1.INFOID = ?";
	final String INSERT_SQL = "INSERT INTO ITSO.CUSTOMERINFO (CUSTOMERID, INFOID, DESCRIPTION) VALUES (?, ?, ?)";
	final String UPDATE_SQL = "UPDATE ITSO.CUSTOMERINFO  SET DESCRIPTION = ?, DATA = ? WHERE CUSTOMERID = ? AND INFOID = ?";
	final String DELETE_SQL = "DELETE FROM ITSO.CUSTOMERINFO  WHERE CUSTOMERID = ? AND INFOID = ?";

	public CustomerInfoBmpPersister() {
		initializeResources();
	}
	
	public void initializeResources() {
		try {
			InitialContext ctx = new InitialContext();
			String dbDatasource = (String)ctx.lookup("java:comp/env/"+DB_DATASOURCE_KEY);
			System.out.println("BMP persister datasource name: "+dbDatasource);
			ds = (DataSource)ctx.lookup(dbDatasource);
			System.out.println("BMP persister datasource");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	private DataSource getDatasource() throws SQLException {
		if (ds == null )  throw new SQLException("Data source is null");
		else return ds;
	}
	

	public void freeResources() {
		System.out.println("BMP persister free resources");
		ds = null;
	}

	public void createState(CustomerInfoKey key) throws SQLException {
		System.out.println("BMP persister createState");
		Connection        con = null;
		PreparedStatement ps  = null;
		try {
			con = getDatasource().getConnection();
			ps = con.prepareStatement(INSERT_SQL);
			ps.setInt(1, key.customerID);
			ps.setInt(2, key.infoID);
			ps.setString(3, "");  // description
			// data is left as null
			int result = ps.executeUpdate();
		} catch (SQLException e) { throw e; }
		finally { 
			if (ps  != null) ps.close();
			if (con != null) con.close(); 
		}
	}
	
	public boolean findPrimaryKey(CustomerInfoKey key) throws SQLException {
		System.out.println("BMP persister findByPrimaryKey");
		Connection        con = null;
		PreparedStatement ps  = null;
		ResultSet         rs  = null;
		boolean result = false;
		try {
			con = getDatasource().getConnection();
			ps = con.prepareStatement(SELECT_SQL);
			ps.setInt(1, key.customerID);
			ps.setInt(2, key.infoID);
			rs = ps.executeQuery();
			result =  rs.next();
		} catch (SQLException e) { throw e; }
		finally { 
			if (rs  != null) rs.close();
			if (ps  != null) ps.close();
			if (con != null) con.close(); 
		}
		return result;
	}
				
	public void loadState(CustomerInfoBmpBean bean) throws SQLException {
		System.out.println("BMP persister loadState");
		CustomerInfoKey key = (CustomerInfoKey) bean.getEntityContext().getPrimaryKey();
		Connection        con = null;
		PreparedStatement ps  = null;
		ResultSet         rs  = null;
		try {
			con = getDatasource().getConnection();
			ps = con.prepareStatement(SELECT_SQL);
			ps.setInt(1, key.customerID);
			ps.setInt(2, key.infoID);
			rs = ps.executeQuery();
			rs.next();
			bean.setCustomerID( rs.getInt(1) );
			bean.setInfoID( rs.getInt(2) );
			bean.setDescription( rs.getString(3) );
			bean.setData( rs.getBytes(4) );
		} catch (SQLException e) { throw e; }
		finally { 
			if (rs  != null) rs.close();
			if (ps  != null) ps.close();
			if (con != null) con.close(); 
		}
	}

	public void storeState(CustomerInfoBmpBean bean) throws SQLException {
		System.out.println("BMP persister storeState");
		Connection        con = null;
		PreparedStatement ps  = null;
		try {
			con = getDatasource().getConnection();
			ps = con.prepareStatement(UPDATE_SQL);
			ps.setString(1, bean.getDescription());
			ps.setBytes(2, bean.getData());
			ps.setInt(3, bean.getCustomerID());
			ps.setInt(4, bean.getInfoID());
			ps.executeUpdate();
		} catch (SQLException e) { throw e; }
		finally { 
			if (ps  != null) ps.close();
			if (con != null) con.close(); 
		}
	}
		
	public boolean deleteState(CustomerInfoBmpBean bean) throws SQLException {
		System.out.println("BMP persister deleteState");
		CustomerInfoKey key = (CustomerInfoKey) bean.getEntityContext().getPrimaryKey();
		Connection        con = null;
		PreparedStatement ps  = null;
		int result;
		try {
			con = getDatasource().getConnection();
			ps = con.prepareStatement(DELETE_SQL);
			ps.setInt(1, key.customerID);
			ps.setInt(2, key.infoID);
			result = ps.executeUpdate();  // is 0 for successful delete
		} catch (SQLException e) { throw e; }
		finally { 
			if (ps  != null) ps.close();
			if (con != null) con.close(); 
		}
		return (result != 0);
	}

}