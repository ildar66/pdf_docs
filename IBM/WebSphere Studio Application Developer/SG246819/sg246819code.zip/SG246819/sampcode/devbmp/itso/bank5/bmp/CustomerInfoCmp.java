package itso.bank5.bmp;
/**
 * Remote interface for Enterprise Bean: CustomerInfoCmp
 */
public interface CustomerInfoCmp extends javax.ejb.EJBObject {
	/**
	 * Get accessor for persistent attribute: description
	 */
	public java.lang.String getDescription() throws java.rmi.RemoteException;
	/**
	 * Set accessor for persistent attribute: description
	 */
	public void setDescription(java.lang.String newDescription)
		throws java.rmi.RemoteException;
	/**
	 * Get accessor for persistent attribute: data
	 */
	public byte[] getData() throws java.rmi.RemoteException;
	/**
	 * Set accessor for persistent attribute: data
	 */
	public void setData(byte[] newData) throws java.rmi.RemoteException;
}
