package itso.bank5.bmp;
import javax.ejb.CreateException;
import itso.bank5.bmp.CustomerInfoKey;
/**
 * Home interface for Enterprise Bean: CustomerInfoBmp
 */
public interface CustomerInfoBmpHome extends javax.ejb.EJBHome {

	/**
	 * Finds an instance using a key for Entity Bean: CustomerInfoBmp
	 */
	public itso.bank5.bmp.CustomerInfoBmp findByPrimaryKey(
		itso.bank5.bmp.CustomerInfoKey primaryKey)
		throws javax.ejb.FinderException, java.rmi.RemoteException;
	/**
	 * @see itso.bank5.bmp.CustomerInfoCmpBean#ejbCreate(int, int)
	 */
	public itso.bank5.bmp.CustomerInfoBmp create(int customerID, int infoID)
		throws CreateException, java.rmi.RemoteException;
}
