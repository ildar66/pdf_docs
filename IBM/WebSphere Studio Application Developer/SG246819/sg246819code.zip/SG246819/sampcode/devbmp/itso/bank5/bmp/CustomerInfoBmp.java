package itso.bank5.bmp;
/**
 * Remote interface for Enterprise Bean: CustomerInfoBmp
 */
public interface CustomerInfoBmp extends javax.ejb.EJBObject {
	/**
	 * Returns the customerID.
	 * @return int
	 */
	public int getCustomerID() throws java.rmi.RemoteException;
	/**
	 * Returns the data.
	 * @return byte[]
	 */
	public byte[] getData() throws java.rmi.RemoteException;
	/**
	 * Returns the description.
	 * @return String
	 */
	public String getDescription() throws java.rmi.RemoteException;
	/**
	 * Returns the infoID.
	 * @return int
	 */
	public int getInfoID() throws java.rmi.RemoteException;
	/**
	 * Sets the data.
	 * @param data The data to set
	 */
	public void setData(byte[] data) throws java.rmi.RemoteException;
	/**
	 * Sets the description.
	 * @param description The description to set
	 */
	public void setDescription(String description)
		throws java.rmi.RemoteException;
}
