package itso.bank5.bmp;
/**
 * Bean implementation class for Enterprise Bean: CustomerInfoCmp
 */
public abstract class CustomerInfoCmpBean implements javax.ejb.EntityBean {
	private javax.ejb.EntityContext myEntityCtx;
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		myEntityCtx = ctx;
	}
	/**
	 * getEntityContext
	 */
	public javax.ejb.EntityContext getEntityContext() {
		return myEntityCtx;
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		myEntityCtx = null;
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbCreate
	 */
	public itso.bank5.bmp.CustomerInfoKey ejbCreate(int customerID, int infoID)
		throws javax.ejb.CreateException {
		setCustomerID(customerID);
		setInfoID(infoID);
		return null;
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbPostCreate
	 */
	public void ejbPostCreate(int customerID, int infoID)
		throws javax.ejb.CreateException {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
	}
	/**
	 * Get accessor for persistent attribute: customerID
	 */
	public abstract int getCustomerID();
	/**
	 * Set accessor for persistent attribute: customerID
	 */
	public abstract void setCustomerID(int newCustomerID);
	/**
	 * Get accessor for persistent attribute: infoID
	 */
	public abstract int getInfoID();
	/**
	 * Set accessor for persistent attribute: infoID
	 */
	public abstract void setInfoID(int newInfoID);
	/**
	 * Get accessor for persistent attribute: description
	 */
	public abstract java.lang.String getDescription();
	/**
	 * Set accessor for persistent attribute: description
	 */
	public abstract void setDescription(java.lang.String newDescription);
	/**
	 * Get accessor for persistent attribute: data
	 */
	public abstract byte[] getData();
	/**
	 * Set accessor for persistent attribute: data
	 */
	public abstract void setData(byte[] newData);
}
