package itso.bank5.beans;
/**
 * Address
 * @generated
 */
public class Address implements java.io.Serializable {
	/**
	 * @generated
	 */
	private java.lang.String zipcode;
	/**
	 * @generated
	 */
	private java.lang.String state;
	/**
	 * @generated
	 */
	private java.lang.String city;
	/**
	 * @generated
	 */
	private java.lang.String street;
	/**
	 * getZipcode
	 * @generated
	 */
	public java.lang.String getZipcode() {
		return zipcode;
	}
	/**
	 * setZipcode
	 * @generated
	 */
	public void setZipcode(java.lang.String newZipcode) {
		zipcode = newZipcode;
	}
	/**
	 * getState
	 * @generated
	 */
	public java.lang.String getState() {
		return state;
	}
	/**
	 * setState
	 * @generated
	 */
	public void setState(java.lang.String newState) {
		state = newState;
	}
	/**
	 * getCity
	 * @generated
	 */
	public java.lang.String getCity() {
		return city;
	}
	/**
	 * setCity
	 * @generated
	 */
	public void setCity(java.lang.String newCity) {
		city = newCity;
	}
	/**
	 * getStreet
	 * @generated
	 */
	public java.lang.String getStreet() {
		return street;
	}
	/**
	 * setStreet
	 * @generated
	 */
	public void setStreet(java.lang.String newStreet) {
		street = newStreet;
	}
}
