package itso.bank5.bmp;
/**
 * Home interface for Enterprise Bean: CustomerInfoCmp
 */
public interface CustomerInfoCmpHome extends javax.ejb.EJBHome {
	/**
	 * Creates an instance from a key for Entity Bean: CustomerInfoCmp
	 */
	public itso.bank5.bmp.CustomerInfoCmp create(int customerID, int infoID)
		throws javax.ejb.CreateException, java.rmi.RemoteException;
	/**
	 * Finds an instance using a key for Entity Bean: CustomerInfoCmp
	 */
	public itso.bank5.bmp.CustomerInfoCmp findByPrimaryKey(
		itso.bank5.bmp.CustomerInfoKey primaryKey)
		throws javax.ejb.FinderException, java.rmi.RemoteException;
}
