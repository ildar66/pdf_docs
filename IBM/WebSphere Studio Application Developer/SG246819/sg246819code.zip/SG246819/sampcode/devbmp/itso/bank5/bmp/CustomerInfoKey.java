package itso.bank5.bmp;
/**
 * Key class for Entity Bean: CustomerInfoCmp
 */
public class CustomerInfoKey implements java.io.Serializable {
	static final long serialVersionUID = 3206093459760846163L;
	/**
	 * Implementation field for persistent attribute: customerID
	 */
	public int customerID;
	/**
	 * Implementation field for persistent attribute: infoID
	 */
	public int infoID;
	/**
	 * Creates an empty key for Entity Bean: CustomerInfoCmp
	 */
	public CustomerInfoKey() {
	}
	/**
	 * Creates a key for Entity Bean: CustomerInfoCmp
	 */
	public CustomerInfoKey(int customerID, int infoID) {
		this.customerID = customerID;
		this.infoID = infoID;
	}
	/**
	 * Returns true if both keys are equal.
	 */
	public boolean equals(java.lang.Object otherKey) {
		if (otherKey instanceof itso.bank5.bmp.CustomerInfoKey) {
			itso.bank5.bmp.CustomerInfoKey o =
				(itso.bank5.bmp.CustomerInfoKey) otherKey;
			return (
				(this.customerID == o.customerID) && (this.infoID == o.infoID));
		}
		return false;
	}
	/**
	 * Returns the hash code for the key.
	 */
	public int hashCode() {
		return (
			(new java.lang.Integer(customerID).hashCode())
				+ (new java.lang.Integer(infoID).hashCode()));
	}
	/**
	 * Get accessor for persistent attribute: customerID
	 */
	public int getCustomerID() {
		return customerID;
	}
	/**
	 * Set accessor for persistent attribute: customerID
	 */
	public void setCustomerID(int newCustomerID) {
		customerID = newCustomerID;
	}
	/**
	 * Get accessor for persistent attribute: infoID
	 */
	public int getInfoID() {
		return infoID;
	}
	/**
	 * Set accessor for persistent attribute: infoID
	 */
	public void setInfoID(int newInfoID) {
		infoID = newInfoID;
	}
}
