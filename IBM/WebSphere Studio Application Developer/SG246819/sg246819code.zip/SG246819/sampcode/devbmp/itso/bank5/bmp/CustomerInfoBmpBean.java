package itso.bank5.bmp;

import javax.ejb.*;
import java.sql.SQLException;
import itso.bank5.bmp.persister.CustomerInfoBmpPersister;

/**
 * Bean implementation class for Enterprise Bean: CustomerInfoBmp
 */
public class CustomerInfoBmpBean
	extends itso.bank5.bmp.CustomerInfoCmpBean
	implements javax.ejb.EntityBean {
		
		
	private javax.ejb.EntityContext myEntityCtx;
	
	// persister class
	private CustomerInfoBmpPersister persister = null;
	
	// the BMP fields
	private int customerID = 0;
	private int infoID = 0;
	private String description = null;
	private byte[] data = null;
	
	// dirty flag
	boolean dirty = true;

	/**
	 * getEntityContext
	 */
	public javax.ejb.EntityContext getEntityContext() {
		return myEntityCtx;
	}
	/**
	 * setEntityContext
	 */
	public void setEntityContext(javax.ejb.EntityContext ctx) {
		myEntityCtx = ctx;
		if (persister == null) persister = new CustomerInfoBmpPersister();
	}
	/**
	 * unsetEntityContext
	 */
	public void unsetEntityContext() {
		if (persister != null) persister.freeResources();
		persister = null;
		myEntityCtx = null;
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbFindByPrimaryKey
	 */
	public itso.bank5.bmp.CustomerInfoKey ejbFindByPrimaryKey(itso.bank5.bmp.CustomerInfoKey primaryKey)
		throws javax.ejb.FinderException {
		boolean found = false;
		try {
			found = persister.findPrimaryKey(primaryKey);
		} 
		catch (SQLException e) {
			e.printStackTrace();
			throw new FinderException(e.getMessage());
		}
		if (found)
			return primaryKey;
		else
			throw new ObjectNotFoundException();
	}
	/**
	 * ejbLoad
	 */
	public void ejbLoad() {
		try {
			persister.loadState(this);
			dirty = false;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new EJBException(e.getSQLState()+" code: "+e.getErrorCode());
		}
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() throws javax.ejb.RemoveException {
		try {
			boolean success = persister.deleteState(this);
			if (!success)
				throw new RemoveException("Not able to delete state");
		} catch (SQLException e) {
			throw new RemoveException(e.getMessage());
		}
	}
	/**
	 * ejbStore
	 */
	public void ejbStore() {
		try {
			if (dirty) persister.storeState(this);
			dirty = false;
		}
		catch (SQLException e) {
			e.printStackTrace();
			throw new EJBException(e.getSQLState()+" code: "+e.getErrorCode());
		}
	}
	/**
	 * @see itso.bank5.bmp.CustomerInfoCmpBean#ejbCreate(int, int)
	 */
	public CustomerInfoKey ejbCreate(int customerID, int infoID)
		throws CreateException {
		CustomerInfoKey key = new CustomerInfoKey(customerID, infoID);
		try {
			persister.createState(key);
			dirty = false;
			return key;
		} 
		catch (SQLException e) {
			e.printStackTrace();
			throw new CreateException(e.getMessage());
		}
	}

	/**
	 * @see itso.bank5.bmp.CustomerInfoCmpBean#ejbPostCreate(int, int)
	 */
	public void ejbPostCreate(int customerID, int infoID)
		throws CreateException {
		super.ejbPostCreate(customerID, infoID);
	}

	/**
	 * Returns the customerID.
	 * @return int
	 */
	public int getCustomerID() {
		return customerID;
	}

	/**
	 * Returns the data.
	 * @return byte[]
	 */
	public byte[] getData() {
		return data;
	}

	/**
	 * Returns the description.
	 * @return String
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Returns the infoID.
	 * @return int
	 */
	public int getInfoID() {
		return infoID;
	}

	/**
	 * Sets the data.
	 * @param data The data to set
	 */
	public void setData(byte[] data) {
		this.data = data;
		dirty = true;
	}

	/**
	 * Sets the description.
	 * @param description The description to set
	 */
	public void setDescription(String description) {
		this.description = description;
		dirty = true;
	}

	/**
	 * Sets the customerID.
	 * @param customerID The customerID to set
	 */
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
		dirty = true;
	}

	/**
	 * Sets the infoID.
	 * @param infoID The infoID to set
	 */
	public void setInfoID(int infoID) {
		this.infoID = infoID;
		dirty = true;
	}

}
