package proxy.soap;

import java.net.*;
import java.util.*;
import org.w3c.dom.*;
import org.apache.soap.*;
import org.apache.soap.encoding.*;
import org.apache.soap.encoding.soapenc.*;
import org.apache.soap.rpc.*;
import org.apache.soap.util.xml.*;
import org.apache.soap.messaging.*;
import org.apache.soap.transport.http.*;

public class BankingProxy
{
  private Call call;
  private URL url = null;
  private String stringURL = "http://localhost:9080/ItsoBank5Web/servlet/rpcrouter";
  private java.lang.reflect.Method setTcpNoDelayMethod;

  public BankingProxy()
  {
    try
    {
      setTcpNoDelayMethod = SOAPHTTPConnection.class.getMethod("setTcpNoDelay", new Class[]{Boolean.class});
    }
    catch (Exception e)
    {
    }
    call = createCall();
  }

  public synchronized void setEndPoint(URL url)
  {
    this.url = url;
  }

  public synchronized URL getEndPoint() throws MalformedURLException
  {
    return getURL();
  }

  private URL getURL() throws MalformedURLException
  {
    if (url == null && stringURL != null && stringURL.length() > 0)
    {
      url = new URL(stringURL);
    }
    return url;
  }

  public synchronized void removeCustAcct(int custid,java.lang.String accid) throws Exception
  {
    String targetObjectURI = "uri:Banking";
    String SOAPActionURI = "";

    if(getURL() == null)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via BankingProxy.setEndPoint(URL).");
    }

    call.setMethodName("removeCustAcct");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setTargetObjectURI(targetObjectURI);
    Vector params = new Vector();
    Parameter custidParam = new Parameter("custid", int.class, new Integer(custid), Constants.NS_URI_SOAP_ENC);
    params.addElement(custidParam);
    Parameter accidParam = new Parameter("accid", java.lang.String.class, accid, Constants.NS_URI_SOAP_ENC);
    params.addElement(accidParam);
    call.setParams(params);
    Response resp = call.invoke(getURL(), SOAPActionURI);

    //Check the response.
    if (resp.generatedFault())
    {
      Fault fault = resp.getFault();
      call.setFullTargetObjectURI(targetObjectURI);
      throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
    }

  }

  public synchronized void addCustAcct(int custid,java.lang.String accid) throws Exception
  {
    String targetObjectURI = "uri:Banking";
    String SOAPActionURI = "";

    if(getURL() == null)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via BankingProxy.setEndPoint(URL).");
    }

    call.setMethodName("addCustAcct");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setTargetObjectURI(targetObjectURI);
    Vector params = new Vector();
    Parameter custidParam = new Parameter("custid", int.class, new Integer(custid), Constants.NS_URI_SOAP_ENC);
    params.addElement(custidParam);
    Parameter accidParam = new Parameter("accid", java.lang.String.class, accid, Constants.NS_URI_SOAP_ENC);
    params.addElement(accidParam);
    call.setParams(params);
    Response resp = call.invoke(getURL(), SOAPActionURI);

    //Check the response.
    if (resp.generatedFault())
    {
      Fault fault = resp.getFault();
      call.setFullTargetObjectURI(targetObjectURI);
      throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
    }

  }

  public synchronized java.math.BigDecimal withdraw(java.lang.String accountID,java.math.BigDecimal amount) throws Exception
  {
    String targetObjectURI = "uri:Banking";
    String SOAPActionURI = "";

    if(getURL() == null)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via BankingProxy.setEndPoint(URL).");
    }

    call.setMethodName("withdraw");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setTargetObjectURI(targetObjectURI);
    Vector params = new Vector();
    Parameter accountIDParam = new Parameter("accountID", java.lang.String.class, accountID, Constants.NS_URI_SOAP_ENC);
    params.addElement(accountIDParam);
    Parameter amountParam = new Parameter("amount", java.math.BigDecimal.class, amount, Constants.NS_URI_SOAP_ENC);
    params.addElement(amountParam);
    call.setParams(params);
    Response resp = call.invoke(getURL(), SOAPActionURI);

    //Check the response.
    if (resp.generatedFault())
    {
      Fault fault = resp.getFault();
      call.setFullTargetObjectURI(targetObjectURI);
      throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
    }
    else
    {
      Parameter refValue = resp.getReturnValue();
      return ((java.math.BigDecimal)refValue.getValue());
    }
  }

  public synchronized java.util.Vector getTransrecords(java.lang.String accountID) throws Exception
  {
    String targetObjectURI = "uri:Banking";
    String SOAPActionURI = "";

    if(getURL() == null)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via BankingProxy.setEndPoint(URL).");
    }

    call.setMethodName("getTransrecords");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setTargetObjectURI(targetObjectURI);
    Vector params = new Vector();
    Parameter accountIDParam = new Parameter("accountID", java.lang.String.class, accountID, Constants.NS_URI_SOAP_ENC);
    params.addElement(accountIDParam);
    call.setParams(params);
    Response resp = call.invoke(getURL(), SOAPActionURI);

    //Check the response.
    if (resp.generatedFault())
    {
      Fault fault = resp.getFault();
      call.setFullTargetObjectURI(targetObjectURI);
      throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
    }
    else
    {
      Parameter refValue = resp.getReturnValue();
      return ((java.util.Vector)refValue.getValue());
    }
  }

  public synchronized java.util.Vector listAccountsOfCustomer(int customerID) throws Exception
  {
    String targetObjectURI = "uri:Banking";
    String SOAPActionURI = "";

    if(getURL() == null)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via BankingProxy.setEndPoint(URL).");
    }

    call.setMethodName("listAccountsOfCustomer");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setTargetObjectURI(targetObjectURI);
    Vector params = new Vector();
    Parameter customerIDParam = new Parameter("customerID", int.class, new Integer(customerID), Constants.NS_URI_SOAP_ENC);
    params.addElement(customerIDParam);
    call.setParams(params);
    Response resp = call.invoke(getURL(), SOAPActionURI);

    //Check the response.
    if (resp.generatedFault())
    {
      Fault fault = resp.getFault();
      call.setFullTargetObjectURI(targetObjectURI);
      throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
    }
    else
    {
      Parameter refValue = resp.getReturnValue();
      return ((java.util.Vector)refValue.getValue());
    }
  }

  public synchronized java.lang.String[] getAccountInfo(java.lang.String accountID) throws Exception
  {
    String targetObjectURI = "uri:Banking";
    String SOAPActionURI = "";

    if(getURL() == null)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via BankingProxy.setEndPoint(URL).");
    }

    call.setMethodName("getAccountInfo");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setTargetObjectURI(targetObjectURI);
    Vector params = new Vector();
    Parameter accountIDParam = new Parameter("accountID", java.lang.String.class, accountID, Constants.NS_URI_SOAP_ENC);
    params.addElement(accountIDParam);
    call.setParams(params);
    Response resp = call.invoke(getURL(), SOAPActionURI);

    //Check the response.
    if (resp.generatedFault())
    {
      Fault fault = resp.getFault();
      call.setFullTargetObjectURI(targetObjectURI);
      throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
    }
    else
    {
      Parameter refValue = resp.getReturnValue();
      return ((java.lang.String[])refValue.getValue());
    }
  }

  public synchronized void removeAcctCust(int custid,java.lang.String accid) throws Exception
  {
    String targetObjectURI = "uri:Banking";
    String SOAPActionURI = "";

    if(getURL() == null)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via BankingProxy.setEndPoint(URL).");
    }

    call.setMethodName("removeAcctCust");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setTargetObjectURI(targetObjectURI);
    Vector params = new Vector();
    Parameter custidParam = new Parameter("custid", int.class, new Integer(custid), Constants.NS_URI_SOAP_ENC);
    params.addElement(custidParam);
    Parameter accidParam = new Parameter("accid", java.lang.String.class, accid, Constants.NS_URI_SOAP_ENC);
    params.addElement(accidParam);
    call.setParams(params);
    Response resp = call.invoke(getURL(), SOAPActionURI);

    //Check the response.
    if (resp.generatedFault())
    {
      Fault fault = resp.getFault();
      call.setFullTargetObjectURI(targetObjectURI);
      throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
    }

  }

  public synchronized void addAcctCust(int custid,java.lang.String accid) throws Exception
  {
    String targetObjectURI = "uri:Banking";
    String SOAPActionURI = "";

    if(getURL() == null)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via BankingProxy.setEndPoint(URL).");
    }

    call.setMethodName("addAcctCust");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setTargetObjectURI(targetObjectURI);
    Vector params = new Vector();
    Parameter custidParam = new Parameter("custid", int.class, new Integer(custid), Constants.NS_URI_SOAP_ENC);
    params.addElement(custidParam);
    Parameter accidParam = new Parameter("accid", java.lang.String.class, accid, Constants.NS_URI_SOAP_ENC);
    params.addElement(accidParam);
    call.setParams(params);
    Response resp = call.invoke(getURL(), SOAPActionURI);

    //Check the response.
    if (resp.generatedFault())
    {
      Fault fault = resp.getFault();
      call.setFullTargetObjectURI(targetObjectURI);
      throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
    }

  }

  public synchronized java.math.BigDecimal deposit(java.lang.String accountID,java.math.BigDecimal amount) throws Exception
  {
    String targetObjectURI = "uri:Banking";
    String SOAPActionURI = "";

    if(getURL() == null)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via BankingProxy.setEndPoint(URL).");
    }

    call.setMethodName("deposit");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setTargetObjectURI(targetObjectURI);
    Vector params = new Vector();
    Parameter accountIDParam = new Parameter("accountID", java.lang.String.class, accountID, Constants.NS_URI_SOAP_ENC);
    params.addElement(accountIDParam);
    Parameter amountParam = new Parameter("amount", java.math.BigDecimal.class, amount, Constants.NS_URI_SOAP_ENC);
    params.addElement(amountParam);
    call.setParams(params);
    Response resp = call.invoke(getURL(), SOAPActionURI);

    //Check the response.
    if (resp.generatedFault())
    {
      Fault fault = resp.getFault();
      call.setFullTargetObjectURI(targetObjectURI);
      throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
    }
    else
    {
      Parameter refValue = resp.getReturnValue();
      return ((java.math.BigDecimal)refValue.getValue());
    }
  }

  public synchronized java.util.Vector getCustomers(java.lang.String accountID) throws Exception
  {
    String targetObjectURI = "uri:Banking";
    String SOAPActionURI = "";

    if(getURL() == null)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via BankingProxy.setEndPoint(URL).");
    }

    call.setMethodName("getCustomers");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setTargetObjectURI(targetObjectURI);
    Vector params = new Vector();
    Parameter accountIDParam = new Parameter("accountID", java.lang.String.class, accountID, Constants.NS_URI_SOAP_ENC);
    params.addElement(accountIDParam);
    call.setParams(params);
    Response resp = call.invoke(getURL(), SOAPActionURI);

    //Check the response.
    if (resp.generatedFault())
    {
      Fault fault = resp.getFault();
      call.setFullTargetObjectURI(targetObjectURI);
      throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
    }
    else
    {
      Parameter refValue = resp.getReturnValue();
      return ((java.util.Vector)refValue.getValue());
    }
  }

  public synchronized java.math.BigDecimal transfer(java.lang.String accountID1,java.lang.String accountID2,java.math.BigDecimal amount) throws Exception
  {
    String targetObjectURI = "uri:Banking";
    String SOAPActionURI = "";

    if(getURL() == null)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via BankingProxy.setEndPoint(URL).");
    }

    call.setMethodName("transfer");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setTargetObjectURI(targetObjectURI);
    Vector params = new Vector();
    Parameter accountID1Param = new Parameter("accountID1", java.lang.String.class, accountID1, Constants.NS_URI_SOAP_ENC);
    params.addElement(accountID1Param);
    Parameter accountID2Param = new Parameter("accountID2", java.lang.String.class, accountID2, Constants.NS_URI_SOAP_ENC);
    params.addElement(accountID2Param);
    Parameter amountParam = new Parameter("amount", java.math.BigDecimal.class, amount, Constants.NS_URI_SOAP_ENC);
    params.addElement(amountParam);
    call.setParams(params);
    Response resp = call.invoke(getURL(), SOAPActionURI);

    //Check the response.
    if (resp.generatedFault())
    {
      Fault fault = resp.getFault();
      call.setFullTargetObjectURI(targetObjectURI);
      throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
    }
    else
    {
      Parameter refValue = resp.getReturnValue();
      return ((java.math.BigDecimal)refValue.getValue());
    }
  }

  public synchronized java.math.BigDecimal getBalance(java.lang.String accountID) throws Exception
  {
    String targetObjectURI = "uri:Banking";
    String SOAPActionURI = "";

    if(getURL() == null)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via BankingProxy.setEndPoint(URL).");
    }

    call.setMethodName("getBalance");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    call.setTargetObjectURI(targetObjectURI);
    Vector params = new Vector();
    Parameter accountIDParam = new Parameter("accountID", java.lang.String.class, accountID, Constants.NS_URI_SOAP_ENC);
    params.addElement(accountIDParam);
    call.setParams(params);
    Response resp = call.invoke(getURL(), SOAPActionURI);

    //Check the response.
    if (resp.generatedFault())
    {
      Fault fault = resp.getFault();
      call.setFullTargetObjectURI(targetObjectURI);
      throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
    }
    else
    {
      Parameter refValue = resp.getReturnValue();
      return ((java.math.BigDecimal)refValue.getValue());
    }
  }

  protected Call createCall()
  {
    SOAPHTTPConnection soapHTTPConnection = new SOAPHTTPConnection();
    if ( setTcpNoDelayMethod != null)
    {
      try
      {
        setTcpNoDelayMethod.invoke(soapHTTPConnection, new Object[]{Boolean.TRUE});
      }
      catch (Exception ex)
      {
      }
    }
    Call call = new Call();
    call.setSOAPTransport(soapHTTPConnection);
    SOAPMappingRegistry smr = call.getSOAPMappingRegistry();
    return call;
  }
}
