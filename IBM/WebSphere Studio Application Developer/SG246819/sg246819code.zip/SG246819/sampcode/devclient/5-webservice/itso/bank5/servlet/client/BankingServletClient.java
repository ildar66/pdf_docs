package itso.bank5.servlet.client;

import java.io.IOException;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import proxy.soap.BankingProxy;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.*;
/**
 * @version 	1.0
 * @author
 */
public class BankingServletClient extends HttpServlet {

	BankingProxy proxy = null;
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		processBanking(req, resp);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		processBanking(req, resp);
	}
	public void init() throws ServletException {
		try {
			proxy = new BankingProxy();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	public void processBanking(HttpServletRequest req, HttpServletResponse resp) {
		try {
			PrintWriter out = resp.getWriter();
			out.println("<html><body><h1>Banking Servlet</h1>");
			BigDecimal amount = null;
			int customerid = 0;
			
			String custlistBut = req.getParameter("custlist");
			String balanceBut  = req.getParameter("balance");
			String customerBut = req.getParameter("customers");
			String trecordBut  = req.getParameter("trecords");
			String depositBut  = req.getParameter("deposit");
			String withdrawBut = req.getParameter("withdraw");
			String transferBut = req.getParameter("transfer");
			
			String account1    = req.getParameter("account1");
			String account2    = req.getParameter("account2");

			try {
				if ( !(req.getParameter("amount").trim().equals("")) ) 
					amount  = new BigDecimal( req.getParameter("amount") );
				if ( !(req.getParameter("customerid").trim().equals("")) ) 
					customerid = new Integer( req.getParameter("customerid") ).intValue();
					
				if (custlistBut != null) 
					out.println("<h2> Customer: "+customerid+"</h2>");
				else
					out.println("<h2> Account: "+account1+"</h2>");

				if (balanceBut  != null) {
					BigDecimal balance = proxy.getBalance(account1);
					out.println("<p> Balance: "+ balance);
				}
				
				if (depositBut  != null) {
					BigDecimal balance = proxy.deposit(account1, amount);
					out.println("<p> Deposit: "+ amount);
					out.println("<p> Balance: "+ balance);
				}
				
				if (withdrawBut != null) {
				  try {
					BigDecimal balance = proxy.withdraw(account1, amount);
					out.println("<p> Withdraw: "+ amount);
					out.println("<p> Balance: "+ balance);
				  } catch (Exception ex) {
					out.println("<p> Withdraw: "+ amount);
					out.println("<p> Sorry: Insufficient funds in account");
				  }
				}
				
				if (transferBut != null) {
				  try {
					BigDecimal balance = proxy.transfer(account1, account2, amount);
					out.println("<p> Transfer: "+ amount);
					out.println("<p> From account: " + account1 + " balance: "+ balance);
					out.println("<p> To account: " + account2 + " balance: "+ proxy.getBalance(account2));
				  } catch (Exception ex) {
					out.println("<p> Transfer: "+ amount);
					out.println("<p> Sorry: Insufficient funds in account");
				  }
				}
				  
				if (customerBut != null) {
					out.println("<h3>Customers:</h3>");
					Vector results = proxy.getCustomers(account1);
					if (results == null)
						out.println("<p> No customers found ");
					else {
						for ( int i=0; i < results.size(); i++ ) {
							out.println((String)results.elementAt(i)+"<br>");
						}
					}
				}

				if (trecordBut != null) {
					out.println("<h3>Transactions:</h3><ul>");
					Vector results = proxy.getTransrecords(account1);
					Enumeration enum = results.elements();
					while (enum.hasMoreElements()) {
						out.println("<li>"+(String)enum.nextElement());
					}
					out.println("</ul>");
				}

				if (custlistBut != null) {
					Vector results = proxy.listAccountsOfCustomer(customerid);
					if ( results.size() == 0 ) 
						out.println("<p>Nothing found");
					else {
						String custdata[] = (String[])results.elementAt(0);
						out.println("<h3>Accounts of "+custdata[2]+"</h3>");
						out.println("<table border=\"1\" cellpadding=\"6\"><tr><td><b>Account</b></td><td><b>Number</b></td><td><b>Balance</b></td><td><b>Tx</b></td><td><b>Amount</b></td><td><b>Timestamp</b></td></tr>");
						for ( int i=1; i < results.size(); i++ ) {
							String account[] = (String[])results.elementAt(i);
							if ( account[0].equals("A") )
								out.println("<tr><td><b>"+account[1]+"</b></td><td>"+account[2]+"</td><td align=\"right\">"+account[3]+"</td><td>"+account[4]+"</td></tr>");
							else
					  			out.println("<tr><td></td><td></td><td></td><td>"+account[1]+"</td><td align=\"right\">"+account[3]+"</td><td>"+account[2]+"</td></tr>");
						}
						out.println("</table>");
					}					
				}

				out.println("</body></html>"); 
			} catch (Exception ex) {
				ex.printStackTrace();
				out.println("<p>Error in banking client: "+ex.getMessage());
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
