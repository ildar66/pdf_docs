package itso.bank5.client2;

import java.awt.GraphicsConfiguration;
import javax.swing.JFrame;
import itso.bank5.access.*;
import itso.bank5.cmp.CustomerKey;
import itso.bank5.cmp.Customer;

/**
 * @author UELI
 */
public class CustomerMaint extends JFrame {

	IvjEventHandler ivjEventHandler = new IvjEventHandler();

	class IvjEventHandler implements java.awt.event.ActionListener, java.awt.event.WindowListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			if (e.getSource() == CustomerMaint.this.getJButton())   // Retrieve
				connRetrieve(e);
			if (e.getSource() == CustomerMaint.this.getJButton1())  // Update
				connUpdate(e);
			if (e.getSource() == CustomerMaint.this.getJButton2())  // Create
				connCreate(e);
			if (e.getSource() == CustomerMaint.this.getJButton3())  // Delete
				connDelete(e);
		};
		public void windowActivated(java.awt.event.WindowEvent e) {};
		public void windowClosed(java.awt.event.WindowEvent e) {};
		public void windowClosing(java.awt.event.WindowEvent e) {
			if (e.getSource() == CustomerMaint.this) 
				connClose(e);
		};
		public void windowDeactivated(java.awt.event.WindowEvent e) {};
		public void windowDeiconified(java.awt.event.WindowEvent e) {};
		public void windowIconified(java.awt.event.WindowEvent e) {};
		public void windowOpened(java.awt.event.WindowEvent e) {};
	};

     private javax.swing.JPanel jContentPane = null;
     private javax.swing.JLabel jLabel = null;
     private java.awt.Panel panel = null;  //  @jve:visual-info  decl-index=0 visual-constraint="264,130"
     private javax.swing.JButton jButton = null;    // Retrieve
     private javax.swing.JButton jButton1 = null;   // Update
     private javax.swing.JButton jButton2 = null;   // Create
     private javax.swing.JButton jButton3 = null;   // Delete
     private java.awt.Panel panel1 = null;
     private javax.swing.JLabel jLabel1 = null;
     private javax.swing.JTextField jTextField = null;  // customer ID
     private javax.swing.JLabel jLabel2 = null;
     private javax.swing.JTextField jTextField1 = null;  // title
     private javax.swing.JLabel jLabel3 = null;
     private javax.swing.JTextField jTextField2 = null;  // firstName
     private javax.swing.JLabel jLabel4 = null;
     private javax.swing.JTextField jTextField3 = null;  // lastName
     private javax.swing.JLabel jLabel5 = null;
     private javax.swing.JTextField jTextField4 = null;  // user ID
     private javax.swing.JLabel jLabel6 = null;
     private javax.swing.JTextField jTextField5 = null;  // password
     private javax.swing.JLabel jLabel7 = null;          // message
     
     private itso.bank5.access.CustomerFactory ivjCustomerFactory = null;  //  @jve:visual-info  decl-index=0 visual-constraint="275,120"
     private CustomerData customerData = null;
	 private Customer customer = null;

	/**
	 * Constructor for CustomerMaint.
	 */
	public CustomerMaint() {
		super();
		System.out.println("CM-constructor");
		getIvjCustomerFactory();
		//getIvjCustomerFactory().setInitialContextProviderURL("iiop://localhost:2809/");
		initialize();
	}

	private void connRetrieve(java.awt.event.ActionEvent arg1) {
		try {
			System.out.println("CM-retrieve-start");
			int customerID = (new Integer( getJTextField().getText() )).intValue();
			System.out.println("CM-retrieve "+customerID);
			CustomerKey customerKey = new CustomerKey( customerID );
			customer = ivjCustomerFactory.findByPrimaryKey(customerKey);
			customerData = customer.getCustomerData();
			getJTextField1().setText(customerData.getTitle());
			getJTextField2().setText(customerData.getFirstName());
			getJTextField3().setText(customerData.getLastName());
			getJTextField4().setText(customerData.getUserID());
			getJTextField5().setText(customerData.getPassword());
			getJLabel7().setText("Retrieve OK.");
			getJLabel7().setForeground(java.awt.Color.blue);
			System.out.println("CM-retrieve-end: "+customerData.getName());
		} catch (java.lang.Throwable ivjExc) {
			getJLabel7().setText("Retrieve failed.");
			getJLabel7().setForeground(java.awt.Color.red);
			handleException(ivjExc);
		}
	}
	private void connUpdate(java.awt.event.ActionEvent arg1) {
		try {
			System.out.println("CM-update-start");
			customerData.setTitle(getJTextField1().getText().trim());
			customerData.setFirstName(getJTextField2().getText().trim());
			customerData.setLastName(getJTextField3().getText().trim());
			customerData.setUserID(getJTextField4().getText().trim());
			customerData.setPassword(getJTextField5().getText().trim());
			customer.setCustomerData( customerData );
			getJLabel7().setText("Update OK.");
			getJLabel7().setForeground(java.awt.Color.blue);
			System.out.println("CM-update-end");
		} catch (java.lang.Throwable ivjExc) {
			getJLabel7().setText("Update failed.");
			getJLabel7().setForeground(java.awt.Color.red);
			handleException(ivjExc);
		}
	}
	private void connCreate(java.awt.event.ActionEvent arg1) {
		try {
			System.out.println("CM-create-start");
			int customerID = (new Integer( getJTextField().getText() )).intValue();
			System.out.println("CM-create "+customerID);
			customer = ivjCustomerFactory.create(customerID);
			customerData = customer.getCustomerData();
			customerData.setTitle(getJTextField1().getText().trim());
			customerData.setFirstName(getJTextField2().getText().trim());
			customerData.setLastName(getJTextField3().getText().trim());
			customerData.setUserID(getJTextField4().getText().trim());
			customerData.setPassword(getJTextField5().getText().trim());
			customer.setCustomerData( customerData );
			getJLabel7().setText("Create OK.");
			getJLabel7().setForeground(java.awt.Color.blue);
			System.out.println("CM-create-end");
		} catch (java.lang.Throwable ivjExc) {
			getJLabel7().setText("Create failed.");
			getJLabel7().setForeground(java.awt.Color.red);
			handleException(ivjExc);
		}
	}
	private void connDelete(java.awt.event.ActionEvent arg1) {
		try {
			System.out.println("CM-delete-start");
			int customerID = (new Integer( getJTextField().getText() )).intValue();
			System.out.println("CM-retrieve "+customerID);
			CustomerKey customerKey = new CustomerKey( customerID );
			customer = ivjCustomerFactory.findByPrimaryKey(customerKey);
			customer.remove();
			getJLabel7().setText("Delete OK.");
			getJLabel7().setForeground(java.awt.Color.blue);
			System.out.println("CM-delete-end");
		} catch (java.lang.Throwable ivjExc) {
			getJLabel7().setText("Delete failed.");
			getJLabel7().setForeground(java.awt.Color.red);
			handleException(ivjExc);
		}
	}
	private void connClose(java.awt.event.WindowEvent arg1) {
		try {
			System.out.println("CM-closing");
			this.dispose();
			System.exit(0);
		} catch (java.lang.Throwable ivjExc) {
			handleException(ivjExc);
		}
	}
	/**
	 * Constructor for CustomerMaint.
	 * @param gc
	 */
	public CustomerMaint(GraphicsConfiguration gc) {
		super(gc);
	}

	/**
	 * Constructor for CustomerMaint.
	 * @param title
	 */
	public CustomerMaint(String title) {
		super(title);
	}

	/**
	 * Constructor for CustomerMaint.
	 * @param title
	 * @param gc
	 */
	public CustomerMaint(String title, GraphicsConfiguration gc) {
		super(title, gc);
	}

	public static void main(String[] args) {
		CustomerMaint cm = new CustomerMaint();
	}
	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
        this.setContentPane(getJContentPane());
        this.setSize(246, 306);
        this.setTitle("ITSO EJB Redbook");
		getJButton().addActionListener(ivjEventHandler);
		getJButton1().addActionListener(ivjEventHandler);
		getJButton2().addActionListener(ivjEventHandler);
		getJButton3().addActionListener(ivjEventHandler);
		this.addWindowListener(ivjEventHandler);
		getJLabel7().setText("Enter a customer ID and Retrieve.");
		getJLabel7().setBackground(java.awt.Color.white);
		getJLabel7().setForeground(java.awt.Color.blue);
		this.setLocation(100,100);
		this.show();
		System.out.println("CM-initialized");			
	}
	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private javax.swing.JPanel getJContentPane() {
		if(jContentPane == null) {
			jContentPane = new javax.swing.JPanel();
			java.awt.BorderLayout layBorderLayout1 = new java.awt.BorderLayout();
			jContentPane.setLayout(layBorderLayout1);
			jContentPane.add(getJLabel(), java.awt.BorderLayout.NORTH);
			jContentPane.add(getPanel(), java.awt.BorderLayout.SOUTH);
			jContentPane.add(getPanel1(), java.awt.BorderLayout.CENTER);
		}
		return jContentPane;
	}
	/**
	 * This method initializes jLabel
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel() {
		if(jLabel == null) {
			jLabel = new javax.swing.JLabel();
			jLabel.setText("Customer Maintenance");
			jLabel.setFont(new java.awt.Font("sansserif", 1, 18));
			jLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		}
		return jLabel;
	}
	/**
	 * This method initializes panel
	 * 
	 * @return java.awt.Panel
	 */
	private java.awt.Panel getPanel() {
		if(panel == null) {
			panel = new java.awt.Panel();
			java.awt.GridLayout layGridLayout5 = new java.awt.GridLayout();
			layGridLayout5.setRows(2);
			panel.setLayout(layGridLayout5);
			panel.add(getJButton(), null);
			panel.add(getJButton1(), null);
			panel.add(getJButton2(), null);
			panel.add(getJButton3(), null);
		}
		return panel;
	}
	/**
	 * This method initializes jButton
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton() {
		if(jButton == null) {
			jButton = new javax.swing.JButton();
			jButton.setPreferredSize(new java.awt.Dimension(82,25));
			jButton.setText("Retrieve");
		}
		return jButton;
	}
	/**
	 * This method initializes jButton1
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton1() {
		if(jButton1 == null) {
			jButton1 = new javax.swing.JButton();
			jButton1.setPreferredSize(new java.awt.Dimension(82,25));
			jButton1.setText("Update");
		}
		return jButton1;
	}
	/**
	 * This method initializes jButton2
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton2() {
		if(jButton2 == null) {
			jButton2 = new javax.swing.JButton();
			jButton2.setPreferredSize(new java.awt.Dimension(82,25));
			jButton2.setText("Create");
		}
		return jButton2;
	}
	/**
	 * This method initializes jButton3
	 * 
	 * @return javax.swing.JButton
	 */
	private javax.swing.JButton getJButton3() {
		if(jButton3 == null) {
			jButton3 = new javax.swing.JButton();
			jButton3.setPreferredSize(new java.awt.Dimension(82,25));
			jButton3.setText("Delete");
		}
		return jButton3;
	}
	/**
	 * This method initializes panel1
	 * 
	 * @return java.awt.Panel
	 */
	private java.awt.Panel getPanel1() {
		if(panel1 == null) {
			panel1 = new java.awt.Panel();
			java.awt.GridBagConstraints consGridBagConstraints3 = new java.awt.GridBagConstraints();
			java.awt.GridBagLayout layGridBagLayout2 = new java.awt.GridBagLayout();
			java.awt.GridBagConstraints consGridBagConstraints4 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints8 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints9 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints11 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints10 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints12 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints14 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints13 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints16 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints17 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints15 = new java.awt.GridBagConstraints();
			java.awt.GridBagConstraints consGridBagConstraints1 = new java.awt.GridBagConstraints();
			consGridBagConstraints17.weightx = 1.0;
			consGridBagConstraints17.fill = java.awt.GridBagConstraints.NONE;
			consGridBagConstraints16.weightx = 1.0;
			consGridBagConstraints16.fill = java.awt.GridBagConstraints.NONE;
			consGridBagConstraints12.weightx = 1.0;
			consGridBagConstraints12.fill = java.awt.GridBagConstraints.NONE;
			consGridBagConstraints12.gridx = 1;
			consGridBagConstraints12.gridy = 3;
			consGridBagConstraints12.insets = new java.awt.Insets(5,10,5,10);
			consGridBagConstraints12.anchor = java.awt.GridBagConstraints.WEST;
			consGridBagConstraints14.insets = new java.awt.Insets(5,10,5,10);
			consGridBagConstraints14.gridx = 0;
			consGridBagConstraints14.gridy = 4;
			consGridBagConstraints14.anchor = java.awt.GridBagConstraints.EAST;
			consGridBagConstraints11.weightx = 1.0;
			consGridBagConstraints11.fill = java.awt.GridBagConstraints.NONE;
			consGridBagConstraints9.weightx = 1.0;
			consGridBagConstraints9.fill = java.awt.GridBagConstraints.NONE;
			consGridBagConstraints9.gridx = 1;
			consGridBagConstraints9.gridy = 1;
			consGridBagConstraints9.insets = new java.awt.Insets(0,10,0,10);
			consGridBagConstraints9.anchor = java.awt.GridBagConstraints.WEST;
			consGridBagConstraints16.gridx = 1;
			consGridBagConstraints16.gridy = 4;
			consGridBagConstraints16.insets = new java.awt.Insets(0,10,0,10);
			consGridBagConstraints16.anchor = java.awt.GridBagConstraints.WEST;
			consGridBagConstraints4.weightx = 1.0;
			consGridBagConstraints4.fill = java.awt.GridBagConstraints.NONE;
			consGridBagConstraints4.anchor = java.awt.GridBagConstraints.WEST;
			consGridBagConstraints4.insets = new java.awt.Insets(0,10,0,10);
			consGridBagConstraints4.gridx = 1;
			consGridBagConstraints4.gridy = 0;
			consGridBagConstraints3.insets = new java.awt.Insets(5,10,5,10);
			consGridBagConstraints3.gridx = 0;
			consGridBagConstraints3.gridy = 0;
			consGridBagConstraints8.gridx = 0;
			consGridBagConstraints8.gridy = 1;
			consGridBagConstraints8.insets = new java.awt.Insets(5,10,5,10);
			consGridBagConstraints11.gridx = 1;
			consGridBagConstraints10.gridx = 0;
			consGridBagConstraints10.gridy = 2;
			consGridBagConstraints10.insets = new java.awt.Insets(5,10,5,10);
			consGridBagConstraints10.anchor = java.awt.GridBagConstraints.EAST;
			consGridBagConstraints15.insets = new java.awt.Insets(5,10,5,10);
			consGridBagConstraints13.gridx = 0;
			consGridBagConstraints13.gridy = 3;
			consGridBagConstraints15.gridx = 0;
			consGridBagConstraints15.gridy = 5;
			consGridBagConstraints15.anchor = java.awt.GridBagConstraints.EAST;
			consGridBagConstraints13.anchor = java.awt.GridBagConstraints.EAST;
			consGridBagConstraints13.insets = new java.awt.Insets(5,10,5,10);
			consGridBagConstraints8.anchor = java.awt.GridBagConstraints.EAST;
			consGridBagConstraints11.gridy = 2;
			consGridBagConstraints11.insets = new java.awt.Insets(0,10,0,10);
			consGridBagConstraints11.anchor = java.awt.GridBagConstraints.WEST;
			consGridBagConstraints1.gridx = 0;
			consGridBagConstraints1.gridy = 6;
			consGridBagConstraints1.insets = new java.awt.Insets(5,10,5,10);
			consGridBagConstraints1.gridwidth = 2;
			consGridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
			consGridBagConstraints17.gridx = 1;
			consGridBagConstraints17.gridy = 5;
			consGridBagConstraints17.insets = new java.awt.Insets(0,10,0,10);
			consGridBagConstraints17.anchor = java.awt.GridBagConstraints.WEST;
			panel1.setLayout(layGridBagLayout2);
			panel1.add(getJLabel1(), consGridBagConstraints3);
			panel1.add(getJTextField(), consGridBagConstraints4);
			panel1.add(getJLabel2(), consGridBagConstraints8);
			panel1.add(getJTextField1(), consGridBagConstraints9);
			panel1.add(getJLabel3(), consGridBagConstraints10);
			panel1.add(getJTextField2(), consGridBagConstraints11);
			panel1.add(getJTextField3(), consGridBagConstraints12);
			panel1.add(getJLabel4(), consGridBagConstraints13);
			panel1.add(getJLabel5(), consGridBagConstraints14);
			panel1.add(getJLabel6(), consGridBagConstraints15);
			panel1.add(getJTextField4(), consGridBagConstraints16);
			panel1.add(getJTextField5(), consGridBagConstraints17);
			panel1.add(getJLabel7(), consGridBagConstraints1);
		}
		return panel1;
	}
	/**
	 * This method initializes jLabel1
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel1() {
		if(jLabel1 == null) {
			jLabel1 = new javax.swing.JLabel();
			jLabel1.setText("Customer ID");
			jLabel1.setPreferredSize(new java.awt.Dimension(100,15));
		}
		return jLabel1;
	}
	/**
	 * This method initializes jTextField
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField() {
		if(jTextField == null) {
			jTextField = new javax.swing.JTextField();
			jTextField.setColumns(4);
			jTextField.setMinimumSize(new java.awt.Dimension(30,19));
			jTextField.setName("id");
		}
		return jTextField;
	}
	/**
	 * This method initializes jLabel2
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel2() {
		if(jLabel2 == null) {
			jLabel2 = new javax.swing.JLabel();
			jLabel2.setText("Title");
			jLabel2.setPreferredSize(new java.awt.Dimension(100,15));
		}
		return jLabel2;
	}
	/**
	 * This method initializes jTextField1
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField1() {
		if(jTextField1 == null) {
			jTextField1 = new javax.swing.JTextField();
			jTextField1.setColumns(4);
			jTextField1.setPreferredSize(new java.awt.Dimension(10,15));
			jTextField1.setMinimumSize(new java.awt.Dimension(30,19));
		}
		return jTextField1;
	}
	/**
	 * This method initializes jLabel3
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel3() {
		if(jLabel3 == null) {
			jLabel3 = new javax.swing.JLabel();
			jLabel3.setText("Firstname");
			jLabel3.setPreferredSize(new java.awt.Dimension(100,15));
		}
		return jLabel3;
	}
	/**
	 * This method initializes jTextField2
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField2() {
		if(jTextField2 == null) {
			jTextField2 = new javax.swing.JTextField();
			jTextField2.setPreferredSize(new java.awt.Dimension(100,15));
			jTextField2.setColumns(30);
			jTextField2.setMinimumSize(new java.awt.Dimension(100,19));
		}
		return jTextField2;
	}
	/**
	 * This method initializes jTextField3
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField3() {
		if(jTextField3 == null) {
			jTextField3 = new javax.swing.JTextField();
			jTextField3.setColumns(30);
			jTextField3.setMinimumSize(new java.awt.Dimension(100,19));
		}
		return jTextField3;
	}
	/**
	 * This method initializes jLabel4
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel4() {
		if(jLabel4 == null) {
			jLabel4 = new javax.swing.JLabel();
			jLabel4.setText("Lastname");
			jLabel4.setPreferredSize(new java.awt.Dimension(100,15));
		}
		return jLabel4;
	}
	/**
	 * This method initializes jLabel5
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel5() {
		if(jLabel5 == null) {
			jLabel5 = new javax.swing.JLabel();
			jLabel5.setText("User ID");
			jLabel5.setPreferredSize(new java.awt.Dimension(100,15));
		}
		return jLabel5;
	}
	/**
	 * This method initializes jLabel6
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel6() {
		if(jLabel6 == null) {
			jLabel6 = new javax.swing.JLabel();
			jLabel6.setText("Password");
			jLabel6.setPreferredSize(new java.awt.Dimension(100,15));
		}
		return jLabel6;
	}
	/**
	 * This method initializes jTextField4
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField4() {
		if(jTextField4 == null) {
			jTextField4 = new javax.swing.JTextField();
			jTextField4.setColumns(8);
			jTextField4.setMinimumSize(new java.awt.Dimension(60,19));
		}
		return jTextField4;
	}
	/**
	 * This method initializes jTextField5
	 * 
	 * @return javax.swing.JTextField
	 */
	private javax.swing.JTextField getJTextField5() {
		if(jTextField5 == null) {
			jTextField5 = new javax.swing.JTextField();
			jTextField5.setPreferredSize(new java.awt.Dimension(100,15));
			jTextField5.setMinimumSize(new java.awt.Dimension(60,19));
			jTextField5.setColumns(8);
		}
		return jTextField5;
	}

	/**
	 * This method initializes jLabel7
	 * 
	 * @return javax.swing.JLabel
	 */
	private javax.swing.JLabel getJLabel7() {
		if(jLabel7 == null) {
			jLabel7 = new javax.swing.JLabel();
			jLabel7.setText("Msg");
			jLabel7.setPreferredSize(new java.awt.Dimension(200,15));
			jLabel7.setMinimumSize(new java.awt.Dimension(200,15));
		}
		return jLabel7;
	}
	/**
	 * This method initializes ivjCustomerFactory
	 * 
	 * @return itso.bank5.access.CustomerFactory
	 */
	private itso.bank5.access.CustomerFactory getIvjCustomerFactory() {
		if(ivjCustomerFactory == null) {
			ivjCustomerFactory = new itso.bank5.access.CustomerFactory();
		}
		return ivjCustomerFactory;
	}
	
	private void handleException(java.lang.Throwable exception) {
		/* Uncomment the following lines to print uncaught exceptions to stdout */
		 System.out.println("--------- UNCAUGHT EXCEPTION ---------");
		 exception.printStackTrace(System.out);
	}

}  //  @jve:visual-info  decl-index=0 visual-constraint="2,-22"
