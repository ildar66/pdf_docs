package itso.bank5.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import itso.bank5.session.*;
import itso.bank5.exception.InsufficientFundException;
import itso.bank5.utility.*;
import java.io.PrintWriter;
import javax.ejb.EJBException;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.math.BigDecimal;
import java.util.*;

/**
 * @version 	1.0
 * @author
 */
public class BankingServletExternalized extends HttpServlet {

	private BankingHome bankingHome;


	/**
	* @see javax.servlet.http.HttpServlet#void (javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	*/
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {

		processBanking(req, resp);

	}

	/**
	* @see javax.servlet.http.HttpServlet#void (javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	*/
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {

		processBanking(req, resp);

	}

	/*
	* @see GenericServlet#init()
	*/
	public void init() throws ServletException {
		try {
			//InitialContext initCtx = new InitialContext();
			//Object objref = initCtx.lookup("ejb/itsobank/Banking");
			//Object objref = initCtx.lookup("java:comp/env/ejb/Banking");
			//bankingHome   = (BankingHome)PortableRemoteObject.narrow(objref,BankingHome.class);
			bankingHome = (BankingHome)HomeFactory.singleton().getHome(BankingServletMessages.getString("itsoejb/Banking_1")); //$NON-NLS-1$
		} catch (NamingException ex) {
			ex.printStackTrace();
			throw new EJBException(BankingServletMessages.getString("itsoError_looking_up_BankingHome___2")+ex.getMessage()); //$NON-NLS-1$
		}
	}

	/**
	 * processBanking
	 */

	public void processBanking(HttpServletRequest req, HttpServletResponse resp) {
		try {
			PrintWriter out = resp.getWriter();
			out.println(BankingServletMessages.getString("itso<html><body><h1>Banking_Servlet</h1>_3")); //$NON-NLS-1$
			BigDecimal amount = null;
			int customerid = 0;
			
			String custlistBut = req.getParameter("custlist"); //$NON-NLS-1$
			String balanceBut  = req.getParameter("balance"); //$NON-NLS-1$
			String customerBut = req.getParameter("customers"); //$NON-NLS-1$
			String trecordBut  = req.getParameter("trecords"); //$NON-NLS-1$
			String depositBut  = req.getParameter("deposit"); //$NON-NLS-1$
			String withdrawBut = req.getParameter("withdraw"); //$NON-NLS-1$
			String transferBut = req.getParameter("transfer"); //$NON-NLS-1$
			
			String account1    = req.getParameter("account1"); //$NON-NLS-1$
			String account2    = req.getParameter("account2"); //$NON-NLS-1$

			try {
				if ( !(req.getParameter("amount").trim().equals("")) )  //$NON-NLS-1$ //$NON-NLS-2$
					amount  = new BigDecimal( req.getParameter("amount") ); //$NON-NLS-1$
				if ( !(req.getParameter("customerid").trim().equals("")) )  //$NON-NLS-1$ //$NON-NLS-2$
					customerid = new Integer( req.getParameter("customerid") ).intValue(); //$NON-NLS-1$
					
				Banking bank = bankingHome.create();
				
				if (custlistBut != null) 
					out.println(BankingServletMessages.getString("itso<h2>_Customer___19")+customerid+"</h2>"); //$NON-NLS-1$ //$NON-NLS-2$
				else
					out.println(BankingServletMessages.getString("itso<h2>_Account___21")+account1+"</h2>"); //$NON-NLS-1$ //$NON-NLS-2$

				if (balanceBut  != null) {
					BigDecimal balance = bank.getBalance(account1);
					out.println(BankingServletMessages.getString("itso<p>_Balance___23")+ balance); //$NON-NLS-1$
				}
				
				if (depositBut  != null) {
					BigDecimal balance = bank.deposit(account1, amount);
					out.println(BankingServletMessages.getString("itso<p>_Deposit___24")+ amount); //$NON-NLS-1$
					out.println(BankingServletMessages.getString("itso<p>_Balance___25")+ balance); //$NON-NLS-1$
				}
				
				if (withdrawBut != null) {
				  try {
					BigDecimal balance = bank.withdraw(account1, amount);
					out.println(BankingServletMessages.getString("itso<p>_Withdraw___26")+ amount); //$NON-NLS-1$
					out.println(BankingServletMessages.getString("itso<p>_Balance___27")+ balance); //$NON-NLS-1$
				  } catch (InsufficientFundException ex) {
					out.println(BankingServletMessages.getString("itso<p>_Withdraw___28")+ amount); //$NON-NLS-1$
					out.println(BankingServletMessages.getString("itso<p>_Sorry__Insufficient_funds_in_account_29")); //$NON-NLS-1$
				  }
				}
				
				if (transferBut != null) {
				  try {
					BigDecimal balance = bank.transfer(account1, account2, amount);
					out.println(BankingServletMessages.getString("itso<p>_Transfer___30")+ amount); //$NON-NLS-1$
					out.println(BankingServletMessages.getString("itso<p>_From_account___31") + account1 + BankingServletMessages.getString("itso_balance___32")+ balance); //$NON-NLS-1$ //$NON-NLS-2$
					out.println(BankingServletMessages.getString("itso<p>_To_account___33") + account2 + BankingServletMessages.getString("itso_balance___34")+ bank.getBalance(account2)); //$NON-NLS-1$ //$NON-NLS-2$
				  } catch (InsufficientFundException ex) {
					out.println(BankingServletMessages.getString("itso<p>_Transfer___35")+ amount); //$NON-NLS-1$
					out.println(BankingServletMessages.getString("itso<p>_Sorry__Insufficient_funds_in_account_36")); //$NON-NLS-1$
				  }
				}
				  
				if (customerBut != null) {
					out.println(BankingServletMessages.getString("itso<h3>Customers_</h3>_37")); //$NON-NLS-1$
					Vector results = bank.getCustomers(account1);
					if (results == null)
						out.println(BankingServletMessages.getString("itso<p>_No_customers_found__38")); //$NON-NLS-1$
					else {
						for ( int i=0; i < results.size(); i++ ) {
							out.println((String)results.elementAt(i)+"<br>"); //$NON-NLS-1$
						}
					}
				}

				if (trecordBut != null) {
					out.println(BankingServletMessages.getString("itso<h3>Transactions_</h3><ul>_40")); //$NON-NLS-1$
					Vector results = bank.getTransrecords(account1);
					Enumeration enum = results.elements();
					while (enum.hasMoreElements()) {
						out.println("<li>"+(String)enum.nextElement()); //$NON-NLS-1$
					}
					out.println("</ul>"); //$NON-NLS-1$
				}

				if (custlistBut != null) {
					Vector results = bank.listAccountsOfCustomer(customerid);
					if ( results.size() == 0 ) 
						out.println(BankingServletMessages.getString("itso<p>Nothing_found_43")); //$NON-NLS-1$
					else {
						String custdata[] = (String[])results.elementAt(0);
						out.println(BankingServletMessages.getString("itso<h3>Accounts_of__44")+custdata[2]+"</h3>"); //$NON-NLS-1$ //$NON-NLS-2$
						out.println(BankingServletMessages.getString("itso<table_border___1___cellpadding___6__><tr><td><b>Account</b></td><td><b>Number</b></td><td><b>Balance</b></td><td><b>Tx</b></td><td><b>Amount</b></td><td><b>Timestamp</b></td></tr>_46")); //$NON-NLS-1$
						for ( int i=1; i < results.size(); i++ ) {
							String account[] = (String[])results.elementAt(i);
							if ( account[0].equals("A") ) //$NON-NLS-1$
								out.println("<tr><td><b>"+account[1]+"</b></td><td>"+account[2]+"</td><td align=\"right\">"+account[3]+"</td><td>"+account[4]+"</td></tr>"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
							else
					  			out.println("<tr><td></td><td></td><td></td><td>"+account[1]+"</td><td align=\"right\">"+account[3]+"</td><td>"+account[2]+"</td></tr>"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
						}
						out.println("</table>"); //$NON-NLS-1$
					}					
				}

				out.println("</body></html>");  //$NON-NLS-1$
			} catch (Exception ex) {
				ex.printStackTrace();
				out.println(BankingServletMessages.getString("itso<p>Error_in_banking_session_bean___59")+ex.getMessage()); //$NON-NLS-1$
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
}
