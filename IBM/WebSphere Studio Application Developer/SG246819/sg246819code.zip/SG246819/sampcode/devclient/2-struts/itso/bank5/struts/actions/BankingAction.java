package itso.bank5.struts.actions;

import java.io.IOException;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import itso.bank5.struts.forms.AccountRequestForm;

import itso.bank5.session.*;
import itso.bank5.utility.*;
import itso.bank5.exception.InsufficientFundException;
import javax.naming.NamingException;
import javax.ejb.EJBException;
import java.math.BigDecimal;
import java.util.*;

/**
 * @version 	1.0
 * @author
 */
public class BankingAction extends Action {

	/**
	* Constructor
	*/
	public BankingAction() {
		super();
	}
	public ActionForward perform(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws IOException, ServletException {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value
		AccountRequestForm accountRequestForm = (AccountRequestForm) form;
		request.setAttribute("formbean",accountRequestForm);

		BankingHome bankingHome;
		try {
			bankingHome   = (BankingHome)HomeFactory.singleton().getHome("ejb/Banking");
		} catch (NamingException ex) {
			ex.printStackTrace();
			throw new EJBException("Error looking up BankingHome: "+ex.getMessage());
		}			

		try {
			
			// do something here
			String accountID = accountRequestForm.getAccountidS();
			BigDecimal amount = accountRequestForm.getAmount();
			String selection = accountRequestForm.getSelection();
			
			Banking bank = bankingHome.create();
			
			if ( selection.equals("balance") ) {
				BigDecimal balance = bank.getBalance(accountID);
				request.setAttribute("balance",balance);
				forward = mapping.findForward("information");
				String[] result = bank.getAccountInfo(accountID);
				request.setAttribute("account",result);
			}
			else if ( selection.equals("list") ) {
				Vector results = bank.getTransrecords(accountID);
				request.setAttribute("trecords",results);
				forward = mapping.findForward("translist");
			} 
			else if ( selection.equals("deposit") ) {
				BigDecimal balance = bank.deposit(accountID, amount);
				request.setAttribute("balance",balance);
				forward = mapping.findForward("funds");
			}
			else if ( selection.equals("withdraw") ) {
				try {
					BigDecimal balance = bank.withdraw(accountID, amount);
					request.setAttribute("balance",balance);
				} catch (InsufficientFundException ex) {
					errors.add("account", new ActionError("error.insuffientfunds"));
				}
				forward = mapping.findForward("funds");
			}

		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("account", new ActionError("error.exception"));

		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.empty()) {
			saveErrors(request, errors);
			forward = mapping.findForward("fail");
		}
		// Write logic determining how the user should be forwarded.
		
		// Finish with
		return (forward);

	}
}
