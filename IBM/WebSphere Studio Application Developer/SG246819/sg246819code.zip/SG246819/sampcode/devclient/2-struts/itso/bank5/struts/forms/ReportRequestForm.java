package itso.bank5.struts.forms;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * Form bean for a Struts application.
 * Users may access 8 fields on this form:
 * <ul>
 * <li>customeridS - [your comment here]
 * <li>accountID - [your comment here]
 * <li>goldS - [your comment here]
 * <li>interestS - [your comment here]
 * <li>goldBalance - [your comment here]
 * <li>customerID - [your comment here]
 * <li>interest - [your comment here]
 * <li>selection - [your comment here]
 * </ul>
 * @version 	1.0
 * @author
 */
public class ReportRequestForm extends ActionForm {

	private String customeridS = null;
	private String accountID = null;
	private String goldS = null;
	private String interestS = null;
	private java.math.BigDecimal goldBalance = null;
	private int customerID;
	private int interest;
	private String selection = null;

	/**
	 * Get customeridS
	 * @return String
	 */
	public String getCustomeridS() {
		return customeridS;
	}

	/**
	 * Set customeridS
	 * @param <code>String</code>
	 */
	public void setCustomeridS(String c) {
		customeridS = c;
	}
	/**
	 * Get accountID
	 * @return String
	 */
	public String getAccountID() {
		return accountID;
	}

	/**
	 * Set accountID
	 * @param <code>String</code>
	 */
	public void setAccountID(String a) {
		accountID = a;
	}
	/**
	 * Get goldS
	 * @return String
	 */
	public String getGoldS() {
		return goldS;
	}

	/**
	 * Set goldS
	 * @param <code>String</code>
	 */
	public void setGoldS(String g) {
		goldS = g;
	}
	/**
	 * Get interestS
	 * @return String
	 */
	public String getInterestS() {
		return interestS;
	}

	/**
	 * Set interestS
	 * @param <code>String</code>
	 */
	public void setInterestS(String i) {
		interestS = i;
	}
	/**
	 * Get goldBalance
	 * @return java.math.BigDecimal
	 */
	public java.math.BigDecimal getGoldBalance() {
		return goldBalance;
	}

	/**
	 * Set goldBalance
	 * @param <code>java.math.BigDecimal</code>
	 */
	public void setGoldBalance(java.math.BigDecimal g) {
		goldBalance = g;
	}
	/**
	 * Get customerID
	 * @return int
	 */
	public int getCustomerID() {
		return customerID;
	}

	/**
	 * Set customerID
	 * @param <code>int</code>
	 */
	public void setCustomerID(int c) {
		customerID = c;
	}
	/**
	 * Get interest
	 * @return int
	 */
	public int getInterest() {
		return interest;
	}

	/**
	 * Set interest
	 * @param <code>int</code>
	 */
	public void setInterest(int i) {
		interest = i;
	}
	/**
	 * Get selection
	 * @return String
	 */
	public String getSelection() {
		return selection;
	}

	/**
	 * Set selection
	 * @param <code>String</code>
	 */
	public void setSelection(String s) {
		selection = s;
	}
	/**
	* Constructor
	*/
	public ReportRequestForm() {

		super();

	}
	public void reset(ActionMapping mapping, HttpServletRequest request) {

		// Reset values are provided as samples only. Change as appropriate.

		customeridS = null;
		accountID = null;
		goldS = null;
		interestS = null;
		goldBalance = null;
		customerID = 0;
		interest = 0;
		selection = null;

	}
	public ActionErrors validate(
		ActionMapping mapping,
		HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();
		// Validate the fields in your form, adding
		// adding each error to this.errors as found, e.g.

		// if ((field == null) || (field.length() == 0)) {
		//   errors.add("field", new ActionError("error.field.required"));
		// }
		if ( selection.equals("Reports") ) {
			if ( customeridS.trim().equals("") |
				 accountID.trim().equals("") |
				 goldS.trim().equals("") |
				 interestS.trim().equals("") )
				errors.add("field", new ActionError("error.required"));
			try {
				customerID = (new Integer(customeridS)).intValue();
				interest = (new Integer(interestS)).intValue();
				goldBalance = new java.math.BigDecimal(goldS);
			} catch (Exception e) {
				errors.add("field", new ActionError("error.invalid"));
			}
		}
		return errors;
	}
}
