package itso.bank5.struts.forms;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * Form bean for a Struts application.
 * Users may access 5 fields on this form:
 * <ul>
 * <li>accountidS - [your comment here]
 * <li>accountidT - [your comment here]
 * <li>amountS - [your comment here]
 * <li>selection - [your comment here]
 * <li>amount - [your comment here]
 * </ul>
 * @version 	1.0
 * @author
 */
public class AccountRequestForm extends ActionForm {

	private String accountidS = null;
	private String accountidT = null;
	private String amountS = null;
	private String selection = null;
	private java.math.BigDecimal amount = null;

	/**
	 * Get accountidS
	 * @return String
	 */
	public String getAccountidS() {
		return accountidS;
	}

	/**
	 * Set accountidS
	 * @param <code>String</code>
	 */
	public void setAccountidS(String a) {
		accountidS = a;
	}
	/**
	 * Get accountidT
	 * @return String
	 */
	public String getAccountidT() {
		return accountidT;
	}

	/**
	 * Set accountidT
	 * @param <code>String</code>
	 */
	public void setAccountidT(String a) {
		accountidT = a;
	}
	/**
	 * Get amountS
	 * @return String
	 */
	public String getAmountS() {
		return amountS;
	}

	/**
	 * Set amountS
	 * @param <code>String</code>
	 */
	public void setAmountS(String a) {
		amountS = a;
	}
	/**
	 * Get selection
	 * @return String
	 */
	public String getSelection() {
		return selection;
	}

	/**
	 * Set selection
	 * @param <code>String</code>
	 */
	public void setSelection(String s) {
		selection = s;
	}
	/**
	 * Get amount
	 * @return java.math.BigDecimal
	 */
	public java.math.BigDecimal getAmount() {
		return amount;
	}

	/**
	 * Set amount
	 * @param <code>java.math.BigDecimal</code>
	 */
	public void setAmount(java.math.BigDecimal a) {
		amount = a;
	}
	/**
	* Constructor
	*/
	public AccountRequestForm() {

		super();

	}
	public void reset(ActionMapping mapping, HttpServletRequest request) {

		// Reset values are provided as samples only. Change as appropriate.

		accountidS = null;
		accountidT = null;
		amountS = null;
		selection = null;
		amount = null;

	}
	public ActionErrors validate(
		ActionMapping mapping,
		HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();
		// Validate the fields in your form, adding
		// adding each error to this.errors as found, e.g.

		// if ((field == null) || (field.length() == 0)) {
		//   errors.add("field", new ActionError("error.field.required"));
		// }
		boolean amountRequired = selection.equals("deposit") || selection.equals("withdraw") || selection.equals("transfer");
	
		if ( accountidS.trim().equals("") ) 
			errors.add("account", new ActionError("error.noaccount"));
		if ( amountS.trim().equals("") & amountRequired )
			errors.add("account", new ActionError("error.noamount"));
		else 
			if ( amountRequired ) {
				try {
					setAmount( new java.math.BigDecimal(amountS) );
				} catch (Exception e) {
					errors.add("account", new ActionError("error.invalidamount"));
				}
		}
		if ( selection.equals("transfer") ) {
			if (accountidT == null || accountidT.trim().equals("") )
				errors.add("account", new ActionError("error.noaccount"));
		}
		return errors;
	}
}
