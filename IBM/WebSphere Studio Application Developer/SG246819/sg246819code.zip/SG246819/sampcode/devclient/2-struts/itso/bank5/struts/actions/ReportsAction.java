package itso.bank5.struts.actions;

import java.io.IOException;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import itso.bank5.struts.forms.ReportRequestForm;

import itso.bank5.session.*;
import itso.bank5.utility.*;
import itso.bank5.exception.InsufficientFundException;
import javax.naming.NamingException;
import javax.ejb.EJBException;
import java.math.BigDecimal;
import java.util.*;

/**
 * @version 	1.0
 * @author
 */
public class ReportsAction extends Action {

	/**
	* Constructor
	*/
	public ReportsAction() {
		super();
	}
	public ActionForward perform(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws IOException, ServletException {

		ActionErrors errors = new ActionErrors();
		ActionForward forward = new ActionForward();
		// return value
		ReportRequestForm reportRequestForm = (ReportRequestForm) form;
		request.setAttribute("formbean",reportRequestForm);

		ReportsHome reportsHome;
		try {
			reportsHome   = (ReportsHome)HomeFactory.singleton().getHome("ejb/Reports");
		} catch (NamingException ex) {
			ex.printStackTrace();
			throw new EJBException("Error looking up ReportsHome: "+ex.getMessage());
		}			

		try {

			// stateful session bean
			Reports report = reportsHome.create();
			
			BigDecimal balance = null;
			String accountID = null;
			int customerID = 0;
			int interest = 10;
			String selection = null;
			selection  = reportRequestForm.getSelection();
		
			if ( selection.equals("Accounts") ) {
				Vector accountList = report.listAllAccounts();
				request.setAttribute("accounts",accountList);
				forward = mapping.findForward("accounts");
			}
			else if ( selection.equals("Customers") ) {
				Vector customerList = report.listCustomerNames();
				request.setAttribute("customers",customerList);
				forward = mapping.findForward("customers");
			}
			else {
				customerID = reportRequestForm.getCustomerID();
				accountID  = reportRequestForm.getAccountID();
				balance    = reportRequestForm.getGoldBalance();
				interest   = reportRequestForm.getInterest();

				report.setCurrentCustomer(customerID);
				report.setCurrentAccount(accountID);
				report.setCurrentBalance(balance);
				report.setCurrentInterest(interest);
		
				Vector goldAccounts = report.listGoldAccounts();			
				request.setAttribute("goldAccounts",goldAccounts);
				
				Vector goldCustomers = report.listGoldCustomers();
				request.setAttribute("goldCustomers",goldCustomers);
				
				Vector transferAcounts = report.listTransferAccounts();
				request.setAttribute("transferAccounts",transferAcounts);
				
				Vector highInterest = report.listHighInterest();
				request.setAttribute("highInterest",highInterest);
				
				String[] largestAccount = report.listLargestAccount();
				request.setAttribute("largestAccount",largestAccount);
				
				forward = mapping.findForward("reports");
			}
			// remove the stateful session bean
			report.remove();

		} catch (Exception e) {

			// Report the error using the appropriate name and ID.
			errors.add("account", new ActionError("error.exception"));

		}

		// If a message is required, save the specified key(s)
		// into the request for use by the <struts:errors> tag.

		if (!errors.empty()) {
			saveErrors(request, errors);
			forward = mapping.findForward("fail");
		}

		// Finish with
		return (forward);

	}
}
