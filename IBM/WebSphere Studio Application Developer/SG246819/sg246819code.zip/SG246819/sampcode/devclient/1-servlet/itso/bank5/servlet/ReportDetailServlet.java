package itso.bank5.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import itso.bank5.session.*;
import itso.bank5.exception.InsufficientFundException;
import java.io.PrintWriter;
import javax.ejb.EJBException;
import javax.ejb.Handle;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.math.BigDecimal;
import java.util.*;

/**
 * @version 	1.0
 * @author
 */
public class ReportDetailServlet extends HttpServlet {

	/**
	* @see javax.servlet.http.HttpServlet#void (javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	*/
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {

		processReports(req, resp);

	}

	/**
	* @see javax.servlet.http.HttpServlet#void (javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	*/
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {

		processReports(req, resp);

	}

	/**
	* @see javax.servlet.GenericServlet#void ()
	*/
	public void init() throws ServletException {

	}

	public void processReports(HttpServletRequest req, HttpServletResponse resp) {
		try {
			BigDecimal balance = null;
			String accountID = null;
			int customerID = 0;
			int interest = 10;
	
			HttpSession session = req.getSession(false);
			Handle handle = (Handle)session.getAttribute("reportEJB");
			Reports report = (Reports)handle.getEJBObject();
			
			try {
				if ( !(req.getParameter("acctradio").trim().equals("")) ) 
					accountID = req.getParameter("acctradio");
				if ( !(req.getParameter("balance").trim().equals("")) ) 
					balance    = new BigDecimal( req.getParameter("balance") );
				if ( !(req.getParameter("interest").trim().equals("")) ) 
					interest   = new Integer( req.getParameter("interest") ).intValue();
				
				customerID = (new Integer( accountID.substring(0,3) )).intValue();
				report.setCurrentCustomer(customerID);
				report.setCurrentAccount(accountID);
				report.setCurrentBalance(balance);
				report.setCurrentInterest(interest);
				
				Vector goldAccounts  = new Vector();			
				Vector goldCustomers = new Vector();
				if (balance != null) {
					goldAccounts = report.listGoldAccounts();			
					goldCustomers = report.listGoldCustomers();
				}
				req.setAttribute("goldAccounts",goldAccounts);
				req.setAttribute("goldCustomers",goldCustomers);
					
				
				Vector transferAcounts = report.listTransferAccounts();
				req.setAttribute("transferAccounts",transferAcounts);
				
				Vector highInterest = report.listHighInterest();
				req.setAttribute("highInterest",highInterest);
				
				String[] largestAccount = report.listLargestAccount();
				req.setAttribute("largestAccount",largestAccount);
				
				// remove the stateful session bean
				report.remove();
				
				// remove session
				session.invalidate();
				
				// call JSP
				getServletContext().getRequestDispatcher("ReportDetails").forward(req,resp);
				
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
}
