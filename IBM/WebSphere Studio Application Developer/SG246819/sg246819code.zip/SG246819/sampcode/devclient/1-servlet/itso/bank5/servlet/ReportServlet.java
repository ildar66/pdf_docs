package itso.bank5.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import itso.bank5.session.*;
import itso.bank5.exception.InsufficientFundException;
import itso.bank5.utility.*;
import java.io.PrintWriter;
import javax.ejb.EJBException;
import javax.ejb.Handle;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.math.BigDecimal;
import java.util.*;

/**
 * @version 	1.0
 * @author
 */
public class ReportServlet extends HttpServlet {

	private ReportsHome reportsHome;


	/**
	* @see javax.servlet.http.HttpServlet#void (javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	*/
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {

		processReports(req, resp);

	}

	/**
	* @see javax.servlet.http.HttpServlet#void (javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	*/
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {

		processReports(req, resp);

	}

	/**
	* @see javax.servlet.GenericServlet#void ()
	*/
	public void init() throws ServletException {
		try {
			//InitialContext initCtx = new InitialContext();
			//Object objref = initCtx.lookup("ejb/itsobank/Reports");
			//Object objref = initCtx.lookup("java:comp/env/ejb/Reports");
			//reportsHome   = (ReportsHome)PortableRemoteObject.narrow(objref,ReportsHome.class);
			reportsHome = (ReportsHome)HomeFactory.singleton().getHome("ejb/Reports");
		} catch (NamingException ex) {
			ex.printStackTrace();
			throw new EJBException("Error looking up ReportsHome: "+ex.getMessage());
		}
	}

	public void processReports(HttpServletRequest req, HttpServletResponse resp) {
		try {
			String custnamesBut   = req.getParameter("custnames");
			String accountsBut    = req.getParameter("accounts");
	
			try {
				Reports report = reportsHome.create();
				
				if (custnamesBut  != null) {
					Handle handle = report.getHandle();
					System.out.println("Handle class "+handle.getClass());
					Vector customerList = report.listCustomerNames();
					System.out.println("Servlet "+customerList.size());
					req.setAttribute("customers",customerList);
					HttpSession session = req.getSession(true);
					session.setAttribute("reportEJB", report.getHandle());
					getServletContext().getRequestDispatcher("ReportCustomers").forward(req,resp);
				}
				
				if (accountsBut  != null) {
					Vector accountList = report.listAllAccounts();
					req.setAttribute("accounts",accountList);
					report.remove();  // remove the stateful session bean
					getServletContext().getRequestDispatcher("ReportAccounts").forward(req,resp);
				}					
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
