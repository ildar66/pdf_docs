package itso.bank5.client.mdb;

import itso.bank5.utility.*;
import java.math.BigDecimal;
import java.util.Properties;
import javax.jms.*;
import javax.naming.*;

public class MdbClient {
	
	private static final String QUEUECONNECTIONFACTORY = "jms/ItsoMdbConnectionFactoryRef";
	private static final String SENDQUEUE              = "jms/ItsoMdbQueueRef";
	private static final String RESPONSEQUEUE          = "jms/ItsoResponseQueueRef";

	private InitialContext initialContext = null;

	/**
	 * Constructor for MDBClient.
	 */
	public MdbClient() {
		super();
	}

	/**
	 * <p>This program writes an object message to SENDQUEUE. It then receives a message from RESPONSEQUEUE</P>
	 */
	public static void main(String[] args) throws JMSException, Exception {

		System.out.println("Client: Start");
		MdbClient testClient = new MdbClient();
		if (args.length == 3) {
			BigDecimal amount = new BigDecimal(args[2]);
			testClient.testMDB(args[0], args[1], amount);
		} else {
			System.out.println("Client: No parms supplied, using default");
			testClient.testMDB("101-1002", "101-1001", new BigDecimal("10"));
		}
	}

	private void testMDB(String fromAccount, String toAccount, BigDecimal amount) {

		String messageID = null;
		String selector  = null;
		boolean verbose = true;
		QueueSession session = null;
		QueueConnection connection = null;
		QueueConnectionFactory qcf = null;

		try {
			// Attempt to retrieve ConnectionFactory and Queues from the JNDI namespace
			if (verbose) System.out.println("Client: Retrieving Queues from JNDI");
			Queue outQueue = (Queue)HomeFactory.singleton().getJMS(SENDQUEUE);
			Queue inQueue  = (Queue)HomeFactory.singleton().getJMS(RESPONSEQUEUE);
			if (verbose) System.out.println("Client: outQueue="+outQueue.getClass());

			if (verbose) System.out.println("Client: Retrieving a QueueConnectionFactory from JNDI");
			try {
				// for deployment
				qcf = (QueueConnectionFactory)HomeFactory.singleton().getJMS(QUEUECONNECTIONFACTORY); 
				if (verbose) System.out.println("Client: deploy factory="+qcf.getClass());
			} catch (Exception e) {
				// for testing
				String QUEUECONNECTIONFACTORYTEST = "jms/ItsoMdbConnectionFactory";
				initialContext = new InitialContext();
				qcf = (QueueConnectionFactory)initialContext.lookup(QUEUECONNECTIONFACTORYTEST);
				if (verbose) System.out.println("Client: test factory="+qcf.getClass());
			}

			// Create a QueueConnection from the QueueConnectionFactory
			connection = qcf.createQueueConnection();
			if (verbose) System.out.println("Client: got connection");
			
			// IMPORTANT: Receive calls will be blocked if the connection is
			// not explicitly started, so make sure its started.
			connection.start();
			if (verbose) System.out.println("Client: connection started");

			// Create a QueueSession from the connection.
			// Not transacted, and acknowledge received messages
			boolean transacted = false;
			session = connection.createQueueSession( transacted, Session.AUTO_ACKNOWLEDGE);
			if (verbose) System.out.println("Client: created queue session");

			// Use the session to create a QueueSender, passing in the Queue as parameter
			QueueSender queueSender = session.createSender(outQueue);
			if (verbose) System.out.println("Client: created sender");

			// assemble our parameters
			TransferDataObject transferMsg = new TransferDataObject(fromAccount, toAccount, amount);

			// use the session to create our objectmessage
			ObjectMessage outMessage = session.createObjectMessage(transferMsg);
			if (verbose) System.out.println("Client: created object message");

			// tell the MDB what business method we want it to call, set correlation ID
			outMessage.setStringProperty("BUSINESSMETHOD", "transfer");
			selector = "CORR:TF"+ (new java.util.Random()).nextInt(999999);
			outMessage.setJMSCorrelationID(selector);

			// send the message
			if (verbose) System.out.println("Client: Sending the message to " + outQueue.getQueueName());
			queueSender.send(outMessage);

			// get message id 
			messageID = outMessage.getJMSMessageID();
			if (verbose) System.out.println("Client: Sent message "+messageID+"/"+selector);

			// Message sent, let's read the response message using the correlation ID
			if (verbose) System.out.println("Client: Receiving message from " + inQueue.getQueueName());
			selector = "JMSCorrelationID = '" + selector + "'";
			QueueReceiver queueReceiver = session.createReceiver(inQueue, selector);

			// Use the QueueReceiver to retrieve the message, blocking for a maximum of 5000ms. 
			// The receive call returns when the message arrives, or after X ms
			if (verbose) System.out.println("Client: Waiting for message");
			Message inMessage = queueReceiver.receive(15000);

			// Check to see if the receive call has actually returned a message.
			if (inMessage == null) {
				System.out.println("Client: The attempt to read the message failed");
				throw new JMSException("Client: Failed to retrieve message.");
			}

			if (inMessage instanceof TextMessage) {
				// Extract the message content with getText()
				String replyString = ((TextMessage) inMessage).getText();
				if (verbose) System.out.println("Client: Reply = '" + replyString + "'");
			} else {
				// Report that the incoming message was not of the expected type, and throw an exception
				System.out.println("Client: Reply message was not a TextMessage");
				throw new JMSException("Client: Retrieved the wrong type of message");
			}

			// Call the close() method on all of the objects.
			queueReceiver.close();
			queueSender.close();
			session.close();
			session = null;
			connection.close();
			connection = null;

			System.out.println("Client: Done");
		} catch (JMSException e) {
			System.out.println("Client: JMS failed with " + e);
			Exception le = e.getLinkedException();
			if (le != null) System.out.println("Client: linked exception " + le);
		} catch (Exception exc) {
			System.out.println("Client: Unexpected error " + exc);
		} finally {
			//  Ensure JMS objects are closed
			try {
				if (session != null) session.close();
				if (connection != null) connection.close();
			} catch (JMSException e) {
				System.out.println("Client: Unexpected error, failed with " + e);
			}
		}
	}
}
