/**
 * JDBC Stored Procedure PartListing. This is the example used in Chapter 12 to demonstrate
 * how to use a Java stored procedure. 
 * The procedure must be installed in the itsowsad database using a "create procedure" call
 */
package itso.wsad.dealer.parts.sp;

import java.sql.*;                   // JDBC classes

public class PartListing
{
    public static void partListing ( String partnum,
                                     ResultSet[] rs ) throws SQLException, Exception
    {
        // Get connection to the database
        System.out.println("In stored procedure");
        Connection con = DriverManager.getConnection("jdbc:default:connection");
        PreparedStatement stmt = null;
        String sql;

        sql = "SELECT"
            + "    ITSO.AAPARTS.NAME AS NAME,"
            + "    ITSO.AAPARTS.DESCRIPTION AS DESCRIPTION,"
            + "    ITSO.AAPARTS.WEIGHT AS WEIGHT"
            + " FROM"
            + "    ITSO.AAPARTS"
            + " WHERE"
            + "    ("
            + "      ( ITSO.AAPARTS.PARTNUMBER like  ?  CONCAT '%' )"
            + "    )";
        stmt = con.prepareStatement( sql );
        stmt.setString( 1, partnum );
        rs[0] = stmt.executeQuery();
        if (con != null) con.close();
    }
}                                    