// This is an example of a Java Bean calling a stored procedure.

package itso.wsad.dealer.web;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class PartListBeanSP {
     String name = new String();
	 String description = new String();
	 Double weight;
		
	/**
	 * Constructor for PartListBeanSP
	 */
	public PartListBeanSP() {
		super();
		
		
	}
	
	private Connection connect() throws Exception {
		Connection con = null;
		// connect to database
		Class.forName("COM.ibm.db2.jdbc.app.DB2Driver").newInstance();
		con = DriverManager.getConnection("jdbc:db2:itsowsad"); 
		
		return con;
	}
	
	public void select(String param) throws Exception {
		Connection con = connect();
		System.out.println("Connection OK");
		// call stored procedure to retrieve parts
		Statement stmt = null;
		try {
	 	  CallableStatement cs = con.prepareCall("{call PartListing('" +param + "')} ");
	 	  
		  ResultSet rs = cs.executeQuery(); 
		  System.out.println("After executeQuery. rs = " + rs);	
		  while (rs.next()) {
		  	setName(rs.getString("name"));
		  	System.out.println("Retrieved name: " + name);
		  	setDescription(rs.getString("description"));
		  	setWeight(new Double(rs.getDouble("weight")));
		  }
		}
		catch(Exception e) {System.out.println("Error: " + e.getMessage());}  
    }

	


	/**
	 * Gets the name
	 * @return Returns a String
	 */
	public String getName() {
		return name;
	}
	/**
	 * Sets the name
	 * @param name The name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
 	/**
	 * Gets the description
	 * @return Returns a String
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * Sets the description
	 * @param description The description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
 	/**
	 * Gets the weight
	 * @return Returns a Double
	 */
	public Double getWeight() {
		return weight;
	}
	/**
	 * Sets the weight
	 * @param weight The weight to set
	 */
	public void setWeight(Double weight) {
		this.weight = weight;
	}
}
