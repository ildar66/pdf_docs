-- IBM ITSO SG24-6292 Sample Application

CONNECT TO ITSOWSAD;

DELETE FROM ITSO.AAINVENTORY;
DELETE FROM ITSO.AAPARTS;
DELETE FROM ITSO.MMINVENTORY;
DELETE FROM ITSO.MMPARTS;


-- Sample Data for Almaden Autos Parts Table
  
INSERT INTO ITSO.AAPARTS VALUES (
	'M100000001', 'CR-MIRROR-L-01',
	'Large drivers side mirror for Cruiser', 10.5, 'mirror01.gif');
	
INSERT INTO ITSO.AAPARTS VALUES (
	'M100000002', 'CR-MIRROR-R-01',
	'Large passenger side mirror for Cruiser', 10.8, 'mirror02.gif');
	
INSERT INTO ITSO.AAPARTS VALUES (
	'M100000003', 'CR-MIRROR-R-01', 
	'Large rear view mirror for Cruiser', 4.6, 'mirror03.gif');

INSERT INTO ITSO.AAPARTS VALUES (
	'W111111111', 'WIPER-BLADE', 
	'Wiper blade for any car', 0.9, 'wiper.gif');

INSERT INTO ITSO.AAPARTS VALUES (
	'B222222222', 'BRAKE-CYLINDER', 
	'Brake master cylinder', 2.2, 'brakecylinder.gif');

INSERT INTO ITSO.AAPARTS VALUES (
	'T333333333', 'TIMING-BELT', 
	'Timing belt', 0.6, 'timingbelt.gif');

INSERT INTO ITSO.AAPARTS VALUES (
	'T0', 'Team', 'International WSAD Groupies', 100.00, 'wsadteam0.gif');

INSERT INTO ITSO.AAPARTS VALUES (
	'T1', 'Olaf', 'German Turbo Engine', 100.11, 'wsadteam1.gif');

INSERT INTO ITSO.AAPARTS VALUES (
	'T2', 'Wouter', 'Belgium Chocolate Steering Wheel', 100.22, 'wsadteam2.gif');

INSERT INTO ITSO.AAPARTS VALUES (
	'T3', 'Denise', 'US Spark Plug', 100.33, 'wsadteam3.gif');

INSERT INTO ITSO.AAPARTS VALUES (
	'T4', 'Mark', 'British Muffler', 100.44, 'wsadteam4.gif');

INSERT INTO ITSO.AAPARTS VALUES (
	'T5', 'Ueli', 'Swiss Cheese Cylinder', 100.55, 'wsadteam5.gif');

INSERT INTO ITSO.AAPARTS VALUES (
	'L1', 'License', 'Personalized license plate', 0.3, 'license.gif');


-- Sample Data for Almaden Autos Inventory Table

INSERT INTO ITSO.AAINVENTORY VALUES (
	21000001, 'M100000001', 10, 89.99, '2A', 'AA - Almaden');
	
INSERT INTO ITSO.AAINVENTORY VALUES (
	21000002, 'M100000002',  5, 99.99, '2B', 'AA - Almaden');



-- Sample Data for Mighty Motors Parts Table

INSERT INTO ITSO.MMPARTS VALUES (
	'M100000001', 'CR-MIRROR-L-01',
	'Large drivers side mirror for Cruiser', 10.5, 'mirror01.gif');
	
INSERT INTO ITSO.MMPARTS VALUES (
	'M100000002', 'CR-MIRROR-R-01',
	'Large passenger side mirror for Cruiser', 10.8, 'mirror02.gif');
	
INSERT INTO ITSO.MMPARTS VALUES (
	'M100000003', 'CR-MIRROR-R-01', 
	'Large rear view mirror for Cruiser', 4.6, 'mirror03.gif');

INSERT INTO ITSO.MMPARTS VALUES (
	'W111111111', 'WIPER-BLADE', 
	'Wiper blade for any car', 0.9, 'wiper.gif');

INSERT INTO ITSO.MMPARTS VALUES (
	'B222222222', 'BRAKE-CYLINDER', 
	'Brake master cylinder', 2.2, 'brakecylinder.gif');

INSERT INTO ITSO.MMPARTS VALUES (
	'X333333333', 'TIMING-BELT', 
	'Timing belt', 0.6, 'timingbelt.gif');

INSERT INTO ITSO.MMPARTS VALUES (
	'T0', 'Team', 'International WSAD Groupies', 100.00, 'wsadteam0.gif');

INSERT INTO ITSO.MMPARTS VALUES (
	'T1', 'Olaf', 'German Turbo Engine', 100.11, 'wsadteam1.gif');

INSERT INTO ITSO.MMPARTS VALUES (
	'T2', 'Wouter', 'Belgium Chocolate Steering Wheel', 100.22, 'wsadteam2.gif');

INSERT INTO ITSO.MMPARTS VALUES (
	'T3', 'Denise', 'US Spark Plug', 100.33, 'wsadteam3.gif');

INSERT INTO ITSO.MMPARTS VALUES (
	'T4', 'Mark', 'British Muffler', 100.44, 'wsadteam4.gif');

INSERT INTO ITSO.MMPARTS VALUES (
	'T5', 'Ueli', 'Swiss Cheese Cylinder', 100.55, 'wsadteam5.gif');

INSERT INTO ITSO.MMPARTS VALUES (
	'L1', 'License', 'Personalized license plate', 0.3, 'license.gif');


-- Sample Data for Mighty Motors Inventory Table

INSERT INTO ITSO.MMINVENTORY VALUES (
	21000003, 'M100000003', 10, 59.99, 'L8', 'MM - San Francisco');
	
INSERT INTO ITSO.MMINVENTORY VALUES (
	21000004, 'M100000003', 12, 57.99, 'B7', 'MM - New York');

INSERT INTO ITSO.MMINVENTORY VALUES (
	31000005, 'W111111111',  2, 12.34, 'H8', 'MM - Los Angeles');

INSERT INTO ITSO.MMINVENTORY VALUES (
	31000006, 'B222222222',  13, 123.45, 'E5', 'MM - Frankfurt');

INSERT INTO ITSO.MMINVENTORY VALUES (
	31000007, 'X333333333', 7, 12.34, '2D', 'MM - Santa Cruz');

INSERT INTO ITSO.MMINVENTORY VALUES (
	900, 'T0', 1, 99.00, 'M0', 'MM - San Jose');

INSERT INTO ITSO.MMINVENTORY VALUES (
	901, 'T1', 1, 11.00, 'M1', 'MM - Heidelberg');

INSERT INTO ITSO.MMINVENTORY VALUES (
	902, 'T2', 1, 22.00, 'M2', 'MM - Brussels');

INSERT INTO ITSO.MMINVENTORY VALUES (
	903, 'T3', 1, 33.00, 'M3', 'MM - Raleigh');

INSERT INTO ITSO.MMINVENTORY VALUES (
	904, 'T4', 1, 44.00, 'M4', 'MM - London');

INSERT INTO ITSO.MMINVENTORY VALUES (
	905, 'T5', 1, 55.00, 'M5', 'MM - Zurich');

INSERT INTO ITSO.MMINVENTORY VALUES (
	910, 'L1', 1, 30.00, 'M6', 'MM - California');


-- Close the connection

CONNECT RESET;