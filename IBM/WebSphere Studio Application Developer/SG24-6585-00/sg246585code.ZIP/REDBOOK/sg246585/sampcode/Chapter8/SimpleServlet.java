import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Vector;
import java.io.PrintWriter;
import java.sql.*;

public class SimpleServlet extends HttpServlet {

	public void init() throws javax.servlet.ServletException {
	}

	public void doPost(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response)
		throws javax.servlet.ServletException, java.io.IOException {
	doGet(request,response);
	}

	public void doGet(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response)
		throws javax.servlet.ServletException, java.io.IOException {
			try {  
			String partialName = request.getParameter("partialName");
			Vector partListResult = new Vector();
			getResults(partialName, partListResult);
			PrintWriter out = response.getWriter();
			out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
			out.println("<HTML>");
   			out.println("	<HEAD> <META http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">");
      		out.println("		<TITLE>PartList.html</TITLE>");
      		out.println("	</HEAD>");      		
      		out.println("<BODY>");
      		out.println("	<P><IMG border=\"0\" height=\"33\" src=\"images/redbooks.gif\" width=\"180\"></P>");
      		out.println("	<H1>Parts Listing Results</H1>");
      		out.println("	<TABLE border=\"1\">");
      		out.println("		<TBODY>");
      		out.println("        <TR>");
      		out.println("            <TH>Number</TH>");
      		out.println("            <TH>Name</TH>");
      		out.println("            <TH>Description</TH>");
      		out.println("            <TH>Weight</TH>");
      		out.println("            <TH>ImageURL</TH>");
      		out.println("        </TR>");
			int i; String[] row;
			try {    	
				for (i=0; ; i++) {
					row = (String[])partListResult.elementAt(i);
      				out.println("		 <TR>");
      				out.println("            <TD>"+row[0]+"</TD>");
      				out.println("            <TD>"+row[1]+"</TD>");
      				out.println("            <TD>"+row[2]+"</TD>");
      				out.println("            <TD>"+row[3]+"</TD>");
      				out.println("            <TD>"+row[4]+"</TD>");
					out.println("        </TR>");
				} 
			} catch (Exception e) {};
			out.println("		</TBODY>");
			out.println("	</TABLE>");
			out.println("</BODY>");
			out.println("</HTML>");
			} catch (Exception ex) { ex.printStackTrace(); System.exit(-1); }
		}
	
	public void getResults(String partialName, Vector partList) throws Exception {
		String dbtab = "aaparts";
		// connect to database
		Connection con = null;
			Class.forName("COM.ibm.db2.jdbc.app.DB2Driver").newInstance();
			con = DriverManager.getConnection("jdbc:db2:itsowsad","db2admin","db2admin"); 
	
		// retrieve parts
		Statement stmt = null;
		ResultSet rs   = null;
		String select = "SELECT * FROM itso." +dbtab+ " WHERE NAME LIKE '%"+partialName+"%'";
			stmt = con.createStatement();
			rs = stmt.executeQuery(select);
			while (rs.next()) {
				String row[] = new String[5];
				partList.addElement(row);
				row[0] = rs.getString("partNumber");
				row[1] = rs.getString("name");
				row[2] = rs.getString("description");
				row[3] = (new Double(rs.getDouble("weight"))).toString();
				row[4] = rs.getString("image_url");
			}
			stmt.close();
			con.close();
	}
}
