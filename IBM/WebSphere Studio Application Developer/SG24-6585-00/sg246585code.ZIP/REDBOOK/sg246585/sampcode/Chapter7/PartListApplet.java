//  Source File Name: PartList.java  
//  Applet to display contents of the parts table in ITSOWSAD

import java.sql.*;
import javax.swing.*;
import java.util.*;
import java.awt.*;

public class PartListApplet extends JApplet {

   public void init() {
     String url = "jdbc:db2:itsowsad";
     JList list;
     JPanel pane;
     Connection con = connect(); 
     Object[][] data = getResults(con);
     makeContentPane(data);     
   }

   public void makeContentPane(Object[][] data) {
        String columnNames[] = {"Part number","Part name","Description","Weight"};
        JTable table = new JTable(data,columnNames);
        table.setPreferredScrollableViewportSize(new Dimension(500,400));
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane,BorderLayout.CENTER);
  }    

   public Object[][] getResults(Connection con)
   {
      int i = 0;
      Object[][] data = new Object[20][4];
     
     try {
       Statement stmt = con.createStatement();
       ResultSet rs = stmt.executeQuery("SELECT * from itso.aaparts");
    
       while (rs.next()) {
         String partnum= rs.getString(1);
         System.out.println("partnumber = "+partnum);
         String name = rs.getString(2);
         String descript= rs.getString(3);
         double weight  = rs.getDouble(4);
         Double w = new Double(weight);
         data[i][0] = partnum;
         data[i][1] = name;
         data[i][2] = descript;
         data[i][3] = new Double(weight);
         i++;      
       }
       stmt.close();  
     }
     catch(Exception e) {e.printStackTrace(); System.exit(-1); }
     return data;
   }

   protected Connection connect()
   {
      Connection con = null;
      String url = "jdbc:db2:itsowsad";
      try
      {
        Class.forName("COM.ibm.db2.jdbc.app.DB2Driver"); 
        con = DriverManager.getConnection(url);
      } catch(Exception e) { e.printStackTrace();
        System.exit(-1);
       
      }
      return con;
   }
}
