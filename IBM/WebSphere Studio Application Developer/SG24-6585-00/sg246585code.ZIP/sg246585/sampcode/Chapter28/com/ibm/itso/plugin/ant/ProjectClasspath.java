package com.ibm.itso.plugin.ant;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;

/**
 * Insert the type's description here.
 * @see Task
 */
public class ProjectClasspath extends Task {

    private String pathvar;

    public void setPathVar(String name){
    	pathvar = name;
    }

    
	/**
	 * The constructor.
	 */
	public ProjectClasspath() {
	}

	public void execute() throws BuildException 
    {
    	IClasspathEntry[] cp = null;
    	StringBuffer returnpath = new StringBuffer();
    	try{
	       cp = getClasspathEntries(getProject().getName(), true);
	       
	       for(int i=0; i<cp.length; i++) {
	       	
	       		switch(cp[i].getEntryKind()){
	       			case IClasspathEntry.CPE_SOURCE:
	       				//this path is for local project source. Nothing to do.
	       				break; 
	       				
	       			case IClasspathEntry.CPE_LIBRARY:
	       			case IClasspathEntry.CPE_VARIABLE:
	       				//these paths contain full external path.
	       				//just add path to the return string.
	        			returnpath.append(cp[i].getPath().toString());
	        			returnpath.append(";");
	        			break;
	        			
	        		case IClasspathEntry.CPE_PROJECT:
	        			//this path contains only a project name.
	        			//we need to search full location of the source path element.
	        			returnpath.append(getProjectSourceLocation(cp[i].getPath().toString()));
	        			break;
	        			
	        		default:
	        			break;
	        	}
	       }
	       //System.out.println(returnpath);

        }catch(Exception e){
            throw new BuildException(e);
        }
        this.getProject().setUserProperty(pathvar, returnpath.toString());
    }

    private IClasspathEntry[] getClasspathEntries(String pjname, boolean resolve) throws Exception {
 	    IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject(pjname);
 	    IJavaProject ijproj = JavaCore.getJavaCore().create(project);
	    IClasspathEntry[] cp = ijproj.getResolvedClasspath(resolve);
	    return cp;
    }
    
    private String getProjectSourceLocation( String pjname ) throws Exception{
    	
    	StringBuffer returnpath = new StringBuffer();
	    IClasspathEntry[] cp = getClasspathEntries(pjname, true);

       	for(int j=0; j<cp.length; j++) {
        	if( cp[j].getEntryKind() == IClasspathEntry.CPE_SOURCE ){
		      	returnpath.append(ResourcesPlugin.getWorkspace().getRoot().getProject(pjname).getLocation().toString());
		       	String sourcepath = cp[j].getPath().toString();
		       	int lastSlash = sourcepath.lastIndexOf("/");
		       	if(lastSlash>0) returnpath.append(sourcepath.substring(lastSlash));
	       		returnpath.append(";");
        	}
       	}
		return returnpath.toString();	       	
    }

}
