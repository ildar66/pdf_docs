package itso.wsad.dealer.web;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class PartListBean {


	java.util.Vector partList = new java.util.Vector();

	/**
	 * Constructor for PartListBean
	 */
	public PartListBean() {
		super();
	}

	/**
	 * Gets the partList
	 * @return Returns a java.util.Vector
	 */
	public java.util.Vector getPartList() {
		return partList;
	}
	/**
	 * Sets the partList
	 * @param partList The partList to set
	 */
	public void setPartList(java.util.Vector partList) {
		this.partList = partList;
	}
	private Connection connect() throws Exception {
		Connection con = null;
		// connect to database
		Class.forName("COM.ibm.db2.jdbc.app.DB2Driver").newInstance();
		con = DriverManager.getConnection("jdbc:db2:itsowsad","",""); 
		
		return con;
	}
	public void select(String param) throws Exception {
		Connection con = connect();
		String dbtab = "aaparts";
		// retrieve parts
		Statement stmt = null;
		ResultSet rs   = null;
		String select = "SELECT * FROM itso." +dbtab+ " WHERE NAME LIKE '%"+param+"%'";

		stmt = con.createStatement();
		rs = stmt.executeQuery(select);
		while (rs.next()) {
			String row[] = new String[5];
			partList.addElement(row);
			row[0] = rs.getString("partNumber");
			row[1] = rs.getString("name");
			row[2] = rs.getString("description");
			row[3] = (new Double(rs.getDouble("weight"))).toString();
			row[4] = rs.getString("image_url");
		}
		stmt.close();
		con.close();
	}
}

