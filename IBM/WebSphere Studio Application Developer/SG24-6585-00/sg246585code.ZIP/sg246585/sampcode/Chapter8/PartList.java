import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Vector;
import itso.wsad.dealer.web.*;
import java.io.PrintWriter;

public class PartList extends HttpServlet {

	public void init() throws javax.servlet.ServletException {
	}

	public void doPost(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response)
		throws javax.servlet.ServletException, java.io.IOException {
		doGet(request,response);
	}

	public void doGet(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response)
		throws javax.servlet.ServletException, java.io.IOException {
		try {
			String resultPage = "/PartList.jsp";
			String partialName = request.getParameter("partialName");
			
			PartListBean partListResult = new PartListBean();
			partListResult.select(partialName);
			request.setAttribute("partListResult", partListResult);
			//Forward the request to the next page
        	RequestDispatcher dispatch = request.getRequestDispatcher(resultPage);
        	dispatch.forward(request, response);
		} catch (Throwable e) {
			try {
				String message = e.getLocalizedMessage();
				PrintWriter out = response.getWriter();
				out.println("<html><body>Error: "+message+"</body><html>");
				e.printStackTrace();
			} catch (Exception ex) {}
		}
	}

}
