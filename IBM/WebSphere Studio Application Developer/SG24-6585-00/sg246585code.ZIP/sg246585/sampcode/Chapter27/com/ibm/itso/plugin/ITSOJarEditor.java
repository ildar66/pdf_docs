package com.ibm.itso.plugin;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IPath;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.SWT; 
import org.eclipse.ui.part.EditorPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.swt.widgets.Composite;
/**
 * Insert the type's description here.
 * @see EditorPart
 */
public class ITSOJarEditor extends EditorPart {
	
	final String[] title = {"File Name","Size","Date"};    	
	final int[] align = {SWT.LEFT, SWT.RIGHT, SWT.LEFT};
	final int[] width = { 200, 70, 100 };
 	private String filename = null;

	/**
	 * The constructor.
	 */
	public ITSOJarEditor() {
	}

	/**
	 * Insert the method's description here.
	 * @see EditorPart#createPartControl
	 */
    public void createPartControl(Composite parent) {

    	final Table table = new Table(parent,SWT.MULTI);
    	final TableColumn[] tc = new TableColumn[3];
		    	
    	for( int i=0; i<3; i++){
    		tc[i] = new TableColumn(table,align[i]); 
    		tc[i].setText(title[i]);
    		tc[i].setResizable(true);
    		tc[i].setWidth(width[i]);
    	}
    	table.setHeaderVisible(true);
    	table.setLinesVisible(true);
        
        try{
        	if(getEditorInput() instanceof IFileEditorInput ) {
		        String[][] st = com.ibm.itso.jarview.JarView.getListFromJar(filename);
	 	        for( int i=0; i<(st.length); i++ ){
   	   				TableItem item = new TableItem(table,SWT.DEFAULT);
					item.setText(st[i]);
		        }
        	}
        }catch(Exception e){
        	System.out.println(e);
        }
    }
	/**
	 * Insert the method's description here.
	 * @see EditorPart#setFocus
	 */
	public void setFocus()  {
	}

	/**
	 * Insert the method's description here.
	 * @see EditorPart#doSave
	 */
	public void doSave(IProgressMonitor arg0)  {
	}

	/**
	 * Insert the method's description here.
	 * @see EditorPart#doSaveAs
	 */
	public void doSaveAs()  {
	}

	/**
	 * Insert the method's description here.
	 * @see EditorPart#gotoMarker
	 */
	public void gotoMarker(IMarker arg0)  {
	}

	/**
	 * Insert the method's description here.
	 * @see EditorPart#init
	 */
	public void init(IEditorSite site, IEditorInput input) throws PartInitException {
		if(!(input instanceof IFileEditorInput)){
			throw new PartInitException("Bad request.");
		}
		setSite(site);
		setInput(input);
		
    	IFile file = ((IFileEditorInput)getEditorInput()).getFile();
        filename = file.getLocation().toString();
		setTitle(file.getName());
	}    
	/**
	 * Insert the method's description here.
	 * @see EditorPart#isDirty
	 */
	public boolean isDirty()  {
		return false;
	}

	/**
	 * Insert the method's description here.
	 * @see EditorPart#isSaveAsAllowed
	 */
	public boolean isSaveAsAllowed()  {
		return false;
	}
}
