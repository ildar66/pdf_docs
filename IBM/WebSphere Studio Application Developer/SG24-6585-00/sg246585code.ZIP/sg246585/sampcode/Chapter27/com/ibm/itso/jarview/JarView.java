package com.ibm.itso.jarview;
import java.io.*;
import java.util.*;
import java.util.jar.*;
public class JarView {


    /**
     * This method is the main entry point for this class.
     */
	public static void main(String[] args) throws IOException {
       // Open the jar file, using the first command line argument as the file
       // name.
		String[][] st = getListFromJar(args[0]);

		for(int i=0; i<st[0].length; i++){
			for(int j=0; j<3; j++){
				System.out.println(st[j][i]);
			}
		}

    }

	public static String[][] getListFromJar(String jarname) throws IOException {

	    JarFile jar = new JarFile(jarname);

	    // Process the jar file. Close it when the block is exited.

	 	Vector v[] = new Vector[3];
	 	for( int i=0; i<3; i++){ v[i] = new Vector(); }
	    try {
          // Loop through the jar entries and print the name of each one.

          for (Enumeration list = jar.entries(); list.hasMoreElements(); ) {
             JarEntry entry = (JarEntry) list.nextElement();
             v[0].addElement(entry.getName());
             v[1].addElement(new Long(entry.getSize()));
             v[2].addElement(new Date(entry.getTime()));
          }
       }
       finally {
          jar.close();
       }

		int sz=v[0].size();

		String[][] st = new String[sz][3];
		
		for(int j=0; j<sz; j++){
			for(int k=0; k<3; k++){
				st[j][k]=v[k].elementAt(j).toString();
			}
		}		
   	    return st;
    }
 }
