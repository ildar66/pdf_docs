package com.ibm.itso.plugin;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.core.resources.IFile;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.SWT; 
/**
 * Insert the type's description here.
 * @see ViewPart
 */
public class ITSOJarViewer extends ViewPart implements ISelectionListener{

	final String[] title = {"File Name","Size","Date"};    	
	final int[] align = {SWT.LEFT, SWT.RIGHT, SWT.LEFT};
	final int[] width = { 200, 70, 100 };
   	private Table table = null;
    private TableColumn[] tc = null;
	/**
	 * The constructor.
	 */
	public ITSOJarViewer() {
	}

	/**
	 * Insert the method's description here.
	 * @see ViewPart#createPartControl
	 */
	public void createPartControl(Composite parent)  {
		    	
		table = new Table(parent,SWT.MULTI);
		tc = new TableColumn[3];		
		
    	for( int i=0; i<3; i++){
    		tc[i] = new TableColumn(table,align[i]); 
    		tc[i].setText(title[i]);
    		tc[i].setResizable(true);
    		tc[i].setWidth(width[i]);
    	}
    	table.setHeaderVisible(true);
    	table.setLinesVisible(true);

		getViewSite().getPage().addSelectionListener(this);
    }	

	/**
	 * Insert the method's description here.
	 * @see ViewPart#setFocus
	 */
	public void setFocus()  {
	}

	public void selectionChanged(IWorkbenchPart part, ISelection selection){
		if(selection instanceof IStructuredSelection){
			Object first = ((IStructuredSelection)selection).getFirstElement();
			if(first instanceof IFile){
				setupContents((IFile)first);
			}
		}
	}

	
	private void setupContents(IFile file) {
		
		String filename = file.getLocation().toString();
		
		if(filename != null){
		
			setTitle(file.toString());
		
			table.removeAll();
		
			try{
		        String[][] st = com.ibm.itso.jarview.JarView.getListFromJar(filename);
	 	        for( int i=0; i<(st.length); i++ ){
	   				TableItem item = new TableItem(table,SWT.DEFAULT);
					item.setText(st[i]);
		        }
	        }catch(Exception e){
	        	System.out.println(e);
	        }
		}
	}
}
