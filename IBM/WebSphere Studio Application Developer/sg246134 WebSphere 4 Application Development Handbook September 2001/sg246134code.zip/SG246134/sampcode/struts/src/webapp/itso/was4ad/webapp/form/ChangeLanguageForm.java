package itso.was4ad.webapp.form;

/**
 * Struts change language form
 */
public class ChangeLanguageForm extends org.apache.struts.action.ActionForm {
	private java.lang.String language = null;
	private java.lang.String country = null;
/**
 * copyInto method
 * @param locale java.util.Locale
 */
public void copyInto(java.util.Locale locale) {}
/**
 * Get the country string
 * @return java.lang.String
 */
public java.lang.String getCountry() {
	return country;
}
/**
 * Get the language string
 * @return java.lang.String
 */
public java.lang.String getLanguage() {
	return language;
}
/**
 * Get the locale
 * @param locale java.util.Locale
 */
public java.util.Locale getLocale() {

    return new java.util.Locale(this.getLanguage(), this.getCountry());

}
/**
 * Set country
 * @param newCountry java.lang.String
 */
public void setCountry(java.lang.String newCountry) {
	country = newCountry;
}
/**
 * Set language
 * @param newLanguage java.lang.String
 */
public void setLanguage(java.lang.String newLanguage) {
	language = newLanguage;
}
}
