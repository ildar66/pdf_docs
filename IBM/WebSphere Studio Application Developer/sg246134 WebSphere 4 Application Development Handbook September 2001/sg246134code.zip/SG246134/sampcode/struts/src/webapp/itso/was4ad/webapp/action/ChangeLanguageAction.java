package itso.was4ad.webapp.action;

import org.apache.struts.action.*;
import javax.servlet.http.*;
import itso.was4ad.webapp.form.ChangeLanguageForm;

/**
 * Struts change language action
 */
public class ChangeLanguageAction extends Action {
/*
 * Perform the action
 */
public ActionForward perform(
    ActionMapping mapping,
    ActionForm form,
    HttpServletRequest request,
    HttpServletResponse response)
    throws java.io.IOException, javax.servlet.ServletException {
    HttpSession session = request.getSession();

    // Set the user locale if locale parameter specified
    try {
        ChangeLanguageForm changeLanguageForm = (ChangeLanguageForm) form;
        java.util.Locale locale = new java.util.Locale(changeLanguageForm.getLanguage(), changeLanguageForm.getCountry());
        session.setAttribute(Action.LOCALE_KEY, locale);
    } catch (Exception e) {
        // do not mind, default locale will be used by Struts
    }

    ActionForward result = mapping.findForward("welcome");
    return result;
}
}
