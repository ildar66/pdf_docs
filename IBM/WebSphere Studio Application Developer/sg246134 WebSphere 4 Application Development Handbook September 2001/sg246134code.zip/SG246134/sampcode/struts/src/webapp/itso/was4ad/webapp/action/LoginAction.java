package itso.was4ad.webapp.action;

import org.apache.struts.action.*;
import javax.servlet.http.*;
import itso.was4ad.usecase.*;
import itso.was4ad.data.*;
import itso.was4ad.webapp.form.LoginForm;

/**
 * Struts login action
 */
public class LoginAction extends Action {
/*
 * Perform the action
 */
public ActionForward perform(
    ActionMapping mapping,
    ActionForm form,
    HttpServletRequest request,
    HttpServletResponse response)
    throws java.io.IOException, javax.servlet.ServletException {
    HttpSession session = request.getSession();

    try {
        // Use the DisplayCustomer use case to locate the customer info
        DisplayCustomer useCase = new DisplayCustomer();
        useCase.setCustomerId(((LoginForm) form).getCustomerId());
        CustomerData data = (CustomerData) useCase.execute();

        // Set the user locale if locale parameter specified
        try {
            String languageString = request.getParameter("language");
            String countryString = request.getParameter("country");
            java.util.Locale locale = new java.util.Locale(languageString, countryString);
            session.setAttribute(Action.LOCALE_KEY, locale);
        } catch (Exception e) {
            // do not mind, default locale will be used by Struts
        }

        // Save the user information in the session
        session.setAttribute("customer", data);
    } catch (Exception e) {
        ActionForward result = mapping.findForward("loginNotSuccessful");
        return result;
    }

    ActionForward result = mapping.findForward("loginSuccessful");
    return result;
}
}
