package itso.was4ad.webapp.action;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

import itso.was4ad.data.*;
import itso.was4ad.usecase.*;
import org.apache.struts.action.*;
/**
 * Struts action to display a customers accounts
 */
public class DisplayAccountsAction extends Action {
/*
 * Perform the action
 */
public ActionForward perform(
    ActionMapping mapping,
    ActionForm form,
    HttpServletRequest request,
    HttpServletResponse response)
    throws IOException, ServletException {

    // Get the customer data from the session
    CustomerData data = (CustomerData) request.getSession().getAttribute("customer");

    // Create and execute the use case
    DisplayCustomerAccounts useCase = new DisplayCustomerAccounts();
    useCase.setCustomerId(data.getId());
    AccountListData accountList = null;
    try {
        accountList = (AccountListData) useCase.execute();
    } catch (Exception e) {
	    // Just absorb for now
    }

    // Put the account list on the request
    request.setAttribute("accountList", accountList.getAccounts());

    return mapping.findForward("displayAccounts");
}
}
