package itso.was4ad.webapp.action;

import org.apache.struts.action.*;
import javax.servlet.http.*;

/**
 * Struts logout action
 */
public class LogoutAction extends Action {
/*
 * Perform the action
 */
public ActionForward perform(
    ActionMapping mapping,
    ActionForm form,
    HttpServletRequest request,
    HttpServletResponse response)
    throws java.io.IOException, javax.servlet.ServletException {

	// Invalidate the user session
    HttpSession session = request.getSession();
    session.invalidate();

    // Forward to the appropriate page
    return mapping.findForward("logoutSuccessful");
}
}
