package itso.was4ad.webapp.form;

import org.apache.struts.action.*;
import javax.servlet.http.*;

/**
 * Struts login form
 */
public class LoginForm extends org.apache.struts.action.ActionForm {
	private java.lang.String user = null;
	private java.lang.String password = null;
	private int customerId = 0;
/**
 * Getter for the parsed customer ID
 * @return int
 */
public int getCustomerId() {
	return this.customerId;
}
/**
 * Get the password string
 */
public java.lang.String getPassword() {
	return password;
}
/**
 * Get the user ID
 * @return java.lang.String
 */
public java.lang.String getUser() {
	return user;
}
/**
 * Set the password
 * @param newPassword java.lang.String
 */
public void setPassword(java.lang.String newPassword) {
	password = newPassword;
}
/**
 * Set the user ID
 * @param newUser java.lang.String
 */
public void setUser(java.lang.String newUser) {
	user = newUser;
}
/**
 * String representation of the form
 * @return java.lang.String
 */
public String toString() {
	return "LoginForm: user=" + this.getUser() + ", password=" + this.getPassword();
}
/**
 * Validate the information entered in the login form.
 * Basically check that the user ID is a valid integer
 */
public ActionErrors validate(ActionMapping mapping, HttpServletRequest req) {
    ActionErrors errors = new ActionErrors();

    try {
        this.customerId = Integer.parseInt(getUser());
    } catch (Exception e) {
        errors.add("user", new ActionError("error.login.user"));
    }

    return errors;
}
}
