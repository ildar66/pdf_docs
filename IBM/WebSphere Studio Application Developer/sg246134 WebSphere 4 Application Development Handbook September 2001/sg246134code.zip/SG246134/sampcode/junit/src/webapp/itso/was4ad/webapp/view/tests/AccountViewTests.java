package itso.was4ad.webapp.view.tests;

import itso.was4ad.data.*;
import itso.was4ad.webapp.view.*;
import junit.framework.*;
/**
 * JUnit tests for the AccountView class
 */
public class AccountViewTests extends TestCase {
/**
 * Constructor
 * @param name java.lang.String
 */
public AccountViewTests(String name) {
	super(name);
}
/**
 * Test the behaviour when the view is created using te default constructor
 * This will happen on a JSP if the object isn't passed in the request as expected
 * We must behave gracefully!
 */
public void testDefaultConstructor() {
	AccountView view = new AccountView();
	assertEquals("Customer ID incorrect", "0", view.getCustomerID());
	assertEquals("Account ID incorrect", "0", view.getNumber());
	assertEquals("Amount incorrect", "$0.00", view.getAmount());
	assertEquals("Type incorrect", "Savings", view.getType());
}
/**
 * Test that the format of the data matches our expectations
 */
public void testFormat() {
    AccountData checking = new AccountData(101, 1001, 12345, true);
    AccountData savings = new AccountData(102, 1002, 0, false);
    AccountView view = null;

    // Check the checking account
    view = new AccountView(checking);
    assertEquals("Customer ID incorrect", "101", view.getCustomerID());
    assertEquals("Account number incorrect", "1001", view.getNumber());
    assertEquals("Amount incorrect", "$12345.00", view.getAmount());
    assertEquals("Type incorrect", "Checking", view.getType());

    // Check the savings account
    view = new AccountView(savings);
    assertEquals("Customer ID incorrect", "102", view.getCustomerID());
    assertEquals("Account number incorrect", "1002", view.getNumber());
    assertEquals("Amount incorrect", "$0.00", view.getAmount());
    assertEquals("Type incorrect", "Savings", view.getType());
}
}
