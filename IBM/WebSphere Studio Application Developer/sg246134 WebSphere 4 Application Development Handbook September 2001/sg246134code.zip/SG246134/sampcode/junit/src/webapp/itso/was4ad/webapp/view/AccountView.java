package itso.was4ad.webapp.view;

import itso.was4ad.data.AccountData;
/**
 * Web channel view bean - provides a formatted view of account data
 */
public class AccountView extends ViewBean {
	private AccountData data = null;
/**
 * AccountView default constructor
 */
public AccountView() {
	this(new AccountData());
}
/**
 * AccountView constructor takes an account data object
 */
public AccountView(AccountData data) {
	super();
	this.data = data;
}
/**
 * Return a formatted representation of the account balance
 * @return java.lang.String
 */
public String getAmount() {
	return "$" + data.getAmount() + ".00";
}
/**
 * Return a formatted representation of the customer number
 * @return java.lang.String
 */
public String getCustomerID() {
	return Integer.toString(data.getCustomerID());
}
/**
 * Return a formatted representation of the account number
 * @return java.lang.String
 */
public String getNumber() {
	return Integer.toString(data.getNumber());
}
/**
 * Return a formatted representation of the account type
 * @return java.lang.String
 */
public String getType() {
	return (data.isChecking() ? "Checking" : "Savings");
}
}
