package itso.was4ad.webapp.view;

import itso.was4ad.data.*;
/**
 * Web channel view bean - manages a list of accounts
 */
public class AccountListView extends ViewBean {
	private AccountData[] data;
	private int index;
	private AccountView view;
/**
 * AccountListView default constructor
 */
public AccountListView() {
       this(new AccountData[0]);
}
/**
 * AccountListView constructor takes an array of account data
 */
public AccountListView(AccountData[] data) {
    super();
    if (data == null) {
        this.data = new AccountData[0];
    } else {
        this.data = data;
    }
    reset();
}
/**
 * AccountListView constructor takes an account data list object
 */
public AccountListView(AccountListData listData) {
	this(listData.getAccounts());
}
/**
 * Return a formatted representation of the amount
 * @return java.lang.String
 */
public String getAmount() {
	return getView().getAmount();
}
/**
 * Return a formatted representation of the customer ID
 * @return java.lang.String
 */
public String getCustomerID() {
	return getView().getAmount();
}
/**
 * Change index to point to the next entry
 */
public String getNext() {
	// Increment pointer and create new view object
    index++;
    view = new AccountView(data[index]);
    
    // Must return something
    return "";
}
/**
 * Get a formatted account number
 * @return java.lang.String
 */
public String getNumber() {
	return getView().getNumber();
}
/**
 * Get a formatted account type
 * @return java.lang.String
 */
public String getType() {
	return getView().getType();
}
/**
 * Private method, returns the view object used to format
 * the account data, or throws ArrayIndexOutOfBoundsException
 * if we have no view
 * @return itso.was4ad.webapp.view.AccountView
 */
private AccountView getView() {
    if (view == null) {
        throw new ArrayIndexOutOfBoundsException();
    }
    return view;
}
/**
 * Reset the index
 */
public void reset() {
	index = -1;
}
}
