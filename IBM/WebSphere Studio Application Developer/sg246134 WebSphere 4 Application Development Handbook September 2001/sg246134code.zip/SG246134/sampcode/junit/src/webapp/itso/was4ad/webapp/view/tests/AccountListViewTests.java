package itso.was4ad.webapp.view.tests;

import itso.was4ad.data.*;
import itso.was4ad.webapp.view.*;
import junit.framework.*;
/**
 * JUnit tests for the AccountListView class
 */
public class AccountListViewTests extends TestCase {
	AccountData[] data = null;	// Data used by some of the tests
/**
 * AccountListViewTests constructor
 * @param name java.lang.String
 */
public AccountListViewTests(String name) {
	super(name);
}
/**
 * Set up some data we'll use in some of the tests
 */
public void setUp() {
    // Create some account data - make the contents predictable
    data = new AccountData[10];
    for (int i = 0; i < 10; i++) {
        data[i] =
            new AccountData(
                i % 4 + 100,					// 4 Customer IDs
                1000 + i,						// Unique account IDs
                i * 250,						// Unique Balances
                (i % 2 == 0 ? true : false));   // Half checking
    }
}
/**
 * Test the behavior with the default constructor
 */
public void testDefaultConstructor() {
    AccountListView list = new AccountListView();
    try {
        list.getNext();
        list.getCustomerID();
        fail("Expected ArrayIndexOutOfBoundsException");
    } catch (ArrayIndexOutOfBoundsException e) {
        // expected
    }
}
/**
 * Test the behavior when we iterate through the list
 */
public void testIteration() {
    AccountListView list = new AccountListView(data);

    // Make sure we iterate correctly through all 10 items
    for (int i = 0; i < 10; i++) {
	    list.getNext();
	    int accountId = 1000 + i;
	    assertEquals("Item " + i + " incorrect", "" + accountId, list.getNumber());
    }

	// Past the end of the list now
    try {
        list.getNext();
        list.getNumber();
        fail("Expected ArrayIndexOutOfBoundsException");
    } catch (ArrayIndexOutOfBoundsException e) {
        // expected
    }
}
/**
 * Test the behavior without an initial getNext()
 */
public void testNoGetNext() {
    AccountListView list = new AccountListView(data);
    try {
        list.getCustomerID();
        fail("Expected ArrayIndexOutOfBoundsException");
    } catch (ArrayIndexOutOfBoundsException e) {
        // expected
    }
}
/**
 * Test the reset method
 */
public void testReset() {
    AccountListView list = new AccountListView(data);

    // Make sure we iterate correctly through the first 5 items
    for (int i = 0; i < 5; i++) {
	    list.getNext();
	    int accountId = 1000 + i;
	    assertEquals("Item " + i + " incorrect", "" + accountId, list.getNumber());
    }

    // Now reset the view and make sure we're back at the beginning
    list.reset();
    list.getNext();
    assertEquals("Reset incorrect", "1000", list.getNumber());
}
}
