package itso.was4ad.webapp.view;

import itso.was4ad.data.CustomerData;
/**
 * Web channel view bean used to format customer account data
 */
public class CustomerView extends ViewBean {
	private CustomerData data = null;
/**
 * CustomerView default constructor
 */
public CustomerView() {
	this(new CustomerData());
}
/**
 * CustomerView constructor takes a customer data object
 */
public CustomerView(CustomerData data) {
	super();
	this.data = data;
}
/**
 * Return a formatted representation of the customer ID
 * @return java.lang.String
 */
public String getId() {
	return Integer.toString(data.getId());
}
/**
 * Return a formatted customer name
 * @return java.lang.String
 */
public String getName() {
	return data.getName();
}
}
