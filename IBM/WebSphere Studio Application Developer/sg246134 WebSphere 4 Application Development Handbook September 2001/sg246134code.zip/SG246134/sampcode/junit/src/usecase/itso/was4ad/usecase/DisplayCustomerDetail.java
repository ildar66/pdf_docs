package itso.was4ad.usecase;

import itso.was4ad.data.*;
/**
<PRE>
Display accounts : displays the PiggyBank accounts of a customer.

Input :
- customer id

Basic path :
1. The customer enters the required input information and submits the request.
2. The system displays the customer all his accounts 
      (including number, balance, checking flag).
</PRE>
*/
public class DisplayCustomerDetail extends UseCase {
	private static final itso.was4ad.helpers.LogHelper LOG =
		new  itso.was4ad.helpers.LogHelper(DisplayCustomerDetail.class);
    private int customerId = 0;
/**
 * Constructor
 */
public DisplayCustomerDetail() {
    super();
}
/**
 * Execute the display customer use case
 */
public DataBean execute() throws Exception {
    LOG.debug("execute()");
    return getCustomerManager().getCustomerFullData(customerId);
}
/**
 * Set the customer number
 * @param newCustomerId int
 */
public void setCustomerId(int newCustomerId) {
	customerId = newCustomerId;
}
}
