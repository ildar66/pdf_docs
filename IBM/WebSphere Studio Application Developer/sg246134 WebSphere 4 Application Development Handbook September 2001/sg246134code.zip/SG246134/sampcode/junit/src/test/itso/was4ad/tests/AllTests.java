package itso.was4ad.tests;

import junit.framework.*;
/**
 * Run all of the tests in the applications
 */
public class AllTests extends TestCase {
/**
 * AllTests constructor
 * @param name java.lang.String
 */
public AllTests(String name) {
	super(name);
}
/**
 * Run all the PiggyBank tests
 * Usage: itso.was4ad.tests.AllTests [-gui]
 * @param args java.lang.String[]
 */
public static void main(String[] args) {
    // Check the command line args
    if (args.length > 0 && args[0].equals("-gui")) {
        // Run the GUI tool - tell it to use the system classloader
        junit.swingui.TestRunner runner = new junit.swingui.TestRunner();
        runner.setLoading(false);
        runner.start(new String[] {AllTests.class.getName()});
    } else {
        // Run the text version
        junit.textui.TestRunner.run(suite());
    }
}
/**
 * Returns a test suite containing all known tests
 * @return junit.framework.TestSuite
 */
public static Test suite() {
	TestSuite suite = new TestSuite("All PiggyBank tests");

	// Add any new tests here
	suite.addTest(itso.was4ad.webapp.tests.AllTests.suite());
	suite.addTest(itso.was4ad.ejb.tests.AllTests.suite());

	// Return the test suite
	return suite;
}
}
