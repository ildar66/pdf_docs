package itso.was4ad.ejb.account;

/**
 * This is a Home interface for the Entity Bean
 */
public interface AccountHome extends javax.ejb.EJBHome {

/**
 * Create a new account
 * @return itso.was4ad.ejb.account.Account
 * @param argNumber int
 * @param argCustomerID int
 * @param argChecking boolean
 * @exception javax.ejb.CreateException
 * @exception java.rmi.RemoteException A remote exception
 */
itso.was4ad.ejb.account.Account create(int argNumber, int argCustomerID, boolean argChecking) throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * Locate all accounts belonging to a customer
 * @return java.util.Collection
 * @param id int
 * @exception java.rmi.RemoteException
 * @exception javax.ejb.FinderException
 */
java.util.Collection findByCustomerID(int id) throws java.rmi.RemoteException, javax.ejb.FinderException;
/**
 * Locate a customer by primary key
 * @return itso.was4ad.ejb.account.Account
 * @param key itso.was4ad.ejb.account.AccountKey
 * @exception java.rmi.RemoteException
 * @exception javax.ejb.FinderException
 */
itso.was4ad.ejb.account.Account findByPrimaryKey(itso.was4ad.ejb.account.AccountKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
