package itso.was4ad.exception;

/**
 * Exception indicating that a cheque is invalid
 */
public class InvalidCheque extends BusinessException {
/**
 * InvalidCheque constructor comment.
 */
public InvalidCheque() {
	super();
}
/**
 * InvalidCheque constructor comment.
 * @param level int
 * @param message java.lang.String
 */
public InvalidCheque(int level, String message) {
	super(level, message);
}
/**
 * InvalidCheque constructor comment.
 * @param s java.lang.String
 */
public InvalidCheque(String s) {
	super(s);
}
}
