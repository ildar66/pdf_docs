package itso.was4ad.exception;

/**
 * Thrown if a specified account does not exist
 */
public class NonExistentAccount extends BusinessException {
/**
 * NonExistentAccount constructor comment.
 */
public NonExistentAccount() {
	super();
}
/**
 * NonExistentAccount constructor comment.
 * @param level int
 * @param message java.lang.String
 */
public NonExistentAccount(int level, String message) {
	super(level, message);
}
/**
 * NonExistentAccount constructor comment.
 * @param s java.lang.String
 */
public NonExistentAccount(String s) {
	super(s);
}
}
