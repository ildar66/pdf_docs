package itso.was4ad.data;

/**
 * Superclass for data beans used to pass state
 * snapshots between the PiggyBank application components
 */
public abstract class DataBean implements java.io.Serializable {
/**
 * DataBean constructor comment.
 */
public DataBean() {
	super();
}
}
