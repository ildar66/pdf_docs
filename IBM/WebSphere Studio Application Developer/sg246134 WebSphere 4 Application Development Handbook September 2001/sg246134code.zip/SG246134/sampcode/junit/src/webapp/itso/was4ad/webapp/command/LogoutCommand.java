package itso.was4ad.webapp.command;

import itso.was4ad.webapp.controller.*;
import itso.was4ad.webapp.view.*;

/**
 * Web logout command
 */
public class LogoutCommand implements Command {
	private static final itso.was4ad.helpers.LogHelper LOG =
		new  itso.was4ad.helpers.LogHelper(LogoutCommand.class);
/**
 * Default constructor
 */
public LogoutCommand() {
	super();
}
/**
 * Execute the Web logout command
 * @param request javax.servlet.http.HttpServletRequest
 * @param response javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception The exception description.
 */
public String execute(
    javax.servlet.http.HttpServletRequest request,
    javax.servlet.http.HttpServletResponse response,
    javax.servlet.http.HttpSession session)
    throws Exception {

    LOG.debug("execute()");

    // Invalidate the session
    if (session != null) {
        CustomerView customer =
            (CustomerView) session.getAttribute(CommandConstants.ATTR_CUSTOMER);
        if (customer != null) {
            LOG.info("Logging out customer " + customer.getId());
        }
        session.invalidate();
    }

    // Return the page we need to forward to
    LOG.debug("Forwarding to logout page");
    return CommandConstants.PAGE_LOGOUT;
}
}
