package itso.was4ad.ejb.account;

/**
 * This is a Home interface for the Session Bean
 */
public interface AccountManagerHome extends javax.ejb.EJBHome {

/**
 * create method for a session bean
 * @return itso.was4ad.ejb.account.AccountManager
 * @exception javax.ejb.CreateException
 * @exception java.rmi.RemoteException
 */
itso.was4ad.ejb.account.AccountManager create() throws javax.ejb.CreateException, java.rmi.RemoteException;
}
