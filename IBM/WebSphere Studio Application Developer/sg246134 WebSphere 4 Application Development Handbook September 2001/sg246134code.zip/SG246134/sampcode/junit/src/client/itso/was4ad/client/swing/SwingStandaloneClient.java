package itso.was4ad.client.swing;

/**
 * Main class for the PiggyBank standalone Swing client application
 */
public class SwingStandaloneClient {
	private static final itso.was4ad.helpers.LogHelper LOG =
		new  itso.was4ad.helpers.LogHelper(SwingStandaloneClient.class);
/**
 * SwingStandaloneClient constructor comment.
 */
public SwingStandaloneClient() {
	super();
}
/**
 * Starts the application
 */
public static void main(String[] args) {
	LOG.debug("main()");
	// Call the class that creates the graphical interface
	SwingInterface swingClient = new SwingInterface();
	swingClient.setVisible(true);
}
}
