package itso.was4ad.ejb.account;

import java.rmi.RemoteException;
import java.util.Properties;
import javax.ejb.*;
import javax.naming.*;
import itso.was4ad.helpers.HomeHelper;
import itso.was4ad.exception.*;
import itso.was4ad.data.*;
import itso.was4ad.helpers.LogHelper;
/**
 * This is a Session Bean Class
 */
public class AccountManagerBean implements SessionBean {
	private static final LogHelper LOG = new LogHelper(AccountManagerBean.class);
	private javax.ejb.SessionContext mySessionCtx = null;
	private final static long serialVersionUID = 3206093459760846163L;
	private static java.util.Random random = new java.util.Random();

	// Constants
	private static final String ACCOUNT_HOME = "java:comp/env/ejb/Account";
	private static final int MAX_ID = 1000;

/**
 * Cash a check drawn on an account
 * @param accountID int
 * @param amount int
 * @param reference java.lang.String
 */
public AccountData cashCheck(int accountID, int amount, String reference) throws NonExistentAccount, InsufficientFunds, InvalidOperation {
	if (LOG.isDebugEnabled()) {
		LOG.debug("cashCheck(" + accountID + ", " + amount + ", " + reference + ")");
	}
    try {
        // Locate the account
       LOG.debug("Calling findByPrimaryKey()");
        AccountKey key = new AccountKey(accountID);
        Account account = getAccountHome().findByPrimaryKey(key);

		// Debit the account
        LOG.debug("Debiting account");
		account.debit(amount);

		// Return the account data containing the new balance
		return account.getAccountData();
    } catch (FinderException e) {
	    LOG.warn("cashCheck() caught finder exception", e);
        throw new NonExistentAccount(
            NonExistentAccount.WARNING,
            "Cannot locate account with id: " + accountID);
    } catch (NamingException e) {
	    LOG.error("cashCheck() caught naming exception", e);
        throw new EJBException(e);
    } catch (RemoteException e) {
	    LOG.error("cashCheck() caught remote exception", e);
	    throw new EJBException(e);
    }
}
/**
 * Open a new account
 * @param customerID int
 * @param checking boolean
 */
public AccountData createAccount(int customerID, boolean checking) {
	if (LOG.isDebugEnabled()) {
		LOG.debug("createAccount(" + customerID + ", " + checking + ")");
	}
    try {
       // Really awful way to get a unique account ID
        LOG.debug("Getting accountID...");
        Account acct = null;
        while (acct == null) {
            try {
                int id = Math.abs(random.nextInt() % MAX_ID);
                LOG.debug(new Integer(id));
                acct = getAccountHome().create(id, customerID, checking);
                LOG.debug("Account created");
            } catch (DuplicateKeyException e) {
                // Try again
                LOG.debug("Duplicate key - try again");
            }
        }
        return acct.getAccountData();
    } catch (CreateException e) {
	    LOG.error("createAccount() caught create exception", e);
        throw new EJBException(e);
    } catch (NamingException e) {
	    LOG.error("createAccount() caught naming exception", e);
        throw new EJBException(e);
    } catch (RemoteException e) {
	    LOG.error("createAccount() caught remote exception", e);
	    throw new EJBException(e);
    }
}
/**
 * Close an account
 * @param id int
 */
public void deleteAccount(int id) throws NonExistentAccount, InvalidOperation {
    if (LOG.isDebugEnabled()) {
        LOG.debug("deleteAccount(" + id + ")");
    }
    try {
        // Locate the account
        AccountKey key = new AccountKey(id);
        Account account = getAccountHome().findByPrimaryKey(key);

        // Remove the Account
        account.remove();
    } catch (FinderException e) {
        throw new NonExistentAccount(
            NonExistentAccount.WARNING,
            "Cannot locate account with id: " + id);
    } catch (RemoveException e) {
        // Make sure the transaction is rolled back
        getSessionContext().setRollbackOnly();

        // Convert to an invalid operation
        throw new InvalidOperation(
            InvalidOperation.WARNING,
            "Cannot remove account with id: " + id + " (" + e.getMessage() + ")");
    } catch (NamingException e) {
        LOG.error("deleteAccount() caught naming exception", e);
        throw new EJBException(e);
    } catch (RemoteException e) {
        LOG.error("deleteAccount() caught remote exception", e);
        throw new EJBException(e);
    }
}
/**
 * ejbActivate method
 * @exception java.rmi.RemoteException
 */
public void ejbActivate() throws java.rmi.RemoteException {
	LOG.info("ejbActivate()");
}
/**
 * ejbCreate method
 * @exception javax.ejb.CreateException
 */
public void ejbCreate() throws javax.ejb.CreateException {
    LOG.debug("ejbCreate()");
}
/**
 * ejbPassivate method
 * @exception java.rmi.RemoteException
 */
public void ejbPassivate() throws java.rmi.RemoteException {
    LOG.debug("ejbPassivate()");
}
/**
 * ejbRemove method
 * @exception java.rmi.RemoteException
 */
public void ejbRemove() throws java.rmi.RemoteException {
    LOG.debug("ejbRemove()");
}
/**
 * Get a data only object representing a particular account
 * @param id int
 */
public AccountData getAccountData(int id) throws NonExistentAccount {
	if (LOG.isDebugEnabled()) {
		LOG.debug("getAccountData(" + id + ")");
	}	
    try {
        // Locate the account
        LOG.debug("Looking up account");
        AccountKey key = new AccountKey(id);
        Account account = getAccountHome().findByPrimaryKey(key);

        // Get the BO
        LOG.debug("Getting account data");
        return account.getAccountData();
    } catch (FinderException e) {
	    LOG.warn("getAccountData() caught finder exception", e);
        throw new NonExistentAccount(
            NonExistentAccount.WARNING,
            "Cannot locate account with id: " + id);
    } catch (NamingException e) {
	    LOG.error("getAccountData() caught naming exception", e);
        throw new EJBException(e);
    } catch (RemoteException e) {
	    LOG.error("getAccountData() caught remote exception", e);
	    throw new EJBException(e);
    }
}
/**
 * Get the home for the Account EJB
 * @return itso.was4ad.ejb.account.AccountHome
 */
private AccountHome getAccountHome() throws NamingException {
	LOG.debug("getAccountHome()");
    return (AccountHome) HomeHelper.getHome(ACCOUNT_HOME, AccountHome.class);
}
/**
 * getSessionContext method
 * @return javax.ejb.SessionContext
 */
public javax.ejb.SessionContext getSessionContext() {
    LOG.debug("getSessionContext()");
    return mySessionCtx;
}
/**
 * setSessionContext method
 * @param ctx javax.ejb.SessionContext
 * @exception java.rmi.RemoteException
 */
public void setSessionContext(javax.ejb.SessionContext ctx)
    throws java.rmi.RemoteException {

    LOG.debug("setSessionContext()");
    mySessionCtx = ctx;
}
/**
 * Transfers money from one account to another, owned by the same customer
 * @param customerID int
 * @param debitID int
 * @param creditID int
 * @param amount int
 */
public AccountListData transfer(int customerID, int debitID, int creditID, int amount)
    throws NonExistentAccount, CustomerNotAuthorized, InsufficientFunds, InvalidOperation {

    if (LOG.isDebugEnabled()) {
        LOG.debug("transfer(" + customerID + ", " + debitID + ", " + creditID + ", " + amount + ")");
    }
    try {
        // Locate the accounts
        LOG.debug("Locating debit account");
        AccountKey key = new AccountKey(debitID);
        Account debitAccount = getAccountHome().findByPrimaryKey(key);
        LOG.debug("Locating credit account");
        key = new AccountKey(creditID);
        Account creditAccount = getAccountHome().findByPrimaryKey(key);

        // Validate that both accounts are owned by the customer
        if (!(creditAccount.isOwnedBy(customerID) && debitAccount.isOwnedBy(customerID))) {
	        String message = "Customer " + customerID + " does not own accounts " + debitID + " and " + creditID;
	        LOG.warn(message);
	        throw new CustomerNotAuthorized(BusinessException.WARNING, message);
        }

        // Transfer the funds - debit first in case we get an InsufficientFunds exception
        LOG.debug("Debiting debit account");
        AccountData debitData = debitAccount.debit(amount);
        LOG.debug("Crediting credit account");
        AccountData creditData = creditAccount.credit(amount);

        // Return the new account balances
        return new AccountListData(new AccountData[] { debitData, creditData });
    } catch (FinderException e) {
        LOG.warn("transfer() caught finder exception", e);
        throw new NonExistentAccount(NonExistentAccount.WARNING, "Cannot locate accounts");
    } catch (NamingException e) {
        LOG.error("transfer() caught naming exception", e);
        throw new EJBException(e);
    } catch (RemoteException e) {
        LOG.error("transfer() caught remote exception", e);
        throw new EJBException(e);
    }
}
}
