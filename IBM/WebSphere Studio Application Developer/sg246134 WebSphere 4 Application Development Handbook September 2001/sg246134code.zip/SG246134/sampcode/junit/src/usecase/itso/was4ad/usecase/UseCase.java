package itso.was4ad.usecase;

import itso.was4ad.data.DataBean;
import itso.was4ad.helpers.HomeHelper;
import javax.naming.NamingException;
import javax.ejb.CreateException;
import java.rmi.RemoteException;
import itso.was4ad.ejb.customer.*;
import itso.was4ad.ejb.account.*;

/**
 * Superclass for all PiggyBank use cases
 */
public abstract class UseCase {
    private static final itso.was4ad.helpers.LogHelper LOG =
        new itso.was4ad.helpers.LogHelper(UseCase.class);
    private static final String CUSTOMER_MANAGER_HOME =
        "java:comp/env/ejb/CustomerManager";
    private static final String ACCOUNT_MANAGER_HOME =
        "java:comp/env/ejb/AccountManager";
/**
 * Default constructor
 */
public UseCase() {
    super();
}
/**
 * Invoked to execute the use case - must have already populated fields
 * using setter methods
 * @exception java.lang.Exception An exception thrown during execution
 */
public abstract DataBean execute() throws Exception;
/**
 * Helper method returning the account manager EJB home
 * @return itso.was4ad.ejb.account.AccountManager
 */
protected AccountManager getAccountManager() throws NamingException, CreateException, RemoteException {
	LOG.debug("getAccountManager()");
    AccountManagerHome home =
        (AccountManagerHome) HomeHelper.getHome(
            ACCOUNT_MANAGER_HOME,
            AccountManagerHome.class);
	return home.create();
}
/**
 * Helper method returning the customer manager EJB home
 * @return itso.was4ad.ejb.customer.CustomerManager
 */
protected CustomerManager getCustomerManager()
    throws NamingException, CreateException, RemoteException {
    CustomerManagerHome home =
        (CustomerManagerHome) HomeHelper.getHome(
            CUSTOMER_MANAGER_HOME,
            CustomerManagerHome.class);
    return home.create();
}
}
