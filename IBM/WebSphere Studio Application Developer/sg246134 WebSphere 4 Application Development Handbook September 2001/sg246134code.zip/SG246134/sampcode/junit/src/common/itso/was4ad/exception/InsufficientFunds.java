package itso.was4ad.exception;

/**
 * Business exception indicating insufficient funds in an account
 * to satisfy requested operation
 */
public class InsufficientFunds extends BusinessException {
/**
 * InsufficientFunds constructor
 */
public InsufficientFunds() {
	super();
}
/**
 * InsufficientFunds constructor
 * @param level int
 * @param message java.lang.String
 */
public InsufficientFunds(int level, String message) {
	super(level, message);
}
/**
 * InsufficientFunds constructor
 * @param s java.lang.String
 */
public InsufficientFunds(String s) {
	super(s);
}
}
