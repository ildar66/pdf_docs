package itso.was4ad.helpers;

import javax.ejb.EJBHome;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

/**
 * Simple helper class for obtaining EJB homes
 */
public class HomeHelper {
	private static final LogHelper LOG = new LogHelper(HomeHelper.class);
/**
 * Looks up an EJB home interface
 * @return javax.ejb.EJBHome
 * @param jndiName java.lang.String
 * @param homeClass java.lang.Class
 * @throws javax.naming.NamingException
 */
public static EJBHome getHome(String jndiName, Class homeClass) throws NamingException {

    if (LOG.isDebugEnabled()) {
        LOG.debug("Getting EJB home: " + jndiName);
    }

    try {
        LOG.debug("Getting InitialContext");
        InitialContext context = new InitialContext();
        LOG.debug("Looking up home");
        EJBHome home = (EJBHome) PortableRemoteObject.narrow(context.lookup(jndiName), homeClass);
        return home;
    } catch (NamingException e) {
        LOG.warn("getHome() caught naming exception", e);
        throw e;
    }
}
}
