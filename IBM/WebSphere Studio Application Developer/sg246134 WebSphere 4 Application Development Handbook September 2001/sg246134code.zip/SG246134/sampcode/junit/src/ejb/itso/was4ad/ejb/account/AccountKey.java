package itso.was4ad.ejb.account;

public class AccountKey implements java.io.Serializable {
	public int number;
	private final static long serialVersionUID = 3206093459760846163L;

/**
 * Default constructor
 */
public AccountKey() {
	super();
}
/**
 * Initialize a key from the passed values
 * @param argNumber int
 */
public AccountKey(int argNumber) {
	number = argNumber;
}
/**
 * equals method
 * @return boolean
 * @param o java.lang.Object
 */
public boolean equals(Object o) {
	if (o instanceof AccountKey) {
		AccountKey otherKey = (AccountKey) o;
		return (((this.number == otherKey.number)));
	}
	else
		return false;
}
/**
 * hashCode method
 * @return int
 */
public int hashCode() {
	return ((new java.lang.Integer(number).hashCode()));
}
/**
 * Return a string representation of the key
 * @return java.lang.String
 */
public String toString() {
	return "[AccountKey number=" + number + "]";
}
}
