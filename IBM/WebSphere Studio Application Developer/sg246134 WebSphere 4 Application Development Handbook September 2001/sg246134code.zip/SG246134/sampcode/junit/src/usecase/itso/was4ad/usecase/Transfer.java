package itso.was4ad.usecase;

import itso.was4ad.data.*;

/**
<PRE>
Transfer money : transfer funds from a PiggyBank account to another PiggyBank account.

Input :
- customer id
- credit account number
- debit account number
- amount to be transfered

Basic path :
1. The customer enters the required input information and submits the request.
2. The system checks that both accounts exist and are different, that the customer is owner of the debit account and that the amount to be transfered is lower than the debit account current balance.
3. The system debits the customer account and credits the other account by the specified amount.
4. The system records the transaction.
5. The system displays the customer a summary of the transaction.

Alternative path :
2b. One of the checks fails.
3b. The system displays a message explaining why the transaction cannot be completed.
</PRE>
*/
public class Transfer extends UseCase {
    private int creditAccountNumber = 0;
    private int debitAccountNumber = 0;
    private int amount = 0;
	private int customerId = 0;
/**
 * Transfer constructor
 */
public Transfer() {
    super();
}
/**
 * Execute the transfer use case
*/
public DataBean execute() throws Exception {
	return getAccountManager().transfer(customerId, debitAccountNumber, creditAccountNumber, amount);
}
/**
 * Set the amount to transfer
 * @param newAmount int
 */
public void setAmount(int newAmount) {
	amount = newAmount;
}
/**
 * Set the account number to credit
 * @param newCreditAccountNumber int
 */
public void setCreditAccountNumber(int newCreditAccountNumber) {
	creditAccountNumber = newCreditAccountNumber;
}
/**
 * Set the number of the customer owning the two accounts
 * @param newCustomerId int
 */
public void setCustomerId(int newCustomerId) {
	customerId = newCustomerId;
}
/**
 * Set the account number to debit
 * @param newDebitAccountNumber int
 */
public void setDebitAccountNumber(int newDebitAccountNumber) {
	debitAccountNumber = newDebitAccountNumber;
}
}
