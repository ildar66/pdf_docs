package itso.was4ad.ejb.customer;

import java.rmi.RemoteException;
import java.util.Properties;
import javax.ejb.*;
import itso.was4ad.data.*;
import itso.was4ad.ejb.account.*;
import itso.was4ad.helpers.HomeHelper;
import itso.was4ad.exception.*;
import java.util.*;
import javax.naming.NamingException;
import itso.was4ad.helpers.LogHelper;
/**
 * This is an Entity Bean class with CMP fields
 */
public class CustomerBean implements EntityBean {
	private static final LogHelper LOG = new LogHelper(CustomerBean.class);
	private javax.ejb.EntityContext entityContext = null;
	public int id;
	public String name;
	private final static long serialVersionUID = 3206093459760846163L;

	// Constants
	private static final String ACCOUNT_HOME = "java:comp/env/ejb/Account";
/**
 * ejbActivate method
 * @exception java.rmi.RemoteException
 */
public void ejbActivate() throws java.rmi.RemoteException {
	LOG.debug("ejbActivate()");
}
/**
 * ejbCreate method
 * @param argId int
 * @param argName java.lang.String
 * @exception javax.ejb.CreateException
 */
public CustomerKey ejbCreate(int argId, String argName) throws javax.ejb.CreateException {
    if (LOG.isDebugEnabled()) {
        LOG.debug("ejbCreate(" + argId + ", " + argName + ")");
    }
    // Initialize CMP fields
    id = argId;
    name = argName;

    // Return null
    return null;
}
/**
 * ejbLoad method
 * @exception java.rmi.RemoteException
 */
public void ejbLoad() throws java.rmi.RemoteException {
	LOG.debug("ejbLoad()");
}
/**
 * ejbPassivate method
 * @exception java.rmi.RemoteException
 */
public void ejbPassivate() throws java.rmi.RemoteException {
    LOG.debug("ejbPassivate()");
}
/**
 * ejbPostCreate method
 * @param argId int
 * @param argName java.lang.String
 * @exception javax.ejb.CreateException
 */
public void ejbPostCreate(int argId, String argName) throws javax.ejb.CreateException {
	LOG.debug("ejbPostCreate()");
}
/**
 * ejbRemove method
 * @exception java.rmi.RemoteException
 * @exception javax.ejb.RemoveException
 */
public void ejbRemove()
    throws java.rmi.RemoteException, javax.ejb.RemoveException {

    LOG.debug("ejbRemove()");

    // Can only remove if we have no open accounts
    LOG.debug("Getting the account home");
    try {
        AccountHome home =
            (AccountHome) HomeHelper.getHome(ACCOUNT_HOME, AccountHome.class);
        LOG.debug("Getting the accounts");
        Collection c = home.findByCustomerID(id);
        if (c != null) {
            LOG.warn("Attempt to remove customer ID " + id + " with open accounts");

            throw new RemoveException("Cannot remove customer with open accounts");
        }
    } catch (FinderException e) {
        LOG.error("getAccounts() caught finder exception", e);
        throw new EJBException(e);
    } catch (NamingException e) {
        LOG.error("getAccounts() caught naming exception", e);
        throw new EJBException(e);
    }
}
/**
 * ejbStore method
 * @exception java.rmi.RemoteException
 */
public void ejbStore() throws java.rmi.RemoteException {
    LOG.debug("ejbStore()");
}
/**
 * Return a data object representing this customer
 * @return itso.was4ad.data.CustomerData
 */
public CustomerData getCustomerData() {
    LOG.debug("getCustomerData()");
    return new CustomerData(id, name);
}
/**
 * getEntityContext method
 * @return javax.ejb.EntityContext
 */
public javax.ejb.EntityContext getEntityContext() {
	LOG.debug("getEntityContext()");
	return entityContext;
}
/**
 * setEntityContext method
 * @param ctx javax.ejb.EntityContext
 * @exception java.rmi.RemoteException
 */
public void setEntityContext(javax.ejb.EntityContext ctx)
    throws java.rmi.RemoteException {

    LOG.debug("setEntityContext()");
    entityContext = ctx;
}
/**
 * unsetEntityContext method
 * @exception java.rmi.RemoteException
 */
public void unsetEntityContext() throws java.rmi.RemoteException {
	LOG.debug("unsetEntityContext()");
	entityContext = null;
}
}
