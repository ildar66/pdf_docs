package itso.was4ad.ejb.customer;

import java.rmi.RemoteException;
import java.util.Properties;
import javax.ejb.*;
import javax.rmi.PortableRemoteObject;
import itso.was4ad.helpers.*;
import itso.was4ad.exception.*;
import itso.was4ad.data.*;
import itso.was4ad.ejb.account.*;
import javax.naming.NamingException;
import java.util.*;
/**
 * This is a Session Bean Class
 */
public class CustomerManagerBean implements SessionBean {
	private static final LogHelper LOG = new LogHelper(CustomerManagerBean.class);
	private javax.ejb.SessionContext mySessionCtx = null;
	private final static long serialVersionUID = 3206093459760846163L;
	private static java.util.Random random = new java.util.Random();
	// Constants
	private static final String CUSTOMER_HOME = "java:comp/env/ejb/Customer";
	private static final String ACCOUNT_HOME = "java:comp/env/ejb/Account";
	private static final int MAX_ID = 1000;
/**
 * Create a new customer
 * @param name java.lang.String
 */
public CustomerData createCustomer(String name) {
    if (LOG.isDebugEnabled()) {
        LOG.debug("createCustomer(" + name + ")");
    }
    try {
       // Really awful way to get a unique customer ID
        Customer cust = null;
        LOG.debug("Creating customer - number is...");
        while (cust == null) {
            try {
                int id = Math.abs(random.nextInt() % MAX_ID);
	            LOG.debug("" + id);
                cust = getCustomerHome().create(id, name);
            } catch (DuplicateKeyException e) {
                LOG.debug("Duplicate key - try again");
                // Try again
            }
        }
        LOG.debug("Created customer");
        return cust.getCustomerData();
    } catch (NamingException e) {
        LOG.error("createCustomer() caught naming exception", e);
        throw new EJBException(e);
    } catch (CreateException e) {
        LOG.error("createCustomer() caught create exception", e);
        throw new EJBException(e);
    } catch (RemoteException e) {
        LOG.error("createCustomer() caught remote exception", e);
        throw new EJBException(e);
    }
}
/**
 * Delete a customer
 * @param id int
 * @exception itso.was4ad.exception.NonExistentCustomer
 * @exception itso.was4ad.exception.InvalidOperation
 */
public void deleteCustomer(int id) throws NonExistentCustomer, InvalidOperation {
    if (LOG.isDebugEnabled()) {
        LOG.debug("deleteCustomer(" + id + ")");
    }
    try {
        // Locate the customer
        LOG.debug("Locating customer");
        CustomerKey key = new CustomerKey(id);
        Customer customer = getCustomerHome().findByPrimaryKey(key);

        // Remove the customer
        LOG.debug("Removing customer");
        customer.remove();
    } catch (FinderException e) {
	    LOG.warn("Cannot locate customer with id " + id, e);
        throw new NonExistentCustomer(
            NonExistentCustomer.WARNING,
            "Cannot locate customer with id: " + id);
    } catch (RemoveException e) {
        // Make sure the transaction is rolled back
        LOG.debug("Setting transaction rollback only");
        getSessionContext().setRollbackOnly();

        // Convert to an invalid operation
        LOG.warn("deleteCustomer() caught remove exception", e);
        throw new InvalidOperation(
            InvalidOperation.WARNING,
            "Cannot remove customer with id: " + id + " (" + e.getMessage() + ")");
    } catch (NamingException e) {
        LOG.error("deleteCustomer() caught naming exception", e);
        throw new EJBException(e);
    } catch (RemoteException e) {
        LOG.error("deleteCustomer() caught remote exception", e);
        throw new EJBException(e);
    }
}
/**
 * ejbActivate method
 * @exception java.rmi.RemoteException
 */
public void ejbActivate() throws java.rmi.RemoteException {
	LOG.debug("ejbActivate()");
}
/**
 * ejbCreate method
 * @exception javax.ejb.CreateException
 */
public void ejbCreate() throws javax.ejb.CreateException {
    LOG.debug("ejbCreate()");
}
/**
 * ejbPassivate method
 * @exception java.rmi.RemoteException
 */
public void ejbPassivate() throws java.rmi.RemoteException {
    LOG.debug("ejbPassivate()");
}
/**
 * ejbRemove method
 * @exception java.rmi.RemoteException
 */
public void ejbRemove() throws java.rmi.RemoteException {
    LOG.debug("ejbRemove()");
}
/**
 * Helper method that returns the Account EJB home
 * @return itso.was4ad.ejb.account.AccountHome
 */
private AccountHome getAccountHome() throws NamingException {
	LOG.debug("getAccountHome()");
    return (AccountHome) HomeHelper.getHome(ACCOUNT_HOME, AccountHome.class);
}
/**
 * Gets a list of data object representing a customer's accounts
 * @return itso.was4ad.data.CustomerData
 * @param id int
 */
public AccountListData getCustomerAccounts(int id) throws NonExistentCustomer {
    if (LOG.isDebugEnabled()) {
        LOG.debug("getCustomerAccounts(" + id + ")");
    }
    try {
        LOG.debug("Getting the accounts");
        Collection c = getAccountHome().findByCustomerID(id);

        // If we got some, stick them in an array, otherwise return null
        if (c != null) {
            if (LOG.isDebugEnabled()) {
                LOG.debug("Got collection, size is " + c.size());
            }
            LOG.debug("Getting data objects from accounts");
            AccountData[] data = new AccountData[c.size()];
            int i = 0;
            Iterator iterator = c.iterator();
            while (iterator.hasNext()) {
                data[i] = ((Account)PortableRemoteObject.narrow(iterator.next(), Account.class)).getAccountData();
                i++;
            }
            return new AccountListData(data);
        } else {
            LOG.debug("No results");
            return null;
        }
    } catch (FinderException e) {
        LOG.error("getCustomerAccounts() caught finder exception", e);
        throw new EJBException(e);
    } catch (NamingException e) {
        LOG.error("getCustomerAccounts() caught naming exception", e);
        throw new EJBException(e);
    } catch (RemoteException e) {
        LOG.error("getCustomerAccounts() caught remote exception", e);
        throw new EJBException(e);
    }

}
/**
 * Gets a data only object representing the customer
 * @return itso.was4ad.data.CustomerData
 * @param id int
 */
public CustomerData getCustomerData(int id) throws NonExistentCustomer {
    if (LOG.isDebugEnabled()) {
        LOG.debug("getCustomerData(" + id + ")");
    }
    try {
        CustomerKey key = new CustomerKey(id);
        Customer customer = getCustomerHome().findByPrimaryKey(key);
        return customer.getCustomerData();
    } catch (FinderException e) {
        LOG.warn("Cannot locate customer with id " + id, e);
        throw new NonExistentCustomer(
            NonExistentCustomer.WARNING,
            "Cannot locate customer with id: " + id);
    } catch (NamingException e) {
        LOG.error("getCustomerData() caught naming exception", e);
        throw new EJBException(e);
    } catch (RemoteException e) {
        LOG.error("getCustomerData() caught remote exception", e);
        throw new EJBException(e);
    }
}
/**
 * Gets a data only object representing the customer and the customer accounts
 * @return itso.was4ad.data.CustomerData
 * @param id int
 */
public CustomerFullData getCustomerFullData(int id) throws NonExistentCustomer {
    if (LOG.isDebugEnabled()) {
        LOG.debug("getCustomerFullData(" + id + ")");
    }
    try {
        CustomerKey key = new CustomerKey(id);
        Customer customer = getCustomerHome().findByPrimaryKey(key);
        return new CustomerFullData(customer.getCustomerData(), getCustomerAccounts(id).getAccounts());
    } catch (FinderException e) {
        LOG.warn("Cannot locate customer with id " + id, e);
        throw new NonExistentCustomer(
            NonExistentCustomer.WARNING,
            "Cannot locate customer with id: " + id);
    } catch (NamingException e) {
        LOG.error("getCustomerData() caught naming exception", e);
        throw new EJBException(e);
    } catch (RemoteException e) {
        LOG.error("getCustomerData() caught remote exception", e);
        throw new EJBException(e);
    }
}
/**
 * Helper method that returns the customer EJB home
 * @return itso.was4ad.ejb.customer.CustomerHome
 */
private CustomerHome getCustomerHome() throws NamingException {
	LOG.debug("getCustomerHome()");
    return (CustomerHome) HomeHelper.getHome(CUSTOMER_HOME, CustomerHome.class);
}
/**
 * getSessionContext method
 * @return javax.ejb.SessionContext
 */
public javax.ejb.SessionContext getSessionContext() {
    LOG.debug("getSessionContext()");
    return mySessionCtx;
}
/**
 * setSessionContext method
 * @param ctx javax.ejb.SessionContext
 * @exception java.rmi.RemoteException
 */
public void setSessionContext(javax.ejb.SessionContext ctx) throws java.rmi.RemoteException {

    LOG.debug("setSessionContext()");
    mySessionCtx = ctx;
}
}
