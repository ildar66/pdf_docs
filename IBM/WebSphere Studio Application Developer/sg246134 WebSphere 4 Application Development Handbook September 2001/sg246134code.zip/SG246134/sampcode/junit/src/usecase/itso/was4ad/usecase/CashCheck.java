package itso.was4ad.usecase;

import itso.was4ad.data.*;

/**
<PRE>
Cash a check : cash a check from the city bank and credit a PiggyBank account.

Input : 
- check reference
- check amount
- account number to credit

Basic path :
1. The customer enters the required input information and submits the request.
2. The system checks that the credit account exists.
3. The system calls the remote city bank system and provides it the check reference and amount.
4. The city bank replies a YES if the check can be debited from the referenced city bank account.
5. The system credits the account by the specified amount.
6. The system records the transaction.
7. The system displays the customer a summary of the transaction.

Alternative path :
2b. The credit account does not exist.
3b. The system displays a message explaining why the transaction cannot be completed.

Alternative path :
4c. The city bank replies a NO : the check cannot be debited from the referenced city bank account.
5c. The system displays a message explaining why the transaction cannot be completed.
</PRE>
*/
public class CashCheck extends UseCase {
    private int checkAmount = 0;
    private java.lang.String checkReference = "";
    private int creditAccountNumber = 0;
/**
 * Constructor
 */
public CashCheck() {
    super();
}
/**
 * Executes the cash check use case
 */
public DataBean execute() throws Exception {
    // Cash the check
    AccountData data =
        getAccountManager().cashCheck(creditAccountNumber, checkAmount, checkReference);

    // Return the data object for the new account info
    return data;
}
/**
 * Set the amount of the check to cash
 * @param newCheckAmount int
 */
public void setCheckAmount(int newCheckAmount) {
	checkAmount = newCheckAmount;
}
/**
 * Set the reference of the check to cash
 * @param newCheckReference java.lang.String
 */
public void setCheckReference(java.lang.String newCheckReference) {
	checkReference = newCheckReference;
}
/**
 * Set the number of the account to credit
 * @param newCreditAccountNumber int
 */
public void setCreditAccountNumber(int newCreditAccountNumber) {
	creditAccountNumber = newCreditAccountNumber;
}
}
