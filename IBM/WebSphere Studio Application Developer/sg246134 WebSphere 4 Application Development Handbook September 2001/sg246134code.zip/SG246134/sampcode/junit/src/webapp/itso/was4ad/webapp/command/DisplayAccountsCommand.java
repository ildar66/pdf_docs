package itso.was4ad.webapp.command;

import itso.was4ad.webapp.controller.*;
import itso.was4ad.usecase.*;
import itso.was4ad.data.*;
import itso.was4ad.webapp.view.*;
import itso.was4ad.exception.BusinessException;

/**
 * Web command to display accounts
 */
public class DisplayAccountsCommand implements Command {
	private static final itso.was4ad.helpers.LogHelper LOG =
		new  itso.was4ad.helpers.LogHelper(DisplayAccountsCommand.class);
/**
 * Default constructor
 */
public DisplayAccountsCommand() {
	super();
}
/**
 * Execure the Web command
 * @param request javax.servlet.http.HttpServletRequest
 * @param response javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 */
public String execute(
    javax.servlet.http.HttpServletRequest request,
    javax.servlet.http.HttpServletResponse response,
    javax.servlet.http.HttpSession session)
    throws Exception {

    LOG.debug("execute()");

    // Retrieve customer id from session context
    CustomerView customer =
        (CustomerView) session.getAttribute(CommandConstants.ATTR_CUSTOMER);
    int customerId = Integer.parseInt(customer.getId());

    // Invoke use case
    String page = null;
    try {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Displaying accounts for customer id " + customerId);
        }
        DisplayCustomerAccounts useCase = new DisplayCustomerAccounts();
        useCase.setCustomerId(customerId);
        AccountListView view = new AccountListView((AccountListData) useCase.execute());
        LOG.debug("Storing account list view in request");
        request.setAttribute(CommandConstants.ATTR_ACCOUNT_LIST, view);

        page = CommandConstants.PAGE_DISPLAY_ACCOUNTS_RESULT;
    } catch (BusinessException e) {
        // Go to error page
        LOG.warn("Caught business exception", e);
        throw e;
    }

    // Return the page we need to forward to
    if (LOG.isDebugEnabled()) {
    	LOG.debug("Forwarding to page " + page);
    }
    return page;
}
}
