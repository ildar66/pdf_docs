package itso.was4ad.data;

/**
 * Data object representing a customer, including all account information
 */
public class CustomerFullData extends DataBean implements java.io.Serializable {
    private int id = 0;
    private java.lang.String name = null;
    private AccountData[] accounts = null;
	private final static long serialVersionUID = -6141075947313825399L;
/**
 * Default constructor
 */
public CustomerFullData() {
	this(new CustomerData(), new AccountData[0]);
}
/**
 * Constructor
 */
public CustomerFullData(int id, String name, AccountData[] accounts) {
	super();
	// Populate fields from parameters
	this.id = id;
	this.name = name;
	this.accounts = accounts;
}
/**
 * Constructor
 */
public CustomerFullData(CustomerData data, AccountData[] accounts) {
	super();
	// Populate fields from parameters
	this.id = data.getId();
	this.name = data.getName();
	this.accounts = accounts;
}
/**
 * Gets the list of accounts
 * @return itso.was4ad.data.AccountData[]
 */
public itso.was4ad.data.AccountData[] getAccounts() {
	return accounts;
}
/**
 * Getter for customer ID
 * @return int
 */
public int getId() {
	return id;
}
/**
 * Getter for customer name
 * @return java.lang.String
 */
public java.lang.String getName() {
	return name;
}
/**
 * Return a string representation of the customer
 * @return java.lang.String
 */
public String toString() {
	StringBuffer buf = new StringBuffer();
	buf.append("[Customer ID=");
	buf.append(id);
	buf.append(", Name=");
	buf.append(name);
	buf.append("]");
	return buf.toString();
}
}
