package itso.was4ad.webapp.view.tests;

import itso.was4ad.data.*;
import itso.was4ad.webapp.view.*;
import junit.framework.*;
/**
 * JUnit tests for the CustomerView class
 */
public class CustomerViewTests extends TestCase {
/**
 * Constructor
 * @param name java.lang.String
 */
public CustomerViewTests(String name) {
	super(name);
}
/**
 * Test the behaviour when the view is created using te default constructor
 * This will happen on a JSP if the object isn't passed in the request as expected
 * We must behave gracefully!
 */
public void testDefaultConstructor() {
	CustomerView view = new CustomerView();
	assertEquals("Customer ID incorrect", "0", view.getId());
	assertEquals("Customer name incorrect", "", view.getName());	
}
/**
 * Test the output format - the view bean formats all output as strings
 */
public void testFormat() {
	CustomerData data = new CustomerData(101, "John Smith");
	CustomerView view = new CustomerView(data);
	assertEquals("Customer ID incorrect", "101", view.getId());
	assertEquals("Customer name incorrect", "John Smith", view.getName());	
}
}
