package itso.was4ad.client.swing;

import itso.was4ad.data.*;
import itso.was4ad.usecase.*;
import java.io.*;

/**
 * Used by the swing GUI components to interact with the PiggyBank
 * use cases
 */
class ClientManager {
    private static final itso.was4ad.helpers.LogHelper LOG =
        new itso.was4ad.helpers.LogHelper(ClientManager.class);

/**
 * ClientManager constructor comment.
 */
public ClientManager() {
	super();
}
/**
 * Invokes the cashCheck use case
 */
String cashCheck(String accID, String money, String reference) {

    String code = null;

    // Get the information we need
    int accountID = Integer.valueOf(accID).intValue();
    int amount = Integer.valueOf(money).intValue();

    // Cash the cheque
    try {
        if (LOG.isDebugEnabled()) {
            LOG.debug(
                "Invoking cashCheck(" + accountID + ", " + amount + ", " + reference + ")");
        }
        // Create the use case instance
        CashCheck useCase = new CashCheck();
        useCase.setCheckAmount(amount);
        useCase.setCheckReference(reference);
        useCase.setCreditAccountNumber(accountID);

        // Execute the operation
        AccountData data = (AccountData) useCase.execute();

        code =
            "Successfully debited "
                + amount
                + " from Account ID "
                + accountID
                + " new balance is $"
                + data.getAmount();
    } catch (Exception e) {
        LOG.error("Exception in cashCheck()", e);
    }
    return code;
}
/**
 * Invokes the displayAccount use case
 */
String displayAccount(String accID) {

    String code = null;

    // Get the information we need
    int accountID = Integer.valueOf(accID).intValue();

    // Display the customer
    try {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Invoking displayAccount(" + accountID + ")");
        }

        // Create the use case
        DisplayAccount useCase = new DisplayAccount();
        useCase.setAccountId(accountID);

        // Execute the use case
        AccountData data = (AccountData) useCase.execute();
        StringBuffer buf = new StringBuffer();
        buf.append("Account number: ");
        buf.append(data.getNumber());
        buf.append("\nCustomer ID: ");
        buf.append(data.getCustomerID());
        buf.append((data.isChecking() ? "\nChecking account" : "\nSavings account"));
        buf.append("\nBalance: ");
        buf.append(data.getAmount());
        code = buf.toString();
    } catch (Exception e) {
        LOG.error("Exception in displayAccount()", e);
        code = "Caught create exception: " + e;
    }
    return code;
}
/**
 * Invokes the display customer use case
 */
String displayCustomer(String cusID) {

    String code = null;

    // Get the information we need
    int customerID = Integer.valueOf(cusID).intValue();

    // Display the customer
    try {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Invoking displayCustomer(" + customerID + ")");
        }

        // Create the use case instance
        DisplayCustomerDetail useCase = new DisplayCustomerDetail();
        useCase.setCustomerId(customerID);

        // Execute the use case
        CustomerFullData data = (CustomerFullData) useCase.execute();

        // Display results
        StringBuffer buf = new StringBuffer();
        buf.append("Customer ID: ");
        buf.append(data.getId());
        buf.append("\nCustomer name: ");
        buf.append(data.getName());
        buf.append("\nAccount list:");
        AccountData[] accounts = data.getAccounts();
        for (int i = 0; i < accounts.length; i++) {
            buf.append("\n\n\tAccount number: ");
            buf.append(accounts[i].getNumber());
            buf.append("\n\tCustomer ID: ");
            buf.append(accounts[i].getCustomerID());
            buf.append(
                (accounts[i].isChecking() ? "\n\tChecking account" : "\n\tSavings account"));
            buf.append("\n\tBalance: ");
            buf.append(accounts[i].getAmount());
        }
        code = buf.toString();
    } catch (Exception e) {
        LOG.error("Exception in displayCustomer()", e);
        code = "Caught create exception: " + e;
    }
    return code;
}
/**
 * Invokes the open account use case
 */
String newAccount(String cusId, String chk){

	String code = null;  
	 
	// Translate the parameters to the desired types
	int customerID = Integer.valueOf(cusId).intValue();
	boolean checking = false;
	if(chk.equals("Y")||chk.equals("y"))	checking = true;
	else if(chk.equals("N")||chk.equals("n")) checking = false;
	else{
		return "Please introduce a correct checking value";
	}
	    
    // Create the account
    try {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Invoking newAccount(" + customerID + ", " + checking + ")");
        }

        // Create the use case
        OpenAccount useCase = new OpenAccount();
        useCase.setChecking(checking);
        useCase.setCustomerId(customerID);

        // Execute the use case
        AccountData data = (AccountData) useCase.execute();

        // Display results
        code = "Created new account, number is " + data.getNumber();
    } catch (Exception e) {
	    LOG.error("Exception in newAccount()",e);
        code = "Exception in newAccount(): " + e;
    }
    return code;
}
/**
 * Invokes the create customer use case
 */
String newCustomer(String customerName) {

    String code = null; //Information about the creation process

    // Create the customer
    try {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Invoking createCustomer(" + customerName + ")");
        }

        // Create use case instance
        CreateCustomer useCase = new CreateCustomer();
        // Set variables for the use case
        useCase.setName(customerName);
        // Execute the use case
        CustomerData customer = (CustomerData) useCase.execute();
        code = "Customer created with ID " + customer.getId();
    } catch (Exception e) {
        LOG.error("Caught exception in newCustomer", e);
        code = "Exception in newCustomer()" + e;
    }
    return code;
}
/**
 * Invokes the transfer use case
 */
String transferMoney(String customer, String debit, String credit, String money) {

    String code = null;

    try {
        // Get the information we need
        int customerID = Integer.valueOf(customer).intValue();
        int debitID = Integer.valueOf(debit).intValue();
        int creditID = Integer.valueOf(credit).intValue();
        int amount = Integer.valueOf(money).intValue();

        
        // Make the transfer
        if (LOG.isDebugEnabled()) {
            LOG.debug("Invoking transfer(" + debitID + ", " + creditID + ", " + amount + ")");
        }

        // Create the use case
        Transfer useCase = new Transfer();
        useCase.setCustomerId(customerID);
        useCase.setDebitAccountNumber(debitID);
        useCase.setCreditAccountNumber(creditID);
        useCase.setAmount(amount);

        // Execute the use case
        AccountListData data = (AccountListData) useCase.execute();

        // Display results
        AccountData debitAccount = data.getAccounts()[0];
        AccountData creditAccount = data.getAccounts()[1];
        StringBuffer buf = new StringBuffer();
        buf.append("Transfer complete\nAccount ");
        buf.append(debitID);
        buf.append(" balance is ");
        buf.append(debitAccount.getAmount());
        buf.append("\nAccount ");
        buf.append(creditID);
        buf.append(" balance is ");
        buf.append(creditAccount.getAmount());
        code = buf.toString();
    } catch (Exception e) {
        LOG.error("Exception in transferMoney()", e);
        code = "Caught create exception: " + e;
    }
    return code;
}
}
