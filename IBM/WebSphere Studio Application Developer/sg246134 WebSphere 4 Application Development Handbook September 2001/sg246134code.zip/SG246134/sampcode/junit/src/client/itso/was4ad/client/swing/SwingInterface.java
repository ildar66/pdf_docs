package itso.was4ad.client.swing;

/**
 * Implements the Swing GUI interface
 */
class SwingInterface extends javax.swing.JFrame {
	private static final itso.was4ad.helpers.LogHelper LOG =
		new  itso.was4ad.helpers.LogHelper(SwingInterface.class);
	private javax.swing.JPanel ivjJFrameContentPane = null;
	private javax.swing.JMenu ivjJClientMenu = null;
	private javax.swing.JMenuItem ivjJCreateCustomer = null;
	private javax.swing.JMenuBar ivjSwingInterfaceJMenuBar = null;
	IvjEventHandler ivjEventHandler = new IvjEventHandler();
	private javax.swing.JMenuItem ivjJCreateAccount = null;
	private javax.swing.JMenuItem ivjJExit = null;
	private javax.swing.JMenuItem ivjJCashCheque = null;
	private javax.swing.JMenuItem ivjJDisplayAccount = null;
	private javax.swing.JMenuItem ivjJDisplayCustomer = null;
	private javax.swing.JMenuItem ivjJTransferMoney = null;

class IvjEventHandler implements java.awt.event.ActionListener, java.awt.event.WindowListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			if (e.getSource() == SwingInterface.this.getJCreateCustomer()) 
				connEtoC1(e);
			if (e.getSource() == SwingInterface.this.getJCreateAccount()) 
				connEtoC2(e);
			if (e.getSource() == SwingInterface.this.getJExit()) 
				connEtoC3(e);
			if (e.getSource() == SwingInterface.this.getJDisplayCustomer()) 
				connEtoC4(e);
			if (e.getSource() == SwingInterface.this.getJDisplayAccount()) 
				connEtoC5(e);
			if (e.getSource() == SwingInterface.this.getJTransferMoney()) 
				connEtoC6(e);
			if (e.getSource() == SwingInterface.this.getJCashCheque()) 
				connEtoC7(e);
		};
		public void windowActivated(java.awt.event.WindowEvent e) {};
		public void windowClosed(java.awt.event.WindowEvent e) {
			if (e.getSource() == SwingInterface.this) 
				connEtoC8(e);
		};
		public void windowClosing(java.awt.event.WindowEvent e) {};
		public void windowDeactivated(java.awt.event.WindowEvent e) {};
		public void windowDeiconified(java.awt.event.WindowEvent e) {};
		public void windowIconified(java.awt.event.WindowEvent e) {};
		public void windowOpened(java.awt.event.WindowEvent e) {};
	};
/**
 * SwingInterface constructor comment.
 */
public SwingInterface() {
	super();
	initialize();
}
/**
 * connEtoC1:  (JCreateCustomer.action.actionPerformed(java.awt.event.ActionEvent) --> SwingInterface.displayNewCustomerPanel(Ljava.awt.event.ActionEvent;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.displayNewCustomerPanel();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  (JCreateAccount.action.actionPerformed(java.awt.event.ActionEvent) --> SwingInterface.displayNewAccountPanel(Ljava.awt.event.ActionEvent;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.displayNewAccountPanel();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (JExit.action.actionPerformed(java.awt.event.ActionEvent) --> SwingInterface.exit()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.exit();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (JDisplayCustomer.action.actionPerformed(java.awt.event.ActionEvent) --> SwingInterface.displayDisplayCustomerPanel()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC4(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.displayDisplayCustomerPanel();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC5:  (JDisplayAccount.action.actionPerformed(java.awt.event.ActionEvent) --> SwingInterface.displayDisplayAccountPanel()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC5(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.displayDisplayAccountPanel();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC6:  (JTransferMoney.action.actionPerformed(java.awt.event.ActionEvent) --> SwingInterface.displayTransferMoneyPanel()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC6(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.displayTransferMoneyPanel();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC7:  (JCashCheque.action.actionPerformed(java.awt.event.ActionEvent) --> SwingInterface.displayCashChequePanel()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC7(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.displayCashChequePanel();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC8:  (SwingInterface.window.windowClosed(java.awt.event.WindowEvent) --> SwingInterface.exit()V)
 * @param arg1 java.awt.event.WindowEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC8(java.awt.event.WindowEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.exit();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Displays the Cash Cheque panel
 */
private void displayCashChequePanel() {
	if (LOG.isDebugEnabled()) {
		LOG.debug("Loading Cash Cheque Panel");
	}
	JCashCheck jCash = new JCashCheck();
	getJFrameContentPane().removeAll();
	getJFrameContentPane().add(jCash, "Center");
	getJFrameContentPane().repaint();
	getJFrameContentPane().setVisible(true);
	return;
}
/**
 * Displays the Display Account panel
 */
private void displayDisplayAccountPanel() {
	if (LOG.isDebugEnabled()) {
		LOG.debug("Loading Display Account Panel");
	}
	JDisplayAccount jdisplayAcc = new JDisplayAccount();
	getJFrameContentPane().removeAll();
	getJFrameContentPane().add(jdisplayAcc, "Center");
	getJFrameContentPane().repaint();
	getJFrameContentPane().setVisible(true);
	return;
}
/**
 * Displays the Display Customer panel
 */
private void displayDisplayCustomerPanel() {
	if (LOG.isDebugEnabled()) {
		LOG.debug("Loading Display Customer Panel");
	}
	JDisplayCustomer jdisplayCus = new JDisplayCustomer();
	getJFrameContentPane().removeAll();
	getJFrameContentPane().add(jdisplayCus, "Center");
	getJFrameContentPane().repaint();
	getJFrameContentPane().setVisible(true);
	return;
}
/**
 * Displays the New Account panel
 */
private void displayNewAccountPanel() {
	if (LOG.isDebugEnabled()) {
		LOG.debug("Loading New Account Panel");
	}
	JNewAccount jnewAcc = new JNewAccount();
	getJFrameContentPane().removeAll();
	getJFrameContentPane().add(jnewAcc, "Center");
	getJFrameContentPane().repaint();
	getJFrameContentPane().setVisible(true);
	return;
}
/**
 * Displays the New Customer panel
 */
private void displayNewCustomerPanel() {
	if (LOG.isDebugEnabled()) {
		LOG.debug("Loading New Customer Panel");
	}
	JNewCustomer jnewCus = new JNewCustomer();
	getJFrameContentPane().removeAll();
	getJFrameContentPane().add(jnewCus, "Center");
	getJFrameContentPane().repaint();
	getJFrameContentPane().setVisible(true);
	return;
}
/**
 * Displays the Transfer Money panel
 */
private void displayTransferMoneyPanel() {
	if (LOG.isDebugEnabled()) {
		LOG.debug("Loading Transfer Money Panel");
	}
	JTransferMoney jTransfer = new JTransferMoney();
	getJFrameContentPane().removeAll();
	getJFrameContentPane().add(jTransfer, "Center");
	getJFrameContentPane().repaint();
	getJFrameContentPane().setVisible(true);
	return;
}
/**
 * Comment
 */
private void exit() {
	if (LOG.isDebugEnabled()) {
		LOG.debug("Exiting the application");
	}
	System.exit(0);
	return;
}
/**
 * 
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private static void getBuilderData() {
/*V1.1
**start of data**
	D0CB838494G88G88G8FDA55AAGGGGGGGGGGGG8CGGGE2F5E9ECE4E5F2A0E4E1F4E145DC8DF0D4D5168E9AA57CA8C18284899891F731E4F7B3B56AE437F0E5149DB3AB35E6E65D9A5CE5E7F14495C7444C42E434E44617F4C292881D04C48888A6E01440C00C7CE80C518292B4B8D1FAA0E210A03C24DF12A61D6ECE776B2473C358F36EFD67766B4E6B7CA91A2AD36F5D6F5CF36EF9671E7BFFBBD2C1D1ECFACAEA01A42524CB5A5F7BA912947719A4DD3E6D7EA50495B6A41BA55D5FEE20BC
	29F1EB9ABCCB0117F4E732B9D7DA13128969AAC857C0FA9B3C67CBEBD3565742CB08F21EG1E6B21E91E214B3174D0B999AC7D10128DCF4CF88CB0ABD0DC83167FAB25D043A3A0ED565E11D2D2A52971BC66D91AD5284357E9794A01D783A4FD0DF97ECF592971678306F99641B371BC4F3B8A1ED94C3A1BAAAB34FC0DD3E7C8CF7CEBF846E6ACCB271F2876EBAEEB571E12141D010EB0C92B3EBE08BE333437FEECD3BD4E32EE59F3C43616B55BED0AC3AD73F45B9C2D1515E771F14A21AA6E9639D9017C4B391D
	D919CC87588969368B08DD59083EA906778AA04B853275971B2BB4DB225AE7C8D5CFBFED8AE56B428B5C46448BFEDBE3D29EC98BEBC47D2F37E4EBF239102E856236B43710ADCB9A49162957B06FFAC897DCCCB69F38C8F80304F88D249B01540BE463C7FB4946063E3B25AA074314934246499739ED77DD745B38FA5F9E53F6969F4BFB310E1300D770CD323994288E488EB49968F59617B3FB764373F813DA6D6C68F0BA0E3BDCA76CD67767CE2BE207774ACA60E8589925596936CA920F3DBFE49DB03007E87E
	B701F107443F6DAB09E2E5611998A9A16599D33A4137957EF125A9DE5331749B7F37D5DDC23F35ECC23F2D869C655E4438E1F8984343AE79F1DED7AE968B18CE845E6A4B646786B359D21796A9A5155F1311E1E00B6F61399919CD5C0662A63FAD5C478F74230F6BGEF838A830A860A87DA56C4BEFE2A6770F0BEE6C16D106DE73DCDAE592D1E705A6CD6452D79FAF74BD03EB6A2AE774E286538DF969C565751229FAFB0744B228537E42C537C115D6C778BAF3BADE459871A874706D954E1BAEB93471AF99D1A
	841E43F00B8E67F5BB1335ADCCDF865E92A01EFF954BDFEA657973041E1799DE2F43391EEF984E52404BD6124D3CFE6B87308F0C0674FDC0CB01D6822535A41B0B010E34D09D9F68FDE7046D48222BDFAE7BCC6FD6F8AABE55AD1FF2F8D459512C1C135DB639492E400840732C69C53FB685482DE56D3B994A78D4F1A8EED935B99D20DD6ED0A018BCBC4F7ADE7C26E637423875368E858A68F0C924B72DAF9F1EF65923FE69324A2A624F417959FD9893DD72B950888A60BD3C857DE55E087DDCBD3C3BDA48D763
	2EA116G699542AF637B364073AF905C0A3D323246560CE6486E9E0AD17B269AF82E037C592D4966922045C00DED501F820559404FD720CD811537437886D4EECFB6C7816D6CC8B6478215B8606920B63D2601E237E673ECA97BBF7E56B0F6D72EDFE94AF672B8ACF186476E4D4C26BA40DDC011C0F1C009C0C9C039AE3081488264820A840A83CA84CA824A6D84BE10251346692E0D39A94337BD7401910E5F97CA867DC26F688BBD8F7D951036075693CC31C1E5E25D44E97A30CE300E18ED2D0179305E2234F2
	305EF6865904F59A58C7BDB8A25F18C2603B071049573D978571DE8BCAEF9F21DF105E8CCA637835CDFB47F1BACB77FD7AFC1BA45E664C926FE7F68571B7875913A73D487AA4974451E420051D54269E6EAB16D8DFF3C276A8543B1CF6C34720D87DAD0C67FD289FEDD23AE096D52338940795DEBCDA5B7ED9BF5A2A75BBADCE097A04258C47F1289ABA860F40FF591F47F150216F45087F1F0CAF2B2A5B5664D515330A2A42FC4DAF7F9BE60BA7E00873E85F7A3B947C56A5700D4B01D60BEFED3F0A75C87DC71D
	53596EF555E34F2875C35758FCCBF2A71B8B5D545EB6C9B8CF2E926957D85A4F1FF32DE104F50DBAC69A9701F17D40084B88955B431731C642B82071B0DD433334D85B2C45A34F7BAA4B5BG5F938634GA89168A520E28F4CDF01DC9E720FD58A9B015E515ABC36EF9C4FEC994A0E3C6F41969E0B5F8C04EECB4A00F1DBEA9FB0EECB1D83C337151E81233642F9E183688BE737C35776EE9A40F1365969F0A82C8390A292DFDF2D29476F30B9EC6AD7B6EB2B221E35754282EA31875B50DBECAC0F0677059E9AC7
	3B5F24F13424F72694FB69068C23F93A6F6EBBB352D45EC68AD57FB84AED3A194D4D943B52810E2AF6FA9DAA47A733F90206FBCC8CDBD90AF57AD9B5DB6FFD2EB83C9247A79D5F08B8A227D42563DDC943E33D1170ACAE7D2C9A27B6CA355723BABB94778119FDFD99FFD8E02168F4F7A85652ABF217DCA6F72BE52C764A0EB376C9FC5FD7FC7060474501AB4B83D61B47E517FB3ED03AC931C5068E2834AE341E8F771D5BD74EEDFB2371D63DED471B1B715B3FF353B43DA332CC786D21AE8F376D244F76DD1924
	002A618CB82415BF6E5D693C7C9A7E9D57276202140F48C507A5721133F6DA000D57258283F50F4842A31AFDBBBE38426D2BF74B8ECF0B824B8C07528366B5C31B02E50053BDC43981B2A3AA76A879656F0AA6E9F1ADFB5A2A5B14CE2F725D7A442FF7C4063D275955F6CD7D817A82FFFB6FFF4B7D3D37F7FD1B6E6E7F6A7A34E9DD3B7D726D1E9F2A5D86344D3B77F67FB0EDD3577E6E6A769A373F6F508403E64A1B22E6C354DE67775B96F56D6D6D1C0B2C6CA0C1C8D91D5DE57CD1EDF7FA86177D95638D9FF5
	6FCB3486AAB1619C22826696F5C0D6155685190CCF6B82ED71D36D345B7974C722FD6EC7B76977397BD53ECFFE9FBC9300F23D18A755DC204B33C24B036F1CDF9640EF70F27EFCAF497F03A1BFDE704BF30C78CB857FC7067C9502FFA857083FCE70FFEC484F6CA27E11BCA37ECE413F5F10DFAE786FEDB16257887ECF8C79FE7FBDED48EF907256FCA33EDD701FB1640789FECB0191BFCA701FB5647B67753F17F2F12E0D316EE8D6F0F179972507764F24ADC13CF3325D6B5F17CBCB41F92BDD37AE65789FD20C
	673EFFCC4135E83B501F123AC1427DB52E134F5563E45469F25BBAE0990F8BEDAD16E73468E3F981FC9F1E6FAC05678AA0AE3BAF8DF94187A5515DA87FFE8A1D673C043E812C3C1B6BF0F5F3FF70FC2F08FCABA13D9EE8270F67EB746973BD14CA7942810F717973AD8A4867B1D13EC440D76972E57668736DCD23FCC7G2F6B71673387647BAF11AF9A70B8DD3E4400FCD3524577821E5B6B4FD75E2B4FD73D0172B57472FD84D7EF60F7AC6C45FCD59B69EC679D011DE5D8BEACCC2F26517E7967397A73309A4F
	6D06EBA724A44D0E343E60F30573E928378470A3FD546775256A77C20EFBBC4EE69B5B5655E2EE3FC93F2E6258BBA6DCBF35585C9E7594ACD8FD9437C7CDE8AB6E7BEA3096FB67B762F990BB07EBF6F614591ABA4A3CDD9DE5F293F461D61BDAD94916E267EC9E2FECE721291D413D3AA9D353D15BC767DB27B7337398C8C7834575D10CBE37F50FB4F82F7CA428F73A4501C8B3F6625C1FD7BF511F594564CC495894421F891A9FD7697C9937EF0F0917FB6F1FBF9A365CEABEBA55BB2B1DD625961AF535D8D21F
	33A9B877605F2B18A996CA7B696C6FFF85F6D9E02DB904C58BEC15409285E64BA5AC73AAE13F9558B101356791669358EA0145892CE38BE12B8436A31F30628142E68B2CC1E0BB8B880B94589C01A58CD0BD3E3C2310E28547F99F9D53FE76891EC1F0B9299565303E24EB9497A57DECCC073485B1A0FE86F319751928BB8C3078EB54FF473B757DF7926005E14966AAA0BE9FF9B46590BCC7BF7B2118FFEF7F8EF8061E67D39C4E4BBF265930746FA3251D57DC99C66732EDB93D9916B09EFF3EB0FF9CDA7E3447
	D4AE5D13423F35A4153EF58964D99FC65FBA60B17A56A36368DBA725FE3BEF4D5B3DBD60DB036638921D072D927655C259E163483E2DBEA37B6247D1CC9CBD04FBF45ABCCE5395E3A2DDCBA1DF5A8D246BCF2AE13D5EC03A261EFF43EFEB08258159EBC923B2ACA09FA14AD862B5AAE331A8E37A41DD034A88651334F4AA6389104F3E114A1858E5D4C64D0DD4467D72CEFF990693FB2EBFDE68EFG59C8215F52ED24BFC168FFF5072ECE874F5B057D768D24FFB9489604D3CC4D4A4271EC1453F7BA4FBF249F6B
	22F6981F67A355057336F0B9BCF82C7BE88376917D00C70653D897E7427DD19A6B4EC08FACBBDA6DF867C35B0BCDC35BE19E25251B5230DCB60F12E86FB8AD5B688CFA3ED6FEFC78603DFDFEC67C889B37160673B3629401AFE578B29D4E7D7A65E63A8B3292F835B751F9E8EF86565BC2C8A7G2DGFA892870E67A466752063D97F052B7443D00AB66511C6FD75CCC7B7B4F0FCA2ECE4859F3C6A3F7D9483DB0AAB9D548B9F2C7A397A164DE9C15DC0C10F3650DC6AECE487DEED4F2CB041CFB4BE86416893922
	7C51482D96F23123121346135C6E025148958839F92312AB95F2692DA8D785E94B7841ED548A18CF07CF9ECFF7BE22593CA2F6FC705D11F98C0F9B9FFCF7E4FFBF5D9DD98C3C1288AA3FA5A5586E0808C0BB668725391CBAC82EACA81D90A4477B6F04F46C8F8C66D1F46A212D7FF6F66A57FFABC0D75A04E4F3A9D055841A273D6826F9DA7D846A0792B3F17C198C6985C00BB1AF10B49156C3C047A6D2FFD411EEB4BF8E6C0FC2CD0E7DE7415C977BD34766430AC1F241BE3CBCB168CE811F972BE2DEBC116AF1
	4D98EDD8BF2C8DF106B6FC6E93F3E4E143BC5358EC089BA497EC03B449480623DE3221F09259F0AEEDECB6D88749855BE0B1346195E1C31B30E1E37A58ECA89CA497ECC32C218DBF6DA29B62058D7FBCC69B168EEBC312218D633B451AEEB259D0B1685E6448EC78E410DC308D47A6874A71361F4B76A79A0057B6195A7974F4BCBB27391545E9F3607989671D58007BD1CE372D5566A06CD306B5BB5D6C40195F3BF8BD9B757AC0E784904742989685690562FBFF0EC5E95F70CB5D7B054DA33D9FB196527A636B
	DA86774D8D99216F84CC48B03E93B0A54378CE40740C216F574C4988F5E7007BFF9C5BFFC8845F2F96F5121AC318F48BE1B78A2CC0E0E93904158A6CA601D589ECC39EE196010D9718D5E019DB887389EC0240A68B6C3DFC42E2857693015DA7300A82429284760F82DBAE301DEC3FA1895285379266E1D8692DFC3C6458F29F45EA1548575C0758E5C82B82DB483088C8475CCAB1BD379F77F09708748216CE9069727E61628EE53FDDEC1F9A360C315CABA25A4564FF3EB50745234723F85840DFA32B3246FBD6
	45BBF4036E1BFCA1F7A8921DD14DC94952721CD41D556FCAB45F495A067765C24CF7241AA96877BBDBE92E339A6BED8A775701A9FCFF16772F751D543FCE1EC2FBCB4FF632FBE410DE8E34EE8A5549BA3751DCB4BBB2F4BDE8F75AB2C3376F27B20D5B7733195851F91CDEF733925C0657E4968A1EFF760413BCF41DF6F64064D5595D2A8C6A837E4464B9AF14FCC6D628FE02570B1C2A2F17C3A226DC2A110F0A077091577716C92F6F3050F746E7246F48307A1E8C50F7C4682B749A692B9DD65FADE9FAFDC705
	BE294BC8DF63307A0E276B753DA7747D4CD01FEBD8FD3F8F50773E50B7395BC8DF78307A1CD9FAFD95A2F6DE5B086B9F1FC8EFE7699EA1F7A89B7BB19582BABA92FFFF74A49E0BE9ED76C75D38075B6216BBA0144E3A14E629FCAA3637195954CE17EBF6A5E94F5C2934BF259CB70B18BD6930EA938EFEFE924D462C47A1A37E7E07E35B597874A8E09D823B1DE1AF02216F269276BA9B1F7E87725DA37245B06CD700BDA330DDECFC7AF740F62590B617E17F8258850195317169C5402A05ECAC431E836C1A40BE
	67FB66B0A9FAD0E07F4630D7A15F4B82BB4D4627D7G7BC01411483067819B17C2FEBF5C0AFD29D5E9113DF6156D3C1DF6E95779810FE3FE7E22154ED7FCD3E95FEEA243D82FF9C2F6737AD86B237AD887694C5BE0BC872A85EA3B0D64FA7BB03E3AEC9E9B1ED7F27DD37B28AF0D90799E694372D41B4A765DF8CC2C472EC5337B4EB6CC705DFE680BD4056F19CAF4767EE43FFE3D9AFD9B6F3B9741B371B65A735F5BC6FBE72BGAB1EC6B1F3438738A79FE20C002F0535856B6F2DCC3E8164DCC09153687E226F
	EDBAB3DA78B711D26DB3463F73DADCBFA5A3F69A0F57A5537C7B12527EBDA65E864FF79A35C1A9AAF49B64FB8E6DEE342BA00A6FB964883C0F61D5BA1C7B6185B6EEE15A8A3C95D1B47F586441FAE91C1EEC36CF9773AD365675C1BAC2E0B69FE1D1827B2B1730D801ED6BA2EC21407EDBE071823B2B1B30A55349270FDF506F75A64D9A4820FD50E09FA4CE677ED9BE5D6FD3BEE6BF4856886CF7F3B3A0AEE7A076FC36FEFF9BE38A6F6B1781F17E2E4DFABE4647849367F33B9EFB0B6AFA7DE3F3253A7BE7047C
	7DE1648C6D77F25AB35E34F8C3E353A79BF9BCABEC5FC997EE5A06B744B67EAAC77514551CBAEBB9FD76642553DFDC2A2E0397DEFEEC375EAF059B23C21E772E564A15E6EA3F1FB83AF883774B769E72CB45CC724B27BD7A6FC69BE7256A7D5253B3345F727A74FC34752FA6BD3F3AAF582F3BB4F96E0F85FDECBCF0FB955EA6576E8BF15E47CE9A78F764DD25FE4AB51366E43F9E4058DEG6945C04BE6521C6CE05B58FE5776612865F85BDB467A0A2419417B033FE138949D3CBFF8250D7687F30127C653FE5A
	7AFC7443B2C82F834A1E15ECAE812A813ABC0B565855DB4A25E176526A1D2EBA18D85AF5CBBD5E76DC1D546655D9642BCEB76E6105C1BA86A89E688920A4206C5B217C5BA95FB816AFD73B3701F7AD6A34BB92F87F816FE870FCEBBBDD86FEC23DACAEEF9F5C3F054D9AFA4D02F644686C8ADDFFDB5CC6E5536FE50CFEDBB05CDAE63396F3745BG23BCBC2647F7864EF16E4521D7634DD583F9EB373230E06FEF967A5FBF596EFF376D703F7F62F57FFB96B6A5ED8F6681764E63E262163760F9CE3EE2F87B60B3
	E8D6271B2E40243EDEEE957EFA58709CEBA8627D52CFB328DF3C6F1F2225681B4F053CB7D12155F703763424AE5EE0967667946147C7GEFBED082508A20F5C05933A95E9359D9866E9043879DD7D539390D5DC221AF434B93FE98A710DC7721E20C75E250D3A5F4ED4B7FF3A89F81E8F1BBE1F62476F0145D46527C74C64F587A132DD703659AE77B6357B5FBF0AC73FE638C7BFDC3786C60F3428B8C0F1C9DFCCE38F20066BAB14013E228AD7E3A8D634EAA522BD89A4FF835F5D95BD0EBFD149B4DB79B7BE042
	10E5FC1B3D8433087D740250EB696C826335741682633D32420221FFBFD3DC907A77B3FB8B743F1F616D75AE7CA921568F4C7B88E503EE13535AB4436C67E99785C86EF4AAAE1802EFC8F3DEA57B6DDB502DE5CD6E299DCCE7404DG52F975887FDD0CB855A79BF761B7309B5F221DFA7660F85E8F71908D3488A891E8E58C352B23EFE8772E8C5A67C9EB2BC2739C6163225075D5D4B47CEF16CB0B706ED913D385BF20FE424B0AB066D4270B019CBBDC04756C36353629BC2B06FFD0047D03DDE9E1B0475EAFB6
	6B6B1EF781DA7E0F0B518778BBA71BEC377532C554D94868E865E36BC1B6BF1166A41B8B6608BD3E815A8B2C18C3ED2E8117FBDA5B10F56F3F9D387E7B5626917FF6F0AC946A77D65A9D43BD216B7C06BD43577924BD6C8EA254D5FD0FCB2B2F48BD6CCC2125452308581A3EA7D7E027BC96274706B545ED2B390A792119B83D101F6F87DE38CAEB49C628A395A886A88E8877DD936630FB9B8305C3FCB76F03EF3CAA7EEF47DC18E74F2575666317308D0939ADDEFA292C7C54ED3356E9E6E8E7BA0FDD25F9FA58
	DC1A5F3E4CF446C3BA91E855DCDAAFDDE92771F7673DD3A5DC8305DA17C8F7E8732EBB7C6BA5DD5FBCE8FC9AD99C4D9C23DC6228657838574146B76B9D4163E19743DDF7840F072F0A3A68875E0ABBE8FE1DD70275D8938B73E920F0209820B82004D86A4B763F097B0C216688E71CCE3695013B92328D7AF9563539E55CF8625F6899104477766B5E533F07767D46F5AD037BE7C7C968F63C3BE478F63C3F44386FAEAF995CF79FADB16E3BBFAC51775D5A7FC1AA080567429724F4D55A44FB1FE26CFED4A94BE2
	EBED6DB9A1BB5AD5A91F0F2F45DFA85D45B40E2A12D9C33551D31552F078D325DCEDD455E54DA1C864B55370DA5C01632BAAED46B135D8AE6643EA20B53C7D6E3B26DF57AF3B499BF2DDFFE49EEF373573026F361D5D06BE8887BCF69E456EDDDB8F060ADD98094FF648F63BAA5B5B0FBB2C389EB85123AA7EF9CD43B6546F21BC9A1373AEEDC33B2F68E47E9FD0CB8788876C2D8D8B97GG58CAGGD0CB818294G94G88G88G8FDA55AA876C2D8D8B97GG58CAGG8CGGGGGGGGGGGGGG
	GGGE2F5E9ECE4E5F2A0E4E1F4E1D0CB8586GGGG81G81GBAGGGC597GGGG
**end of data**/
}
/**
 * Return the JCashCheque property value.
 * @return javax.swing.JMenuItem
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JMenuItem getJCashCheque() {
    if (ivjJCashCheque == null) {
        try {
            ivjJCashCheque = new javax.swing.JMenuItem();
            ivjJCashCheque.setName("JCashCheque");
            ivjJCashCheque.setText("Cash a Cheque");
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JCashCheck Menu item");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJCashCheque()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJCashCheque;
}
/**
 * Return the JClientMenu property value.
 * @return javax.swing.JMenu
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JMenu getJClientMenu() {
    if (ivjJClientMenu == null) {
        try {
            ivjJClientMenu = new javax.swing.JMenu();
            ivjJClientMenu.setName("JClientMenu");
            ivjJClientMenu.setText("Client Menu");
            ivjJClientMenu.add(getJCreateCustomer());
            ivjJClientMenu.add(getJCreateAccount());
            ivjJClientMenu.add(getJDisplayCustomer());
            ivjJClientMenu.add(getJDisplayAccount());
            ivjJClientMenu.add(getJTransferMoney());
            ivjJClientMenu.add(getJCashCheque());
            ivjJClientMenu.add(getJExit());
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JClientMenu");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJClientMenu()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJClientMenu;
}
/**
 * Return the JCreateAccount property value.
 * @return javax.swing.JMenuItem
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JMenuItem getJCreateAccount() {
    if (ivjJCreateAccount == null) {
        try {
            ivjJCreateAccount = new javax.swing.JMenuItem();
            ivjJCreateAccount.setName("JCreateAccount");
            ivjJCreateAccount.setText("Create Account");
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JCreateAccount Menu item");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in JCreateAccount()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJCreateAccount;
}
/**
 * Return the JCreateCustomer property value.
 * @return javax.swing.JMenuItem
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JMenuItem getJCreateCustomer() {
    if (ivjJCreateCustomer == null) {
        try {
            ivjJCreateCustomer = new javax.swing.JMenuItem();
            ivjJCreateCustomer.setName("JCreateCustomer");
            ivjJCreateCustomer.setText("Create New Customer");
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JCreateCustomer Menu item");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJCreateCustomer()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJCreateCustomer;
}
/**
 * Return the JDisplayAccount property value.
 * @return javax.swing.JMenuItem
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JMenuItem getJDisplayAccount() {
    if (ivjJDisplayAccount == null) {
        try {
            ivjJDisplayAccount = new javax.swing.JMenuItem();
            ivjJDisplayAccount.setName("JDisplayAccount");
            ivjJDisplayAccount.setText("Display Account");
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JDisplayAccount Menu item");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJDisplayAccount()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJDisplayAccount;
}
/**
 * Return the JDisplayCustomer property value.
 * @return javax.swing.JMenuItem
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JMenuItem getJDisplayCustomer() {
    if (ivjJDisplayCustomer == null) {
        try {
            ivjJDisplayCustomer = new javax.swing.JMenuItem();
            ivjJDisplayCustomer.setName("JDisplayCustomer");
            ivjJDisplayCustomer.setText("Display Customer");
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JDisplayCustomer Menu item");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJDisplayCustomer()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJDisplayCustomer;
}
/**
 * Return the JExit property value.
 * @return javax.swing.JMenuItem
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JMenuItem getJExit() {
    if (ivjJExit == null) {
        try {
            ivjJExit = new javax.swing.JMenuItem();
            ivjJExit.setName("JExit");
            ivjJExit.setText("Exit");
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JExit Menu Item");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJExit()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJExit;
}
/**
 * Return the JFrameContentPane property value.
 * @return javax.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JPanel getJFrameContentPane() {
    if (ivjJFrameContentPane == null) {
        try {
            ivjJFrameContentPane = new javax.swing.JPanel();
            ivjJFrameContentPane.setName("JFrameContentPane");
            ivjJFrameContentPane.setLayout(new java.awt.GridLayout());
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JFrameContentPane");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJFrameContentPane()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJFrameContentPane;
}
/**
 * Return the JTransferMoney property value.
 * @return javax.swing.JMenuItem
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JMenuItem getJTransferMoney() {
    if (ivjJTransferMoney == null) {
        try {
            ivjJTransferMoney = new javax.swing.JMenuItem();
            ivjJTransferMoney.setName("JTransferMoney");
            ivjJTransferMoney.setText("Transfer money");
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JTransferMoney menu item");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJTransferMoney()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJTransferMoney;
}
/**
 * Return the SwingInterfaceJMenuBar property value.
 * @return javax.swing.JMenuBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JMenuBar getSwingInterfaceJMenuBar() {
    if (ivjSwingInterfaceJMenuBar == null) {
        try {
            ivjSwingInterfaceJMenuBar = new javax.swing.JMenuBar();
            ivjSwingInterfaceJMenuBar.setName("SwingInterfaceJMenuBar");
            ivjSwingInterfaceJMenuBar.add(getJClientMenu());
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JMenuBar");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error(
                "Exception caught in getSwingInterfaceJMenuBar()",
                (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjSwingInterfaceJMenuBar;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {
    LOG.error("Exception", (Exception) exception);
}
/**
 * Initializes connections
 * @exception java.lang.Exception The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() throws java.lang.Exception {
	// user code begin {1}
	if (LOG.isDebugEnabled()) {
		LOG.debug("Initalizing connections for the SwingInterface");
	}
	// user code end
	getJCreateCustomer().addActionListener(ivjEventHandler);
	getJCreateAccount().addActionListener(ivjEventHandler);
	getJExit().addActionListener(ivjEventHandler);
	getJDisplayCustomer().addActionListener(ivjEventHandler);
	getJDisplayAccount().addActionListener(ivjEventHandler);
	getJTransferMoney().addActionListener(ivjEventHandler);
	getJCashCheque().addActionListener(ivjEventHandler);
	this.addWindowListener(ivjEventHandler);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		if (LOG.isDebugEnabled()) {
			LOG.debug("Loading the SwingInterface");
		}
		// user code end
		setName("SwingInterface");
		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		setJMenuBar(getSwingInterfaceJMenuBar());
		setSize(424, 332);
		setVisible(true);
		setTitle("PiggyBank");
		setContentPane(getJFrameContentPane());
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
}
