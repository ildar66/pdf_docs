package itso.was4ad.exception;

/**
 * Exception that indicates that in invalid operation was attempted
 */
public class InvalidOperation extends BusinessException {
/**
 * NonExistentAccount constructor comment.
 */
public InvalidOperation() {
	super();
}
/**
 * NonExistentAccount constructor comment.
 * @param level int
 * @param message java.lang.String
 */
public InvalidOperation(int level, String message) {
	super(level, message);
}
/**
 * NonExistentAccount constructor comment.
 * @param s java.lang.String
 */
public InvalidOperation(String s) {
	super(s);
}
}
