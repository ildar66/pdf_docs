package itso.was4ad.client.swing;

/**
 * GUI panel to display an account
 */
public class JDisplayAccount extends javax.swing.JPanel {
	private static final itso.was4ad.helpers.LogHelper LOG =
		new  itso.was4ad.helpers.LogHelper(JDisplayAccount.class);
	private javax.swing.JLabel ivjJDisplayAccLabel = null;
	IvjEventHandler ivjEventHandler = new IvjEventHandler();
	private javax.swing.JTextField ivjJDisplayAccTextField = null;
	private javax.swing.JButton ivjJDisplayAccButton = null;

class IvjEventHandler implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			if (e.getSource() == JDisplayAccount.this.getJDisplayAccButton()) 
				connEtoC1(e);
		};
	};
/**
 * JNewCustomer constructor comment.
 */
public JDisplayAccount() {
	super();
	initialize();
}
/**
 * connEtoC1:  (JDisplayCusButton.action.actionPerformed(java.awt.event.ActionEvent) --> JDisplayCustomer.createCustomer(Ljava.awt.event.ActionEvent;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.displayAccount(getJDisplayAccTextField().getText());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * This method gives the control to the ClientManager class
 * that is in charge of performing the operations
 */
public void displayAccount(String accountID) {
	if (LOG.isDebugEnabled()) {
		LOG.debug("Getting account data");
	}
	ClientManager mgr = new ClientManager();
	String code = mgr.displayAccount(accountID);
	showDialog(code);
	return;
}
/**
 * Return the JDisplayCusButton property value.
 * @return javax.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JButton getJDisplayAccButton() {
    if (ivjJDisplayAccButton == null) {
        try {
            ivjJDisplayAccButton = new javax.swing.JButton();
            ivjJDisplayAccButton.setName("JDisplayAccButton");
            ivjJDisplayAccButton.setFont(new java.awt.Font("Arial", 1, 14));
            ivjJDisplayAccButton.setText("Display Account");
            ivjJDisplayAccButton.setBounds(21, 149, 145, 25);
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JDisplayAccButton");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJDisplayAccButton()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJDisplayAccButton;
}
/**
 * Return the JDisplayCusLabel property value.
 * @return javax.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JLabel getJDisplayAccLabel() {
    if (ivjJDisplayAccLabel == null) {
        try {
            ivjJDisplayAccLabel = new javax.swing.JLabel();
            ivjJDisplayAccLabel.setName("JDisplayAccLabel");
            ivjJDisplayAccLabel.setFont(new java.awt.Font("Arial", 1, 14));
            ivjJDisplayAccLabel.setText("Account ID");
            ivjJDisplayAccLabel.setBounds(19, 25, 132, 14);
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JDisplayAccLabel");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJDisplayAccLabel()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJDisplayAccLabel;
}
/**
 * Return the JDisplayCusTextField property value.
 * @return javax.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JTextField getJDisplayAccTextField() {
    if (ivjJDisplayAccTextField == null) {
        try {
            ivjJDisplayAccTextField = new javax.swing.JTextField();
            ivjJDisplayAccTextField.setName("JDisplayAccTextField");
            ivjJDisplayAccTextField.setFont(new java.awt.Font("dialog", 0, 14));
            ivjJDisplayAccTextField.setBounds(17, 45, 191, 20);
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JDisplayAccTextField");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJDisplayAccTextField()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJDisplayAccTextField;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {
    LOG.error("Exception in JDisplayAccount", (Exception) exception);
}
/**
 * Initializes connections
 * @exception java.lang.Exception The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() throws java.lang.Exception {
	// user code begin {1}
	if (LOG.isDebugEnabled()) {
		LOG.debug("Initializing connections for JDisplayAccount");
	}
	// user code end
	getJDisplayAccButton().addActionListener(ivjEventHandler);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		if (LOG.isDebugEnabled()) {
			LOG.debug("Loading JDisplayAccount panel");
		}
		// user code end
		setName("JNewCustomer");
		setLayout(null);
		setSize(234, 218);
		add(getJDisplayAccLabel(), getJDisplayAccLabel().getName());
		add(getJDisplayAccTextField(), getJDisplayAccTextField().getName());
		add(getJDisplayAccButton(), getJDisplayAccButton().getName());
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		JDisplayAccount aJDisplayAccount;
		aJDisplayAccount = new JDisplayAccount();
		frame.setContentPane(aJDisplayAccount);
		frame.setSize(aJDisplayAccount.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.show();
		java.awt.Insets insets = frame.getInsets();
		frame.setSize(frame.getWidth() + insets.left + insets.right, frame.getHeight() + insets.top + insets.bottom);
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
/**
 * Shows a confirmation dialog with possible errors
 * Creation date: (6/20/01 5:39:56 PM)
 * @param code java.lang.String
 */
public void showDialog(String code) {
	if (LOG.isDebugEnabled()) {
		LOG.debug("Loading confirmation dialog for Display Account");
	}
	ConfirmationDialog dialog = new ConfirmationDialog(code);
}
}
