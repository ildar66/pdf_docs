package itso.was4ad.ejb.customer;

public class CustomerKey implements java.io.Serializable {
	public int id;
	private final static long serialVersionUID = 3206093459760846163L;

/**
 * Default constructor
 */
public CustomerKey() {
	super();
}
/**
 * Initialize a key from the passed values
 * @param argId int
 */
public CustomerKey(int argId) {
	id = argId;
}
/**
 * equals method
 * @return boolean
 * @param o java.lang.Object
 */
public boolean equals(Object o) {
	if (o instanceof CustomerKey) {
		CustomerKey otherKey = (CustomerKey) o;
		return (((this.id == otherKey.id)));
	}
	else
		return false;
}
/**
 * hashCode method
 * @return int
 */
public int hashCode() {
	return ((new java.lang.Integer(id).hashCode()));
}
/**
 * Return a string representation of the key
 * @return java.lang.String
 */
public String toString() {
	return "[CustomerKey id=" + id + "]";
}
}
