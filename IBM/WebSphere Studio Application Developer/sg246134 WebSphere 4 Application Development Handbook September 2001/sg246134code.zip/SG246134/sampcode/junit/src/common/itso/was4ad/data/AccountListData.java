package itso.was4ad.data;

/**
 * Data object representing a list of accounts
 */
public class AccountListData extends DataBean implements java.io.Serializable {
	private AccountData[] accounts = null;
	private final static long serialVersionUID = -7352595703561453108L;
/**
 * Default constructor
 */
public AccountListData() {
    this(new AccountData[0]);
}
/**
 * Constructor
 */
public AccountListData(AccountData[] accounts) {
	super();
    this.accounts = accounts;
}
/**
 * Get the list of accounts
 * @return itso.was4ad.data.AccountData[]
 */
public itso.was4ad.data.AccountData[] getAccounts() {
	return accounts;
}
}
