package itso.was4ad.webapp.command;

import itso.was4ad.webapp.controller.*;
import itso.was4ad.usecase.*;
import itso.was4ad.data.*;
import itso.was4ad.webapp.view.*;
import javax.servlet.http.*;

/**
 * Web channel login command
 */
public class LoginCommand implements Command {
	private static final itso.was4ad.helpers.LogHelper LOG =
		new  itso.was4ad.helpers.LogHelper(LoginCommand.class);
    // Constants
    private static final String PARM_USER = "user";
    private static final String PARM_PASS = "pass";
/**
 * Default constructor
 */
public LoginCommand() {
	super();
}
/**
 * Executes the Web login command
 * @param request javax.servlet.http.HttpServletRequest
 * @param response javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 */
public String execute(
    HttpServletRequest request,
    HttpServletResponse response,
    HttpSession session)
    throws Exception {

    // Get the parameters from the request
    LOG.debug("Getting parameters from the request");
    String id = request.getParameter(PARM_USER);
    String pass = request.getParameter(PARM_PASS);
    String page = null;

    try {
        // Login if we get a valid ID
        LOG.debug("Locating user");
        DisplayCustomer useCase = new DisplayCustomer();
        useCase.setCustomerId(Integer.parseInt(id));
        CustomerData data = (CustomerData) useCase.execute();

        // Create a new session if needed
        if (session == null) {
            LOG.debug("Creating HTTP session");
            session = request.getSession();
        }

        // Save the user information in the session
        LOG.debug("Storing customer data in session");
        session.setAttribute(CommandConstants.ATTR_CUSTOMER, new CustomerView(data));

        // We logged in successfully
        LOG.info("Customer " + data.getId() + " logged in succesfully");
        page = CommandConstants.PAGE_WELCOME;
    } catch (itso.was4ad.exception.NonExistentCustomer e) {
        LOG.warn("Unsuccessful login attempt for customer ID " + id);
        page = CommandConstants.PAGE_LOGIN_FAIL;
    }

    // Forward to the appropriate page
    return page;
}
}
