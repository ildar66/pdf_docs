package itso.was4ad.exception;

/**
 * Thrown if an operation is unauthorized
 */
public class UnauthorizedOperation extends BusinessException {
/**
 * UnauthorizedOperation constructor comment.
 */
public UnauthorizedOperation() {
	super();
}
/**
 * UnauthorizedOperation constructor comment.
 * @param level int
 * @param message java.lang.String
 */
public UnauthorizedOperation(int level, String message) {
	super(level, message);
}
/**
 * UnauthorizedOperation constructor comment.
 * @param s java.lang.String
 */
public UnauthorizedOperation(String s) {
	super(s);
}
}
