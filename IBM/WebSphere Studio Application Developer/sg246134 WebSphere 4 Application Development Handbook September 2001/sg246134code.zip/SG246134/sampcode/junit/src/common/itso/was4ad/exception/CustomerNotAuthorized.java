package itso.was4ad.exception;

/**
 * Exception indicating that a customer is not authorized
 * to perform the requested operation
 */
public class CustomerNotAuthorized extends BusinessException {
/**
 * CustomerNotAuthorized constructor
 */
public CustomerNotAuthorized() {
	super();
}
/**
 * CustomerNotAuthorized constructor
 * @param level int
 * @param message java.lang.String
 */
public CustomerNotAuthorized(int level, String message) {
	super(level, message);
}
/**
 * CustomerNotAuthorized constructor
 * @param s java.lang.String
 */
public CustomerNotAuthorized(String s) {
	super(s);
}
}
