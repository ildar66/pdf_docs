package itso.was4ad.webapp.controller;

import java.io.Serializable;
/**
 * Contains information about an application specific error message
 *
 */
public class Error implements Serializable {
    private String message = "No message available";
    private String source = "Unknown source";

    // Constants
    public static final String ATTR_ERROR = "error";
/**
 * Default constructor
 */
public Error() {
	super();
}
/**
 * Error constructor
 * @param java.lang.String source Source of the error
 * @param java.lang.String message Error message
 */
public Error(String source, String message) {
	super();
	// Initialize fields
	this.source = source;
	this.message = message;
}
/**
 * Get the message for this error
 * @return java.lang.String
 */
public java.lang.String getMessage() {
	return message;
}
/**
 * Get the component that is the source of this error
 * @return java.lang.String
 */
public java.lang.String getSource() {
	return source;
}
}
