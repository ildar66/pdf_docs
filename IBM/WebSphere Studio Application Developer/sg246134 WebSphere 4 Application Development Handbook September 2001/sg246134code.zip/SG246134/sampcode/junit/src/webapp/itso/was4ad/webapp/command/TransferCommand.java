package itso.was4ad.webapp.command;

import itso.was4ad.webapp.controller.*;
import itso.was4ad.webapp.view.*;
import itso.was4ad.usecase.*;
import itso.was4ad.data.*;
import itso.was4ad.exception.BusinessException;

/**
 * Web channel transfer command
 */
public class TransferCommand implements Command {
	private static final itso.was4ad.helpers.LogHelper LOG =
		new  itso.was4ad.helpers.LogHelper(TransferCommand.class);

	// Constants
	private static final String PARM_FROM_ACCT = "from";
	private static final String PARM_TO_ACCT = "to";
	private static final String PARM_AMOUNT = "amount";
/**
 * Default constructor
 */
public TransferCommand() {
	super();
}
/**
 * Execute the web transfer
 * @param request javax.servlet.http.HttpServletRequest
 * @param response javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 */
public String execute(
    javax.servlet.http.HttpServletRequest request,
    javax.servlet.http.HttpServletResponse response,
    javax.servlet.http.HttpSession session)
    throws Exception {

    LOG.debug("execute()");
    String page = null;
    int from = 0;
    int to = 0;
    int amount = 0;

    // Retrieve customer id from session context
    LOG.debug("Getting customer ID from session");
    CustomerView customer = (CustomerView) session.getAttribute(CommandConstants.ATTR_CUSTOMER);
    int customerId = Integer.parseInt(customer.getId());

    // Validate input
    try {
        // Get values from request
        from = Integer.parseInt(request.getParameter(PARM_FROM_ACCT));
        to = Integer.parseInt(request.getParameter(PARM_TO_ACCT));
        amount = Integer.parseInt(request.getParameter(PARM_AMOUNT));
    } catch (Exception e) {
        // Bad or missing values
        LOG.debug("Bad or missing values - forward to transfer page");

        // Get the list of valid accounts for this customer
        LOG.debug("Getting account list");
        DisplayCustomerAccounts useCase = new DisplayCustomerAccounts();
        useCase.setCustomerId(customerId);
        AccountData[] accounts = ((AccountListData) useCase.execute()).getAccounts();

        // Put list of valid accounts in request and forward
        request.setAttribute(CommandConstants.ATTR_ACCOUNT_LIST, new AccountListView(accounts));
        page = CommandConstants.PAGE_TRANSFER;
    }

    if (page == null) {
        // Input validated - invoke the use case
        LOG.debug("Invoking use case");
        Transfer transfer = new Transfer();
        transfer.setCustomerId(customerId);
        transfer.setDebitAccountNumber(from);
        transfer.setCreditAccountNumber(to);
        transfer.setAmount(amount);
        AccountListData newData = (AccountListData) transfer.execute();

        // Store the new balances in the request and forward to result page
        LOG.debug("String new account details in request");
        request.setAttribute(CommandConstants.ATTR_ACCOUNT_LIST, new AccountListView(newData));
        page = CommandConstants.PAGE_TRANSFER_RESULT;
    }

    // Forward to appropriate page
    if (LOG.isDebugEnabled()) {
        LOG.debug("Forwarding to " + page);
    }
    return page;
}
}
