package itso.was4ad.ejb.account;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface Account extends javax.ejb.EJBObject {

/**
 * Credit an account
 * @return itso.was4ad.data.AccountData
 * @param amount int The amount to credit
 * @exception java.rmi.RemoteException A remote exception
 */
itso.was4ad.data.AccountData credit(int amount) throws java.rmi.RemoteException, itso.was4ad.exception.InvalidOperation;
/**
 * Debit an account
 * @return itso.was4ad.data.AccountData
 * @param amount int The amount to debit
 * @exception java.rmi.RemoteException A remote exception
 */
itso.was4ad.data.AccountData debit(int amount) throws java.rmi.RemoteException, itso.was4ad.exception.InsufficientFunds, itso.was4ad.exception.InvalidOperation;
/**
 * Return a data only object containing a snapshot of the account information
 * @return itso.was4ad.bo.Account The account information
 * @exception java.rmi.RemoteException A remote exception.
 */
itso.was4ad.data.AccountData getAccountData() throws java.rmi.RemoteException;
/**
 * Returns true if the account is owned by the specified customer
 * @return boolean
 * @param customerID int The customer ID
 * @exception java.rmi.RemoteException A remote exception
 */
boolean isOwnedBy(int customerID) throws java.rmi.RemoteException;
}
