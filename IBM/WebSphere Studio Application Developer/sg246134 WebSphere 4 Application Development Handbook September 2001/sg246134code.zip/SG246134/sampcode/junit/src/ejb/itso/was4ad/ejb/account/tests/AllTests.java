package itso.was4ad.ejb.account.tests;

import junit.framework.*;
/**
 * Run all of the tests in this package
 */
public class AllTests extends TestCase {
/**
 * AllTests constructor
 * @param name java.lang.String
 */
public AllTests(String name) {
	super(name);
}
/**
 * Run this test suite
 * @param args java.lang.String[]
 */
public static void main(String[] args) {
	junit.textui.TestRunner.run(suite());
}
/**
 * Returns a test suite containing all tests in this package
 * @return junit.framework.Test
 */
public static Test suite() {
	TestSuite suite = new TestSuite("All Account EJB Tests");

	// Add any new tests here
	suite.addTestSuite(AccountTests.class);

	// Return the test suite
	return suite;
}
}
