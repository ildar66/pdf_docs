package itso.was4ad.ejb.customer;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface CustomerManager extends javax.ejb.EJBObject {

/**
 * Create a new customer
 * @return itso.was4ad.data.CustomerData
 * @param name java.lang.String
 * @exception java.rmi.RemoteException
 */
itso.was4ad.data.CustomerData createCustomer(java.lang.String name) throws java.rmi.RemoteException;
/**
 * Delete a customer
 * @return void
 * @param id int
 * @exception itso.was4ad.exception.NonExistentCustomer
 * @exception java.rmi.RemoteException
 * @exception itso.was4ad.exception.InvalidOperation
 */
void deleteCustomer(int id) throws itso.was4ad.exception.NonExistentCustomer, java.rmi.RemoteException, itso.was4ad.exception.InvalidOperation;
/**
 * Get the accounts for a customer
 * @return itso.was4ad.data.AccountListData
 * @param id int
 * @exception itso.was4ad.exception.NonExistentCustomer
 * @exception java.rmi.RemoteException
 */
itso.was4ad.data.AccountListData getCustomerAccounts(int id) throws itso.was4ad.exception.NonExistentCustomer, java.rmi.RemoteException;
/**
 * Get a data object representing a customer
 * @return itso.was4ad.data.CustomerData
 * @param id int
 * @exception itso.was4ad.exception.NonExistentCustomer
 * @exception java.rmi.RemoteException
 */
itso.was4ad.data.CustomerData getCustomerData(int id) throws itso.was4ad.exception.NonExistentCustomer, java.rmi.RemoteException;
/**
 * Get a data object representing a customer and the customer's accounts
 * @return itso.was4ad.data.CustomerFullData
 * @param id int
 * @exception itso.was4ad.exception.NonExistentCustomer
 * @exception java.rmi.RemoteException
 */
itso.was4ad.data.CustomerFullData getCustomerFullData(int id) throws itso.was4ad.exception.NonExistentCustomer, java.rmi.RemoteException;
}
