package itso.was4ad.usecase;

import itso.was4ad.data.*;

/**
 * Open an account in the PiggyBank.
 */
public class OpenAccount extends UseCase {
	private boolean checking = false;
	private String name = null;
	private int customerId = 0;
/**
 * OpenAccount constructor
 */
public OpenAccount() {
	super();
}
/**
 * Execute the open account use case
 */
public DataBean execute() throws Exception {
	return getAccountManager().createAccount(customerId, checking);
}
/**
 * Specify whether the new account is a checking account
 * @param newChecking boolean
 */
public void setChecking(boolean newChecking) {
	checking = newChecking;
}
/**
 * Specify the customer number opening the new account
 * @param newCustomerId int
 */
public void setCustomerId(int newCustomerId) {
	customerId = newCustomerId;
}
}
