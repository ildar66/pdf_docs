package itso.was4ad.usecase;

import itso.was4ad.data.*;

/**
<PRE>
Display account : displays a PiggyBank account

Input :
- account id

Basic path :
1. The customer enters the required input information and submits the request.
2. The system displays the customer his accounts 
      (including number, balance, checking flag).
</PRE>
*/
public class DisplayAccount extends UseCase {
	private static final itso.was4ad.helpers.LogHelper LOG =
		new  itso.was4ad.helpers.LogHelper(DisplayAccount.class);
    private int accountId = 0;
/**
 * Constructor
 */
public DisplayAccount() {
    super();
}
/**
 * Executes the display accounts use case
 */
public DataBean execute() throws Exception {
    LOG.debug("execute()");
    return getAccountManager().getAccountData(accountId);
}
/**
 * Set the number of the account to display
 * @param newAccountId int
 */
public void setAccountId(int newAccountId) {
	accountId = newAccountId;
}
}
