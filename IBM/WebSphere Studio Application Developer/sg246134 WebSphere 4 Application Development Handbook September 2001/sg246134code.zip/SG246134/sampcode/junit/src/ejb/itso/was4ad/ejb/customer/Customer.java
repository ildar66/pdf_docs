package itso.was4ad.ejb.customer;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface Customer extends javax.ejb.EJBObject {

/**
 * Returns a data only object representing the customer information
 * @return itso.was4ad.data.CustomerData The customer data
 * @exception java.rmi.RemoteException
 */
itso.was4ad.data.CustomerData getCustomerData() throws java.rmi.RemoteException;
}
