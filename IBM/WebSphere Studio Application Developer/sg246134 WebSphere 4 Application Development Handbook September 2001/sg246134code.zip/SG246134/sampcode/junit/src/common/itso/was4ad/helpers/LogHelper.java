package itso.was4ad.helpers;

import com.ibm.ras.*;

/**
 * This class provides a log and trace facility to the PiggyBank
 * application. It is implemented as a wrapper around the
 * WebSphere JRas facility, to enable the underlying logging
 * framework to be changed without rewriting application code.
 */
public class LogHelper {
	// Instance variables
	private RASMessageLogger ml = null;
	private RASTraceLogger tl = null;
	private String className = null;
	private String packageName = null;

	// Statics
	private static boolean initialized = false;
	private static com.ibm.websphere.ras.Manager manager = null;

	// Constants
	private static final String ORGANIZATION = "PiggyBank Corporation";
	private static final String PRODUCT = "PiggyBank Application";
	private static final String DEFAULT_PACKAGE = "Default package";

	/**
	 * Creates a new LogHelper instance for a component
	 */
	public LogHelper(Class component) {
		super();

		// Initialize JRas if necessary
		if (!initialized) {
			init();
		}

		// Set up the loggers for this component
		className = component.getName();
		int index = className.lastIndexOf(".");
		if (index > 0) {
			packageName = className.substring(0, index);
		} else {
			packageName = DEFAULT_PACKAGE;
		}
		ml = manager.createRASMessageLogger(ORGANIZATION, PRODUCT, packageName, className);
		tl = manager.createRASTraceLogger(ORGANIZATION, PRODUCT, packageName, className);
	}

	/**
	 * Initialize the JRas logging system
	 */
	private static synchronized void init() {
		// Safeguard against race condition
		if (!initialized) {
			// Get a reference to the manager singleton
			manager = com.ibm.websphere.ras.Manager.getManager();

                        // We have now initialized the logging system successfully
			initialized = true;
		}
	}

	/**
	 * Returns the name of the method invoking the logger.
	 * This method is very expensive, so try not to call it
	 * unless absolutely necessary.
	 */
	private String getCallingMethod() {
		java.io.StringWriter sw = new java.io.StringWriter();
		java.io.PrintWriter pw = new java.io.PrintWriter(sw);
		new Throwable().printStackTrace(pw);
		String st = sw.toString();
		int start = st.indexOf(className) + className.length() + 1;
		int end = st.indexOf(")", start) + 1;
		return st.substring(start, end);
	}

	/**
	 * Logs a debug message
	 * @param o java.lang.Object The message to be written to the log
	 */
	public void debug(Object o) {
		if (isDebugEnabled()) {
			tl.trace(RASITraceEvent.TYPE_MISC_DATA, className, getCallingMethod(), o.toString());
		}
	}

	/**
	 * Logs a debug message including stack trace from an exception
	 * @param o java.lang.Object The message to be written to the log
	 * @param e java.lang.Exception The exception
	 */
	public void debug(Object o, Exception e) {
		if (isDebugEnabled()) {
			tl.trace(RASITraceEvent.TYPE_MISC_DATA, className, getCallingMethod(), o.toString());
			tl.exception(RASITraceEvent.TYPE_MISC_DATA, className, getCallingMethod(), e);
		}
	}

	/**
	 * Logs an error message
	 * @param o java.lang.Object The message to be written to the log
	 */
	public void error(Object o) {
		ml.textMessage(RASIMessageEvent.TYPE_ERR, className, getCallingMethod(), o.toString());
	}

	/**
	 * Logs an error message including stack trace from an exception
	 * @param o java.lang.Object The message to be written to the log
	 * @param e java.lang.Exception The exception
	 */
	public void error(Object o, Exception e) {
		ml.textMessage(RASIMessageEvent.TYPE_ERR, className, getCallingMethod(), o.toString());
		ml.exception(RASIMessageEvent.TYPE_ERR, className, getCallingMethod(), e);
	}

	/**
	 * Logs an informational message
	 * @param o java.lang.Object The message to be written to the log
	 */
	public void info(Object o) {
		if (isInfoEnabled()) {
			ml.textMessage(RASIMessageEvent.TYPE_INFO, className, getCallingMethod(), o.toString());
		}
	}

	/**
	 * Logs an informational message including stack trace from an exception
	 * @param o java.lang.Object The message to be written to the log
	 * @param e java.lang.Exception The exception
	 */
	public void info(Object o, Exception e) {
		if (isInfoEnabled()) {
			ml.textMessage(RASIMessageEvent.TYPE_INFO, className, getCallingMethod(), o.toString());
			ml.exception(RASIMessageEvent.TYPE_INFO, className, getCallingMethod(), e);
		}
	}

	/**
	 * Returns true if debug level logging is enabled for this component
	 * @return boolean
	 */
	public boolean isDebugEnabled() {
		return tl.isLoggable(RASITraceEvent.TYPE_MISC_DATA);
	}

	/**
	 * Returns true if info level logging is enabled for this component
	 * @return boolean
	 */
	public boolean isInfoEnabled() {
		return ml.isLoggable(RASIMessageEvent.TYPE_INFO);
	}

	/**
	 * Logs a warning message
	 * @param o java.lang.Object The message to be written to the log
	 */
	public void warn(Object o) {
		ml.textMessage(RASIMessageEvent.TYPE_WARN, className, getCallingMethod(), o.toString());
	}

	/**
	 * Logs a warning message including stack trace from an exception
	 * @param o java.lang.Object The message to be written to the log
	 * @param e java.lang.Exception The exception
	 */
	public void warn(Object o, Exception e) {
		ml.textMessage(RASIMessageEvent.TYPE_WARN, className, getCallingMethod(), o.toString());
		ml.exception(RASIMessageEvent.TYPE_WARN, className, getCallingMethod(), e);
	}

}
