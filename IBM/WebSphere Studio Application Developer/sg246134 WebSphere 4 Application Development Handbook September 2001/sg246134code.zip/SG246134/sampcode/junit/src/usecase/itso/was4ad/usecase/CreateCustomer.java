package itso.was4ad.usecase;

import itso.was4ad.data.*;

/**
 * Use case to create a customer
 */
public class CreateCustomer extends UseCase {
	private static final itso.was4ad.helpers.LogHelper LOG =
		new  itso.was4ad.helpers.LogHelper(CreateCustomer.class);
	private java.lang.String name = null;
/**
 * Insert the method's description here.
 * Creation date: (7/11/01 6:19:05 PM)
 * @exception java.lang.Exception The exception description.
 */
public DataBean execute() throws Exception {
    LOG.debug("execute()");
    CustomerData data = getCustomerManager().createCustomer(name);
    if (LOG.isDebugEnabled()) {
    	LOG.debug("New customer created: " + data);
    }
    return data;
}
/**
 * Set the name of the new customer
 * @param newName java.lang.String
 */
public void setName(java.lang.String newName) {
	name = newName;
}
}
