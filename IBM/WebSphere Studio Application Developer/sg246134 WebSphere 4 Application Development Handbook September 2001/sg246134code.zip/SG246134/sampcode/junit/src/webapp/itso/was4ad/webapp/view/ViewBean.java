package itso.was4ad.webapp.view;

import java.io.*;
/**
 * Superclass of all Web channel view beans
 */
public abstract class ViewBean implements Serializable {
/**
 * Default constructor
 */
public ViewBean() {
	super();
}
}
