package itso.was4ad.data;

/**
 * Data object representing an account
 */
public class AccountData extends DataBean implements java.io.Serializable {
    private int number = 0;
    private int customerID = 0;
    private int amount = 0;
    private boolean checking = false;
	private final static long serialVersionUID = -232436885352315222L;
/**
 * Default constructor
 */
public AccountData() {
	super();
}
/**
 * Constructor
 */
public AccountData(int customerID, int number, int amount, boolean checking) {
	super();
	// Populate fields from parameters
	this.customerID = customerID;
	this.number = number;
	this.amount = amount;
	this.checking = checking;
}
/**
 * Getter for the account balance
 * @return int
 */
public int getAmount() {
	return amount;
}
/**
 * Getter for the customer ID
 * @return int
 */
public int getCustomerID() {
	return customerID;
}
/**
 * Getter for the account number
 * @return int
 */
public int getNumber() {
	return number;
}
/**
 * Returns true if this is a checking account
 * @return boolean
 */
public boolean isChecking() {
	return checking;
}
/**
 * Return a string representation of the account
 * @return java.lang.String
 */
public String toString() {
	StringBuffer buf = new StringBuffer();
	buf.append("[Account Number=");
	buf.append(number);
	buf.append(", Customer ID=");
	buf.append(customerID);
	buf.append(", Amount=");
	buf.append(amount);
	buf.append(", Checking=");
	buf.append(checking);
	buf.append("]");
	return buf.toString();
}
}
