package itso.was4ad.client.swing;

/**
 * GUI panel to transfer money between a customer's accounts
 */
public class JTransferMoney extends javax.swing.JPanel {
	private static final itso.was4ad.helpers.LogHelper LOG =
		new  itso.was4ad.helpers.LogHelper(JTransferMoney.class);
	private javax.swing.JButton ivjJTransferButton = null;
	IvjEventHandler ivjEventHandler = new IvjEventHandler();
	private javax.swing.JLabel ivjJAmountLabel = null;
	private javax.swing.JLabel ivjJCreditLabel = null;
	private javax.swing.JLabel ivjJDebitLabel = null;
	private javax.swing.JTextField ivjJAmountTextField = null;
	private javax.swing.JTextField ivjJCreditTextField = null;
	private javax.swing.JTextField ivjJDebitTextField = null;

class IvjEventHandler implements java.awt.event.ActionListener {
		public void actionPerformed(java.awt.event.ActionEvent e) {
			if (e.getSource() == JTransferMoney.this.getJTransferButton()) 
				connEtoC1(e);
		};
	};
	private javax.swing.JLabel ivjJCustomerLabel = null;
	private javax.swing.JTextField ivjJCustomerTextField = null;
/**
 * JNewCustomer constructor comment.
 */
public JTransferMoney() {
	super();
	initialize();
}
/**
 * connEtoC1:  (JNewCusButton.action.actionPerformed(java.awt.event.ActionEvent) --> JNewCustomer.createCustomer(Ljava.awt.event.ActionEvent;)V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.transferMoney(getJCustomerTextField().getText(), getJDebitTextField().getText(), getJCreditTextField().getText(), getJAmountTextField().getText());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Return the JAmount property value.
 * @return javax.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JLabel getJAmountLabel() {
    if (ivjJAmountLabel == null) {
        try {
            ivjJAmountLabel = new javax.swing.JLabel();
            ivjJAmountLabel.setName("JAmountLabel");
            ivjJAmountLabel.setFont(new java.awt.Font("Arial", 1, 14));
            ivjJAmountLabel.setText("Amount");
            ivjJAmountLabel.setBounds(13, 135, 107, 14);
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JAmountLabel");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJAmountLabel()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJAmountLabel;
}
/**
 * Return the JTransferTextField11 property value.
 * @return javax.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JTextField getJAmountTextField() {
    if (ivjJAmountTextField == null) {
        try {
            ivjJAmountTextField = new javax.swing.JTextField();
            ivjJAmountTextField.setName("JAmountTextField");
            ivjJAmountTextField.setFont(new java.awt.Font("dialog", 0, 14));
            ivjJAmountTextField.setBounds(125, 132, 100, 20);
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JTransferTextField11");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJTransferTextField11()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJAmountTextField;
}
/**
 * Return the JCredit property value.
 * @return javax.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JLabel getJCreditLabel() {
    if (ivjJCreditLabel == null) {
        try {
            ivjJCreditLabel = new javax.swing.JLabel();
            ivjJCreditLabel.setName("JCreditLabel");
            ivjJCreditLabel.setFont(new java.awt.Font("Arial", 1, 14));
            ivjJCreditLabel.setText("Credit account");
            ivjJCreditLabel.setBounds(13, 103, 107, 14);
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JCreditLabel");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJCreditLabel()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJCreditLabel;
}
/**
 * Return the JTransferTextField1 property value.
 * @return javax.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JTextField getJCreditTextField() {
    if (ivjJCreditTextField == null) {
        try {
            ivjJCreditTextField = new javax.swing.JTextField();
            ivjJCreditTextField.setName("JCreditTextField");
            ivjJCreditTextField.setFont(new java.awt.Font("dialog", 0, 14));
            ivjJCreditTextField.setBounds(125, 99, 100, 20);
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JTransferTextField1");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJTransferTextField1()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJCreditTextField;
}
/**
 * Return the JCustomerLabel property value.
 * @return javax.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JLabel getJCustomerLabel() {
	if (ivjJCustomerLabel == null) {
		try {
			ivjJCustomerLabel = new javax.swing.JLabel();
			ivjJCustomerLabel.setName("JCustomerLabel");
			ivjJCustomerLabel.setFont(new java.awt.Font("Arial", 1, 14));
			ivjJCustomerLabel.setText("Customer ID");
			ivjJCustomerLabel.setBounds(13, 35, 108, 14);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJCustomerLabel;
}
/**
 * Return the JCustomerTextField property value.
 * @return javax.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JTextField getJCustomerTextField() {
	if (ivjJCustomerTextField == null) {
		try {
			ivjJCustomerTextField = new javax.swing.JTextField();
			ivjJCustomerTextField.setName("JCustomerTextField");
			ivjJCustomerTextField.setFont(new java.awt.Font("dialog", 0, 14));
			ivjJCustomerTextField.setBounds(125, 32, 100, 20);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJCustomerTextField;
}
/**
 * Return the JNewCusLabel property value.
 * @return javax.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JLabel getJDebitLabel() {
    if (ivjJDebitLabel == null) {
        try {
            ivjJDebitLabel = new javax.swing.JLabel();
            ivjJDebitLabel.setName("JDebitLabel");
            ivjJDebitLabel.setFont(new java.awt.Font("Arial", 1, 14));
            ivjJDebitLabel.setText("Debit account");
            ivjJDebitLabel.setBounds(13, 70, 108, 14);
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JDebitLabel");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJDebitLabel()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJDebitLabel;
}
/**
 * Return the JTransferTextField property value.
 * @return javax.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JTextField getJDebitTextField() {
    if (ivjJDebitTextField == null) {
        try {
            ivjJDebitTextField = new javax.swing.JTextField();
            ivjJDebitTextField.setName("JDebitTextField");
            ivjJDebitTextField.setFont(new java.awt.Font("dialog", 0, 14));
            ivjJDebitTextField.setBounds(125, 68, 100, 20);
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JTransferTextField");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJTransferTextField()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJDebitTextField;
}
/**
 * Return the JTransferButton property value.
 * @return javax.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JButton getJTransferButton() {
    if (ivjJTransferButton == null) {
        try {
            ivjJTransferButton = new javax.swing.JButton();
            ivjJTransferButton.setName("JTransferButton");
            ivjJTransferButton.setFont(new java.awt.Font("Arial", 1, 14));
            ivjJTransferButton.setText("Transfer Money");
            ivjJTransferButton.setBounds(19, 171, 145, 25);
            // user code begin {1}
            if (LOG.isDebugEnabled()) {
                LOG.debug("Loading JTransferButton");
            }
            // user code end
        } catch (java.lang.Throwable ivjExc) {
            // user code begin {2}
            LOG.error("Exception caught in getJTransferButton()", (Exception) ivjExc);
            // user code end
            handleException(ivjExc);
        }
    }
    return ivjJTransferButton;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {
    LOG.error("Exception in JTransferMoney", (Exception) exception);
}
/**
 * Initializes connections
 * @exception java.lang.Exception The exception description.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() throws java.lang.Exception {
	// user code begin {1}
	if (LOG.isDebugEnabled()) {
		LOG.debug("Initializing connections for JTransferMoney");
	}
	// user code end
	getJTransferButton().addActionListener(ivjEventHandler);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		if (LOG.isDebugEnabled()) {
			LOG.debug("Loading JTransferMoney panel");
		}
		// user code end
		setName("JDebit");
		setLayout(null);
		setSize(234, 218);
		add(getJDebitLabel(), getJDebitLabel().getName());
		add(getJDebitTextField(), getJDebitTextField().getName());
		add(getJTransferButton(), getJTransferButton().getName());
		add(getJCreditLabel(), getJCreditLabel().getName());
		add(getJCreditTextField(), getJCreditTextField().getName());
		add(getJAmountLabel(), getJAmountLabel().getName());
		add(getJAmountTextField(), getJAmountTextField().getName());
		add(getJCustomerTextField(), getJCustomerTextField().getName());
		add(getJCustomerLabel(), getJCustomerLabel().getName());
		initConnections();
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		javax.swing.JFrame frame = new javax.swing.JFrame();
		JTransferMoney aJTransferMoney;
		aJTransferMoney = new JTransferMoney();
		frame.setContentPane(aJTransferMoney);
		frame.setSize(aJTransferMoney.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.show();
		java.awt.Insets insets = frame.getInsets();
		frame.setSize(frame.getWidth() + insets.left + insets.right, frame.getHeight() + insets.top + insets.bottom);
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of javax.swing.JPanel");
		exception.printStackTrace(System.out);
	}
}
/**
 * Shows a confirmation dialog with possible errors
 * Creation date: (6/20/01 5:39:56 PM)
 * @param code java.lang.String
 */
public void showDialog(String code) {
	if (LOG.isDebugEnabled()) {
		LOG.debug("Loading confirmation dialog for Transfer Money");
	}
	ConfirmationDialog dialog = new ConfirmationDialog(code);
}
/**
 * This method gives the control to the ClientManager class
 * that is in charge of performing the operations
 */
public void transferMoney(String customerId, String debit, String credit, String amount) {
	if (LOG.isDebugEnabled()) {
		LOG.debug("Transferring money");
	}
	ClientManager mgr = new ClientManager();
	String code = mgr.transferMoney(customerId, debit, credit, amount);
	showDialog(code);
	return;
}
}
