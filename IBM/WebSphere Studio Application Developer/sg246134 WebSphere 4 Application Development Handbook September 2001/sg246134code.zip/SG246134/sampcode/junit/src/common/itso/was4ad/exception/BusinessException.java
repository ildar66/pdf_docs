package itso.was4ad.exception;

/**
 * A PiggyBank business exception
 */
public class BusinessException extends Exception {
	private int level;
	public final static int WARNING = 1;
	public final static int ERROR = 2;
/**
 * Default constructor
 */
public BusinessException() {
	super();
	this.setLevel(WARNING);
}
/**
 * Constructor
 * @param level int
 * @param description java.lang.String
 */
public BusinessException(int level, String message) {
    super(message);
    this.level = level;
}
/**
 * Constructor.
 * @param s java.lang.String
 */
public BusinessException(String s) {
	super(s);
	this.setLevel(ERROR);
}
/**
 * Gets the exception level
 * @return int
 */
public int getLevel() {
	return level;
}
/**
 * Sets the exception level
 * @param newLevel int
 */
public void setLevel(int newLevel) {
	level = newLevel;
}
}
