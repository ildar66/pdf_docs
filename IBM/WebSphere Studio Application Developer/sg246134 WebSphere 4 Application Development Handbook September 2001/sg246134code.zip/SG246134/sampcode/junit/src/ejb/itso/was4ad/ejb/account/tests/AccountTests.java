package itso.was4ad.ejb.account.tests;

import junit.framework.*;
import itso.was4ad.helpers.HomeHelper;
import itso.was4ad.ejb.account.*;
import itso.was4ad.data.*;
import itso.was4ad.exception.*;
import javax.naming.*;
import javax.ejb.*;
import javax.rmi.*;
import java.rmi.*;
import java.util.*;
/**
 * JUnit tests for the Account EJB
 */
public class AccountTests extends TestCase {
	private static final String ACCOUNT_HOME = "java:comp/env/ejb/Account";
/**
 * AccountTests constructor
 * @param name java.lang.String
 */
public AccountTests(String name) {
	super(name);
}
/**
 * Helper method that locates the Account EJB's home interface
 * @return itso.was4ad.ejb.account.AccountHome
 * @exception javax.naming.NamingException
 */
private static AccountHome getAccountHome() throws NamingException {
    InitialContext context = new InitialContext();
    return (AccountHome) PortableRemoteObject.narrow(context.lookup(ACCOUNT_HOME), AccountHome.class);
}
/**
 * Set up some data used by the tests
 */
public void setUp() throws NamingException, CreateException, RemoteException, InvalidOperation {
	// Get the home interface
	AccountHome home = getAccountHome();

	// Create some accounts and put money in some of them
	home.create(1000, 100, false);
	home.create(1001, 101, false).credit(1000);
	home.create(1002, 102, true).credit(10000);
	home.create(1003, 102, false).credit(2500);
	home.create(1004, 103, true).credit(10);
	
}
/**
 * Delete the data used by the tests. CAUTION This method
 * removes any account with a number in the range 1000 - 1009!
 */
public void tearDown() throws NamingException, RemoteException {
    // Get the home interface
    AccountHome home = getAccountHome();

    // Delete any accounts left lying around
    for (int i = 1000; i < 1010; i++) {
        try {
            // Look for the account
            AccountKey key = new AccountKey(i);
            Account acct = home.findByPrimaryKey(key);

            // Empty the account and remove it
            int balance = acct.getAccountData().getAmount();
            if (balance != 0) {
                acct.debit(balance);
            }
            acct.remove();
        } catch (Exception e) {
            //Ignore
        }
    }
}
/**
 * Test account creation
 */
public void testCreate() throws NamingException, CreateException, RemoteException {
	// Create an account
	Account account = getAccountHome().create(1005, 201, true);

	// Now get the data from the account and check it
	AccountData data = account.getAccountData();
	assertEquals("Account ID incorrect", 1005, data.getNumber());
	assertEquals("Customer ID incorrect", 201, data.getCustomerID());
	assertEquals("Type incorrect", true, data.isChecking());
}
/**
 * Test account credit
 */
public void testCredit() throws NamingException, FinderException, RemoteException, BusinessException {
    // Locate one of the previously set up accounts
    AccountKey key = new AccountKey(1004);
    Account account = getAccountHome().findByPrimaryKey(key);

    // Get the current balance
    int balance = account.getAccountData().getAmount();

    // Now credit the account and check again
    assertEquals("Account credit failed", balance + 1000, account.credit(1000).getAmount());
}
/**
 * Test account debit
 */
public void testDebit() throws NamingException, FinderException, RemoteException, BusinessException {
    // Locate one of the previously set up accounts
    AccountKey key = new AccountKey(1004);
    Account account = getAccountHome().findByPrimaryKey(key);

    // Get the balance
    int balance = account.getAccountData().getAmount();

    // Perform debit and check balance again
    assertEquals("Account debit incorrect", balance - 1, account.debit(1).getAmount());
}
/**
 * Test debit of more money than is in the account
 */
public void testDebitOverdraw() throws NamingException, FinderException, RemoteException, BusinessException {
    // Locate one of the previously set up accounts
    AccountKey key = new AccountKey(1004);
    Account account = getAccountHome().findByPrimaryKey(key);

    // Get the balance
    int balance = account.getAccountData().getAmount();

    // Attempt to debit more than we have
    try {
	    account.debit(balance + 1);
	    fail("Should throw InsufficientFunds");
    } catch (InsufficientFunds e) {
	    // expected
    }
    
    // Make sure the balance is the same
    assertEquals("Balance changed after InsufficientFunds", balance, account.getAccountData().getAmount());
}
/**
 * Test findByCustomerID
 */
public void testFindByCustomerID() throws NamingException, FinderException, RemoteException {
    // Locate two of the previously set up accounts
    Collection c = getAccountHome().findByCustomerID(102);

    // Make sure there are two accounts
    assertNotNull("Collection is null", c);
    assertEquals("Wrong number of accounts", 2, c.size());

    // Check we got the correct accounts
    Iterator iter = c.iterator();
    for (int id = 1002; id < 1004; id++) {
        Account account = (Account) PortableRemoteObject.narrow(iter.next(), Account.class);
        AccountData data = account.getAccountData();
        assertEquals("Got wrong account", id, data.getNumber());
    }
}
/**
 * Test account ownership check
 */
public void testIsOwnedBy() throws NamingException, FinderException, RemoteException, BusinessException {
    // Locate one of the previously set up accounts
    AccountKey key = new AccountKey(1004);
    Account account = getAccountHome().findByPrimaryKey(key);

	// Check that isOwnedBy functions correctly
	assertTrue("isOwnedBy incorrect", account.isOwnedBy(103));
	assertEquals("isOwnedBy incorrect", false, account.isOwnedBy(104));
}
/**
 * Test negative account credit
 */
public void testNegativeCredit() throws NamingException, FinderException, RemoteException, BusinessException {
    // Locate one of the previously set up accounts
    AccountKey key = new AccountKey(1004);
    Account account = getAccountHome().findByPrimaryKey(key);

    // Try a negative credit
    try {
        account.credit(-1000);
        fail("Shouldn't allow negative credit");
    } catch (InvalidOperation e) {
        // expected
    }
}
/**
 * Test negative account debit
 */
public void testNegativeDebit() throws NamingException, FinderException, RemoteException, BusinessException {
    // Locate one of the previously set up accounts
    AccountKey key = new AccountKey(1004);
    Account account = getAccountHome().findByPrimaryKey(key);

    // Try a negative debit
    try {
        account.debit(-1000);
        fail("Shouldn't allow negative debit");
    } catch (InvalidOperation e) {
        // expected
    }
}
/**
 * Test account removal
 */
public void testRemove() throws NamingException, FinderException, RemoveException, RemoteException {
    // Locate one of the previously set up accounts - this one
    // does not have a balance
    AccountKey key = new AccountKey(1000);
    Account account = getAccountHome().findByPrimaryKey(key);

    // Now remove the account
    account.remove();

    // Now if we look for it again we shouldn't find it
    try {
        account = getAccountHome().findByPrimaryKey(key);
        fail("Found removed account!");
    } catch (FinderException e) {
        // expected
    }
}
/**
 * Test account removal when there's a balance
 */
public void testRemoveWithBalance() throws NamingException, FinderException, RemoteException, BusinessException {
    // Locate one of the previously set up accounts -
    // this one does have a balance
    AccountKey key = new AccountKey(1001);
    Account account = getAccountHome().findByPrimaryKey(key);

    // Remove the account
    try {
        account.remove();
        fail("Shouldn't remove account with a balance");
    } catch (RemoveException e) {
        // expected
    }

    // Now if we look for it again it should still be there
    account = getAccountHome().findByPrimaryKey(key);
}
}
