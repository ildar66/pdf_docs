package itso.was4ad.exception;

/**
 * Thrown if a specified customer does not exist
 */
public class NonExistentCustomer extends BusinessException {
/**
 * NonExistentAccount constructor comment.
 */
public NonExistentCustomer() {
	super();
}
/**
 * NonExistentAccount constructor comment.
 * @param level int
 * @param message java.lang.String
 */
public NonExistentCustomer(int level, String message) {
	super(level, message);
}
/**
 * NonExistentAccount constructor comment.
 * @param s java.lang.String
 */
public NonExistentCustomer(String s) {
	super(s);
}
}
