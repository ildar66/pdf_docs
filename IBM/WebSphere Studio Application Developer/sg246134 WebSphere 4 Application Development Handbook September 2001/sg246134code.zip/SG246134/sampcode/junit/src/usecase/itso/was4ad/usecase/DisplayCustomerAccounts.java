package itso.was4ad.usecase;

import itso.was4ad.data.*;

/**
<PRE>
Display accounts : displays all PiggyBank accounts for a customer

Input :
- account id

Basic path :
1. The customer enters the required input information and submits the request.
2. The system displays the customer his accounts 
      (including number, balance, checking flag).
</PRE>
*/
public class DisplayCustomerAccounts extends UseCase {
	private static final itso.was4ad.helpers.LogHelper LOG =
		new  itso.was4ad.helpers.LogHelper(DisplayCustomerAccounts.class);
    private int customerId = 0;
/**
 * Constructor
 */
public DisplayCustomerAccounts() {
    super();
}
/**
 * Executes the display customer accounts use case
 */
public DataBean execute() throws Exception {
    LOG.debug("execute()");
    return getCustomerManager().getCustomerAccounts(customerId);
}
/**
 * Set the number of the customer whose account we are to display
 * @param newCustomerId int
 */
public void setCustomerId(int newCustomerId) {
	customerId = newCustomerId;
}
}
