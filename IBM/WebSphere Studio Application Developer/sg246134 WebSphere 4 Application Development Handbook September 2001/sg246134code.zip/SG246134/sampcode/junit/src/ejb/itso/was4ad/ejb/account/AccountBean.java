package itso.was4ad.ejb.account;

import java.rmi.RemoteException;
import java.util.Properties;
import javax.ejb.*;
import itso.was4ad.data.*;
import itso.was4ad.exception.*;
import itso.was4ad.helpers.LogHelper;
/**
 * This is an Entity Bean class with CMP fields
 */
public class AccountBean implements EntityBean {
	private static final LogHelper LOG = new LogHelper(AccountBean.class);
	public int balance;
	public boolean checking;
	public int customerID;
	private javax.ejb.EntityContext entityContext = null;
	public int number;
	private final static long serialVersionUID = 3206093459760846163L;
/**
 * Credits an account
 * @param amount int
 */
public AccountData credit(int amount) throws InvalidOperation {
	if (LOG.isDebugEnabled()) {
		LOG.debug("credit(" + amount + ")");
	}
    balance = balance + amount;
    if (LOG.isDebugEnabled()) {
        LOG.debug(
            "Account: " + number + " credited " + amount + ", new balance " + balance);
    }
    // Return a data object representing the new balance
    return getAccountData();
}
/**
 * Debits the account
 * @param amount int
 * @exception itso.was4ad.exception.InsufficientFunds
 */
public AccountData debit(int amount) throws InsufficientFunds, InvalidOperation {
	if (LOG.isDebugEnabled()) {
		LOG.debug("debit(" + amount + ")");
	}
    if (amount <= balance) {
        balance = balance - amount;
    } else {
	    LOG.debug("Insufficient funds available");
        throw new InsufficientFunds(
            InsufficientFunds.WARNING,
            "Debit: " + amount + " Funds available: " + balance);
    }
    if (LOG.isDebugEnabled()) {
        LOG.debug(
            "Account: " + number + " credited " + amount + ", new balance " + balance);
    }
	// Return a data object representing the new balance
	return getAccountData();
}
/**
 * ejbActivate method
 * @exception java.rmi.RemoteException A remote exception
 */
public void ejbActivate() throws java.rmi.RemoteException {
	LOG.debug("ejbActivate()");
}
/**
 * ejbCreate method for a CMP entity bean
 * @param argNumber int
 * @param argCustomerID int
 * @param argChecking boolean
 * @exception javax.ejb.CreateException
 */
public AccountKey ejbCreate(int argNumber, int argCustomerID, boolean argChecking) throws javax.ejb.CreateException {
	if (LOG.isDebugEnabled()) {
		LOG.debug("ejbCreate(" + argNumber + ", " + argCustomerID + ", " + argChecking + ")");
	}
	// Initialize CMP fields
	number = argNumber;
	customerID = argCustomerID;
	checking = argChecking;
	balance = 0;

	// Return null
	return null;
}
/**
 * ejbLoad method
 * @exception java.rmi.RemoteException
 */
public void ejbLoad() throws java.rmi.RemoteException {
	LOG.debug("ejbLoad()");
}
/**
 * ejbPassivate method
 * @exception java.rmi.RemoteException
 */
public void ejbPassivate() throws java.rmi.RemoteException {
    LOG.debug("ejbPassivate()");
}
/**
 * ejbPostCreate method for a CMP entity bean
 * @param argNumber int
 * @param argCustomerID int
 * @param argChecking boolean
 */
public void ejbPostCreate(int argNumber, int argCustomerID, boolean argChecking) throws javax.ejb.CreateException {
    LOG.debug("ejbPostCreate()");
}
/**
 * ejbRemove method
 * @exception javax.ejb.RemoveException
 */
public void ejbRemove() throws javax.ejb.RemoveException {
	LOG.debug("ejbRemove()");
	// Cannot remove an account with a balance
	if (balance != 0) {
		LOG.warn("Attempt to remove an account with a balance");
		throw new RemoveException("Cannot remove an account with a balance");
	}
}
/**
 * ejbStore method
 * @exception java.rmi.RemoteException
 */
public void ejbStore() throws java.rmi.RemoteException {
	LOG.debug("ejbStore()");
}
/**
 * Returns a data object that contains the account data
 * @return itso.was4ad.data.AccountData
 */
public AccountData getAccountData() {
	LOG.debug("getAccountData()");
	AccountData data = new AccountData(customerID, number, balance, checking);
	return data;
}
/**
 * getEntityContext
 * @return javax.ejb.EntityContext
 */
public javax.ejb.EntityContext getEntityContext() {
	LOG.debug("getEntityContext()");
	return entityContext;
}
/**
 * Returns true if the account is owned by the specified customer
 * @return boolean
 * @param customerID int
 */
public boolean isOwnedBy(int customerID) {
	if (LOG.isDebugEnabled()) {
		LOG.debug("isOwnedBy(" + customerID + ")");
	}
	return this.customerID == customerID;
}
/**
 * setEntityContext method
 * @param ctx javax.ejb.EntityContext
 * @exception java.rmi.RemoteException
 */
public void setEntityContext(javax.ejb.EntityContext ctx) throws java.rmi.RemoteException {
	LOG.debug("setEntityContext()");
	entityContext = ctx;
}
/**
 * unsetEntityContext method
 * @exception java.rmi.RemoteException
 */
public void unsetEntityContext() throws java.rmi.RemoteException {
	LOG.debug("unsetEntityContext()");
	entityContext = null;
}
}
