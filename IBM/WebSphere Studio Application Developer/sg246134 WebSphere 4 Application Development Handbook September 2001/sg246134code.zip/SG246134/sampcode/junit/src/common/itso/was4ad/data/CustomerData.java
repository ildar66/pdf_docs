package itso.was4ad.data;

/**
 * Data object representing a customer
 */
public class CustomerData extends DataBean implements java.io.Serializable {
    private int id = 0;
    private java.lang.String name = "";
	private final static long serialVersionUID = 6243678159598791600L;
/**
 * Default constructor
 */
public CustomerData() {
	super();
}
/**
 * Constructor
 */
public CustomerData(int id, String name) {
	super();
	// Populate fields from parameters
	this.id = id;
	this.name = name;
}
/**
 * Getter for customer ID
 * @return int
 */
public int getId() {
	return id;
}
/**
 * Getter for customer name
 * @return java.lang.String
 */
public java.lang.String getName() {
	return name;
}
/**
 * Return a string representation of the customer
 * @return java.lang.String
 */
public String toString() {
	StringBuffer buf = new StringBuffer();
	buf.append("[Customer ID=");
	buf.append(id);
	buf.append(", Name=");
	buf.append(name);
	buf.append("]");
	return buf.toString();
}
}
