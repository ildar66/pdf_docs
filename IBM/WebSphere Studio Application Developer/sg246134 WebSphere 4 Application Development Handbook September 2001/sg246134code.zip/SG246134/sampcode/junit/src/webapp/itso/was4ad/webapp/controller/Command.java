package itso.was4ad.webapp.controller;

import javax.servlet.http.*;
import javax.servlet.*;
/**
 * Interface implemented by all Web channel commands
 */
public interface Command {
/**
 * Invoked by the controller servlet to execute a command
 * @param request javax.servlet.http.HttpServletRequest
 * @param response javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 */
String execute(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception;
}
