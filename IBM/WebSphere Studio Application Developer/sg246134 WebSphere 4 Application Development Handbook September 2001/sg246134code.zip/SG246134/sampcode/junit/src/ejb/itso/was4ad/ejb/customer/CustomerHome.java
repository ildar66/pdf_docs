package itso.was4ad.ejb.customer;

/**
 * This is a Home interface for the Entity Bean
 */
public interface CustomerHome extends javax.ejb.EJBHome {
/**
 * Create a new customer
 * @return itso.was4ad.ejb.customer.Customer
 * @param argId int
 * @param argName java.lang.String
 * @exception javax.ejb.CreateException
 * @exception java.rmi.RemoteException
 */
itso.was4ad.ejb.customer.Customer create(int argId, java.lang.String argName) throws javax.ejb.CreateException, java.rmi.RemoteException;
/**
 * findByPrimaryKey method
 * @return itso.was4ad.ejb.customer.Customer
 * @param key itso.was4ad.ejb.customer.CustomerKey
 * @exception java.rmi.RemoteException The exception description.
 * @exception javax.ejb.FinderException The exception description.
 */
itso.was4ad.ejb.customer.Customer findByPrimaryKey(itso.was4ad.ejb.customer.CustomerKey key) throws java.rmi.RemoteException, javax.ejb.FinderException;
}
