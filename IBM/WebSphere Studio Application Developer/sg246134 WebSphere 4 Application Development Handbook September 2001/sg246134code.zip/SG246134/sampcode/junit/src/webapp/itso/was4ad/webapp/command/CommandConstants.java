package itso.was4ad.webapp.command;

/**
 * Constants that name pages in the PiggyBank application
 */
public abstract class CommandConstants {
	public static final String PAGE_ERROR = "error.jsp";
    public static final String PAGE_LOGIN = "login.jsp";
    public static final String PAGE_LOGIN_FAIL = "loginfail.jsp";
    public static final String PAGE_LOGOUT = "logout.jsp";
    public static final String PAGE_WELCOME = "welcome.jsp";
    public static final String PAGE_DISPLAY_ACCOUNTS_RESULT = "displayAccountsResult.jsp";
    public static final String PAGE_TRANSFER = "transfer.jsp";
    public static final String PAGE_TRANSFER_RESULT = "transferResult.jsp";

    public static final String ATTR_CUSTOMER = "customer";
    public static final String ATTR_ACCOUNT_LIST = "accountList";
    public static final String ATTR_EXCEPTION = "exception";
}
