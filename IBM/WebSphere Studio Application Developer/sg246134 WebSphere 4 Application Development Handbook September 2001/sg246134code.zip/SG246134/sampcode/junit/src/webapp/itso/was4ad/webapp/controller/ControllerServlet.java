package itso.was4ad.webapp.controller;

import javax.servlet.http.*;
import javax.servlet.*;
import java.util.*;
import itso.was4ad.helpers.LogHelper;
/**
 * The Web channel controller servlet.
 * Implements a very simple command pattern.
 * Examines the URL used to invoke the servlet to determine
 * the command to execute. Simple mapping based upon the
 * URL - remove the extension, uppercase the first character,
 * append 'Command' to the end and attempt to create a new instance
 * of a class with that name. The package containing commands can be
 * specified in an init parameter. The controller provides some basic
 * functionality we don't want to replicate everywhere - checking if
 * we're logged in and handling exceptions.
 */
public class ControllerServlet extends HttpServlet {
	// Use for logging and tracing
	private static final LogHelper LOG = new LogHelper(ControllerServlet.class);
	
	// Instance variables
	private Hashtable commandCache = null;
	private String commandPackage = "itso.was4ad.webapp.command.";
	private String loginCommand = "Login";
	private String loginPage = "login.jsp";
	private String errorPage = "error.jsp";

	// Constants
	private static final String PARM_CMD_PKG = "COMMAND_PACKAGE";
	private static final String PARM_LOGIN_CMD = "LOGIN_COMMAND";
	private static final String PARM_LOGIN_ATTR = "LOGIN_ATTR";
	private static final String PARM_LOGIN_PAGE = "LOGIN_PAGE";
	private static final String PARM_ERROR_PAGE = "ERROR_PAGE";
/**
 * Process incoming HTTP GET requests 
 * 
 * @param request Object that encapsulates the request to the servlet 
 * @param response Object that encapsulates the response from the servlet
 */
public void doGet(HttpServletRequest request, HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {
	LOG.debug("doGet()");
	performTask(request, response);

}
/**
 * Process incoming HTTP POST requests 
 * 
 * @param request Object that encapsulates the request to the servlet 
 * @param response Object that encapsulates the response from the servlet
 */
public void doPost(HttpServletRequest request, HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {
	LOG.debug("doPost()");
	performTask(request, response);

}
/**
 * Manages the cache of commands in a Hashtable
 * @return itso.was4ad.webapp.controller.Command
 * @param commandName java.lang.String
 */
private Command getCommand(String commandName)
    throws ClassNotFoundException, InstantiationException, IllegalAccessException {

	if (LOG.isDebugEnabled()) {
		LOG.debug("getCommand(" + commandName + ")");
	}
	
    Command commandObject = null;

    // First check the cache
    commandObject = (Command) commandCache.get(commandName);
    if (commandObject == null) {
        // Locate the command, create a new instance, and save it in the cache
        LOG.info("Creating new command instance: " + commandName);
        Class c = Class.forName(commandPackage + commandName + "Command");
        commandObject = (Command) c.newInstance();
        commandCache.put(commandName, commandObject);
    }

    // Return the command object (or null)
    return commandObject;
}
/**
 * Returns the servlet info string.
 */
public String getServletInfo() {

	return super.getServletInfo();

}
/**
 * Initializes the servlet - basically processes init parameters
 */
public void init() {
    LOG.debug("init()");

    // Initialize parameters or use defaults
    ServletConfig config = getServletConfig();
    if (config.getInitParameter(PARM_CMD_PKG) != null) {
        commandPackage = config.getInitParameter(PARM_CMD_PKG);
    }
    if (config.getInitParameter(PARM_LOGIN_CMD) != null) {
        loginCommand = config.getInitParameter(PARM_LOGIN_CMD);
    }
    if (config.getInitParameter(PARM_LOGIN_PAGE) != null) {
        loginPage = config.getInitParameter(PARM_LOGIN_PAGE);
    }
    if (config.getInitParameter(PARM_ERROR_PAGE) != null) {
        errorPage = config.getInitParameter(PARM_ERROR_PAGE);
    }

    // Log the parameters
    LOG.info("Package containing commands: " + commandPackage);
    LOG.info("Login command: " + loginCommand);
    LOG.info("Login page: " + loginPage);
    LOG.info("Error page: " + errorPage);

    // Initialize the cache of commands
    commandCache = new Hashtable();

    LOG.info("Controller servlet initialized");
}
/**
 * Process incoming requests for information
 * 
 * @param request Object that encapsulates the request to the servlet 
 * @param response Object that encapsulates the response from the servlet
 */
public void performTask(
    HttpServletRequest request,
    HttpServletResponse response)
    throws ServletException {

    LOG.debug("performTask()");

    // The page we need to forward to
    String resultPage = loginPage;

    // First figure out the command name from the request URI
    LOG.debug("Figuring out command name:");
    java.io.File f = new java.io.File(request.getRequestURI());
    String commandName = f.getName();
    commandName = commandName.substring(0, commandName.lastIndexOf("."));
    commandName =
        commandName.substring(0, 1).toUpperCase() + commandName.substring(1);
    LOG.debug(commandName);

    // Make sure we are logged in, if not forward to login page
    HttpSession session = request.getSession(false);
    if (session != null
        && session.getAttribute(itso.was4ad.webapp.command.CommandConstants.ATTR_CUSTOMER) != null
        || commandName.equals(loginCommand)) {
        // Execute the comand
        try {
            LOG.debug("Executing command");
            resultPage = getCommand(commandName).execute(request, response, session);
        } catch (Exception e) {
	        LOG.warn("Caught unexpected exception executing command: " + commandName, e);
            Error err = new Error(commandName, "Caught unexpected exception " + e);
            request.setAttribute(Error.ATTR_ERROR, err);
            resultPage = errorPage;
        }
    }

    // Forward to the result page
    try {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Forwarding to page: " + resultPage);
        }
        RequestDispatcher rd = getServletContext().getRequestDispatcher(resultPage);
        rd.forward(request, response);
    } catch (java.io.IOException e) {
	    LOG.error("Caught unexpected IOException forwarding to " + resultPage, e);
        throw new ServletException(
            "Controller servlet caught IOException exception",
            e);
    }
}
}
