package itso.was4ad.ejb.customer;

/**
 * This is a Home interface for the Session Bean
 */
public interface CustomerManagerHome extends javax.ejb.EJBHome {

/**
 * create method for a session bean
 * @return itso.was4ad.ejb.customer.CustomerManager
 * @exception javax.ejb.CreateException
 * @exception java.rmi.RemoteException
 */
itso.was4ad.ejb.customer.CustomerManager create() throws javax.ejb.CreateException, java.rmi.RemoteException;
}
