package itso.was4ad.usecase;

import itso.was4ad.data.*;

/**
<PRE>
Display balance : displays the balance of a PiggyBank account.

Input :
- customer id
- account number

Basic path :
1. The customer enters the required input information and submits the request.
2. The system checks that the account exists and that the customer is its owner.
3. The system records the transaction. (?)
4. The system displays the customer its account balance.

Alternative path :
2b. One of the checks fails.
3b. The system displays a message explaining why the transaction cannot be completed.
</PRE>
*/
public class DisplayBalance extends UseCase {

    private int accountNumber = 0;
/**
  * DisplayBalance constructor
 */
public DisplayBalance() {
    super();
}
/**
 * Execute the display balance use case
 */
public DataBean execute() throws Exception {
    // Get the data
    return getAccountManager().getAccountData(accountNumber);
}
/**
 * Set the number of the account to get the balance of
 * @param newAccountNumber int
 */
public void setAccountNumber(int newAccountNumber) {
	accountNumber = newAccountNumber;
}
}
