package itso.was4ad.ejb.account;

/**
 * This is an Enterprise Java Bean Remote Interface
 */
public interface AccountManager extends javax.ejb.EJBObject {

/**
 * Cash a check
 * @return itso.was4ad.data.AccountData
 * @param accountID int
 * @param amount int
 * @param reference java.lang.String
 * @exception java.rmi.RemoteException
 * @exception itso.was4ad.exception.InvalidOperation
 * @exception itso.was4ad.exception.NonExistentAccount
 * @exception itso.was4ad.exception.InsufficientFunds
 */
itso.was4ad.data.AccountData cashCheck(int accountID, int amount, java.lang.String reference) throws java.rmi.RemoteException, itso.was4ad.exception.InvalidOperation, itso.was4ad.exception.NonExistentAccount, itso.was4ad.exception.InsufficientFunds;
/**
 * Open a new account
 * @return itso.was4ad.data.AccountData
 * @param customerID int
 * @param checking boolean
 * @exception java.rmi.RemoteException
 */
itso.was4ad.data.AccountData createAccount(int customerID, boolean checking) throws java.rmi.RemoteException;
/**
 * Close an account
 * @return void
 * @param id int
 * @exception java.rmi.RemoteException
 * @exception itso.was4ad.exception.InvalidOperation
 * @exception itso.was4ad.exception.NonExistentAccount
 */
void deleteAccount(int id) throws java.rmi.RemoteException, itso.was4ad.exception.InvalidOperation, itso.was4ad.exception.NonExistentAccount;
/**
 * Get a data object containing information for an account
 * @return itso.was4ad.data.AccountData
 * @param id int
 * @exception java.rmi.RemoteException
 * @exception itso.was4ad.exception.NonExistentAccount
 */
itso.was4ad.data.AccountData getAccountData(int id) throws java.rmi.RemoteException, itso.was4ad.exception.NonExistentAccount;
/**
 * Transfer money between two customer accounts
 * @return itso.was4ad.data.AccountListData
 * @param customerID int
 * @param debitID int
 * @param creditID int
 * @param amount int
 * @exception java.rmi.RemoteException
 * @exception itso.was4ad.exception.InvalidOperation
 * @exception itso.was4ad.exception.NonExistentAccount
 * @exception itso.was4ad.exception.InsufficientFunds
 * @exception itso.was4ad.exception.CustomerNotAuthorized
 */
itso.was4ad.data.AccountListData transfer(int customerID, int debitID, int creditID, int amount) throws itso.was4ad.exception.CustomerNotAuthorized, java.rmi.RemoteException, itso.was4ad.exception.InvalidOperation, itso.was4ad.exception.NonExistentAccount, itso.was4ad.exception.InsufficientFunds;
}
