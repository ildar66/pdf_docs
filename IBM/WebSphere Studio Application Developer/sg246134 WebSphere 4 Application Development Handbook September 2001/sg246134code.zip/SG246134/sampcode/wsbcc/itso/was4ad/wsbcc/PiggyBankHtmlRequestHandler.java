package itso.was4ad.wsbcc;

import com.ibm.dse.base.*;
/**
 * Insert the type's description here.
 * Creation date: (6/28/01 5:16:34 PM)
 * @author: Administrator
 */
public class PiggyBankHtmlRequestHandler extends com.ibm.dse.cs.html.HtmlRequestHandler {
/**
 * PiggyBankHtmlRequestHandler constructor comment.
 */
public PiggyBankHtmlRequestHandler() {
	super();
}
/**
 * <p>Copy customerId parameter to the session context.
 */
protected void addBusinessDataToSessionCtx(
    String sessionId,
    javax.servlet.http.HttpServletRequest request) {
    try {
        Context sessionCtx = Context.getCurrentContextForSession(sessionId);
        String value = request.getParameter("customerId");
        sessionCtx.setValueAt("customerId", value);
    } catch (Exception e) {
        // let the next steps handle this
    }
}
/**
 * The session operation context requires some data to be added to it.
 * 
 * @param opCtx com.ibm.dse.base.Context
 * @param kcReqData com.ibm.dse.base.KeyedCollection 
 */
protected void addRequiredDataToOperationCtx(
    Context opCtx,
    KeyedCollection kcReqData) {
    try {
        super.addRequiredDataToOperationCtx(opCtx, kcReqData);
        java.util.Enumeration enum = kcReqData.getEnumeration();
        while (enum.hasMoreElements()) {
            opCtx.addElement((DataElement) enum.nextElement());
        }
    } catch (Exception exc) {
    }
}
public ServerOperation executeSessionRequest(com.ibm.dse.clientserver.ChannelContext channelContext) throws Exception {	
	//String sessionId = (String)getValueAt(com.ibm.dse.cs.servlet.CSConstants.SESSIONIDKEY);
	Context sessionContext = (Context) Context.readObject("sessionContext");
	Context.addSession(getSessionId(channelContext), null, sessionContext);
        String value = ((javax.servlet.http.HttpServletRequest)channelContext.getChannelRequest()).getParameter("customerId");
        sessionContext.setValueAt("customerId", value);
	//addBusinessDataToSessionCtx(getSessionId(channelContext), (javax.servlet.http.HttpServletRequest)channelContext.getChannelRequest());	
	DSEServerOperation operation=(DSEServerOperation)super.executeSessionRequest(channelContext);

		
	return operation;
}
}
