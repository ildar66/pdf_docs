package itso.was4ad.wsbcc;

import itso.was4ad.usecase.*;
import itso.was4ad.data.*;
import com.ibm.dse.base.*;
/**
 * Simulates a host system. Designed according to the singleton pattern.
 */
public class HostSystem extends com.ibm.dse.base.Service {
/**
 * HostSystem constructor comment.
 */
public HostSystem() {
	super();
}
/**
 * Insert the method's description here.
 * @return java.lang.String
 * @param request java.lang.String
 */
public synchronized String execute(String request)
    throws com.ibm.dse.base.DSEException {
    try {
        String response = null;
        // fork on the request id (first 5 numbers)
        String requestId = request.substring(0, 5);
        // Call the appropriate use case and send back formatted answer
        if ("00001".equals(requestId)) { // customer info
            DisplayCustomer useCase = new DisplayCustomer();
            useCase.setCustomerId(Integer.parseInt(request.substring(5, 13).trim()));
            CustomerData data = (CustomerData) useCase.execute();
            response = data.getId() + "\\" + data.getName() + "\\";
        } else
            if ("00002".equals(requestId)) { // accounts
                DisplayCustomerAccounts displayAccounts = new DisplayCustomerAccounts();
                displayAccounts.setCustomerId(
                    Integer.parseInt(request.substring(5, 13).trim()));
                AccountListData data = (AccountListData) displayAccounts.execute();
                AccountData[] accounts = data.getAccounts();
                response = "";
                for (int i = 0; i < accounts.length; i++) {
                    AccountData account = accounts[i];
                    String checkingString = null;
                    if (account.isChecking()) {
                        checkingString = "YES";
                    } else {
                        checkingString = "NO";
                    }
                    response =
                        response
                            + account.getNumber()
                            + "\\"
                            + checkingString
                            + "\\"
                            + account.getAmount()
                            + "\\";
                }
            } else
                if ("00003".equals(requestId)) { // transfer
                    Transfer transfer = new Transfer();
                    transfer.setCustomerId(Integer.parseInt(request.substring(5, 13).trim()));
                    transfer.setDebitAccountNumber(
                        Integer.parseInt(request.substring(13, 21).trim()));
                    transfer.setCreditAccountNumber(
                        Integer.parseInt(request.substring(21, 29).trim()));
                    transfer.setAmount(Integer.parseInt(request.substring(29, 42).trim()));
                    AccountListData data = (AccountListData) transfer.execute();
                    response = "";
                } else {
                    throw new com.ibm.dse.base.DSEException(
                        com.ibm.dse.base.DSEException.critical,
                        "HostSystem error",
                        "Unknown host request id " + requestId);
                }
        return response;
    } catch (Exception e) {
        throw new DSEException(
            DSEException.critical,
            "HostSystem error",
            "Host system cannot handle request \""
                + request
                + "\" because of exception : "
                + e.toString());
    }
}
}
