package itso.was4ad.wsbcc;

import javax.servlet.*;
import javax.servlet.http.*;
import java.net.*;
import com.ibm.dse.base.*;
import com.ibm.dse.clientserver.*;

/**
 * <p>This servlet starts the server. It creates an initial context
 * in the server and starts the client-server service.
 *
 * <p>There are 2 ways to start the server:
 * <ol>
 *  <li>When the servlet is triggered from inside the real WAS,
 *      the WAS calls the init() method. This will read parameter
 *      values defined for this servlet in the WAS. The supported
 *      parameters are:
 *      <UL>
 *       <LI>wbcbIniFile -- (optional)
 *       <LI>acceptHttpRestart -- (optional) if "false", no HTTP-triggered restart is allowed
 *       <LI>initStart -- (optional) if "false", no initialisation will be done 
 *      </UL>
 *  <li>When the servlet is triggered by a GET request to a normal Web
 *      server (i.e. the WebSphere Test Environment), it will expect
 *      parameter values to be passed as request parameters. In this
 *      case, the following parameters are supported:
 *      <UL>
 *       <LI>wbcbIniFile -- (optional)
 *       <LI>entryPointUrl -- (optional) path where started server can be accessed
 *       <LI>password (required if not null)
 *      </UL>
 *      The servlet will respond with a page that allows you to enter into
 *      the started server using the 'entryPointUrl'.
 * </ol>
 */
public class StartServerServlet extends HttpServlet {
	//TBM: default dseIniFileName should be the standard dseIniFile.
	//Some of the default hardcoded paths should also be modified.
	private static final String defaultEntryPointUrl = "/piggybank-wsbcc/index.html";
	private static String defaultIniFileName = "D:\\IBMVJava\\ide\\project_resources\\IBM WebSphere Test Environment\\hosts\\default_host\\piggybank-wsbcc\\XML\\dse.ini";
	private static final String requiredPassword = null;
	private boolean acceptHttpRestart = true;
/**
 * <p>Initialize the servlet.
 *
 * <p>To avoid the framework initialization when the Application Server
 * is initiated set the initStart parameter to false.
 */
public void init(ServletConfig sc) {
    try {
        super.init(sc);

        String initStart = getInitParameter("initStart");
        if (initStart != null && initStart.equals("false")) {
            // Do nothing: the user doesn't want to initialize the
            // environment in the Application Server's startup
        } else {
            // set the HTTP restart preference
            this.acceptHttpRestart =
                (new Boolean(getInitParameter("acceptHttpRestart"))).booleanValue();
            // Get the path of the server's dse.ini file
            String path = getInitParameter("iniFile");
            if (path == null) {
                path = this.defaultIniFileName;
            } else {
                this.defaultIniFileName = path;
            }
            //only try to initialize when the .ini file exists
            //otherwise trust initialize() to be called from
            //the doGet() method
            if (new java.io.File(path).exists()) {
                initialize(path);
            }
            log("StartServerServlet initialized properly");
        }
    } catch (Exception e) {
        log("Exception in StartServerServlet.init(): " + e);
    }

}
/**
 * <p>Creates an initial context in the server and starts the
 * client-server service.
 */
private void initialize(String iniFileName) throws Exception {	
	//reset the framework
	Context.reset();
	HandlerRegistry.resetInstance();
	
	// Read data from .ini file
	Settings.reset(iniFileName);
	Settings.initializeExternalizers(Settings.MEMORY);

	// Create the initial context in the server
	Context context = new Context("globalContext");

	// Initialize the client-server service, required for session management
	((CSServerService)context.getService("CSServer")).initiateServer();
}
/**
 * <p>Initializes the environment from a get request. Password is required for 
 * security reasons. 
 */
public void service(HttpServletRequest req, HttpServletResponse res)
    throws java.io.IOException {
    // check the password
    String password = req.getParameter("password");
    if ((!this.acceptHttpRestart)
        || ((this.requiredPassword != null)
            && (!this.requiredPassword.equals(password)))) {
        // consider it as violent DoS so immediately close the output stream
        // NB : it could be considered to log the hit source as well
        log("BblStartHtmlServerServlet hit with a wrong password");

        ServletOutputStream strmOut = res.getOutputStream();
        strmOut.println("No access.");
        strmOut.close();

        return;
    }

    // determine the entry point URL
    String entryPointUrl = req.getParameter("entryPointUrl");
    if (entryPointUrl == null) {
        log("Warning: no 'entryPointUrl' parameter in URL, using default");
        entryPointUrl = this.defaultEntryPointUrl;
    }

    // determine the location of .ini file
    String iniFileName = req.getParameter("iniFile");
    if (iniFileName == null) {
        log("Warning: no 'iniFile' parameter in URL, using default");
        iniFileName = this.defaultIniFileName;
    }

    String strMessage = "Initialization OK";

    // start the server
    try {
        log("Using the ini file: " + iniFileName);
        strMessage += " from file " + iniFileName + ".<BR>";
        strMessage += "You can now <a href=\""
            + entryPointUrl
            + "\">enter</a> the application.";

        initialize(iniFileName);
    } catch (Throwable t) {
        strMessage = "ERROR in server: " + t.toString();
    }

    //send response to client
    ServletOutputStream strmOut = res.getOutputStream();
    strmOut.println("<HTML><HEAD>");
    strmOut.println("<TITLE>WBCC Start</TITLE>");
    strmOut.println("</HEAD><BODY>");
    strmOut.println("<H1><B>" + this.getClass().getName() + "</B></H1><HR>");
    strmOut.println(strMessage + "<BR><HR>");
    strmOut.println("</BODY></HTML>");
    strmOut.close();
}
}
