package itso.was4ad.wsbcc;

import com.ibm.dse.base.*;
import java.util.*;
/**
 * Insert the type's description here.
 * Creation date: (6/22/01 5:04:18 PM)
 * @author: Administrator
 */
public class CommandOperation extends com.ibm.dse.base.DSEServerOperation {
	protected java.lang.String replyPage = null;
/**
 * CommandOperation constructor comment.
 */
public CommandOperation() {
	super();
}
/**
 * CommandOperation constructor comment.
 * @param arg1 java.lang.String
 * @exception java.io.IOException The exception description.
 */
public CommandOperation(String arg1) throws java.io.IOException {
	super(arg1);
}
/**
 * CommandOperation constructor comment.
 * @param arg1 java.lang.String
 * @param arg2 com.ibm.dse.base.Context
 * @exception java.io.IOException The exception description.
 * @exception com.ibm.dse.base.DSEInvalidRequestException The exception description.
 */
public CommandOperation(String arg1, com.ibm.dse.base.Context arg2) throws java.io.IOException, com.ibm.dse.base.DSEInvalidRequestException {
	super(arg1, arg2);
}
/**
 * CommandOperation constructor comment.
 * @param arg1 java.lang.String
 * @param arg2 java.lang.String
 * @exception java.io.IOException The exception description.
 * @exception com.ibm.dse.base.DSEObjectNotFoundException The exception description.
 * @exception com.ibm.dse.base.DSEInvalidRequestException The exception description.
 */
public CommandOperation(String arg1, String arg2) throws java.io.IOException, com.ibm.dse.base.DSEObjectNotFoundException, com.ibm.dse.base.DSEInvalidRequestException {
	super(arg1, arg2);
}
public void execute() throws Exception {
    super.execute();
    setValueAt(com.ibm.dse.cs.html.HtmlConstants.REPLYPAGE, this.replyPage);
}
/**
 * <p>This method will initialize "this" operation will all the data stored
 * inside the tag: aTag
 * @return java.lang.Object
 * @param aTag com.ibm.dse.base.Tag an operation Tag
 */
public Object initializeFrom(Tag aTag)
    throws java.io.IOException, DSEException {
    super.initializeFrom(aTag);
    com.ibm.dse.base.Vector attributes = aTag.getAttrList();
    for (int i = 0; i < attributes.size(); i++) {
        TagAttribute attribute = (TagAttribute) attributes.elementAt(i);
        if (attribute.getName().equals("replyPage")) {
            this.replyPage = (String) attribute.getValue();
        }
    }
    return this;
}
}
