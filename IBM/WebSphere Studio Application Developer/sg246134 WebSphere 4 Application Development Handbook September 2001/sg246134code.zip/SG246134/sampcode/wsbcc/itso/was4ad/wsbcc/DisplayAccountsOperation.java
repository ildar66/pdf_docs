package itso.was4ad.wsbcc;

import itso.was4ad.usecase.*;
import itso.was4ad.data.*;
/**
 * Insert the type's description here.
 * Creation date: (6/25/01 10:09:27 AM)
 * @author: Administrator
 */
public class DisplayAccountsOperation extends CommandOperation {
/**
 * DisplayAccountsOperation constructor comment.
 */
public DisplayAccountsOperation() {
	super();
}
/**
 * DisplayAccountsOperation constructor comment.
 * @param arg1 java.lang.String
 * @exception java.io.IOException The exception description.
 */
public DisplayAccountsOperation(String arg1) throws java.io.IOException {
	super(arg1);
}
/**
 * DisplayAccountsOperation constructor comment.
 * @param arg1 java.lang.String
 * @param arg2 com.ibm.dse.base.Context
 * @exception java.io.IOException The exception description.
 * @exception com.ibm.dse.base.DSEInvalidRequestException The exception description.
 */
public DisplayAccountsOperation(String arg1, com.ibm.dse.base.Context arg2) throws java.io.IOException, com.ibm.dse.base.DSEInvalidRequestException {
	super(arg1, arg2);
}
/**
 * DisplayAccountsOperation constructor comment.
 * @param arg1 java.lang.String
 * @param arg2 java.lang.String
 * @exception java.io.IOException The exception description.
 * @exception com.ibm.dse.base.DSEObjectNotFoundException The exception description.
 * @exception com.ibm.dse.base.DSEInvalidRequestException The exception description.
 */
public DisplayAccountsOperation(String arg1, String arg2) throws java.io.IOException, com.ibm.dse.base.DSEObjectNotFoundException, com.ibm.dse.base.DSEInvalidRequestException {
	super(arg1, arg2);
}
public void execute() throws Exception {
    super.execute();
    // call the use case and put data bean in the context
    com.ibm.dse.base.Context sessionContext = this.getContext().getParent();
    CustomerData customer = (CustomerData) sessionContext.getValueAt("customerInfo");
    DisplayCustomerAccounts displayAccounts = new DisplayCustomerAccounts();
    displayAccounts.setCustomerId(customer.getId());
    AccountListData data = (AccountListData) displayAccounts.execute();
}
}
