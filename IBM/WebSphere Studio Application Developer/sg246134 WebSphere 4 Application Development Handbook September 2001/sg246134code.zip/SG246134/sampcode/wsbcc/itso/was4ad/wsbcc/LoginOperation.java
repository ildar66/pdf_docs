package itso.was4ad.wsbcc;

import com.ibm.dse.base.*;
/**
 * Insert the type's description here.
 * Creation date: (6/28/01 12:16:55 PM)
 * @author: Administrator
 */
public class LoginOperation extends GenericHostOperation {
/**
 * LoginOperation constructor comment.
 */
public LoginOperation() {
	super();
}
/**
 * LoginOperation constructor comment.
 * @param arg1 java.lang.String
 * @exception java.io.IOException The exception description.
 */
public LoginOperation(String arg1) throws java.io.IOException {
	super(arg1);
}
/**
 * LoginOperation constructor comment.
 * @param arg1 java.lang.String
 * @param arg2 com.ibm.dse.base.Context
 * @exception java.io.IOException The exception description.
 * @exception com.ibm.dse.base.DSEInvalidRequestException The exception description.
 */
public LoginOperation(String arg1, com.ibm.dse.base.Context arg2) throws java.io.IOException, com.ibm.dse.base.DSEInvalidRequestException {
	super(arg1, arg2);
}
/**
 * LoginOperation constructor comment.
 * @param arg1 java.lang.String
 * @param arg2 java.lang.String
 * @exception java.io.IOException The exception description.
 * @exception com.ibm.dse.base.DSEObjectNotFoundException The exception description.
 * @exception com.ibm.dse.base.DSEInvalidRequestException The exception description.
 */
public LoginOperation(String arg1, String arg2) throws java.io.IOException, com.ibm.dse.base.DSEObjectNotFoundException, com.ibm.dse.base.DSEInvalidRequestException {
	super(arg1, arg2);
}
public void execute() throws Exception {
    String sessionId =
        (String) getValueAt(com.ibm.dse.cs.servlet.CSConstants.SESSIONIDKEY);
    //Context sessionContext = (Context) Context.readObject("sessionContext");
    //Context.addSession(sessionId, null, sessionContext);
    Context sessionContext = Context.getCurrentContextForSession(sessionId);
    this.getContext().setValueAt(
        "customerId",
        sessionContext.getValueAt("customerId"));
    super.execute();
}
}
