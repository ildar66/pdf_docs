package itso.was4ad.wsbcc;

import com.ibm.dse.base.*;
/**
 * Insert the type's description here.
 * Creation date: (6/29/01 10:17:09 AM)
 * @author: Administrator
 */
public class PiggyBankJspContextServices extends com.ibm.dse.cs.html.DSEJspContextServices {
/**
 * PiggyBankJspContextServices constructor comment.
 */
public PiggyBankJspContextServices() {
	super();
}
public String get(KeyedCollection kColl,String key) {
	String retVal="";
	try {
		DataElement d=kColl.getElementAt(key);
		if (d!=null) {
			retVal=(String)d.getValue();
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return retVal;
}
/**
 * <p>Gets the value of certain field of the KeyedCollection which is
 * the element at idx of the indexed colection iColl
 *
 * <p>The method will return an empty string when noting is found.
 */
public String getIndexedToken(IndexedCollection iColl, int idx, String element) {
	String s ="";
	try {
		KeyedCollection record = (KeyedCollection) iColl.getElementAt(idx);
		if (record.size() != 0)
			s = get( record, element);
	} catch (Exception e) {
		//ignore
	}
	return s;
}
/**
 * <p>Gets the value of certain field of the KeyedCollection which is
 * the element at idx of the indexed colection 'name'.
 *
 * <p>The method will return an empty string when noting is found.
 */
public String getIndexedToken(String name, int idx, String element) {
	IndexedCollection iColl = (IndexedCollection) getElement(name);
	return getIndexedToken(iColl, idx, element);
}
/**
 * Returns an IndexedCollection size, or 0 if it is null.
 * @return int
 * @param param com.ibm.dse.base.IndexedCollection
 */
public int getSize(IndexedCollection indexedCollection) {
	int returnValue = 0;
	if (indexedCollection == null) {
		returnValue = 0;
	}
	else {
		returnValue = indexedCollection.size();
	}
	return returnValue;
}
/**
 * Returns an IndexedCollection size by its name in the context, 
 * or 0 if it is not present in the context.
 * @return int
 * @param indexedCollectionName java.lang.String
 */
public int getSize(String indexedCollectionName) {
	int returnValue = 0;
	try {
		IndexedCollection indexedCollection = (IndexedCollection) this.getElement(indexedCollectionName);
		returnValue = this.getSize(indexedCollection);
	}
	catch (ClassCastException e) {
		returnValue = 0;
	}
	return returnValue;
}
}
