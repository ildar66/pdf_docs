package itso.wsad.alma.web;

import javax.servlet.http.HttpServlet;

public class MightyMotorsInquire extends HttpServlet {

	public void init() throws javax.servlet.ServletException {
	}

	public void doPost(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response)
		throws javax.servlet.ServletException, java.io.IOException {
			performTask(request, response);
	}

	public void doGet(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response)
		throws javax.servlet.ServletException, java.io.IOException {
			performTask(request, response);
	}

	public void performTask(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response) {

		try {
			response.setContentType("text/html; charset=UTF-8");
			javax.xml.transform.TransformerFactory tFactory = 
				javax.xml.transform.TransformerFactory.newInstance();
			javax.xml.transform.Source xslSource =
				new javax.xml.transform.stream.StreamSource(
					new java.net.URL ("http://localhost:8080/ITSOAlma/stylesheets/static/InquirePartsResultTable.xsl").openStream());
			javax.xml.transform.Transformer transformer = 
				tFactory.newTransformer(xslSource);
			java.io.PrintWriter out = response.getWriter();
				
		// For SOAP over HTTP	
			itso.wsad.alma.wsstatic.proxy.InquirePartsProxy proxy =
				new itso.wsad.alma.wsstatic.proxy.InquirePartsProxy();
			org.w3c.dom.Element result = proxy.inquireParts
				((String)request.getSession().getAttribute("partNo"));
			javax.xml.transform.Source xmlSource = new javax.xml.transform.dom.DOMSource(result);
			
			transformer.transform(xmlSource,
						new javax.xml.transform.stream.StreamResult(out));				
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

}
