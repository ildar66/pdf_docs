package itso.wsad.alma.mq.proxy;

import java.net.*;
import java.util.*;
import org.w3c.dom.*;
import org.apache.soap.*;
import org.apache.soap.encoding.*;
import org.apache.soap.rpc.*;
import org.apache.soap.util.xml.*;
import org.apache.soap.transport.*;
import com.ibm.soap.transport.mqseries.*;

public class InquirePartsProxy
{
  private Call call = new Call();
  private URL url = null;
  private String SOAPActionURI = "";
  private SOAPMappingRegistry smr = call.getSOAPMappingRegistry();

  public InquirePartsProxy() throws MalformedURLException
  {
    call.setTargetObjectURI("urn:InquireParts");
    call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);
    SOAPTransport ss = new SOAPMQSeriesConnection("SOAPManager","SOAPIN", "SYSTEM.DEFAULT.MODEL.QUEUE");
    call.setSOAPTransport(ss);
    this.url = new URL("http://my-http");
    this.SOAPActionURI = "urn:InquireParts";
  }

  public synchronized void setEndPoint(URL url)
  {
    this.url = url;
  }

  public synchronized URL setEndPoint()
  {
    return url;
  }

  public synchronized org.w3c.dom.Element inquireParts_(java.lang.String partNumber) throws Exception
  {
    if(url == null)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via " + "InquirePartsProxy.setEndPoint(URL).");
    }

    call.setMethodName("inquireParts");
    call.setEncodingStyleURI(Constants.NS_URI_LITERAL_XML);
    Vector params = new Vector();
    Parameter partNumberParam = new Parameter("partNumber", java.lang.String.class, partNumber, Constants.NS_URI_SOAP_ENC);
    params.addElement(partNumberParam);
    call.setParams(params);
    Response resp = call.invoke(url, SOAPActionURI);

    //Check the response.
    if (resp.generatedFault())
    {
      Fault fault = resp.getFault();
      throw new SOAPException(fault.getFaultCode(), fault.getFaultString());
    }
    else
    {
      Parameter refValue = resp.getReturnValue();
      return ((org.w3c.dom.Element)refValue.getValue());
    }
  }

  public synchronized itso.wsad.alma.wsstatic.mappings.InquirePartsResults inquireParts(java.lang.String partNumber) throws Exception
  {

    // delegate to method inquireParts_
    org.w3c.dom.Element result_ = inquireParts_(partNumber);

    // convert result_ from an org.w3c.dom.Element to mappings.InquirePartsResults
    itso.wsad.alma.wsstatic.mappings.InquirePartsResultsFactory factory = new itso.wsad.alma.wsstatic.mappings.InquirePartsResultsFactory();
    factory.setPackageName("itso.wsad.alma.mappings");
    itso.wsad.alma.wsstatic.mappings.InquirePartsResults result = (itso.wsad.alma.wsstatic.mappings.InquirePartsResults)factory.loadDocument("InquirePartsResults", result_);

    return result;
  }

}
