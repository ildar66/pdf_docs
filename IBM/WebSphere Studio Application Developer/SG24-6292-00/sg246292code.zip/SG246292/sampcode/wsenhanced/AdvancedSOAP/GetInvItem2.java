package itso.wsad.alma.custom;

import org.w3c.dom.Element;

public class GetInvItem2 {

	public InvItemBean getAsBean(String partNumber, long itemNumber) {
		System.out.println("In getAsBean of GetInvItem (default)");
		System.out.println("partNumber is " + partNumber);
		System.out.println("itemNumber is " + itemNumber);

		InvItemBean result = new InvItemBean();
		result.setCost(33.33F);
		result.setDescription("An item.");
		result.setImageURL("Part-"+partNumber+".gif");
		result.setItemNumber(itemNumber);
		result.setLocation("Here.");
		result.setPartNumber(partNumber);
		result.setQuantity(66);
		result.setShelf("S1");
		result.setWeight(999.9);
		result.setName("Magic part");
		return result;
	}
}