package itso.wsad.alma.message;

import org.w3c.dom.*;

public class XMLUtils {
	public static java.lang.String domWriter(Node node,
			java.lang.StringBuffer buffer) {
		if ( node == null ) 
			return "";

		int type = node.getNodeType();
		switch ( type ) {
		case Node.DOCUMENT_NODE: {
			buffer.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
			domWriter(((org.w3c.dom.Document)node).getDocumentElement(),buffer);
			break;
		}
		case Node.ELEMENT_NODE: {
			buffer.append("<" + node.getNodeName());
			NamedNodeMap attrs = node.getAttributes();
			int length = (attrs != null) ? attrs.getLength() : 0;
			for ( int i = 0; i < length; i++ ) {
				Attr attr = (org.w3c.dom.Attr) attrs.item(i);
				buffer.append(" " + attr.getNodeName() + "=\"" );
				buffer.append(attr.getNodeValue() + "\"");
			}
			buffer.append(">"); 
			NodeList children = node.getChildNodes();
			if ( children != null ) {
				int len = children.getLength();
				for ( int i = 0; i < len; i++ ) {
					if(((Node)children.item(i)).getNodeType() == Node.ELEMENT_NODE)
					buffer.append("\n");
					domWriter(children.item(i),buffer);
				}
			}
			buffer.append("</" + node.getNodeName() + ">");
			break;
		}
		case Node.CDATA_SECTION_NODE: 
		case Node.TEXT_NODE:{
			buffer.append(node.getNodeValue());
			break;
		}
		}
		return buffer.toString();
	}
}
