package itso.wsad.alma.message;

import java.util.*;
import org.w3c.dom.*;
import org.apache.soap.*;
import org.apache.soap.rpc.*;
import org.apache.soap.messaging.*;

public class MessageService {
	public void sendDocument(org.apache.soap.Envelope requestEnvelope, 
								org.apache.soap.rpc.SOAPContext requestContext,
								org.apache.soap.rpc.SOAPContext responseContext) {
	  try {
		System.out.println("Received a sendDocument message.");
		Body b = requestEnvelope.getBody();
		Vector v = b.getBodyEntries();
		
		for (int i=0;i<v.size();i++) {
			Element elem = (Element) v.elementAt(i);
			System.out.println( "Body element with index " + i + 
			                    " is " + elem.getNodeName());
			String inElem = XMLUtils.domWriter(elem, new StringBuffer());
			System.out.println(inElem);
		}
		
		responseContext.setRootPart("Message received.", "text/plain");
	  }
	  catch(Exception e ) {
	  	e.printStackTrace(System.err);
	  }
	}
}