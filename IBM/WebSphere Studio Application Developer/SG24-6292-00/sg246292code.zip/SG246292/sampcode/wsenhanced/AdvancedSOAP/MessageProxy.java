package itso.wsad.alma.message;

import java.io.*;
import java.net.*;
import java.util.*;
import org.w3c.dom.*;
import org.apache.soap.*;
import org.apache.soap.messaging.*;
import org.apache.soap.transport.*;
import org.apache.soap.util.*;

public class MessageProxy
{
  private URL url = null;
  private String soapActionURI = "urn:Message";
 
  public MessageProxy() throws MalformedURLException { }

  public synchronized void setEndPoint(URL url) {
    this.url = url;
  }

  public synchronized String sendDocument(java.lang.String filename) 
								throws Exception {
	if(url == null) {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
      "A URL must be specified via " + "ExchangeProxy.setEndPoint(URL).");
	}
 
	// ** instantiate SOAP message and its elements
	Envelope env = new Envelope();
	Body     body = new Body();
	Vector   bodyElementVector = new Vector();
	Message  msg = new Message();
	
	// ** create body element and add it to body
	MessageSerializer ms = new MessageSerializer(filename);
	Bean bean = new Bean(MessageSerializer.class, ms);
	bodyElementVector.add(bean);
	body.setBodyEntries(bodyElementVector);
	env.setBody(body);

	// ** send message
	System.out.println("Proxy: sending message ...");  
	msg.send(this.url, soapActionURI, env);
	System.out.println("Proxy: done.");

	// ** receive response
	System.out.println("Proxy: receiving response ...");
	SOAPTransport t = msg.getSOAPTransport();
	BufferedReader br = t.receive();
	System.out.println("Proxy: done.");

	// ** create response string
	String nextLine = null;
	StringBuffer result = new StringBuffer();
	while ((nextLine = br.readLine()) != null) {
		result.append(nextLine);
	}
	
	return result.toString();
  }
}
