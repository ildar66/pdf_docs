package itso.wsad.alma.message;

import java.io.*;
import org.apache.soap.rpc.*;
import org.apache.soap.util.xml.*;

public class MessageSerializer implements Serializer {

	StringBuffer message = null;
	
	public MessageSerializer(String filename) {
		try {
			BufferedReader br = new BufferedReader(new FileReader(filename));
	 		String nextLine = br.readLine(); // skip first line of document
	 		message = new StringBuffer();
	 		while ((nextLine = br.readLine()) != null) {
	   			message.append(nextLine);
			}
		} catch (Exception e ) {
			e.printStackTrace(System.err);
			message.append("<messageContent></messageContent>");
		}
	}
		
	public void marshall(String inScopeEncStyle, Class javaType, Object src,
                       Object context, Writer sink, NSStack nsStack,
                       XMLJavaMappingRegistry xjmr, SOAPContext ctx)
				 throws IllegalArgumentException, IOException {
	 nsStack.pushScope();
	 sink.write("<ns1:sendDocument xmlns:ns1=\"urn:Message\">");
	 sink.write(message.toString());
	 sink.write("</ns1:sendDocument>");
	 nsStack.popScope();
	 }
}

