package itso.wsad.alma.custom.mappings;

import org.apache.soap.util.xml.Deserializer;
import org.apache.soap.util.xml.Serializer;

public class StringSerializer implements Serializer, Deserializer {

	public void marshall(java.lang.String inScopeEncStyle, 
			java.lang.Class javaType, java.lang.Object src,
     			java.lang.Object context, java.io.Writer sink,
			org.apache.soap.util.xml.NSStack nsStack,
			org.apache.soap.util.xml.XMLJavaMappingRegistry xjmr,
			org.apache.soap.rpc.SOAPContext ctx) {

		nsStack.pushScope();

		// ** Java to XML
		String tagname = context.toString();
		System.out.println("Marshalling: " + tagname +": "+ src.toString());

		try {
			sink.write("<" + tagname + " xsi:type=\"xsd:string\">" 
						 + src.toString() + "</" + tagname + ">");
		}
		catch(java.io.IOException e) {
			throw new java.lang.IllegalArgumentException("marshall:IOException");
		}
		finally {
			nsStack.popScope();
		}
	}
	
	public org.apache.soap.util.Bean unmarshall(
			java.lang.String inScopeEncStyle,
			org.apache.soap.util.xml.QName elementType,
			org.w3c.dom.Node src,
			org.apache.soap.util.xml.XMLJavaMappingRegistry xjmr,
			org.apache.soap.rpc.SOAPContext ctx)
		throws java.lang.IllegalArgumentException {

		org.apache.soap.util.Bean result = null;
		org.w3c.dom.Element element = null;
		org.w3c.dom.Node textNode = null;

		try { 
			System.out.print("Unmarshalling string element: " + src.getNodeName());
			int    nodeType = src.getNodeType();
			String nodeName = src.getNodeName();
			if(nodeType!=org.w3c.dom.Node.ELEMENT_NODE) 
			    throw new IllegalArgumentException("unmarshall:invalid node type");
			else
		        element = (org.w3c.dom.Element) src;
		    
			org.w3c.dom.NodeList nl = element.getChildNodes();
			if(nl.getLength()!=1)
				throw new IllegalArgumentException(
					"unmarshall: invalid child list length");
			else {
				textNode = nl.item(0);
				nodeType = textNode.getNodeType();										
			}
			if(nodeType!=org.w3c.dom.Node.TEXT_NODE)
			    throw new IllegalArgumentException(
					"unmarshall: invalid child node type");
		
			String myString = ((org.w3c.dom.Text) textNode).getNodeValue();
			result = new org.apache.soap.util.Bean(String.class, myString);
				}
		catch(IllegalArgumentException e) {
			e.printStackTrace(System.err);
			throw(e);
		}
		return result;
	}
}