package itso.wsad.alma.message;

import java.net.*;

public class MessageClient {

	public static void main(String[] args) {
		try {
			String response = null;
			String filename = "catalog.xml";
			MessageProxy mp = new MessageProxy();
			mp.setEndPoint(new 
				URL("http://localhost:8080/ITSOAdvanced/servlet/messagerouter"));
			response = mp.sendDocument(filename);
			System.out.println("Client: response to sendDocument is: " + response);
		}
		catch( MalformedURLException e ) {
			e.printStackTrace(System.err);
		}
		catch( Exception e ) {
			e.printStackTrace(System.err);
		}
	}
}