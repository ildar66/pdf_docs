package itso.wsad.alma.wscomposed.service;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import itso.wsad.alma.web.PartsMasterViewBean;

public class InquireParts
{
	private DocumentBuilder     builder;
  
	/**
	 * inquireParts - Web Service
	 */
	public org.w3c.dom.Element inquireParts(java.lang.String partNumber)
	{
		//Variables
		PartsMasterViewBean masterViewBean = new PartsMasterViewBean();
		Element result = null;
		try {
			// search local DB
			masterViewBean.setpartNo(partNumber);
			masterViewBean.setDataSourceName("jdbc/ITSOWSAD");
			masterViewBean.execute();
			if ( masterViewBean.first() ) {
				System.out.println("Almaden Auto Result");
				// convert result to XML
				result = convertToXml(masterViewBean);
				return result;
			}
			// nothing found in local Database, look for MightyMotors
			itso.wsad.alma.wsstatic.proxy.InquirePartsProxy proxy =
					new itso.wsad.alma.wsstatic.proxy.InquirePartsProxy();
			result = proxy.inquireParts(partNumber);
			if (result!=null) System.out.println("Mighty Motors Result");
			return result;
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * convertToXml - create XML for a part
	 */
	private org.w3c.dom.Element convertToXml(PartsMasterViewBean masterViewBean) throws Exception
	{
		Document doc = null;
		Element result = null;

		doc = getDocumentBuilder().newDocument();
		result = doc.createElement("InquirePartsResult");
		result.setAttribute("xmlns", "http://www.redbooks.ibm.com/ITSOWSAD/schemas/InquireResults");
		result.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
		result.setAttribute("xsi:schemaLocation", "http://www.redbooks.ibm.com/ITSOWSAD/schemas/InquireResults wsdl/composed/InquireParts.xsd");

		try {
			do {
				result.appendChild(populatePart(doc, masterViewBean));			
			}
			while ( masterViewBean.next() );
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return result;
	}
   
	/**
	 * populatePart - create XML for a part
	 */
	private Element populatePart(Document doc, PartsMasterViewBean masterViewBean) throws Exception {
		Element elPart = doc.createElement("Part");
		try {
			elPart.appendChild( newElement(doc, "ItemNumber",  masterViewBean.getITSO_AAINVENTORY_ITEMNUMBER()) );
			elPart.appendChild( newElement(doc, "Quantity",    masterViewBean.getITSO_AAINVENTORY_QUANTITY()) );
			elPart.appendChild( newElement(doc, "Cost",        masterViewBean.getITSO_AAINVENTORY_COST()) );
			elPart.appendChild( newElement(doc, "Shelf",       masterViewBean.getITSO_AAINVENTORY_SHELF()) );
			elPart.appendChild( newElement(doc, "Location",    masterViewBean.getITSO_AAINVENTORY_LOCATION()) );
			elPart.appendChild( newElement(doc, "PartNumber",  masterViewBean.getITSO_AAPARTS_PARTNUMBER()) );
			elPart.appendChild( newElement(doc, "Name",        masterViewBean.getITSO_AAPARTS_NAME()) );
			elPart.appendChild( newElement(doc, "Description", masterViewBean.getITSO_AAPARTS_DESCRIPTION()) );
			elPart.appendChild( newElement(doc, "Weight",      masterViewBean.getITSO_AAPARTS_WEIGHT()) );
			elPart.appendChild( newElement(doc, "ImageURL",    masterViewBean.getITSO_AAPARTS_IMAGE_URL()) );
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new Exception("Error in DB bean: "+ex.getMessage());
		}
		return elPart;  
	}
	
	/**
	 * newElement - create XML name/value pair
	 */
	private Element newElement(Document doc, String name, String value) {
		Element element = doc.createElement(name);
		element.appendChild( doc.createTextNode(value) );
		return element;
	}

	/**
	 * getDocumentBuilder - share XML document builder
	 */
	private DocumentBuilder getDocumentBuilder() throws Exception {
		if (builder == null) {
			try {
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				builder = factory.newDocumentBuilder();
			} catch (ParserConfigurationException ex) {
				ex.printStackTrace();
				throw new Exception("Error creating document builder: "+ex.getMessage());
			}
		}
		return builder;
	}
}
