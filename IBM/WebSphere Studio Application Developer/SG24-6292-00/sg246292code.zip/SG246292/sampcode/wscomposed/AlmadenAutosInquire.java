package itso.wsad.santa.web;

import javax.servlet.http.HttpServlet;

public class AlmadenAutosInquire extends HttpServlet {

	public void doPost(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response)
		throws javax.servlet.ServletException, java.io.IOException {
			performTask(request, response);
	}

	public void doGet(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response)
		throws javax.servlet.ServletException, java.io.IOException {
			performTask(request, response);
	}

	public void performTask(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response) {

		try {
			response.setContentType("text/html; charset=UTF-8");
			javax.xml.transform.TransformerFactory tFactory = 
				javax.xml.transform.TransformerFactory.newInstance();
			javax.xml.transform.Source xslSource =
				new javax.xml.transform.stream.StreamSource(
					new java.net.URL ("http://localhost:8080/ITSOSanta/InquirePartsResultTable.xsl").openStream());
			javax.xml.transform.Transformer transformer = 
				tFactory.newTransformer(xslSource);
			java.io.PrintWriter out = response.getWriter();
				
		// For SOAP over HTTP	
			itso.wsad.santa.wsstatic.proxy.InquireAlmaPartsProxy proxy =
				new itso.wsad.santa.wsstatic.proxy.InquireAlmaPartsProxy();
			org.w3c.dom.Element result = proxy.inquireParts
				((String)request.getSession().getAttribute("partNo"));
			javax.xml.transform.Source xmlSource = new javax.xml.transform.dom.DOMSource(result);
			
			transformer.transform(xmlSource,
						new javax.xml.transform.stream.StreamResult(out));				
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

}
