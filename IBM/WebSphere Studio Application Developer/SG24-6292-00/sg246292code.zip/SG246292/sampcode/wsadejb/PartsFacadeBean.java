package itso.wsad.mighty.ejb;

import javax.naming.*;
import javax.ejb.*;
import java.util.*;
import itso.wsad.mighty.bean.PartInventory;

/**
 * Bean implementation class for Enterprise Bean: PartsFacade
 */
public class PartsFacadeBean implements javax.ejb.SessionBean {
	// Home cache
	private MmpartsHome partsHome; 
	
	private javax.ejb.SessionContext mySessionCtx;
	/**
	 * getSessionContext
	 */
	public javax.ejb.SessionContext getSessionContext() {
		return mySessionCtx;
	}
	/**
	 * setSessionContext
	 */
	public void setSessionContext(javax.ejb.SessionContext ctx) {
		mySessionCtx = ctx;
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbCreate
	 */
	public void ejbCreate() throws javax.ejb.CreateException {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() {
	}
	
	/**
	 * getPartsHome - share home of part
	 */
	private MmpartsHome getPartsHome() {
		if (partsHome == null) {
			try {
				InitialContext ic = new InitialContext();
				//Object objref = ic.lookup("itso/wsad/mighty/Mmparts");
				Object objref = ic.lookup("java:comp/env/ejb/Mmparts");
				partsHome = (MmpartsHome)javax.rmi.PortableRemoteObject.narrow(objref,MmpartsHome.class);
			} catch (NamingException ex) {
				ex.printStackTrace();
				throw new EJBException("Error looking up MmpartsHome: "+ex.getMessage());
			}
		}
		return partsHome;
	}
	
	/**
	 *inquireParts - find matching parts and return as Vector of beans
	 */
	public Vector inquireParts(String partNumber) {
		Vector          resultVector = new Vector();
		PartInventory   partInv;
		Mmparts         part = null;
		Mminventory     inv  = null;
		try {
			part = getPartsHome().findByPrimaryKey( new MmpartsKey(partNumber) );
			Enumeration items = part.getMminventory();
			while (items.hasMoreElements()) {
				inv = (Mminventory)javax.rmi.PortableRemoteObject.narrow
					    (items.nextElement(), Mminventory.class);
				partInv = new itso.wsad.mighty.bean.PartInventory();
				partInv.setPartNumber ( partNumber );
				partInv.setName       ( part.getName() ); 
				partInv.setDescription( part.getDescription() );
				partInv.setWeight     ( part.getWeight().doubleValue() );
				partInv.setImageUrl   ( part.getImage_url() );
				partInv.setItemNumber ( inv.getItemnumber() );
				partInv.setQuantity   ( inv.getQuantity().intValue() );
				partInv.setCost       ( inv.getCost() );
				partInv.setShelf      ( inv.getShelf() );
				partInv.setLocation   ( inv.getLocation() );
				resultVector.addElement(partInv);
			}
		} catch (FinderException ex) {
			System.out.println("Cannot find part: "+partNumber);
			ex.printStackTrace();
		} catch (java.rmi.RemoteException ex) {
			ex.printStackTrace();
		}
		if (resultVector.size() == 0) return null;
		else return resultVector;
	}
	/**
	 * inquirePartsArray - find matching parts and return as array of beans
	 */
	public PartInventory[] inquirePartsArray(String partNumber) {
		Vector resultVector = inquireParts(partNumber);
		if (resultVector == null) return null;
		int noResults = resultVector.size();
		PartInventory[] result = new PartInventory[noResults];
		for (int i=0; i < noResults; i++) {
			result[i] = (PartInventory)resultVector.elementAt(i);
		}
		return result;
	}
	
}
