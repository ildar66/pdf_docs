package itso.wsad.mighty.bean;

import java.io.Serializable;

public class PartInventory implements Serializable {
	protected java.lang.String     partNumber;
	protected java.lang.String     name;
	protected java.lang.String     description;
	protected double               weight;
	protected java.lang.String     imageUrl;
	protected java.lang.Long       itemNumber;
	protected int                  quantity;
	protected java.math.BigDecimal cost;
	protected java.lang.String     shelf;
	protected java.lang.String     location;

	/**
	 * Constructor for PartInventory
	 */
	public PartInventory() {
		super();
	}

	/**
	 * Gets the partNumber
	 * @return Returns a java.lang.String
	 */
	public java.lang.String getPartNumber() {
		return partNumber;
	}
	/**
	 * Sets the partNumber
	 * @param partNumber The partNumber to set
	 */
	public void setPartNumber(java.lang.String partNumber) {
		this.partNumber = partNumber;
	}

	/**
	 * Gets the name
	 * @return Returns a java.lang.String
	 */
	public java.lang.String getName() {
		return name;
	}
	/**
	 * Sets the name
	 * @param name The name to set
	 */
	public void setName(java.lang.String name) {
		this.name = name;
	}

	/**
	 * Gets the description
	 * @return Returns a java.lang.String
	 */
	public java.lang.String getDescription() {
		return description;
	}
	/**
	 * Sets the description
	 * @param description The description to set
	 */
	public void setDescription(java.lang.String description) {
		this.description = description;
	}

	/**
	 * Gets the weight
	 * @return Returns a double
	 */
	public double getWeight() {
		return weight;
	}
	/**
	 * Sets the weight
	 * @param weight The weight to set
	 */
	public void setWeight(double weight) {
		this.weight = weight;
	}

	/**
	 * Gets the imageUrl
	 * @return Returns a java.lang.String
	 */
	public java.lang.String getImageUrl() {
		return imageUrl;
	}
	/**
	 * Sets the imageUrl
	 * @param imageUrl The imageUrl to set
	 */
	public void setImageUrl(java.lang.String imageUrl) {
		this.imageUrl = imageUrl;
	}

	/**
	 * Gets the itemNumber
	 * @return Returns a java.lang.Long
	 */
	public java.lang.Long getItemNumber() {
		return itemNumber;
	}
	/**
	 * Sets the itemNumber
	 * @param itemNumber The itemNumber to set
	 */
	public void setItemNumber(java.lang.Long itemNumber) {
		this.itemNumber = itemNumber;
	}

	/**
	 * Gets the quantity
	 * @return Returns a int
	 */
	public int getQuantity() {
		return quantity;
	}
	/**
	 * Sets the quantity
	 * @param quantity The quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/**
	 * Gets the cost
	 * @return Returns a java.math.BigDecimal
	 */
	public java.math.BigDecimal getCost() {
		return cost;
	}
	/**
	 * Sets the cost
	 * @param cost The cost to set
	 */
	public void setCost(java.math.BigDecimal cost) {
		this.cost = cost;
	}

	/**
	 * Gets the shelf
	 * @return Returns a java.lang.String
	 */
	public java.lang.String getShelf() {
		return shelf;
	}
	/**
	 * Sets the shelf
	 * @param shelf The shelf to set
	 */
	public void setShelf(java.lang.String shelf) {
		this.shelf = shelf;
	}

	/**
	 * Gets the location
	 * @return Returns a java.lang.String
	 */
	public java.lang.String getLocation() {
		return location;
	}
	/**
	 * Sets the location
	 * @param location The location to set
	 */
	public void setLocation(java.lang.String location) {
		this.location = location;
	}
	public String toString() {
		return("Part="+partNumber+"/"+name+"/"+weight+
		       "/item/"+itemNumber+"/"+quantity+"/"+cost+"/"+shelf+"/"+location);
	}
}

