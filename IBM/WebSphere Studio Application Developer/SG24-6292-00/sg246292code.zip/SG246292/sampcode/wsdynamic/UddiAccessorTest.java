// change XXXXXXXX according to your business entity and WSDL file
// the redbook uses ITSOSJC as value

package itso.wsad.alma.wsdynamic.uddi;
import java.util.Vector;

public class UddiAccessorTest {

	public static void main(String[] args) {
		String provider = "ITSO - Auto Parts Association (XXXXXXXX)";
		String service  = "http://www.redbooks.ibm.com/XXXXXXXX/definitions/InquirePartsRemoteInterface";
		UddiAccessor uddi = new UddiAccessor();
		Vector result = uddi.findServiceImplementations(provider, service);
		for (int i=0; i < result.size(); i++) {
			System.out.println("Result="+(String)result.elementAt(i));
		}
	}
}

