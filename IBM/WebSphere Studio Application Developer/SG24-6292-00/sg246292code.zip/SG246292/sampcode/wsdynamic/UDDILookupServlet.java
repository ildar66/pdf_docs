// change ITSOSJC according to your business entity and WSDL file
// in the provider and service fields

package itso.wsad.alma.web;

import javax.servlet.http.HttpServlet;
import javax.xml.transform.*;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.dom.DOMSource;
import org.w3c.dom.Element;
import itso.wsad.alma.wsdynamic.proxy.InquirePartsProxy;
import itso.wsad.alma.wsdynamic.uddi.UddiAccessor;
import java.util.Vector;

public class UDDILookupServlet extends HttpServlet {
	
	String provider = "ITSO - Auto Parts Association (ITSOSJC)";
	String service  = "http://www.redbooks.ibm.com/ITSOSJC/definitions/InquirePartsRemoteInterface";

	public void doPost(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response)
		throws javax.servlet.ServletException, java.io.IOException {
			doGet(request, response);
	}

	public void doGet(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response)
		throws javax.servlet.ServletException, java.io.IOException {
		try {
			response.setContentType("text/html; charset=UTF-8");  
			java.io.PrintWriter out = response.getWriter();
			out.println("<HTML><HEAD><TITLE>Inventory Inquiry Results</TITLE></HEAD><BODY BGCOLOR=\"#ffffff\">");
			out.println("<CENTER>");
			out.println("<FONT COLOR=\"#0000ff\"><IMG border=\"0\" height=\"33\" src=\"images/autopartsassociation.gif\" width=400\"><CENTER><H1>Parts Inventory Inquiry</H1></CENTER></FONT>");
			out.println("</CENTER>");
	
			TransformerFactory tFactory = TransformerFactory.newInstance();
			Source xslSource = new StreamSource(
				new java.net.URL("http://localhost:8080/ITSOAlma/stylesheets/dynamic/InquirePartsResultTable.xsl").openStream() );
			Transformer transformer = tFactory.newTransformer(xslSource);
			InquirePartsProxy proxy = new InquirePartsProxy();
			String partNumber = (String)request.getSession().getAttribute("partNo");
			
			UddiAccessor uddi = new UddiAccessor();
			
			Vector endpoints = uddi.findServiceImplementations(provider, service);
			for (int i=0; i < endpoints.size(); i++) {
				String endpoint = (String)endpoints.elementAt(i);
				proxy.setEndPoint( new java.net.URL(endpoint) );
				out.println("<h2>"+endpoint+"</h2>");
			 	try {
			 		Element result = proxy.inquireParts(partNumber);
					Source xmlSource = new DOMSource(result);
					transformer.transform(xmlSource, new StreamResult(out));
				} catch (Exception e) {
					out.println("<FONT COLOR=\"#0000ff\"><CENTER><H3>Web Service at this URL not available.</H3></CENTER></FONT>");
				}
			}
			out.println("</BODY></HTML>");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
