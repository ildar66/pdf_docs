package itso.wsad.mighty.xml;

import org.w3c.dom.*;
import javax.xml.parsers.*;

public class XMLParserTest {

	public static void main(String[] args) {
		Element returnResult = null;
		
		try {
			String filename = "InquireParts.xml"; 
			DocumentBuilderFactory bf = DocumentBuilderFactory.newInstance();
			bf.setNamespaceAware(true);
			DocumentBuilder xmlParser = bf.newDocumentBuilder();
			Document xmlDoc = xmlParser.parse(filename);
			String result = domWriter(xmlDoc.getDocumentElement(), new StringBuffer());
			System.out.println("Content of XML file is: " + result);
		}
		catch(Exception e) {
			System.err.println("XML exception has occured:");
			e.printStackTrace(System.err);
		}
	}
	
	public static java.lang.String domWriter(Node node, StringBuffer buffer) {
		if ( node == null ) 
			return "";

			int type = node.getNodeType();
			switch( type ) {
			case Node.DOCUMENT_NODE: {
				buffer.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
				domWriter(((org.w3c.dom.Document)node).getDocumentElement(), 
					buffer);
				break;
			}
			case Node.ELEMENT_NODE: {
				buffer.append("<" + node.getNodeName());
				NamedNodeMap attrs = node.getAttributes();
				int length = (attrs != null) ? attrs.getLength() : 0;
					for(int i = 0; i < length; i++) {
					Attr attr = (org.w3c.dom.Attr) attrs.item(i);
					buffer.append(" " + attr.getNodeName() + "=\"" );
					buffer.append(attr.getNodeValue() + "\"");
				}
				buffer.append(">"); 
				NodeList children = node.getChildNodes();
				if( children != null) {
					int len = children.getLength();
					for( int i = 0; i < len; i++) {									
						domWriter(children.item(i),buffer);
					}
				}
				buffer.append("</" + node.getNodeName() + ">");
				break;
			}
			case Node.CDATA_SECTION_NODE: 
			case Node.TEXT_NODE:{
				buffer.append(node.getNodeValue());
				break;
			}
		}
		return buffer.toString();
	}		
}