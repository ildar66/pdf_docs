package itso.wsad.dealer.ejb;

public class InsufficientStockException extends Exception  {
	public InsufficientStockException() {
		super();
	}
	public InsufficientStockException(String s) {
		super(s);
	}
}