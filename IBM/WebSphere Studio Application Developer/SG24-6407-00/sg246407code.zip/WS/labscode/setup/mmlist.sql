-- IBM ITSO SG24-6292 Sample Application

CONNECT TO ITSOWSAD;

SELECT partnumber, substr(name,1,15) as Name, decimal(weight,6,2) as Weight, substr(description,1,40) as Description FROM ITSO.MMPARTS;
SELECT substr(char(itemnumber),1,10) as Itemnumber, partnumber, quantity, cost, shelf, substr(location,1,25) as Location FROM ITSO.MMINVENTORY;

-- Close the connection
CONNECT RESET;