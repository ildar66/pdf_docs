package itso.wsad.wsdynamic;

import javax.servlet.http.HttpServlet;
import javax.xml.transform.*;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.dom.DOMSource;
import org.w3c.dom.Element;
import itso.wsad.wsclient.proxy.InquirePartsProxy;
import java.util.Vector;

public class DynamicServlet extends HttpServlet {

	public void doPost(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response) {
		try {
			doGet(request, response);
		} catch (Throwable e) {}
	}
	
	public void doGet(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response) {
		try {

			response.setContentType("text/html; charset=UTF-8");  
			java.io.PrintWriter out = response.getWriter();
			out.println("<HTML><HEAD><TITLE>Dynamic Part Inventory Inquiry Results</TITLE></HEAD><BODY BGCOLOR=\"#ffffcc\">");
			out.println("<H1>Dynamic Part Inventory Inquiry Results</H1>");
	
			TransformerFactory tFactory = TransformerFactory.newInstance();
			Source xslSource = new StreamSource(
				new java.net.URL("http://localhost:8080/ItsoWsClientWeb/wsdynamic/DynamicPartInventory.xsl").openStream() );
			Transformer transformer = tFactory.newTransformer(xslSource);
			InquirePartsProxy proxy = new InquirePartsProxy();
			String partNumber = (String)request.getParameter("partNumber");
			
			UddiServiceImplementer uddi = new UddiServiceImplementer();
			Vector endpoints = uddi.getImplementers("ITSO","http://www.redbooks.ibm.com/ITSOWSAD/definitions/InquirePartsRemoteInterface");
			for (int i=0; i < endpoints.size(); i++) {
				String endpoint = (String)endpoints.elementAt(i);
				out.println("<h2>"+endpoint+"</h2>");
				proxy.setEndPoint( new java.net.URL(endpoint) );
				try {
					Element result = proxy.retrievePartInventory_(partNumber);
					Source xmlSource = new DOMSource(result);
					transformer.transform(xmlSource, new StreamResult(out));
				} catch (Exception e) {
					out.println("<FONT COLOR=\"#0000ff\"><CENTER><H3>No results</H3></CENTER></FONT>");
				}
			}
			out.println("</BODY></HTML>");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}