package itso.wsad.wsdynamic;

import java.util.*;
import com.ibm.uddi.*;
import com.ibm.uddi.client.*;
import com.ibm.uddi.datatype.tmodel.*;
import com.ibm.uddi.datatype.*;
import com.ibm.uddi.response.*;
import com.ibm.uddi.util.*;
import com.ibm.uddi.datatype.binding.*;

public class UddiAccessor {

  public UddiAccessor() {
		super();
  }
  
  public Vector findServiceImplementations(String provider, String service) {
  	
	UDDIProxy proxy   = new UDDIProxy();
	// IBM Test Registry
	String inquiryAPI = "http://www-3.ibm.com/services/uddi/testregistry/inquiryapi";
	String publishAPI = "http://www-3.ibm.com/services/uddi/testregistry/protect/publishapi";
	// IBM Registry Preview
	//String inquiryAPI = "http://localhost/services/uddi/inquiryAPI";
	//String publishAPI = "http://localhost/services/uddi/publishAPI";
	Vector result     = new Vector();	
		
	try {
		proxy.setInquiryURL(inquiryAPI);
		proxy.setPublishURL(publishAPI);
		
		TModelBag tmb = new TModelBag();
		
		// find tmodel for the service name
		TModelList tml = proxy.find_tModel(service, null, 0);
		TModelInfos tmis = tml.getTModelInfos();
		Vector v1 = tmis.getTModelInfoVector();
		for (int i1=0; i1 < v1.size(); i1++) {
			TModelInfo tmi = (TModelInfo)v1.elementAt(i1);
			String tmk = tmi.getTModelKey();
			System.out.println("TModel="+tmi.getNameString()+" "+tmk);
 			Vector tmbv = new Vector();
			tmb.setTModelKeyVector(tmbv);
			TModelKey tmKey = new TModelKey(tmk);
			tmbv.addElement(tmKey);
		}
        	
		// find business by provider
		BusinessList bl = proxy.find_business(provider, null, 0);
		BusinessInfos bis = bl.getBusinessInfos();
		Vector v2 = bis.getBusinessInfoVector();
        	
		for (int i2 = 0; i2 < v2.size(); i2++) {
			BusinessInfo bi = (BusinessInfo)v2.elementAt(i2);
			String bkey = bi.getBusinessKey();
			System.out.println("  Business="+bi.getNameString()+" "+bkey);
        		
			// find service of business
			ServiceInfos sis = bi.getServiceInfos();
			Vector v3 = sis.getServiceInfoVector();
       		
			for (int i3 = 0; i3 < v3.size(); i3++) {
				ServiceInfo si = (ServiceInfo)v3.elementAt(i3);
				String skey = si.getServiceKey();
				System.out.println("    Service="+si.getNameString()+" "+skey);
       			
				// find binding of service that implements tmodel
				BindingDetail bd = proxy.find_binding(null, skey, tmb, 0);
				Vector v4 = bd.getBindingTemplateVector();
				for (int i4 = 0; i4 < v4.size(); i4++) {
  					BindingTemplate bt = (BindingTemplate)v4.elementAt(i4);
       			
					// get access point
					AccessPoint accessPoint = bt.getAccessPoint();
					System.out.println("      AccessPoint="+accessPoint.getText());
						
					TModelInstanceDetails tid = bt.getTModelInstanceDetails();
					Vector v5 = tid.getTModelInstanceInfoVector();
					for (int i5 = 0; i5 < v5.size(); i5++) {
						TModelInstanceInfo tii = (TModelInstanceInfo)v5.elementAt(i5);
						InstanceDetails inst = tii.getInstanceDetails();
						OverviewDoc od = inst.getOverviewDoc();
						OverviewURL ou = od.getOverviewURL();
						System.out.println("      WSDL="+ou.getText());
						
						//javax.wsdl.Definition wd = com.ibm.wsdl.xml.WSDLReader.readWSDL( new java.net.URL(ou.getText()),"" );
					} 
					
					// add access point to result
					result.addElement(accessPoint.getText());
				}
			}
		}	        	
		System.out.println("END");
	}
	catch (Exception e) { e.printStackTrace(); };
	return result;
  }
  
}

