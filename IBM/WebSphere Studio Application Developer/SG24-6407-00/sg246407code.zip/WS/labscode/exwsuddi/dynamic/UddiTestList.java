package itso.wsad.wsdynamic;

import java.util.Vector;

public class UddiTestList {

	public static void main(String[] args) {
		String provider = "ITSO";
		String service  = "http://www.redbooks.ibm.com/ITSOWSAD/definitions/InquirePartsRemoteInterface";
		UddiServiceImplementer uddi = new UddiServiceImplementer();
		Vector result = uddi.getImplementers(provider, service);
		for (int i=0; i < result.size(); i++) {
			System.out.println("Result="+(String)result.elementAt(i));
		}
	}
}

