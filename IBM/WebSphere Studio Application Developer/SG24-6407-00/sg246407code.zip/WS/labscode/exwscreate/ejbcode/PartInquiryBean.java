package itso.wsad.manu.facade; 

import javax.naming.*;
import javax.ejb.*;
import java.rmi.*;
import javax.rmi.*;
import java.util.*;
import itso.wsad.manu.ejb.*;
import itso.wsad.manu.beans.PartInventory;

/**
 * Bean implementation class for Enterprise Bean: PartInquiry
 */
public class PartInquiryBean implements javax.ejb.SessionBean {
	private MmPartHome      partHome;
	private javax.ejb.SessionContext mySessionCtx;
	/**
	 * getSessionContext
	 */
	public javax.ejb.SessionContext getSessionContext() {
		return mySessionCtx;
	}
	/**
	 * setSessionContext
	 */
	public void setSessionContext(javax.ejb.SessionContext ctx) {
		mySessionCtx = ctx;
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbCreate
	 */
	public void ejbCreate() throws javax.ejb.CreateException {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() {
	}
	
	/**
	 * getPartHome - share HOME of part
	 */
	private MmPartHome getPartHome() {
		if (partHome == null) {
			try {
				InitialContext initCtx = new InitialContext();
				//Object objref = initCtx.lookup("itso/wsad/manu/MmPart");
				Object objref = initCtx.lookup("java:comp/env/ejb/MmPart");
				partHome = (MmPartHome)PortableRemoteObject.narrow(objref,MmPartHome.class);
			} catch (NamingException ex) {
				ex.printStackTrace();
				throw new EJBException("Error looking up MmPartHome: "+ex.getMessage());
			}
		}
		return partHome;
	}
	
	/**
	 * retrievePartInventory - find matching parts and return as Vector of beans
	 */
	public Vector retrievePartInventory(String partNumber) {
		Vector          resultVector = new Vector();
		PartInventory   bean;
		MmPart          part = null;
		MmInventory     inv  = null;
		try {
			part = getPartHome().findByPrimaryKey(partNumber);
			Enumeration items = part.getStocks();
			while (items.hasMoreElements()) {
				inv = (MmInventory)javax.rmi.PortableRemoteObject.narrow
					    (items.nextElement(), MmInventory.class);
				bean = new itso.wsad.manu.beans.PartInventory();
				bean.setPartNumber ( partNumber );
				bean.setName       ( part.getName() ); 
				bean.setDescription( part.getDescription() );
				bean.setWeight     ( part.getWeight() );
				bean.setImageUrl   ( part.getImageUrl() );
				bean.setItemNumber ( inv.getItemNumber() );
				bean.setQuantity   ( inv.getQuantity() );
				bean.setCost       ( inv.getCost() );
				bean.setShelf      ( inv.getShelf() );
				bean.setLocation   ( inv.getLocation() );
				resultVector.addElement(bean);
			}
		} catch (FinderException ex) {
			System.out.println("Cannot find part: "+partNumber);
			ex.printStackTrace();
		} catch (java.rmi.RemoteException ex) {
			ex.printStackTrace();
		}
		if (resultVector.size() == 0) return null;
		else return resultVector;
	}
	/**
	 * retrievePartInventoryArray - find matching parts and return as array of beans
	 */
	public PartInventory[] retrievePartInventoryArray(String partNumber) {
		Vector resultVector = retrievePartInventory(partNumber);
		if (resultVector == null) return null;
		int noResults = resultVector.size();
		PartInventory[] result = new PartInventory[noResults];
		for (int i=0; i < noResults; i++) {
			result[i] = (PartInventory)resultVector.elementAt(i);
		}
		return result;
	}

}
