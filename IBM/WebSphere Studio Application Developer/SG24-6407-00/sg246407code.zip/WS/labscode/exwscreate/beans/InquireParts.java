package itso.wsad.manu.beans;

import javax.naming.*;
import javax.ejb.*;
import java.rmi.*;
import javax.rmi.*;
import javax.xml.parsers.*;
import java.util.Enumeration;
import java.util.Vector;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import itso.wsad.manu.facade.*;
import itso.wsad.manu.beans.*;

public class InquireParts {

	private PartInquiryHome partInquiryHome;
	private DocumentBuilder builder;

	/**
	 * Constructor for InquireParts
	 */
	public InquireParts() {
		super();
	}
	
	/**
	 * retrievePartInventory - find matching parts and return as XML
	 */
	public org.w3c.dom.Element retrievePartInventory(String partNumber) throws Exception {
		Element  result = null;
		Document doc    = null;
		DocumentBuilder builder;
		PartInquiry     partInquiry;
		
		doc = getDocumentBuilder().newDocument();
		result = doc.createElement("PartInventory");
		result.setAttribute("xmlns", "http://www.redbooks.ibm.com/ITSOWSAD/schemas/PartInventory");
		result.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
		result.setAttribute("xsi:schemaLocation", "http://www.redbooks.ibm.com/ITSOWSAD/schemas/PartInventory wsdl/PartInventory.xsd");

		try {
			partInquiry = getPartInquiryHome().create();
			Vector resultbeans = partInquiry.retrievePartInventory(partNumber);
			for (int i=0; i<resultbeans.size(); i++) {
				result.appendChild( populatePart(doc, (PartInventory)resultbeans.elementAt(i)) );
			}
		} catch (CreateException ex) {
			System.out.println("Cannot find part: "+partNumber);
			ex.printStackTrace();
			throw new Exception("Error finding part: "+ex.getMessage());	
		} catch (java.rmi.RemoteException ex) {
			ex.printStackTrace();
			throw new Exception("Error with session EJB: "+ex.getMessage());	
		}
		return result;
	}

	/**
	 * populatePart - create XML for a part
	 */
	private Element populatePart(Document doc, PartInventory bean) throws org.w3c.dom.DOMException {
		Element elPart = doc.createElement("Part");
		elPart.appendChild( newElement(doc, "ItemNumber",  bean.getItemNumber().toString()) );
		elPart.appendChild( newElement(doc, "Quantity",    (new Integer(bean.getQuantity())).toString()) );
		elPart.appendChild( newElement(doc, "Cost",        bean.getCost().toString()) );
		elPart.appendChild( newElement(doc, "Shelf",       bean.getShelf()) );
		elPart.appendChild( newElement(doc, "Location",    bean.getLocation()) );
		elPart.appendChild( newElement(doc, "PartNumber",  bean.getPartNumber()) );
		elPart.appendChild( newElement(doc, "Name",        bean.getName()) );
		elPart.appendChild( newElement(doc, "Description", bean.getDescription()) );
		elPart.appendChild( newElement(doc, "Weight",      (new Double(bean.getWeight())).toString()) );
		elPart.appendChild( newElement(doc, "ImageURL",    bean.getImageUrl()) );
		return elPart;  
	}
	
	/**
	 * newElement - create XML name/value pair
	 */
	private Element newElement(Document doc, String name, String value) {
		Element element = doc.createElement(name);
		element.appendChild( doc.createTextNode(value) );
		return element;
	}

	/**
	 * getPartInquiryHome - share HOME of session bean
	 */
	private PartInquiryHome getPartInquiryHome() throws Exception {
		if (partInquiryHome == null) {
			try {
				InitialContext initCtx = new InitialContext();
				Object objref = initCtx.lookup("itso/wsad/manu/PartInquiry");
				//Object objref = initCtx.lookup("java:comp/env/ejb/PartInquiry");
				partInquiryHome = (PartInquiryHome)PortableRemoteObject.narrow(objref,PartInquiryHome.class);
			} catch (NamingException ex) {
				ex.printStackTrace();
				throw new Exception("Error looking up PartInquiryHome: "+ex.getMessage());
			}
		}
		return partInquiryHome;
	}

	/**
	 * getDocumentBuilder - share XML document builder
	 */
	private DocumentBuilder getDocumentBuilder() throws Exception {
		if (builder == null) {
			try {
				DocumentBuilderFactory factory = new org.apache.xerces.jaxp.DocumentBuilderFactoryImpl();
				builder = factory.newDocumentBuilder();
			} catch (ParserConfigurationException ex) {
				ex.printStackTrace();
				throw new Exception("Error creating document builder: "+ex.getMessage());
			}
		}
		return builder;
	}

}
