package itso.wsad.manu.beans;

import java.io.Serializable;

public class PartInventory implements Serializable {
	protected java.lang.String     partNumber;
	protected java.lang.String     name;
	protected java.lang.String     description;
	protected double               weight;
	protected java.lang.String     imageUrl;
	protected java.lang.Long       itemNumber;
	protected int                  quantity;
	protected java.math.BigDecimal cost;
	protected java.lang.String     shelf;
	protected java.lang.String     location;

	public PartInventory() {
		super();
	}
	public java.lang.String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(java.lang.String partNumber) {
		this.partNumber = partNumber;
	}
	public java.lang.String getName() {
		return name;
	}
	public void setName(java.lang.String name) {
		this.name = name;
	}
	public java.lang.String getDescription() {
		return description;
	}
	public void setDescription(java.lang.String description) {
		this.description = description;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public java.lang.String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(java.lang.String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public java.lang.Long getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(java.lang.Long itemNumber) {
		this.itemNumber = itemNumber;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public java.math.BigDecimal getCost() {
		return cost;
	}
	public void setCost(java.math.BigDecimal cost) {
		this.cost = cost;
	}
	public java.lang.String getShelf() {
		return shelf;
	}
	public void setShelf(java.lang.String shelf) {
		this.shelf = shelf;
	}
	public java.lang.String getLocation() {
		return location;
	}
	public void setLocation(java.lang.String location) {
		this.location = location;
	}
	public String toString() {
		return("Part="+partNumber+"/"+name+"/"+weight+
		       "/item/"+itemNumber+"/"+quantity+"/"+cost+"/"+shelf+"/"+location);
	}
}

