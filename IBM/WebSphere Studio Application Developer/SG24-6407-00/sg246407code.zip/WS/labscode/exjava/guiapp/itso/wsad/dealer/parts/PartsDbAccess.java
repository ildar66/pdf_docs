package itso.wsad.dealer.parts;

import com.ibm.db.*;
import com.ibm.db.base.*;
import com.ibm.ivj.db.uibeans.*;
public class PartsDbAccess extends DatabaseAccess {
public static com.ibm.db.DatabaseConnection conn() throws java.lang.Throwable, com.ibm.db.DataException {
  com.ibm.db.DatabaseConnection connection = null;
  try{ 
    connection = new com.ibm.db.DatabaseConnection();
    connection.setConnectionAlias("itso.wsad.dealer.parts.PartsDbAccess.conn");
    connection.setDriverName("COM.ibm.db2.jdbc.app.DB2Driver");
    connection.setDataSourceName("jdbc:db2:itsowsad");
    connection.setUserID("");
    connection.setPromptUID(false);
    connection.setAutoCommit(true);
    connection.setPassword("");
  }
  catch(com.ibm.db.DataException e){throw e;}
  catch(java.lang.Throwable e){throw e;}
  return connection;
}
public static com.ibm.db.StatementMetaData listParts() throws java.lang.Throwable {
  String name = "itso.wsad.dealer.parts.PartsDbAccess.listParts";
  String statement = "SELECT ITSO.AAPARTS.PARTNUMBER, ITSO.AAPARTS.NAME, ITSO.AAPARTS.WEIGHT, ITSO.AAPARTS.IMAGE_URL FROM ITSO.AAPARTS WHERE ( ( ITSO.AAPARTS.NAME like '%'||:PARTIALNAME||'%' ) ) ORDER BY ITSO.AAPARTS.WEIGHT";

  StatementMetaData aSpec = null;
  try{
    aSpec = new com.ibm.db.StatementMetaData();
    aSpec.setName(name);
    aSpec.setSQL(statement);
    aSpec.addTable("ITSO.AAPARTS");
    aSpec.addColumn("AAPARTS.PARTNUMBER", 1,1);
    aSpec.addColumn("AAPARTS.NAME", 1,1);
    aSpec.addColumn("AAPARTS.WEIGHT", 8,8);
    aSpec.addColumn("AAPARTS.IMAGE_URL", 12,12);
    aSpec.addParameter("PARTIALNAME", 1, 1);
    // user code begin {1} 
    // user code end {1}
  }
  catch(java.lang.Throwable e){
    // user code begin {2} 
    // user code end {2}
    throw e;
  }
  return aSpec;
/*V2.0
**start of SQL Assist data**
504b030414g08g08g32a4142bgggggggggggg0cggg6275696c64657220646174618593cb4ac3401440
6f9206118b505a7425b8711b6626e923761521d44053a50fbbe82264518b528ad6a908822b3fc7fe8cdf20880bffc1dc44a1
33577431599c9c99fb9a79f9047bb584da64d2bd4eef53679e2e66ce402eaf16b3b688b7d7cfe26d6c023cdcgc06126567f
f1d6af17ef1f078f9d1fcf9460798c4b30f8ea169ec0fc668232db65227125ec45c3c1991304e7417f3870a238e884c9a8df
25aa905055d47118754e87c4cb025514af17c421b198847dc5c26f6f149f84fd4d774bb056c2d0d692e7cc455ade3c431104
f351b02fd3f9dd54f9e315e10da6f9f59c3635fa7718cbcf1beb6d32a391ad23e5181f5b8d604711eb12807802c12ec11c41
856086a0a6a4e4d2942cce04b9133cf798d69bbcde7f072d58033d53e84df41097c8c845d1f3925caea6da7c9bc57ccbc718
2c0abafa5eab8579929d59f52e5e5f930b82b1d616a1f405f845b506ff02504b0708347d92805201gg8b03gg504b0102
14g14g08g08g32a4142b347d92805201gg8b03gg0cggggggggggggggggg6275696c64657220
64617461504b0506gggg01g01g3aggg8c01gggg
**end of SQL Assist data**/
}
}
