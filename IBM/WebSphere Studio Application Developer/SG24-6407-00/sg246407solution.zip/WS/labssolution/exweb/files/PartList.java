package itso.wsad.dealer.web;

import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Vector;
import java.io.PrintWriter;
import java.sql.*;

public class PartList extends HttpServlet {

	public void init() throws javax.servlet.ServletException {
	}

	public void doPost(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response)
		throws javax.servlet.ServletException, java.io.IOException {
			doGet(request,response);
	}

	public void doGet(
		javax.servlet.http.HttpServletRequest request,
		javax.servlet.http.HttpServletResponse response)
		throws javax.servlet.ServletException, java.io.IOException {
		try {
			String resultPage = "/PartList.jsp";
			String partialName = request.getParameter("partialName");
			Vector partListResult = new Vector();
			getResults(partialName, partListResult);
			request.setAttribute("partListResult", partListResult);
			//Forward the request to the next page
        	RequestDispatcher dispatch = request.getRequestDispatcher(resultPage);
        	dispatch.forward(request, response);
		} catch (Throwable e) {
			try {
				String message = e.getLocalizedMessage();
				PrintWriter out = response.getWriter();
				out.println("<html><body>Error: "+message+"</body><html>");
				e.printStackTrace();
			} catch (Exception ex) {}
		}
	}
	
	public void getResults(String partialName, Vector partList) throws Exception {
		String dbtab = "aaparts";
		// connect to database
		Connection con = null;
			Class.forName("COM.ibm.db2.jdbc.app.DB2Driver").newInstance();
			con = DriverManager.getConnection("jdbc:db2:itsowsad","db2admin","db2admin"); 
	
		// retrieve parts
		Statement stmt = null;
		ResultSet rs   = null;
		String select = "SELECT * FROM itso." +dbtab+ " WHERE NAME LIKE '%"+partialName+"%'";
			stmt = con.createStatement();
			rs = stmt.executeQuery(select);
			while (rs.next()) {
				String row[] = new String[5];
				partList.addElement(row);
				row[0] = rs.getString("partNumber");
				row[1] = rs.getString("name");
				row[2] = rs.getString("description");
				row[3] = (new Double(rs.getDouble("weight"))).toString();
				row[4] = rs.getString("image_url");
			}
			stmt.close();
			con.close();
	}


}
