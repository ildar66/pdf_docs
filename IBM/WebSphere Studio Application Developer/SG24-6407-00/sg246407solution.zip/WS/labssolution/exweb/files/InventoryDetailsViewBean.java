
package itso.wsad.dealer.dbapp;
/**************************************************************
*Description - Inventory Details View Bean
* 
* An HTML View Bean wrappers your data so that you can capture the 
* output and make it HTML friendly
*/
 
// Imports
import java.io.*;
import com.ibm.db.beans.*;
import java.sql.Types;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

public class InventoryDetailsViewBean {
   // ConnectionSpec
   protected static DBConnectionSpec connectionSpec = null;

   //Variables
   protected DBSelect detailsViewDBBean = null;

   protected String dvUsername = "";
   protected String dvPassword = "";
   protected String dvDataSourceName = "";
  
   protected String inquantity1;  
   protected String inITSO_MMPARTS_PARTNUMBER3;  
   protected String inITSO_MMINVENTORY_ITEMNUMBER3;

   //Constants
   protected static final String SQL_STRING = "SELECT ITSO.MMPARTS.PARTNUMBER, ITSO.MMPARTS.NAME, ITSO.MMPARTS.DESCRIPTION, ITSO.MMPARTS.IMAGE_URL, ITSO.MMINVENTORY.ITEMNUMBER, ITSO.MMINVENTORY.QUANTITY, ITSO.MMINVENTORY.COST, ITSO.MMINVENTORY.SHELF, ITSO.MMINVENTORY.LOCATION FROM ITSO.MMINVENTORY, ITSO.MMPARTS WHERE ITSO.MMINVENTORY.PARTNUMBER = ITSO.MMPARTS.PARTNUMBER AND ITSO.MMINVENTORY.QUANTITY < :quantity AND ITSO.MMPARTS.PARTNUMBER = :ITSO_MMPARTS_PARTNUMBER3 AND ITSO.MMINVENTORY.ITEMNUMBER = :ITSO_MMINVENTORY_ITEMNUMBER3 ORDER BY ITSO.MMPARTS.PARTNUMBER ASC";	 
   protected static final String PARAM1_NAME = "quantity1"; 
   protected static final String PARAM2_NAME = "ITSO_MMPARTS_PARTNUMBER3"; 
   protected static final String PARAM3_NAME = "ITSO_MMINVENTORY_ITEMNUMBER3";
   
   protected static final String Inventory_ITSO_MMPARTS_PARTNUMBER4_LABEL = "ITSO_MMPARTS_PARTNUMBER4";
   protected static final String Inventory_ITSO_MMPARTS_NAME4_LABEL = "ITSO_MMPARTS_NAME4";
   protected static final String Inventory_ITSO_MMPARTS_DESCRIPTION4_LABEL = "ITSO_MMPARTS_DESCRIPTION4";
   protected static final String Inventory_ITSO_MMPARTS_IMAGE_URL4_LABEL = "ITSO_MMPARTS_IMAGE_URL4";
   protected static final String Inventory_ITSO_MMINVENTORY_ITEMNUMBER4_LABEL = "ITSO_MMINVENTORY_ITEMNUMBER4";
   protected static final String Inventory_ITSO_MMINVENTORY_QUANTITY4_LABEL = "ITSO_MMINVENTORY_QUANTITY4";
   protected static final String Inventory_ITSO_MMINVENTORY_COST4_LABEL = "ITSO_MMINVENTORY_COST4";
   protected static final String Inventory_ITSO_MMINVENTORY_SHELF4_LABEL = "ITSO_MMINVENTORY_SHELF4";
   protected static final String Inventory_ITSO_MMINVENTORY_LOCATION4_LABEL = "ITSO_MMINVENTORY_LOCATION4";
   
   /*****************************************************************
   * Initialize the connectionSpec
   */
   protected void initConnectionSpec() throws SQLException {
      connectionSpec = new DBConnectionSpec();
      connectionSpec.setUsername(getUsername());
      connectionSpec.setPassword(getPassword());
      connectionSpec.setDataSourceName(getDataSourceName());
   }

   /*****************************************************************
   * Execute the database query
   */
   public void execute() throws SQLException {
      getDBSelect().execute();
   }
 
   /****************************************************************
   *prepare the sql statement for execution
   **/
   protected void prepareStatement() throws SQLException {
      // Set SQL statement.
      getDBSelect().setCommand(SQL_STRING);

      DBSelectMetaData resultMetaData = getDBSelect().getMetaData();

      // Assign labels to columns.  
      resultMetaData.setColumnLabel(1, Inventory_ITSO_MMPARTS_PARTNUMBER4_LABEL);
      resultMetaData.setColumnLabel(2, Inventory_ITSO_MMPARTS_NAME4_LABEL);
      resultMetaData.setColumnLabel(3, Inventory_ITSO_MMPARTS_DESCRIPTION4_LABEL);
      resultMetaData.setColumnLabel(4, Inventory_ITSO_MMPARTS_IMAGE_URL4_LABEL);
      resultMetaData.setColumnLabel(5, Inventory_ITSO_MMINVENTORY_ITEMNUMBER4_LABEL);
      resultMetaData.setColumnLabel(6, Inventory_ITSO_MMINVENTORY_QUANTITY4_LABEL);
      resultMetaData.setColumnLabel(7, Inventory_ITSO_MMINVENTORY_COST4_LABEL);
      resultMetaData.setColumnLabel(8, Inventory_ITSO_MMINVENTORY_SHELF4_LABEL);
      resultMetaData.setColumnLabel(9, Inventory_ITSO_MMINVENTORY_LOCATION4_LABEL);
      
      //Add parameters descriptions to meta data.
      DBParameterMetaData metaData = getDBSelect().getParameterMetaData(); 
      metaData.setParameter(1, PARAM1_NAME, 
                            DatabaseMetaData.procedureColumnIn, 
                            java.sql.Types.LONGVARCHAR, 
                            java.lang.String.class);  
      metaData.setParameter(2, PARAM2_NAME, 
                            DatabaseMetaData.procedureColumnIn, 
                            java.sql.Types.LONGVARCHAR, 
                            java.lang.String.class); 
      metaData.setParameter(3, PARAM3_NAME, 
                            DatabaseMetaData.procedureColumnIn, 
                            java.sql.Types.LONGVARCHAR, 
                            java.lang.String.class);
           
      // Set parameters.  
      getDBSelect().setParameter(PARAM1_NAME, inquantity1); 
      getDBSelect().setParameter(PARAM2_NAME, inITSO_MMPARTS_PARTNUMBER3); 
      getDBSelect().setParameter(PARAM3_NAME, inITSO_MMINVENTORY_ITEMNUMBER3);	
   }
      
   /*************************************************************
   * Closes Result Set
   */
   public void close() throws DBException, SQLException {
      getDBSelect().close();
      detailsViewDBBean = null;
   }

   /**************************************************************
   *Moves to the next row of the result set if it exsits
   *@return true if there is another row of data
   */
   public boolean next() throws DBException, SQLException {
      return getDBSelect().next();
   }

   /**************************************************************
   *Moves to the first row of the result set if it exsits
   *@return true if there is a first row of data
   */
   public boolean first() throws DBException, SQLException {
      return getDBSelect().first();
   }

   /*************************************************************
   * Formats code so that is HTML Firendly
   * @param in The incoming String
   * @return The formated String
   */
   protected String massageOutput(Object in) {
      Object out = in;
      //Place code here to format your output
      return (out != null) ? out.toString() : "";
   }
      
   //Setters 
   /**************************************************************
   * Set quantity1
   * @param quantity1
   */
   public void setquantity1(String quantity1) {
      inquantity1 = quantity1;
   }

   /**************************************************************
   * Set ITSO_MMPARTS_PARTNUMBER3
   * @param ITSO_MMPARTS_PARTNUMBER3
   */
   public void setITSO_MMPARTS_PARTNUMBER3(String ITSO_MMPARTS_PARTNUMBER3) {
      inITSO_MMPARTS_PARTNUMBER3 = ITSO_MMPARTS_PARTNUMBER3;
   }

   /**************************************************************
   * Set ITSO_MMINVENTORY_ITEMNUMBER3
   * @param ITSO_MMINVENTORY_ITEMNUMBER3
   */
   public void setITSO_MMINVENTORY_ITEMNUMBER3(String ITSO_MMINVENTORY_ITEMNUMBER3) {
      inITSO_MMINVENTORY_ITEMNUMBER3 = ITSO_MMINVENTORY_ITEMNUMBER3;
   }

   /**************************************************************
   * Set the database username
   */
   public void setUsername(String username){
      dvUsername = username;
   }
   
   /**************************************************************
    * Set the database password
    */
   public void setPassword(String password){
      dvPassword = password;
   }
   
   /**************************************************************
    * Set the database data source name
    */
   public void setDataSourceName(String dataSourceName){
      dvDataSourceName = dataSourceName;
   }

   //Getters
   /**************************************************************
   * Get the result set
   * @return The DBSelect Object
   */
   protected DBSelect getDBSelect() throws DBException, SQLException {
      if (detailsViewDBBean == null) {
         // Create selection bean
         detailsViewDBBean = new DBSelect();
         if (connectionSpec == null){
            initConnectionSpec();
         }
         detailsViewDBBean.setConnectionSpec(connectionSpec);

         // The following option turns off the firing of events, and
         // causes all values to be fetched from the db with getString.
         detailsViewDBBean.setOptimizeForJsp(true);
         prepareStatement();
      }
      return detailsViewDBBean;
   }

   /**************************************************************
   * Get ITSO_MMPARTS_PARTNUMBER4
   * @return return column ITSO.MMPARTS.PARTNUMBER
   */
   public String getITSO_MMPARTS_PARTNUMBER4() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMPARTS_PARTNUMBER4_LABEL);
      return massageOutput(ret);
   }

   /**************************************************************
   * Get ITSO_MMPARTS_NAME4
   * @return return column ITSO.MMPARTS.NAME
   */
   public String getITSO_MMPARTS_NAME4() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMPARTS_NAME4_LABEL);
      return massageOutput(ret);
   }

   /**************************************************************
   * Get ITSO_MMPARTS_DESCRIPTION4
   * @return return column ITSO.MMPARTS.DESCRIPTION
   */
   public String getITSO_MMPARTS_DESCRIPTION4() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMPARTS_DESCRIPTION4_LABEL);
      return massageOutput(ret);
   }

   /**************************************************************
   * Get ITSO_MMPARTS_IMAGE_URL4
   * @return return column ITSO.MMPARTS.IMAGE_URL
   */
   public String getITSO_MMPARTS_IMAGE_URL4() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMPARTS_IMAGE_URL4_LABEL);
      return massageOutput(ret);
   }

   /**************************************************************
   * Get ITSO_MMINVENTORY_ITEMNUMBER4
   * @return return column ITSO.MMINVENTORY.ITEMNUMBER
   */
   public String getITSO_MMINVENTORY_ITEMNUMBER4() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMINVENTORY_ITEMNUMBER4_LABEL);
      return massageOutput(ret);
   }

   /**************************************************************
   * Get ITSO_MMINVENTORY_QUANTITY4
   * @return return column ITSO.MMINVENTORY.QUANTITY
   */
   public String getITSO_MMINVENTORY_QUANTITY4() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMINVENTORY_QUANTITY4_LABEL);
      return massageOutput(ret);
   }

   /**************************************************************
   * Get ITSO_MMINVENTORY_COST4
   * @return return column ITSO.MMINVENTORY.COST
   */
   public String getITSO_MMINVENTORY_COST4() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMINVENTORY_COST4_LABEL);
      return massageOutput(ret);
   }

   /**************************************************************
   * Get ITSO_MMINVENTORY_SHELF4
   * @return return column ITSO.MMINVENTORY.SHELF
   */
   public String getITSO_MMINVENTORY_SHELF4() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMINVENTORY_SHELF4_LABEL);
      return massageOutput(ret);
   }

   /**************************************************************
   * Get ITSO_MMINVENTORY_LOCATION4
   * @return return column ITSO.MMINVENTORY.LOCATION
   */
   public String getITSO_MMINVENTORY_LOCATION4() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMINVENTORY_LOCATION4_LABEL);
      return massageOutput(ret);
   }

   /**************************************************************
   * Get the database username
   * @return String database username
   */
   public String getUsername(){
      return dvUsername;
   }
   
   /**************************************************************
    * Get the database password
    * @return String database password
    */
   public String getPassword(){
      return dvPassword;
   }
   
   /**************************************************************
    * Get the database data source name
    * @return String database data source name
    */
   public String getDataSourceName(){
      return dvDataSourceName;
   }
}

