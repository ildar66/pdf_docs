
package itso.wsad.dealer.dbapp;
/**************************************************************
*Description - Inventory Master View Bean
* 
* An HTML View Bean wrappers your data so that you can capture the 
* output and make it HTML friendly
*/
 
// Imports
import java.io.*;
import com.ibm.db.beans.*;
import java.sql.Types;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

public class InventoryMasterViewBean {
   // ConnectionSpec
   protected static DBConnectionSpec connectionSpec = null;

   //Variables
   protected DBSelect masterViewDBBean = null;

   protected String mvUsername = "";
   protected String mvPassword = "";
   protected String mvDataSourceName = "";
  
   protected String inquantity1;

   //Constants
   protected static final String SQL_STRING = "SELECT ITSO.MMPARTS.PARTNUMBER, ITSO.MMPARTS.NAME, ITSO.MMPARTS.DESCRIPTION, ITSO.MMPARTS.IMAGE_URL, ITSO.MMINVENTORY.ITEMNUMBER, ITSO.MMINVENTORY.QUANTITY, ITSO.MMINVENTORY.COST, ITSO.MMINVENTORY.SHELF, ITSO.MMINVENTORY.LOCATION FROM ITSO.MMINVENTORY, ITSO.MMPARTS WHERE ITSO.MMINVENTORY.PARTNUMBER = ITSO.MMPARTS.PARTNUMBER AND ITSO.MMINVENTORY.QUANTITY < :quantity ORDER BY ITSO.MMPARTS.PARTNUMBER ASC";	 
   protected static final String PARAM1_NAME = "quantity1";
   protected static final String Inventory_ITSO_MMPARTS_PARTNUMBER3_LABEL = "ITSO_MMPARTS_PARTNUMBER3";
   protected static final String Inventory_ITSO_MMPARTS_NAME3_LABEL = "ITSO_MMPARTS_NAME3";
   protected static final String Inventory_ITSO_MMPARTS_DESCRIPTION3_LABEL = "ITSO_MMPARTS_DESCRIPTION3";
   protected static final String Inventory_ITSO_MMPARTS_IMAGE_URL3_LABEL = "ITSO_MMPARTS_IMAGE_URL3";
   protected static final String Inventory_ITSO_MMINVENTORY_ITEMNUMBER3_LABEL = "ITSO_MMINVENTORY_ITEMNUMBER3";
   protected static final String Inventory_ITSO_MMINVENTORY_QUANTITY3_LABEL = "ITSO_MMINVENTORY_QUANTITY3";
   protected static final String Inventory_ITSO_MMINVENTORY_COST3_LABEL = "ITSO_MMINVENTORY_COST3";
   protected static final String Inventory_ITSO_MMINVENTORY_SHELF3_LABEL = "ITSO_MMINVENTORY_SHELF3";
   protected static final String Inventory_ITSO_MMINVENTORY_LOCATION3_LABEL = "ITSO_MMINVENTORY_LOCATION3";
  
   /*****************************************************************
   * Initialize the connectionSpec
   */
   protected void initConnectionSpec() throws SQLException {
      connectionSpec = new DBConnectionSpec();
      connectionSpec.setUsername(getUsername());
      connectionSpec.setPassword(getPassword());
      connectionSpec.setDataSourceName(getDataSourceName());
   }
 
   /*****************************************************************
   * Execute the database query
   */
   public void execute() throws SQLException {
      getDBSelect().execute();
   }
 
   /****************************************************************
   *prepare the sql statement for execution
   **/
   protected void prepareStatement() throws SQLException {
      // Set SQL statement.
      getDBSelect().setCommand(SQL_STRING);

      DBSelectMetaData resultMetaData = getDBSelect().getMetaData();

      // Assign labels to columns.  
      resultMetaData.setColumnLabel(1, Inventory_ITSO_MMPARTS_PARTNUMBER3_LABEL);
      resultMetaData.setColumnLabel(2, Inventory_ITSO_MMPARTS_NAME3_LABEL);
      resultMetaData.setColumnLabel(3, Inventory_ITSO_MMPARTS_DESCRIPTION3_LABEL);
      resultMetaData.setColumnLabel(4, Inventory_ITSO_MMPARTS_IMAGE_URL3_LABEL);
      resultMetaData.setColumnLabel(5, Inventory_ITSO_MMINVENTORY_ITEMNUMBER3_LABEL);
      resultMetaData.setColumnLabel(6, Inventory_ITSO_MMINVENTORY_QUANTITY3_LABEL);
      resultMetaData.setColumnLabel(7, Inventory_ITSO_MMINVENTORY_COST3_LABEL);
      resultMetaData.setColumnLabel(8, Inventory_ITSO_MMINVENTORY_SHELF3_LABEL);
      resultMetaData.setColumnLabel(9, Inventory_ITSO_MMINVENTORY_LOCATION3_LABEL);
      
      //Add parameters descriptions to meta data.
      DBParameterMetaData metaData = getDBSelect().getParameterMetaData(); 
      metaData.setParameter(1, PARAM1_NAME, 
                            DatabaseMetaData.procedureColumnIn, 
                            java.sql.Types.LONGVARCHAR, 
                            java.lang.String.class); 
           
      // Set parameters.  
      getDBSelect().setParameter(PARAM1_NAME, 
                            inquantity1); 
   }
      
   /*************************************************************
   * Closes Result Set
   */
   public void close() throws DBException, SQLException {
      getDBSelect().close();
      masterViewDBBean = null;
   }

   /**************************************************************
   *Moves to the next row of the result set if it exsits
   *@return true if there is another row of data
   */
   public boolean next() throws DBException, SQLException {
      return getDBSelect().next();
   }

   /**************************************************************
   *Moves to the first row of the result set if it exsits
   *@return true if there is a first row of data
   */
   public boolean first() throws DBException, SQLException {
      return getDBSelect().first();
   }

   /*************************************************************
   * Formats code so that is HTML Firendly
   * @param in The incoming String
   * @return The formated String
   */
   protected String massageOutput(Object in) {
      Object out = in;
      //Place code here to format your output
      return (out != null) ? out.toString() : "";
   }
      
   //Setters 
   /**************************************************************
   * Set quantity1
   * @param quantity1
   */
   public void setquantity1(String quantity1) {
      inquantity1 = quantity1;
   }
   /**************************************************************
   * Set the database username
   */
   public void setUsername(String username){
      mvUsername = username;
   }
   
   /**************************************************************
    * Set the database password
    */
   public void setPassword(String password){
      mvPassword = password;
   }
   
   /**************************************************************
    * Set the database data source name
    */
   public void setDataSourceName(String dataSourceName){
      mvDataSourceName = dataSourceName;
   }

   //Getters
   /**************************************************************
   * Get the result set
   * @return The DBSelect Object
   */
   protected DBSelect getDBSelect() throws DBException, SQLException {
      if (masterViewDBBean == null) {
         // Create selection bean
         masterViewDBBean = new DBSelect();
         if (connectionSpec == null){
            initConnectionSpec();
         }
         masterViewDBBean.setConnectionSpec(connectionSpec);
         
         // The following option turns off the firing of events, and
         // causes all values to be fetched from the db with getString.
         masterViewDBBean.setOptimizeForJsp(true);
         prepareStatement();
      }
      return masterViewDBBean;
   }

   /**************************************************************
   * Get ITSO_MMPARTS_PARTNUMBER3
   * @return return column ITSO.MMPARTS.PARTNUMBER
   */
   public String getITSO_MMPARTS_PARTNUMBER3() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMPARTS_PARTNUMBER3_LABEL);
      return massageOutput(ret);
   }
   /**************************************************************
   * Get ITSO_MMPARTS_NAME3
   * @return return column ITSO.MMPARTS.NAME
   */
   public String getITSO_MMPARTS_NAME3() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMPARTS_NAME3_LABEL);
      return massageOutput(ret);
   }
   /**************************************************************
   * Get ITSO_MMPARTS_DESCRIPTION3
   * @return return column ITSO.MMPARTS.DESCRIPTION
   */
   public String getITSO_MMPARTS_DESCRIPTION3() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMPARTS_DESCRIPTION3_LABEL);
      return massageOutput(ret);
   }
   /**************************************************************
   * Get ITSO_MMPARTS_IMAGE_URL3
   * @return return column ITSO.MMPARTS.IMAGE_URL
   */
   public String getITSO_MMPARTS_IMAGE_URL3() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMPARTS_IMAGE_URL3_LABEL);
      return massageOutput(ret);
   }
   /**************************************************************
   * Get ITSO_MMINVENTORY_ITEMNUMBER3
   * @return return column ITSO.MMINVENTORY.ITEMNUMBER
   */
   public String getITSO_MMINVENTORY_ITEMNUMBER3() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMINVENTORY_ITEMNUMBER3_LABEL);
      return massageOutput(ret);
   }
   /**************************************************************
   * Get ITSO_MMINVENTORY_QUANTITY3
   * @return return column ITSO.MMINVENTORY.QUANTITY
   */
   public String getITSO_MMINVENTORY_QUANTITY3() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMINVENTORY_QUANTITY3_LABEL);
      return massageOutput(ret);
   }
   /**************************************************************
   * Get ITSO_MMINVENTORY_COST3
   * @return return column ITSO.MMINVENTORY.COST
   */
   public String getITSO_MMINVENTORY_COST3() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMINVENTORY_COST3_LABEL);
      return massageOutput(ret);
   }
   /**************************************************************
   * Get ITSO_MMINVENTORY_SHELF3
   * @return return column ITSO.MMINVENTORY.SHELF
   */
   public String getITSO_MMINVENTORY_SHELF3() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMINVENTORY_SHELF3_LABEL);
      return massageOutput(ret);
   }
   /**************************************************************
   * Get ITSO_MMINVENTORY_LOCATION3
   * @return return column ITSO.MMINVENTORY.LOCATION
   */
   public String getITSO_MMINVENTORY_LOCATION3() throws DBException, SQLException {
      Object ret = getDBSelect().getColumn(Inventory_ITSO_MMINVENTORY_LOCATION3_LABEL);
      return massageOutput(ret);
   }
   /**************************************************************
   * Get the database username
   * @return String database username
   */
   public String getUsername(){
      return mvUsername;
   }
   
   /**************************************************************
    * Get the database password
    * @return String database password
    */
   public String getPassword(){
      return mvPassword;
   }
   
   /**************************************************************
    * Get the database data source name
    * @return String database data source name
    */
   public String getDataSourceName(){
      return mvDataSourceName;
   }
}

 

 

