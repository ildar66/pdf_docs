package itso.wsad.dealer.ejbweb;

import itso.wsad.dealer.ejb.*;
import itso.wsad.dealer.session.*;
import java.io.PrintWriter;
import javax.ejb.EJBException;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class InventoryControl extends HttpServlet {


	private InventoryHome   inventoryHome;
	private StockUpdateHome stockUpdateHome;


	public void init() throws javax.servlet.ServletException {
		try {
			InitialContext initCtx = new InitialContext();
			Object objref = initCtx.lookup("itso/wsad/dealer/Inventory");
			//Object objref = initCtx.lookup("java:comp/env/ejb/Inventory");
			inventoryHome   = (InventoryHome)PortableRemoteObject.narrow(objref,InventoryHome.class);
			objref = initCtx.lookup("itso/wsad/dealer/StockUpdate");
			//objref = initCtx.lookup("java:comp/env/ejb/StockUpdate");
			stockUpdateHome = (StockUpdateHome)PortableRemoteObject.narrow(objref,StockUpdateHome.class);
		} catch (NamingException ex) {
			ex.printStackTrace();
			throw new EJBException("Error looking up Inventory/StockUpdateHome: "+ex.getMessage());
		}
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		doGet(request,response);
	}


	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		try {
			String retrieveBut = request.getParameter("retrieve");
			if (retrieveBut != null) processEntity(request, response);
			else processSession(request, response);	
		} catch (Throwable ex) {
			ex.printStackTrace();
			throw new EJBException("Error in doGet: "+ex.getMessage());
		}
	}


	public void processEntity(HttpServletRequest request, HttpServletResponse response) {
		try {
			PrintWriter out = response.getWriter();
			out.println("<html><body><h1>Inventory Control Servlet</h1>");
			String stockitem   = request.getParameter("stockitem");
			Inventory inv = inventoryHome.findByPrimaryKey( new Long(stockitem) );
			out.println("<h2> Inventory item: "+stockitem+"</h2>");
			out.println("<p>Part number: "+inv.getPartNumber()); 
			out.println("<p>Quantity: "   +inv.getQuantity()); 
			out.println("<p>Cost: "       +inv.getCost().toString()); 
			out.println("<p>Shelf: "      +inv.getShelf()); 
			out.println("<p>Location: "   +inv.getLocation());
			out.println("</body></html>"); 
 		} catch (Throwable ex) {
			ex.printStackTrace();
			throw new EJBException("Error in retrieve inventory: "+ex.getMessage());
		}
	}


	public void processSession(HttpServletRequest request, HttpServletResponse response) {
		try {
			PrintWriter out = response.getWriter();
			out.println("<html><body><h1>Inventory Control Servlet</h1>");
			String stockitem1s  = request.getParameter("stockitem1");
			long stockitem1 =  (new Long(stockitem1s)).longValue();
			String stockitem2s  = request.getParameter("stockitem2");
			long stockitem2 = 0;
			if (!stockitem2s.equals("")) stockitem2 =  (new Long(stockitem2s)).longValue();
			String quantity    = request.getParameter("quantity");
			String addBut      = request.getParameter("add");
			String removeBut   = request.getParameter("remove");
			String moveBut     = request.getParameter("move");
			out.println("<h2> Inventory item: "+stockitem1+"</h2>");
			int quant = (new Integer(quantity)).intValue();
			StockUpdate su = stockUpdateHome.create();
			if (addBut != null) {
				int stock = su.addStock(stockitem1, quant);
				out.println("<p> New stock quantity: "+stock);
			}
			if (removeBut != null) {
				int stock = su.removeStock(stockitem1, quant);
				out.println("<p> New stock quantity: "+stock);
			}
			if (moveBut != null) {
				su.moveStock(stockitem1,stockitem2, quant);
				int stock1 = su.addStock(stockitem1, 0); 
				int stock2 = su.addStock(stockitem2, 0); 
				out.println("<p> Moved quantity "+quant+" to item "+stockitem2);
				out.println("<p> New quantities are: "+stock1+" and "+stock2);
			}
			out.println("</body></html>"); 
		} catch (Throwable ex) {
			ex.printStackTrace();
			throw new EJBException("Error in process session: "+ex.getMessage());
		}
	}
}
