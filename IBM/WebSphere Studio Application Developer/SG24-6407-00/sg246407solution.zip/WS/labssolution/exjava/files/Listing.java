package itso.wsad.dealer.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Listing {

	// database table
	static String dbtab = "aaparts";
	
	public static void main(String[] args) {
	System.out.println("Parts Listing for "+dbtab);
	
	// connect to database
	Connection con = null;
	con = connect();
	
	// retrieve parts
	Statement stmt = null;
	ResultSet rs   = null;
	String select = "SELECT * FROM itso."+dbtab;
	try {
		stmt = con.createStatement();
		rs = stmt.executeQuery(select);
		while (rs.next()) {
			String partnum = rs.getString("partNumber");
			String name    = rs.getString("name");
			String descript= rs.getString("description");
			double weight  = rs.getDouble("weight");
			String url     = rs.getString("image_url");
			System.out.println(partnum+" "+name+" "+descript+" "+url+" "+weight);
		}
		System.out.println("End of Listing");
		stmt.close();
		con.close();
	} catch(Exception e) {
		System.err.print("Exception: "); 
		System.err.println(e.getMessage());
	}	
	}
	protected static Connection connect() {
		Connection con = null;
		try {
			Class.forName("COM.ibm.db2.jdbc.app.DB2Driver").newInstance();
			con = DriverManager.getConnection("jdbc:db2:itsowsad"); 
		} catch(Exception e) {
			System.err.print("Exception: "); 
			System.err.println(e.getMessage());
		}
		return con;
	}
}

